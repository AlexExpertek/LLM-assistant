from app.sources.kontur_zakupki.adapter import KonturZakupkiAdapter
from app.sources.resolver import resolve_source_by_url


class FakeKonturClient:
    def search_all(self, payload, **kwargs):
        return self.search(payload)["items"]

    def search(self, payload):
        return {
            "items": [
                {"id": "IS123", "title": "Поставка алюминиевого листа"},
                {"id": "IS999", "title": "Поставка бумаги"},
            ]
        }

    def get_purchase(self, purchase_id):
        if purchase_id == "IS123":
            return {
                "id": "IS123",
                "title": "Поставка алюминиевого листа АМг2",
                "description": "Лист АМг2 2х1500х3000",
                "customer": {"name": "АО Заказчик", "inn": "7700000000"},
                "lawType": "223-ФЗ",
                "maxPrice": 1234567.89,
                "currency": "RUB",
                "publishDate": "2026-08-10T10:00:00",
                "submissionDeadline": "2026-08-20T12:00:00",
                "documents": [
                    {"id": "d1", "name": "Техническое задание.pdf", "url": "https://files.example/tz.pdf"}
                ],
            }
        return {"id": purchase_id, "title": "Поставка бумаги"}

    def get_documents(self, purchase_id):
        return None


def test_kontur_search_maps_to_canonical_contract(monkeypatch):
    import app.sources.kontur_zakupki.adapter as module
    monkeypatch.setattr(module, "should_check", lambda *a: (True, "test"))
    monkeypatch.setattr(module, "save_result", lambda *a, **kw: None)
    from app.core.config import settings
    monkeypatch.setattr(settings, "kontur_filter_aluminium", True)
    monkeypatch.setattr(settings, "kontur_fetch_details", True)
    monkeypatch.setattr(settings, "kontur_fetch_documents", True)
    monkeypatch.setattr(settings, "kontur_search_payload", {})
    monkeypatch.setattr(settings, "kontur_search_query", "алюминий")
    monkeypatch.setattr(settings, "kontur_search_query_field", "query")
    monkeypatch.setattr(settings, "kontur_max_rows", 100)
    monkeypatch.setattr(settings, "kontur_limit_field", "limit")

    adapter = KonturZakupkiAdapter(client=FakeKonturClient())
    rows = adapter.search()

    assert len(rows) == 1
    tender = rows[0]
    assert tender.source == "kontur_zakupki"
    assert tender.external_id == "IS123"
    assert tender.customer_inn == "7700000000"
    assert tender.law_type == "223-FZ"
    assert str(tender.amount) == "1234567.89"
    assert tender.documents[0].name == "Техническое задание.pdf"


def test_kontur_fetch_by_url():
    adapter = KonturZakupkiAdapter(client=FakeKonturClient())
    tender = adapter.fetch_by_url("https://zakupki.kontur.ru/IS123")
    assert tender is not None
    assert tender.external_id == "IS123"


def test_resolver_detects_kontur():
    assert resolve_source_by_url("https://zakupki.kontur.ru/IS123") == "kontur_zakupki"
