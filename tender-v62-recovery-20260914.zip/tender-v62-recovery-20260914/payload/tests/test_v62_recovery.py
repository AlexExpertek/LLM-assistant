import asyncio
from datetime import datetime, timedelta, timezone
from unittest.mock import Mock

import httpx
import pytest

from app.core.config import settings
from app.sources.schemas import SourceTender
from app.marketplace_discovery.b2b_center import B2BCenterDiscoveryClient, _parse_datetime
from app.marketplace_discovery.schemas import MarketplaceTender
from app.marketplace_discovery import runner
from app.marketplace_discovery.business_filter import evaluate_business_rules
from app.marketplace_discovery.review_store import list_review_candidates
from app.workers import tasks_parsing
from app.sources.kontur_zakupki.client import KonturAccessError, KonturZakupkiClient


def tender(text="алюминиевый профиль АД31 600 кг", number="100"):
    return MarketplaceTender(platform="b2b_center", external_id=number, title="Поставка " + text,
                             raw_text=text, deadline=datetime.now(timezone.utc) + timedelta(days=2))


@pytest.fixture
def isolated_storage(monkeypatch, tmp_path):
    monkeypatch.setattr(settings, "storage_path", str(tmp_path))
    return tmp_path


def setup_runner(monkeypatch, items):
    adapter = Mock(platform_code="b2b_center")
    adapter.search.return_value = items
    monkeypatch.setattr(runner, "get_marketplaces", lambda: [adapter])
    monkeypatch.setattr(runner, "DISCOVERY_QUERIES", ["алюминий"])
    ingest = Mock(return_value={"status": "ingested_only"})
    monkeypatch.setattr(runner.process_new_tender, "run", ingest)
    return adapter, ingest


def test_daily_schedule():
    from app.workers.celery_app import celery_app
    schedule = celery_app.conf.beat_schedule
    assert schedule["monitor-eis-daily"]["args"] == ("zakupki_gov_ru",)
    assert schedule["monitor-eis-daily"]["schedule"].hour == {3}
    assert schedule["marketplace-scout-daily"]["schedule"].hour == {2}


def test_numeric_alloy_is_text_query(monkeypatch):
    urls = []
    def handler(request):
        urls.append(request.url)
        return httpx.Response(200, text="Ничего не найдено")
    factory = httpx.Client
    monkeypatch.setattr(httpx, "Client", lambda **kw: factory(transport=httpx.MockTransport(handler), **kw))
    assert B2BCenterDiscoveryClient().search("5083") == []
    assert urls[0].params["f_keyword"] == "алюминий 5083"
    assert urls[0].params["trade"] == "buy"


@pytest.mark.parametrize("page", ["<html>Login</html>", "<html>g-recaptcha</html>"])
def test_unknown_or_blocked_html_not_empty_success(page):
    with pytest.raises(RuntimeError):
        B2BCenterDiscoveryClient()._parse(page, query="алюминий")


def test_parse_realistic_table_row():
    page = '''<table><tr><td><a class="search-results-title" href="/market/test/tender-12345/">Поставка алюминиевого профиля АД31 600 кг</a></td><td>Завод</td><td>14.09.2026 09:00</td><td>30.09.2026 12:00</td></tr></table>'''
    rows = B2BCenterDiscoveryClient()._parse(page, query="профиль")
    assert len(rows) == 1
    assert rows[0].external_id == "12345"
    assert rows[0].deadline.utcoffset() == timedelta(hours=3)


def test_candidates_persist_but_do_not_enter_qualified_pipeline(monkeypatch, isolated_storage):
    _, ingest = setup_runner(monkeypatch, [tender("алюминиевый профиль АД31")])
    result = runner.run_marketplace_discovery()["b2b_center"]
    assert result["candidates_saved"] == 1
    assert result["persisted"] == 0
    ingest.assert_not_called()
    assert len(list_review_candidates()) == 1
    runner.run_marketplace_discovery()
    assert len(list_review_candidates()) == 1  # deterministic id, no duplication


def test_qualified_positions_reach_report_contract(monkeypatch, isolated_storage):
    _, ingest = setup_runner(monkeypatch, [tender()])
    result = runner.run_marketplace_discovery()["b2b_center"]
    assert result["persisted"] == 1
    data = ingest.call_args.args[0]
    assert data["raw_payload"]["positions"][0]["quantity"] == 600
    assert data["raw_payload"]["positions"][0]["unit"] == "кг"
    from app.reports.dashboard_eligibility import evaluate_dashboard_tender
    assert evaluate_dashboard_tender({"positions": data["raw_payload"]["positions"]}).eligible
    assert ingest.call_args.kwargs == {"launch_pipeline": False}


def test_small_positions_never_summed():
    from app.reports.dashboard_eligibility import evaluate_dashboard_tender
    assert not evaluate_dashboard_tender({"positions": [
        {"name": "Алюминиевый профиль АД31", "quantity": 300, "unit": "кг"},
        {"name": "Алюминиевый профиль АД31", "quantity": 300, "unit": "кг"},
    ]}).eligible


def test_same_day_expired_not_ingested(monkeypatch, isolated_storage):
    item = tender()
    item.deadline = datetime.now(timezone.utc) - timedelta(minutes=1)
    _, ingest = setup_runner(monkeypatch, [item])
    assert runner.run_marketplace_discovery()["b2b_center"]["expired"] == 1
    ingest.assert_not_called()


def test_search_failure_not_reported_ok(monkeypatch, isolated_storage):
    adapter, _ = setup_runner(monkeypatch, [])
    adapter.search.side_effect = TimeoutError("network")
    assert runner.run_marketplace_discovery()["b2b_center"]["status"] == "error"


def test_unknown_platform_rejected():
    with pytest.raises(ValueError, match="Unknown marketplace"):
        runner.run_marketplace_discovery(platforms=["missing_adapter"])
    assert runner.run_marketplace_discovery(platforms=[]) == {}


def test_position_change_invalidates_hash():
    first = SourceTender(source="b2b_center", external_id="1", title="Профиль", raw_payload={"positions": [{"quantity": 600}]})
    second = first.model_copy(update={"raw_payload": {"positions": [{"quantity": 700}]}})
    assert tasks_parsing.compute_source_hash(first) != tasks_parsing.compute_source_hash(second)


def test_aware_deadline_normalizes_to_utc():
    assert tasks_parsing._dt("2026-09-14T12:00:00+03:00") == datetime(2026, 9, 14, 9)
    assert tasks_parsing._dt(_parse_datetime("14.09.2026 12:00")) == datetime(2026, 9, 14, 9)


def test_kontur_403_does_not_retry(monkeypatch, isolated_storage):
    monkeypatch.setattr(settings, "kontur_api_base_url", "https://example.test")
    monkeypatch.setattr(settings, "kontur_api_key", "test")
    monkeypatch.setattr(settings, "kontur_api_key_header", "X-Key")
    calls = []
    def handler(request):
        calls.append(request)
        return httpx.Response(403, text='{"title":"Invalid subscription period"}')
    factory = httpx.Client
    monkeypatch.setattr(httpx, "Client", lambda **kw: factory(transport=httpx.MockTransport(handler), **kw))
    with pytest.raises(KonturAccessError):
        KonturZakupkiClient()._request("GET", "/search")
    assert len(calls) == 1
    adapter = Mock()
    adapter.search.side_effect = KonturAccessError("403")
    monkeypatch.setattr(tasks_parsing, "get_adapter", lambda _: adapter)
    retry = Mock(side_effect=AssertionError("must not retry"))
    monkeypatch.setattr(tasks_parsing.monitor_source, "retry", retry)
    assert tasks_parsing.monitor_source.run("kontur_zakupki")["status"] == "blocked"
    retry.assert_not_called()


def test_monitor_counts_queued_not_new(monkeypatch, isolated_storage):
    adapter = Mock()
    adapter.search.return_value = [SourceTender(source="tender_pro", external_id="1", title="Профиль")]
    monkeypatch.setattr(tasks_parsing, "get_adapter", lambda _: adapter)
    monkeypatch.setattr(tasks_parsing.process_new_tender, "delay", Mock())
    result = tasks_parsing.monitor_source.run("tender_pro")
    assert result["queued_count"] == 1 and "new_tenders" not in result


def test_llm_total_deadline_and_no_inner_retry(monkeypatch):
    from app.llm.router import ModelRouter, TaskType
    router = ModelRouter()
    monkeypatch.setattr(settings, "default_llm_provider", "yandex")
    monkeypatch.setattr(settings, "llm_total_timeout_seconds", 0.01)
    calls = []
    async def stalled(*args):
        calls.append(1)
        await asyncio.sleep(10)
    monkeypatch.setattr(router, "_call_yandex", stalled)
    with pytest.raises(TimeoutError):
        asyncio.run(router.complete(TaskType.EXTRACT_FIELDS, "system", "text"))
    assert len(calls) == 1


def test_confidential_cannot_be_forced_abroad():
    from app.llm.router import ModelRouter, TaskType
    assert ModelRouter()._resolve_route(TaskType.CONFIDENTIAL, "anthropic")[0] == "yandex"


def test_five_requested_seeds_present_and_unavailable_retained(monkeypatch):
    from app.marketplace_discovery.scout.runner import DEFAULT_SEEDS
    from app.marketplace_discovery.scout import web_scout
    for domain in ("etpgpb.ru", "zakupki.rosatom.ru", "etp.metal-it.ru", "tektorg.ru", "etp.acron.ru"):
        assert any(domain in url for url in DEFAULT_SEEDS)
    monkeypatch.setattr(web_scout, "_probe", lambda _: None)
    candidates = web_scout.scout_urls(["https://etp.acron.ru/app"])
    assert len(candidates) == 1 and candidates[0].integration_score == 0
    assert candidates[0].reasons[0].startswith("probe_failed:")


@pytest.mark.parametrize("supported", [True, False])
def test_eis_search_persists_then_fetches_detail(monkeypatch, supported):
    from unittest.mock import MagicMock
    source = SourceTender(source="zakupki_gov_ru", external_id="32600001", title="Алюминиевый лист", raw_payload={"stage": "search"})
    detail = source.model_copy(update={"raw_payload": {"stage": "detail"}})
    session = MagicMock()
    session.__enter__.return_value = session
    def assign_id(row):
        row.id = "00000000-0000-0000-0000-000000000001"
    session.add.side_effect = assign_id
    monkeypatch.setattr(tasks_parsing, "SyncSessionLocal", lambda: session)
    monkeypatch.setattr(tasks_parsing, "find_existing_tender", lambda *a: None)
    adapter = Mock()
    def fetch(_):
        assert session.commit.called, "discovery must be durable before network access"
        return detail if supported else None
    adapter.fetch_by_id.side_effect = fetch
    monkeypatch.setattr(tasks_parsing, "get_adapter", lambda _: adapter)
    original = tasks_parsing.process_new_tender.run
    recursive = Mock(return_value=Mock(id="detail-task"))
    monkeypatch.setattr(tasks_parsing.process_new_tender, "delay", recursive)
    result = original(source.model_dump(mode="json"))
    if supported:
        assert result["status"] == "queued_for_detail"
        assert recursive.call_args.args[0]["raw_payload"]["stage"] == "detail"
    else:
        assert result["status"] == "awaiting_detail"
        recursive.assert_not_called()
