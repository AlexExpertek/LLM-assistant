"""Test-only configuration; no production services or secrets are used."""
import os
import tempfile

for key, value in {
    "DATABASE_URL": "postgresql+asyncpg://test:test@127.0.0.1:1/test",
    "DATABASE_URL_SYNC": "postgresql+psycopg2://test:test@127.0.0.1:1/test",
    "REDIS_URL": "redis://127.0.0.1:1/0",
    "CELERY_BROKER_URL": "memory://",
    "CELERY_RESULT_BACKEND": "cache+memory://",
    "QDRANT_URL": "http://127.0.0.1:1",
    "STORAGE_PATH": tempfile.mkdtemp(prefix="tender-tests-"),
}.items():
    os.environ[key] = value
