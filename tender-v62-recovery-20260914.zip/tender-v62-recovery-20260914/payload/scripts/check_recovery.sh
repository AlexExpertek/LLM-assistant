#!/usr/bin/env bash
set -Eeuo pipefail
cd /home/stdadmin/LLM-assistant/tender-ai-platform-v6.2
docker compose ps -a
docker compose exec -T celery_worker celery -A app.workers.celery_app inspect ping
docker compose exec -T celery_beat python - <<'PY'
from app.workers.celery_app import celery_app
print('TIMEZONE:', celery_app.conf.timezone)
for key, entry in celery_app.conf.beat_schedule.items():
    print(key, entry['schedule'], entry.get('args', ()))
PY
docker compose exec -T celery_worker python - <<'PY'
from app.sources.run_status import list_runs
from app.marketplace_discovery.review_store import list_review_candidates
from app.core.config import settings
import json
print('SOURCE RUNS:', json.dumps(list_runs(), ensure_ascii=False, indent=2))
print('REVIEW ITEMS (max 500):', len(list_review_candidates(500)))
print('LLM PROVIDER:', settings.default_llm_provider)
print('LLM READ/TOTAL TIMEOUT:', settings.llm_read_timeout_seconds, settings.llm_total_timeout_seconds)
PY
curl --fail --silent --show-error --max-time 20 http://127.0.0.1:8000/health
