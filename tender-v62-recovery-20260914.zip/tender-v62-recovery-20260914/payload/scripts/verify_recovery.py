"""Offline smoke check of built image. Uses existing config, prints no secrets."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.core.config import settings
from app.workers.celery_app import celery_app
from app.marketplace_discovery.business_filter import evaluate_business_rules
from app.marketplace_discovery.runner import marketplace_to_source_tender
from app.marketplace_discovery.schemas import MarketplaceTender
from app.reports.dashboard_eligibility import evaluate_dashboard_tender
from app.api.marketplace_scout import router

if settings.eis_monitor_enabled:
    assert "monitor-eis-daily" in celery_app.conf.beat_schedule
item = MarketplaceTender(platform="b2b_center", external_id="smoke", title="Поставка алюминиевого профиля", raw_text="Алюминиевый профиль АД31 600 кг")
business = evaluate_business_rules(item.title, item.raw_text)
assert business.relevant
canonical = marketplace_to_source_tender(item, business)
assert evaluate_dashboard_tender({"positions": canonical.raw_payload["positions"]}).eligible
assert any(route.path == "/marketplaces/review" for route in router.routes)
print("OFFLINE_SMOKE_OK: schedule, pipeline imports, position mapping, API routes")
print("No HTTP, DB, LLM requests or notifications were sent.")
