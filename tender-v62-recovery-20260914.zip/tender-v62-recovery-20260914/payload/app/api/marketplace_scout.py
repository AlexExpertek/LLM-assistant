from __future__ import annotations

from fastapi import (
    APIRouter,
    Query,
)

from app.marketplace_discovery.scout.store import (
    list_candidates,
)


router = APIRouter(
    prefix="/marketplaces",
    tags=[
        "Tender Marketplace Discovery"
    ],
)


@router.get(
    "/discovered",
    summary="Автоматически найденные тендерные площадки",
)
def get_discovered_marketplaces(
    min_score: int = Query(
        default=0,
        ge=0,
        le=100,
    ),
    limit: int = Query(
        default=100,
        ge=1,
        le=500,
    ),
):
    items = list_candidates(
        min_score=min_score,
        limit=limit,
    )

    return {
        "count": len(items),
        "marketplaces": items,
    }


@router.get(
    "/recommended",
    summary="Площадки, рекомендованные к подключению",
)
def get_recommended_marketplaces():
    items = list_candidates(
        min_score=60,
        limit=100,
    )

    return {
        "count": len(items),
        "marketplaces": items,
    }


@router.get("/review", summary="Закупки с неподтверждённым объёмом")
def get_review_candidates(limit: int = Query(default=100, ge=1, le=500)):
    from app.marketplace_discovery.review_store import list_review_candidates
    items = list_review_candidates(limit)
    return {"count": len(items), "candidates": items}


@router.get("/source-runs", summary="Последние результаты поиска по источникам")
def get_source_runs():
    from app.sources.run_status import list_runs
    items = list_runs()
    return {"count": len(items), "runs": items}
