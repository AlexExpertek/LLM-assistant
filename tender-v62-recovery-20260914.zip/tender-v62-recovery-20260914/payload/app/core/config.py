"""
Конфигурация приложения — обновлено: добавлены параметры Битрикс24.
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # БД
    database_url: str
    database_url_sync: str

    # Redis / Celery
    redis_url: str
    celery_broker_url: str
    celery_result_backend: str

    # Qdrant
    qdrant_url: str

    # LLM
    anthropic_api_key: str = ""
    anthropic_model_default: str = "claude-sonnet-4-6"
    anthropic_model_cheap: str = "claude-haiku-4-5-20251001"
    yandex_api_key: str = ""
    yandex_folder_id: str = ""
    yandex_model_uri: str = ""
    default_llm_provider: str = "anthropic"
    llm_read_timeout_seconds: float = 120.0
    llm_total_timeout_seconds: float = 180.0
    eis_monitor_enabled: bool = True
    kontur_monitor_enabled: bool = True
    marketplace_scout_enabled: bool = True

    # Telegram
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""

    # Битрикс24 — коробочная версия
    bitrix24_webhook_url: str = ""   # напр: https://bitrix.tdsm.ru/rest/1/ТОКЕН
    bitrix24_chat_id: str = ""       # ID группового чата (только цифры)
    bitrix24_user_id: str = ""

    # ЕИС zakupki.gov.ru
    eis_token: str = ""  # Токен физлица для SOAP API getDocsIP
    tender_pro_api_key: str = ""
    tender_pro_max_rows: int = 1000
    tender_pro_open_only: bool = True
    tender_pro_fetch_details: bool = True
    tender_pro_request_timeout: float = 30.0
    # Контур.Закупки API
    # Exact API host/auth/paths are supplied with the API licence and stay configurable.
    kontur_api_base_url: str = ""
    kontur_api_key: str = ""
    kontur_api_key_header: str = ""
    kontur_api_key_prefix: str = ""
    kontur_api_key_query_param: str = ""
    kontur_search_path: str = ""
    kontur_search_method: str = "POST"
    kontur_purchase_path: str = ""
    kontur_documents_path: str = ""
    kontur_request_timeout: float = 30.0
    kontur_max_rows: int = 1000
    kontur_fetch_details: bool = True
    kontur_fetch_documents: bool = True
    kontur_filter_aluminium: bool = True
    kontur_search_query: str = "алюминий"
    kontur_search_query_field: str = "query"
    kontur_limit_field: str = "limit"
    kontur_search_payload: dict = {}

    analysis_version: str = "v6.2"

    # Уведомления
    notifications_enabled: bool = False

    # Прочее
    environment: str = "development"
    log_level: str = "INFO"
    storage_path: str = "/app/storage"
    max_download_size_mb: int = 200
    max_archive_uncompressed_mb: int = 500
    max_archive_files: int = 500


settings = Settings()
