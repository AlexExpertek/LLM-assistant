"""
Model router — выбирает LLM-провайдера и конкретную модель по типу задачи,
стоимости и требованиям к конфиденциальности данных.

Логика выбора (из ТЗ, раздел 7.1, компонент "Model router"):
  - простое извлечение полей из таблиц -> Claude Haiku (дёшево, быстро)
  - сложный анализ договорных рисков, генерация КП -> Claude Sonnet
  - данные не должны покидать РФ -> YandexGPT

Использование:
    from app.llm.router import llm_router

    result = await llm_router.complete(
        task="extract_fields",
        system_prompt="...",
        user_prompt="...",
        json_mode=True,
    )
"""
import asyncio
import json
from enum import Enum
from typing import Any, Optional

import anthropic
import httpx


from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class TaskType(str, Enum):
    """Тип задачи определяет какая модель будет использована."""
    EXTRACT_FIELDS = "extract_fields"            # извлечение полей -> Haiku
    SCORING_EXPLANATION = "scoring_explanation"   # объяснение скоринга -> Haiku
    CONTRACT_RISK_ANALYSIS = "contract_risk"      # анализ рисков договора -> Sonnet
    OFFER_GENERATION = "offer_generation"         # генерация КП -> Sonnet
    CONFIDENTIAL = "confidential"                  # данные не должны уходить за рубеж -> YandexGPT


class LLMResponse:
    """Унифицированный ответ независимо от провайдера."""

    def __init__(self, text: str, provider: str, model: str, raw: Any = None):
        self.text = text
        self.provider = provider
        self.model = model
        self.raw = raw

    def as_json(self) -> dict:
        """Парсит ответ как JSON, выбрасывает понятную ошибку если не удалось."""
        try:
            # модели иногда оборачивают JSON в ```json ... ``` — снимаем обёртку
            cleaned = self.text.strip()
            if cleaned.startswith("```"):
                cleaned = cleaned.split("```")[1]
                if cleaned.startswith("json"):
                    cleaned = cleaned[4:]
            return json.loads(cleaned.strip())
        except (json.JSONDecodeError, IndexError) as e:
            logger.error("llm_json_parse_failed", text=self.text[:500], error=str(e))
            raise ValueError(f"Модель вернула невалидный JSON: {e}")


class ModelRouter:
    """
    Центральный роутер LLM-запросов.
    Решает: какой провайдер, какая модель, и выполняет вызов с retry-логикой.
    """

    # Карта "задача -> (провайдер, модель)" — редактируется по мере оптимизации стоимости
    ROUTING_TABLE = {
        TaskType.EXTRACT_FIELDS: ("anthropic", "cheap"),
        TaskType.SCORING_EXPLANATION: ("anthropic", "cheap"),
        TaskType.CONTRACT_RISK_ANALYSIS: ("anthropic", "default"),
        TaskType.OFFER_GENERATION: ("anthropic", "default"),
        TaskType.CONFIDENTIAL: ("yandex", "default"),
    }

    def __init__(self):
        pass  # Clients are scoped to each event loop/task; Celery owns retries.

    def _resolve_route(self, task: TaskType, force_provider: Optional[str] = None) -> tuple[str, str]:
        """Возвращает (provider, model_name) для задачи."""
        if task == TaskType.CONFIDENTIAL:
            return "yandex", settings.yandex_model_uri
        if force_provider:
            provider = force_provider
            model_key = "default"
        else:
            configured = settings.default_llm_provider.strip().lower()
            if configured not in {"anthropic", "yandex"}:
                raise ValueError("DEFAULT_LLM_PROVIDER должен быть anthropic или yandex")
            # CONFIDENTIAL всегда остаётся в Yandex; остальные задачи используют
            # явно выбранного в .env провайдера. Тип задачи определяет класс модели.
            if task == TaskType.CONFIDENTIAL:
                provider, model_key = "yandex", "default"
            else:
                _, model_key = self.ROUTING_TABLE.get(task, (configured, "default"))
                provider = configured

        if provider == "anthropic":
            model = (
                settings.anthropic_model_cheap
                if model_key == "cheap"
                else settings.anthropic_model_default
            )
        else:
            model = settings.yandex_model_uri

        return provider, model

    async def _call_anthropic(
        self,
        model: str,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int = 2048,
        temperature: float = 0.0,
    ) -> LLMResponse:
        if not settings.anthropic_api_key:
            raise RuntimeError("ANTHROPIC_API_KEY не настроен")
        async with anthropic.AsyncAnthropic(
            api_key=settings.anthropic_api_key,
            timeout=httpx.Timeout(settings.llm_read_timeout_seconds, connect=10.0),
            max_retries=0,
        ) as client:
            response = await client.messages.create(
                model=model, max_tokens=max_tokens, temperature=temperature,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
            )
        text = "".join(block.text for block in response.content if block.type == "text")
        return LLMResponse(text=text, provider="anthropic", model=model, raw=response)

    async def _call_yandex(
        self,
        model_uri: str,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int = 2048,
        temperature: float = 0.0,
    ) -> LLMResponse:
        """
        YandexGPT через Yandex Cloud Foundation Models API.
        Документация: https://yandex.cloud/ru/docs/foundation-models/
        """
        if not settings.yandex_api_key:
            raise RuntimeError("YANDEX_API_KEY не настроен")

        url = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion"
        headers = {
            "Authorization": f"Api-Key {settings.yandex_api_key}",
            "x-folder-id": settings.yandex_folder_id,
            "Content-Type": "application/json",
        }
        payload = {
            "modelUri": model_uri,
            "completionOptions": {
                "stream": False,
                "temperature": temperature,
                "maxTokens": str(max_tokens),
            },
            "messages": [
                {"role": "system", "text": system_prompt},
                {"role": "user", "text": user_prompt},
            ],
        }

        async with httpx.AsyncClient(timeout=httpx.Timeout(settings.llm_read_timeout_seconds, connect=10.0)) as client:
            resp = await client.post(url, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()

        text = data["result"]["alternatives"][0]["message"]["text"]
        return LLMResponse(text=text, provider="yandex", model=model_uri, raw=data)

    async def complete(
        self,
        task: TaskType,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int = 2048,
        temperature: float = 0.0,
        force_provider: Optional[str] = None,
        json_mode: bool = False,
    ) -> LLMResponse:
        """
        Главный метод. Выбирает провайдера по типу задачи и выполняет запрос.

        json_mode=True добавляет в system_prompt явную инструкцию вернуть только JSON
        (Claude и YandexGPT не имеют отдельного "JSON mode" как OpenAI, поэтому
        это решается через промпт + guardrails-валидацию на стороне приложения).
        """
        provider, model = self._resolve_route(task, force_provider)

        effective_system_prompt = system_prompt
        if json_mode:
            effective_system_prompt += (
                "\n\nКРИТИЧЕСКИ ВАЖНО: ответь ТОЛЬКО валидным JSON, без markdown-обёртки "
                "```json, без преамбулы и без пояснений до или после JSON. "
                "Если значение поля не найдено в тексте — используй null, "
                "никогда не придумывай значения."
            )

        logger.info(
            "llm_request",
            task=task.value,
            provider=provider,
            model=model,
        )

        if provider not in {"anthropic", "yandex"}:
            raise ValueError(f"Неизвестный провайдер: {provider}")
        call = self._call_anthropic if provider == "anthropic" else self._call_yandex
        try:
            return await asyncio.wait_for(
                call(model, effective_system_prompt, user_prompt, max_tokens, temperature),
                timeout=settings.llm_total_timeout_seconds,
            )
        except Exception as exc:
            logger.error("llm_request_failed", provider=provider, model=model,
                         error_type=type(exc).__name__,
                         http_status=getattr(exc, "status_code", getattr(getattr(exc, "response", None), "status_code", None)))
            raise


# Singleton — один инстанс на всё приложение
llm_router = ModelRouter()
