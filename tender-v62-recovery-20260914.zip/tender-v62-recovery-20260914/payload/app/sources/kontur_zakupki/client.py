"""HTTP client for Контур.Закупки External API."""

from __future__ import annotations

import time
from typing import Any
from urllib.parse import urljoin

import httpx

from app.core.config import settings


class KonturConfigurationError(RuntimeError):
    pass


class KonturApiError(RuntimeError):
    pass


class KonturAccessError(KonturApiError):
    """Access/subscription failure; automatic retries cannot repair it."""
    pass


class KonturZakupkiClient:
    RETRY_STATUSES = {429, 500, 502, 503, 504}

    def __init__(self) -> None:
        self.base_url = settings.kontur_api_base_url.rstrip("/")
        self.api_key = settings.kontur_api_key.strip()
        self.timeout = settings.kontur_request_timeout

    def _require_config(self) -> None:
        if not self.base_url:
            raise KonturConfigurationError(
                "KONTUR_API_BASE_URL is not configured"
            )

        if not self.api_key:
            raise KonturConfigurationError(
                "KONTUR_API_KEY is not configured"
            )

    def _url(self, path: str) -> str:
        if not path:
            raise KonturConfigurationError(
                "Kontur API endpoint path is empty"
            )

        return urljoin(
            self.base_url + "/",
            path.lstrip("/"),
        )

    def _auth(
        self,
    ) -> tuple[dict[str, str], dict[str, str]]:
        headers = {
            "Accept": "application/json",
        }

        params: dict[str, str] = {}

        if settings.kontur_api_key_header:
            value = self.api_key

            if settings.kontur_api_key_prefix:
                value = (
                    f"{settings.kontur_api_key_prefix} "
                    f"{value}"
                ).strip()

            headers[
                settings.kontur_api_key_header
            ] = value

        elif settings.kontur_api_key_query_param:
            params[
                settings.kontur_api_key_query_param
            ] = self.api_key

        else:
            raise KonturConfigurationError(
                "Configure KONTUR_API_KEY_HEADER "
                "or KONTUR_API_KEY_QUERY_PARAM"
            )

        return headers, params

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        max_attempts: int = 5,
    ) -> Any:
        self._require_config()

        url = self._url(path)

        auth_headers, auth_params = self._auth()

        request_params: dict[str, Any] = {
            **auth_params,
            **(params or {}),
        }

        last_error: Exception | None = None

        for attempt in range(1, max_attempts + 1):
            try:
                with httpx.Client(
                    timeout=self.timeout,
                    follow_redirects=True,
                ) as client:
                    response = client.request(
                        method=method.upper(),
                        url=url,
                        headers=auth_headers,
                        params=request_params,
                        json=json_body,
                    )

                if response.status_code in self.RETRY_STATUSES:
                    if attempt >= max_attempts:
                        raise KonturApiError(
                            f"Kontur API HTTP "
                            f"{response.status_code}: "
                            f"{response.text[:500]}"
                        )

                    retry_after = response.headers.get(
                        "Retry-After"
                    )

                    if retry_after:
                        try:
                            delay = float(retry_after)
                        except ValueError:
                            delay = 2 ** (attempt - 1)
                    else:
                        delay = 2 ** (attempt - 1)

                    time.sleep(min(delay, 30))
                    continue

                if response.status_code in {401, 403}:
                    raise KonturAccessError(
                        f"Kontur API HTTP {response.status_code}: access or subscription denied"
                    )

                if response.status_code >= 400:
                    raise KonturApiError(
                        f"Kontur API HTTP "
                        f"{response.status_code}: "
                        f"{response.text[:500]}"
                    )

                if not response.content:
                    return None

                return response.json()

            except (
                httpx.TimeoutException,
                httpx.NetworkError,
            ) as exc:
                last_error = exc

                if attempt >= max_attempts:
                    break

                time.sleep(
                    min(
                        2 ** (attempt - 1),
                        30,
                    )
                )

        raise KonturApiError(
            f"Kontur API request failed: "
            f"{last_error}"
        )

    # ---
    # Search API
    # ---------------------------------------------------------

    def search_page(
        self,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Return one Контур search page."""

        path = settings.kontur_search_path

        method = (
            settings.kontur_search_method
            or "POST"
        ).upper()

        if method == "GET":
            result = self._request(
                "GET",
                path,
                params=payload,
            )
        else:
            result = self._request(
                "POST",
                path,
                json_body=payload,
            )

        if not isinstance(result, dict):
            raise KonturApiError(
                "Kontur search response "
                "is not a JSON object"
            )

        return result

    def search(
        self,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Backward-compatible alias for one search page.
        """
        return self.search_page(payload)

    def search_all(
        self,
        payload: dict[str, Any],
        *,
        max_rows: int | None = None,
    ) -> list[dict[str, Any]]:
        """
        Load Контур search pages until max_rows
        or TotalCount is reached.

        API page size is controlled by Контур
        and is currently max 50 items per page.
        """

        requested = (
            max_rows
            if max_rows is not None
            else settings.kontur_max_rows
        )

        requested = max(
            1,
            int(requested),
        )

        items: list[dict[str, Any]] = []
        seen_ids: set[str] = set()

        page = int(
            payload.get("PageNumber", 0) or 0
        )

        total_count: int | None = None

        while len(items) < requested:
            page_payload = {
                **payload,
                "PageNumber": page,
            }

            result = self.search_page(
                page_payload
            )

            page_items = (
                result.get("Items")
                or result.get("items")
                or []
            )

            if not isinstance(page_items, list):
                raise KonturApiError(
                    "Kontur search Items "
                    "is not a list"
                )

            if total_count is None:
                raw_total = result.get(
                    "TotalCount"
                )

                if raw_total is not None:
                    try:
                        total_count = int(
                            raw_total
                        )
                    except (
                        TypeError,
                        ValueError,
                    ):
                        total_count = None

            if not page_items:
                break

            added = 0

            for item in page_items:
                if not isinstance(item, dict):
                    continue

                purchase_id = item.get("Id")

                if purchase_id is None:
                    continue

                purchase_id = str(
                    purchase_id
                )

                if purchase_id in seen_ids:
                    continue

                seen_ids.add(
                    purchase_id
                )

                items.append(
                    item
                )

                added += 1

                if len(items) >= requested:
                    break

            if len(items) >= requested:
                break

            if total_count is not None:
                if len(seen_ids) >= total_count:
                    break

            if added == 0:
                break

            page += 1

        return items

    #
    # Purchase API
    # ---

    def get_purchase(
        self,
        purchase_id: str,
    ) -> dict[str, Any]:
        """
        Return detailed purchase information.

        Demo:
         /external/v1/testpurchases/{id}

        Production:
         /external/v1/purchases/{id}
        """

        path_template = (
            settings.kontur_purchase_path
        )

        if not path_template:
            raise KonturConfigurationError(
                "KONTUR_PURCHASE_PATH "
                "is not configured"
            )

        path = path_template.format(
            id=str(purchase_id)
        )

        result = self._request(
            "GET",
            path,
        )

        if not isinstance(result, dict):
            raise KonturApiError(
                "Kontur purchase response "
                "is not a JSON object"
            )

        return result

    #
    # Limits
    # ---------------------------------------------------------

    def get_limit_groups(
        self,
    ) -> list[dict[str, Any]]:
        result = self._request(
            "GET",
            "/external/v1/limitGroups",
        )

        if not isinstance(result, list):
            raise KonturApiError(
                "Kontur limitGroups response "
                "is not a JSON array"
            )

        return [
            item
            for item in result
            if isinstance(item, dict)
        ]
