"""Контур.Закупки -> canonical SourceTender adapter."""

from __future__ import annotations

import re
from datetime import datetime
from decimal import Decimal, InvalidOperation
from typing import Any
from urllib.parse import urlparse

from app.core.config import settings
from app.sources.kontur_zakupki.client import KonturAccessError
from app.core.logging import get_logger
from app.sources.base import TenderSourceAdapter
from app.sources.kontur_zakupki.client import KonturZakupkiClient
from app.sources.kontur_zakupki.discovery_cache import (
    compute_feed_hash,
    save_result,
    should_check,
)
from app.sources.schemas import SourceDocument, SourceTender

logger = get_logger(__name__)


ALUMINIUM_TEXT_KEYWORDS = (
    "алюмин",
    "aluminium",
    "aluminum",
    "алюминиевая лента",
    "алюминиевый лист",
    "алюминиевый профиль",
    "алюминиевая труба",
    "алюминиевая шина",
    "алюминиевая фольга",
)

# Numeric alloy designations must not match inside
# postal codes, phone numbers or other long numbers.
ALUMINIUM_NUMERIC_ALLOYS = (
    "1561",
    "5083",
    "5754",
    "5251",
    "6060",
    "6063",
    "6082",
)

# Russian alloy designations may be followed directly
# by temper/state characters, e.g. Д16Т.
ALUMINIUM_RUSSIAN_ALLOYS = (
    "амг",
    "ад31",
    "ад0",
    "ад1",
    "а5е",
    "а5",
    "д16",
)


def _matched_aluminium_keywords(text: str) -> list[str]:
    haystack = str(text or "").lower()

    matched: list[str] = []

    for keyword in ALUMINIUM_TEXT_KEYWORDS:
        if keyword in haystack:
            matched.append(keyword)

    for alloy in ALUMINIUM_NUMERIC_ALLOYS:
        pattern = rf"(?<!\d){re.escape(alloy)}(?!\d)"

        if re.search(pattern, haystack):
            matched.append(alloy)

    for alloy in ALUMINIUM_RUSSIAN_ALLOYS:
        # Require a token boundary before the alloy.
        # Right side is intentionally less strict:
        # Д16Т / АМг2М / А5Е etc. are valid forms.
        pattern = (
            rf"(?<![0-9a-zа-яё])"
            rf"{re.escape(alloy)}"
        )

        if re.search(
            pattern,
            haystack,
            flags=re.IGNORECASE,
        ):
            matched.append(alloy)

    return matched



def _first(
    data: dict[str, Any],
    *paths: str,
    default=None,
):
    for path in paths:
        cur: Any = data
        ok = True

        for part in path.split("."):
            if isinstance(cur, dict) and part in cur:
                cur = cur[part]
            else:
                ok = False
                break

        if ok and cur not in (None, ""):
            return cur

    return default


def _as_decimal(value: Any) -> Decimal | None:
    if value in (None, ""):
        return None

    if isinstance(value, Decimal):
        return value

    if isinstance(value, (int, float)):
        return Decimal(str(value))

    text = (
        str(value)
        .replace("\xa0", " ")
        .replace(" ", "")
        .replace(",", ".")
    )

    text = re.sub(r"[^0-9.\-]", "", text)

    try:
        return Decimal(text) if text else None
    except InvalidOperation:
        return None


def _as_datetime(value: Any) -> datetime | None:
    if value in (None, ""):
        return None

    if isinstance(value, datetime):
        return value

    text = str(value).strip()

    for normalized in (
        text,
        text.replace("Z", "+00:00"),
    ):
        try:
            return datetime.fromisoformat(normalized)
        except ValueError:
            pass

    for fmt in (
        "%d.%m.%Y %H:%M",
        "%d.%m.%Y",
        "%Y-%m-%d %H:%M:%S",
    ):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            pass

    return None


def _items(payload: Any) -> list[dict[str, Any]]:
    """Extract search result items from Контур response."""

    if isinstance(payload, list):
        return [
            item
            for item in payload
            if isinstance(item, dict)
        ]

    if not isinstance(payload, dict):
        return []

    for key in (
        "Items",
        "items",
        "Purchases",
        "purchases",
        "Results",
        "results",
        "Data",
        "data",
        "Tenders",
        "tenders",
    ):
        value = payload.get(key)

        if isinstance(value, list):
            return [
                item
                for item in value
                if isinstance(item, dict)
            ]

        if isinstance(value, dict):
            nested = _items(value)
            if nested:
                return nested

    return []


def _law_type(value: Any) -> str | None:
    text = str(value or "").lower()

    if "44" in text:
        return "44-FZ"

    if "223" in text:
        return "223-FZ"

    if any(
        token in text
        for token in (
            "commercial",
            "коммерч",
        )
    ):
        return "commercial"

    return None


def _documents_from_payload(
    payload: Any,
) -> list[SourceDocument]:
    """Map Контур Docs and generic document structures."""

    docs: list[SourceDocument] = []
    seen: set[str] = set()

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            url = _first(
                node,
                "Url",
                "url",
                "DownloadUrl",
                "downloadUrl",
                "download_url",
                "Href",
                "href",
                "Link",
                "link",
                "FileUrl",
                "fileUrl",
            )

            name = _first(
                node,
                "FileName",
                "fileName",
                "filename",
                "Name",
                "name",
                "Title",
                "title",
                "Caption",
                "caption",
            )

            content_type = _first(
                node,
                "ContentType",
                "contentType",
                "content_type",
                "MimeType",
                "mimeType",
                "mime_type",
            )

            external_id = _first(
                node,
                "Id",
                "id",
                "DocumentId",
                "documentId",
                "FileId",
                "fileId",
            )

            if (
                isinstance(url, str)
                and url.startswith(
                    (
                        "http://",
                        "https://",
                    )
                )
            ):
                if url not in seen:
                    seen.add(url)

                    docs.append(
                        SourceDocument(
                            external_id=(
                                str(external_id)
                                if external_id
                                else None
                            ),
                            name=str(
                                name
                                or url.rsplit("/", 1)[-1]
                                or "document"
                            ),
                            url=url,
                            content_type=(
                                str(content_type)
                                if content_type
                                else None
                            ),
                        )
                    )

            for key, value in node.items():
                if key.lower() in {
                    "documents",
                    "docs",
                    "files",
                    "attachments",
                    "documentation",
                }:
                    walk(value)

        elif isinstance(node, list):
            for value in node:
                walk(value)

    walk(payload)

    return docs


def _summary_text(data: dict[str, Any]) -> str:
    """
    Text available directly in search response.

    This is intentionally cheap: it is used before
    get_purchase() so we do not spend purchase quota
    unnecessarily.
    """

    parts: list[str] = []

    for key in (
        "OrderName",
        "Title",
        "title",
        "Name",
        "name",
        "Description",
        "description",
        "Subject",
        "subject",
    ):
        value = data.get(key)

        if value:
            parts.append(str(value))

    for key in (
        "Customers",
        "Customer",
        "Organizer",
        "DeliveryPlaces",
    ):
        value = data.get(key)

        if value:
            parts.append(str(value))

    return " ".join(parts)


def _looks_aluminium(
    data: dict[str, Any],
) -> bool:
    haystack = _summary_text(data).lower()

    # Detailed response may contain useful nested data.
    for key in (
        "Lots",
        "lots",
        "Objects",
        "objects",
        "Positions",
        "positions",
        "Products",
        "products",
        "Docs",
        "documents",
        "files",
    ):
        value = data.get(key)

        if value:
            haystack += " " + str(value).lower()

    return bool(
        _matched_aluminium_keywords(
            haystack
        )
    )


class KonturZakupkiAdapter(TenderSourceAdapter):
    source_code = "kontur_zakupki"

    def __init__(
        self,
        client: KonturZakupkiClient | None = None,
    ) -> None:
        self.client = client or KonturZakupkiClient()

    def _search_payload(self) -> dict[str, Any]:
        return dict(
            settings.kontur_search_payload
        )

    def search(self) -> list[SourceTender]:
        """
        Контур two-stage discovery pipeline:

        1. Search API
        2. Discovery cache
        3. Cheap aluminium pre-filter
        4. Purchase API only for search candidates
        5. Detailed validation
        6. SourceTender mapping
        """

        payload = self._search_payload()

        summaries = self.client.search_all(
            payload,
            max_rows=settings.kontur_max_rows,
        )

        results: list[SourceTender] = []
        seen: set[str] = set()

        cached = 0
        search_irrelevant = 0
        search_candidates = 0
        purchase_irrelevant = 0
        purchase_errors = 0
        accepted = 0

        logger.info(
            "kontur_search_received",
            count=len(summaries),
        )

        for summary in summaries:
            purchase_id = str(
                _first(
                    summary,
                    "Id",
                    "id",
                    "PurchaseId",
                    "purchaseId",
                    "purchase_id",
                    "TenderId",
                    "tenderId",
                    "NotificationNumber",
                    "number",
                )
                or ""
            ).strip()

            if not purchase_id:
                continue

            if purchase_id in seen:
                continue

            seen.add(purchase_id)

            # -------------------------------------------------
            # STAGE 1A.
            # Hash only the cheap Search API representation.
            # -------------------------------------------------

            feed_hash = compute_feed_hash(
                summary
            )

            check_needed, cache_reason = (
                should_check(
                    purchase_id,
                    feed_hash,
                )
            )

            if not check_needed:
                cached += 1
                continue

            # -------------------------------------------------
            # STAGE 1B.
            # Cheap Search-level aluminium pre-filter.
            #
            # Purchase API MUST NOT be called before this.
            # -------------------------------------------------

            if (
                settings.kontur_filter_aluminium
                and not _looks_aluminium(summary)
            ):
                search_irrelevant += 1

                save_result(
                    purchase_id,
                    feed_hash,
                    decision="search_irrelevant",
                    reason=(
                        "Search metadata contains no "
                        "relevant aluminium signals"
                    ),
                )

                continue

            search_candidates += 1

            save_result(
                purchase_id,
                feed_hash,
                decision="search_candidate",
                reason=(
                    "Search pre-filter matched "
                    "aluminium signals"
                ),
            )

            # -------------------------------------------------
            # STAGE 2.
            # Purchase API is allowed ONLY now.
            # -------------------------------------------------

            detail = summary
            purchase_data: dict[str, Any] = {}

            if settings.kontur_fetch_details:
                try:
                    fetched = (
                        self.client.get_purchase(
                            purchase_id
                        )
                    )

                    if isinstance(
                        fetched,
                        dict,
                    ):
                        purchase_data = fetched

                        detail = {
                            **summary,
                            **fetched,
                        }

                except KonturAccessError:
                    raise
                except Exception as exc:
                    purchase_errors += 1

                    save_result(
                        purchase_id,
                        feed_hash,
                        decision="detail_error",
                        reason=str(exc)[:1000],
                    )

                    logger.warning(
                        "kontur_details_failed",
                        purchase_id=purchase_id,
                        cache_reason=cache_reason,
                        error=str(exc),
                    )

                    continue

            # -------------------------------------------------
            # Second relevance check over the detailed card.
            # -------------------------------------------------

            if (
                settings.kontur_filter_aluminium
                and not _looks_aluminium(detail)
            ):
                purchase_irrelevant += 1

                save_result(
                    purchase_id,
                    feed_hash,
                    decision="purchase_irrelevant",
                    reason=(
                        "Detailed purchase contains no "
                        "relevant aluminium signals"
                    ),
                )

                continue

            # -------------------------------------------------
            # Mapping only after both stages passed.
            # -------------------------------------------------

            try:
                source_tender = self._map(
                    detail,
                    purchase_id,
                )

                source_tender.raw_payload = {
                    "search": summary,
                    "purchase": purchase_data,
                    "relevance": {
                        "stage": "purchase_candidate",
                        "search_candidate": True,
                        "purchase_checked": bool(
                            purchase_data
                        ),
                        "decision": "accepted",
                    },
                }

                results.append(
                    source_tender
                )

                accepted += 1

                save_result(
                    purchase_id,
                    feed_hash,
                    decision="accepted",
                    reason=(
                        "Search and Purchase stages passed"
                    ),
                )

            except Exception as exc:
                purchase_errors += 1

                save_result(
                    purchase_id,
                    feed_hash,
                    decision="detail_error",
                    reason=(
                        "Mapping failed: "
                        + str(exc)[:900]
                    ),
                )

                logger.warning(
                    "kontur_mapping_failed",
                    purchase_id=purchase_id,
                    error=str(exc),
                )

        logger.info(
            "kontur_search_done",
            total=len(summaries),
            cached=cached,
            search_irrelevant=search_irrelevant,
            search_candidates=search_candidates,
            purchase_irrelevant=purchase_irrelevant,
            purchase_errors=purchase_errors,
            accepted=accepted,
        )

        return results

    def _map(
        self,
        data: dict[str, Any],
        purchase_id: str | None = None,
    ) -> SourceTender:

        pid = (
            purchase_id
            or str(
                _first(
                    data,
                    "Id",
                    "id",
                    "NotificationNumber",
                    "purchaseId",
                    "purchase_id",
                    "tenderId",
                    "number",
                )
                or ""
            ).strip()
        )

        if not pid:
            raise ValueError(
                "Kontur purchase has no id"
            )

        title = str(
            _first(
                data,
                "Title",
                "OrderName",
                "title",
                "name",
                "subject",
                "purchaseName",
                default=f"Закупка {pid}",
            )
        )

        customer_name = _first(
            data,
            "Organizer.FullName",
            "Organizer.Name",
            "Customer.FullName",
            "Customer.Name",
            "customer.name",
            "customerName",
            "organization.name",
            "buyer.name",
        )

        customer_inn = _first(
            data,
            "Organizer.Inn",
            "Customer.Inn",
            "customer.inn",
            "customerInn",
            "organization.inn",
            "buyer.inn",
        )

        docs = _documents_from_payload(
            data.get("Docs")
            or data.get("Documents")
            or data
        )

        unique_docs: dict[
            str,
            SourceDocument,
        ] = {}

        for doc in docs:
            key = (
                doc.url
                or f"{doc.external_id}:{doc.name}"
            )
            unique_docs[key] = doc

        public_url = _first(
            data,
            "Link",
            "link",
            "Url",
            "url",
            "purchaseUrl",
            "webUrl",
            "sourceUrl",
        )

        if not public_url:
            public_url = (
                f"https://zakupki.kontur.ru/{pid}"
            )

        raw_law = _first(
            data,
            "Law",
            "LawType",
            "law",
            "lawType",
            "PurchaseType",
            "purchaseType",
            "type",
            "regulation",
        )

        procurement_method = _first(
            data,
            "NotificationPlacingWay",
            "ProcurementMethod",
            "procurementMethod",
            "method",
            "procedureType",
            "purchaseMethod",
        )

        amount = _as_decimal(
            _first(
                data,
                "InitialSum.Price",
                "Amount",
                "amount",
                "maxPrice",
                "initialPrice",
                "price",
                "nmck",
            )
        )

        currency = str(
            _first(
                data,
                "InitialSum.Currency",
                "Currency",
                "currency",
                "currencyCode",
                default="RUB",
            )
        )

        publish_date = _as_datetime(
            _first(
                data,
                "PublicationDateTimeUTC",
                "PublicationDateTime",
                "publishDate",
                "publishedAt",
                "publicationDate",
                "datePublished",
            )
        )

        submission_deadline = _as_datetime(
            _first(
                data,
                "ApplicationDeadline",
                "submissionDeadline",
                "deadline",
                "applicationEndDate",
                "endDate",
            )
        )

        delivery_place = _first(
            data,
            "DeliveryPlace",
            "deliveryPlace",
            "deliveryAddress",
            "placeOfDelivery",
        )

        region = _first(
            data,
            "Region.Name",
            "region.name",
            "region",
            "deliveryRegion",
            "customer.region",
        )

        return SourceTender(
            source=self.source_code,
            external_id=pid,
            title=title,
            description=_first(
                data,
                "Description",
                "description",
                "Summary",
                "summary",
                "ObjectDescription",
                "objectDescription",
                "purchaseDescription",
            ),
            customer_name=(
                str(customer_name)
                if customer_name
                else None
            ),
            customer_inn=(
                str(customer_inn)
                if customer_inn
                else None
            ),
            law_type=_law_type(raw_law),
            procurement_method=(
                str(procurement_method)
                if procurement_method
                else None
            ),
            amount=amount,
            currency=currency,
            region=region,
            delivery_place=delivery_place,
            publish_date=publish_date,
            submission_deadline=(
                submission_deadline
            ),
            source_url=str(public_url),
            documents=list(
                unique_docs.values()
            ),
            raw_payload=data,
        )

    def fetch_by_id(
        self,
        external_id: str,
    ) -> SourceTender | None:

        data = self.client.get_purchase(
            external_id
        )

        if not isinstance(data, dict):
            return None

        tender = self._map(
            data,
            external_id,
        )

        tender.raw_payload = {
            "search": {},
            "purchase": data,
            "relevance": {
                "stage": "direct_purchase",
                "search_candidate": None,
                "purchase_checked": True,
                "decision": "direct_fetch",
            },
        }

        return tender

    def fetch_by_url(
        self,
        url: str,
    ) -> SourceTender | None:

        parsed = urlparse(url)
        host = (
            parsed.hostname
            or ""
        ).lower()

        if "zakupki.kontur.ru" not in host:
            return None

        path = parsed.path.strip("/")

        if not path:
            return None

        external_id = path.split("/", 1)[0]

        return self.fetch_by_id(
            external_id
        )
