from __future__ import annotations

import re
from typing import Any

from app.core.logging import get_logger
from app.sources.base import TenderSourceAdapter
from app.sources.schemas import SourceDocument, SourceTender

from app.sources.zakupki_gov_public.public_client import (
    EisPublicSearchClient,
)
from app.sources.zakupki_gov_public.detail_client import (
    EisPublicDetailClient,
)
from app.sources.zakupki_gov_public.relevance import (
    evaluate_search_relevance,
)
from app.sources.zakupki_gov_public.discovery_cache import (
    compute_feed_hash,
    save_result,
    should_check,
)


logger = get_logger(__name__)



def _parse_eis_datetime(value):
    """Normalize EIS date/datetime values for SourceTender."""

    if value in (None, ""):
        return None

    from datetime import date, datetime

    if isinstance(value, datetime):
        return value

    if isinstance(value, date):
        return value

    raw = str(value).strip()

    formats = (
        "%d.%m.%Y %H:%M:%S",
        "%d.%m.%Y %H:%M",
        "%d.%m.%Y",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d",
    )

    for fmt in formats:
        try:
            return datetime.strptime(
                raw,
                fmt,
            )
        except ValueError:
            continue

    return None


class ZakupkiGovPublicAdapter(TenderSourceAdapter):
    """
    Public EIS adapter.

    Search:
        public EIS search
        -> deterministic relevance
        -> discovery cache
        -> SourceTender

    Detail:
        EIS 223-FZ public purchase page
        -> lots
        -> document metadata
        -> SourceTender

    Document downloading/extraction is intentionally NOT performed here.
    That remains a separate processing stage.
    """

    source_code = "zakupki_gov_ru"

    # Broad discovery vocabulary.
    #
    # Search remains intentionally broader than the final
    # relevance filter. False positives are rejected later by
    # evaluate_search_relevance(), while missing a procurement
    # at discovery time cannot be recovered downstream.
    SEARCH_QUERIES = (
        "алюминий",
        "алюминиевый лист",
        "алюминиевая лента",
        "алюминиевый профиль",
        "алюминиевая труба",
        "алюминиевый пруток",
        "алюминиевая шина",
        "алюминиевая плита",
        "алюминиевый прокат",
        "цветной металлопрокат",
        "АД31",
        "АМг2",
        "АМг3",
        "АМг5",
        "АМг6",
        "Д16",
        "6063",
        "6082",
        "5083",
    )

    SEARCH_PAGES = 3
    RECORDS_PER_PAGE = 50

    def __init__(
        self,
        *,
        verify: bool = False,
    ) -> None:
        self.search_client = EisPublicSearchClient(
            verify=verify,
        )
        self.detail_client = EisPublicDetailClient(
            verify=verify,
        )

    @staticmethod
    def _search_item_to_source(
        item: Any,
        *,
        relevance: Any | None = None,
        cache_reason: str | None = None,
    ) -> SourceTender:

        raw_payload = {
            "stage": "search",
            "search_item": {
                "external_id": item.external_id,
                "title": item.title,
                "law_type": item.law_type,
                "status": item.status,
                "customer_name": item.customer_name,
                "amount": (
                    str(item.amount)
                    if item.amount is not None
                    else None
                ),
                "published_date": (
                    str(item.published_date)
                    if item.published_date
                    else None
                ),
                "updated_date": (
                    str(item.updated_date)
                    if item.updated_date
                    else None
                ),
            },
            "cache_reason": cache_reason,
        }

        if relevance is not None:
            raw_payload["relevance"] = {
                "relevant": relevance.relevant,
                "score": relevance.score,
                "decision": relevance.decision,
                "products": relevance.products,
                "alloys": relevance.alloys,
                "negatives": relevance.negatives,
                "reasons": relevance.reasons,
            }

        return SourceTender(
            source="zakupki_gov_ru",
            external_id=str(item.external_id),
            title=(
                item.title
                or f"Закупка {item.external_id}"
            ),
            customer_name=item.customer_name,
            law_type=item.law_type,
            amount=item.amount,
            source_url=item.source_url,
            submission_deadline=_parse_eis_datetime(
                item.submission_deadline
            ),
            documents=[],
            raw_payload=raw_payload,
        )

    @staticmethod
    def _detail_to_source(
        detail: Any,
        *,
        source_url: str | None = None,
    ) -> SourceTender:

        documents = [
            SourceDocument(
                external_id=doc.uid,
                name=doc.name,
                url=doc.url,
                download_type="url",
            )
            for doc in detail.documents
        ]

        lots_payload = []

        for lot in detail.lots:
            lots_payload.append(
                {
                    "number": getattr(
                        lot,
                        "number",
                        None,
                    ),
                    "name": getattr(
                        lot,
                        "name",
                        None,
                    ),
                    "amount": (
                        str(getattr(lot, "amount", None))
                        if getattr(
                            lot,
                            "amount",
                            None,
                        ) is not None
                        else None
                    ),
                }
            )

        raw_payload = {
            "stage": "detail",
            "notice_guid": getattr(
                detail,
                "notice_guid",
                None,
            ),
            "lots": lots_payload,
            "documents": {
                "total": len(documents),
                "items": [
                    {
                        "external_id": doc.external_id,
                        "name": doc.name,
                        "url": doc.url,
                    }
                    for doc in documents
                ],
            },
        }

        external_id = str(
            getattr(
                detail,
                "external_id",
                "",
            )
            or getattr(
                detail,
                "purchase_notice_number",
                "",
            )
        )

        title = (
            getattr(detail, "title", None)
            or f"Закупка {external_id}"
        )

        return SourceTender(
            source="zakupki_gov_ru",
            external_id=external_id,
            title=title,
            customer_name=getattr(
                detail,
                "customer_name",
                None,
            ),
            law_type=getattr(
                detail,
                "law_type",
                None,
            )
            or "223-FZ",
            amount=getattr(
                detail,
                "amount",
                None,
            ),
            source_url=(
                source_url
                or getattr(
                    detail,
                    "source_url",
                    None,
                )
            ),
            submission_deadline=_parse_eis_datetime(
                getattr(
                    detail,
                    "submission_deadline",
                    None,
                )
            ),
            documents=documents,
            raw_payload=raw_payload,
        )

    def search(self) -> list[SourceTender]:
        results: list[SourceTender] = []
        seen: set[str] = set()
        page_failures = 0

        for query in self.SEARCH_QUERIES:
            logger.info(
                "eis_public_search_started",
                query=query,
            )

            query_items = []

            for page in range(
                1,
                self.SEARCH_PAGES + 1,
            ):
                try:
                    page_items = (
                        self.search_client.search(
                            query,
                            page=page,
                            records_per_page=(
                                self.RECORDS_PER_PAGE
                            ),
                        )
                    )

                except Exception as exc:
                    page_failures += 1
                    logger.warning(
                        "eis_public_search_page_failed",
                        query=query,
                        page=page,
                        error=str(exc),
                    )

                    # One failed page must not discard results
                    # already collected from previous pages.
                    continue

                if not page_items:
                    break

                query_items.extend(
                    page_items
                )

                logger.info(
                    "eis_public_search_page_received",
                    query=query,
                    page=page,
                    count=len(page_items),
                )

                # A short page normally means there is no
                # following result page.
                if (
                    len(page_items)
                    < self.RECORDS_PER_PAGE
                ):
                    break

            for item in query_items:
                external_id = str(
                    item.external_id
                )

                if external_id in seen:
                    continue

                seen.add(external_id)

                relevance = (
                    evaluate_search_relevance(
                        item.title
                    )
                )

                feed_hash = compute_feed_hash(
                    item
                )

                check, cache_reason = (
                    should_check(
                        external_id,
                        feed_hash,
                    )
                )

                if not check:
                    continue

                if not relevance.relevant:
                    save_result(
                        external_id,
                        feed_hash,
                        relevance.decision,
                        "; ".join(
                            relevance.reasons
                        ),
                    )
                    continue

                results.append(
                    self._search_item_to_source(
                        item,
                        relevance=relevance,
                        cache_reason=cache_reason,
                    )
                )

                save_result(
                    external_id,
                    feed_hash,
                    relevance.decision,
                    "; ".join(
                        relevance.reasons
                    ),
                )

        if page_failures and not results:
            raise RuntimeError(f"EIS search incomplete: {page_failures} page requests failed")
        logger.info(
            "eis_public_search_finished",
            search_status="partial" if page_failures else "ok",
            page_failures=page_failures,
            tenders=len(results),
        )

        return results

    def fetch_by_id(
        self,
        external_id: str,
    ) -> SourceTender | None:

        external_id = str(
            external_id
        ).strip()

        if not external_id:
            return None

        # Current public Detail implementation is for 223-FZ.
        if not external_id.startswith("3"):
            logger.warning(
                "eis_public_detail_unsupported_law",
                external_id=external_id,
            )
            return None

        source_url = (
            "https://zakupki.gov.ru/"
            "epz/order/notice/notice223/"
            "common-info.html"
            f"?regNumber={external_id}"
        )

        detail = self.detail_client.fetch_223(
            external_id,
            source_url,
        )

        return self._detail_to_source(
            detail,
            source_url=source_url,
        )

    def fetch_by_url(
        self,
        url: str,
    ) -> SourceTender | None:

        match = re.search(
            r"(?:regNumber|purchaseNoticeNumber)="
            r"(\d+)",
            url,
        )

        if not match:
            match = re.search(
                r"(\d{11,})",
                url,
            )

        if not match:
            return None

        return self.fetch_by_id(
            match.group(1)
        )
