"""Latest per-source run status, persisted without credentials or raw exceptions."""
import json
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from app.core.config import settings


def record_run(source, **result):
    if not re.fullmatch(r"[a-z0-9_]+", source):
        raise ValueError("Invalid source code")
    directory = Path(settings.storage_path) / "source_runs"
    directory.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(dir=directory, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump({"source": source, "recorded_at": datetime.now(timezone.utc).isoformat(), **result}, stream)
        os.replace(name, directory / (source + ".json"))
    finally:
        if os.path.exists(name):
            os.unlink(name)


def list_runs():
    rows = []
    for path in sorted((Path(settings.storage_path) / "source_runs").glob("*.json")):
        try:
            rows.append(json.loads(path.read_text()))
        except (OSError, ValueError):
            continue
    return rows
