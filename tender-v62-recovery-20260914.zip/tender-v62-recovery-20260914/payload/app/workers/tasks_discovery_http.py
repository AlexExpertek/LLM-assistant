"""Daily inspection of configured marketplace seeds, not tender ingestion."""
from app.workers.celery_app import celery_app
from app.marketplace_discovery.scout.runner import run_marketplace_scout


@celery_app.task(name="app.workers.tasks_discovery_http.discover_new_sources")
def discover_new_sources():
    candidates = run_marketplace_scout(persist=True)
    failed = sum(any(reason.startswith("probe_failed:") for reason in c.reasons) for c in candidates)
    return {"status": "partial" if failed else "completed", "checked": len(candidates),
            "unavailable": failed, "scope": "configured_seed_urls",
            "tender_adapters_added": 0}
