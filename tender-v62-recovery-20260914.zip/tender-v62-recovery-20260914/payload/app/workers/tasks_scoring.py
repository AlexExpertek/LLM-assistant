"""Tender-level LLM extraction, multi-position analysis and persistence for v6."""
import asyncio
import httpx
import anthropic
from datetime import datetime

from sqlalchemy import delete, select, update
from sqlalchemy.orm import joinedload

from app.core.config import settings
from app.core.logging import get_logger
from app.db.session import SyncSessionLocal
from app.llm.extraction import extract_tender_positions
from app.models.database import Decision, ExtractedFact, Lot, ProcessingStatus, Tender, TenderItem, TenderStatus
from app.scoring.alloy_normalizer import is_known_alloy
from app.scoring.multiposition import analyze_positions
from app.scoring.rules import score_tender
from app.workers.celery_app import celery_app

logger = get_logger(__name__)
MODEL_VERSION = "scoring-v6.0"


def _num(val):
    try:
        return float(str(val).replace(",", ".")) if val not in (None, "") else None
    except (ValueError, TypeError):
        return None


def _bool(val):
    if isinstance(val, bool):
        return val
    if val is None:
        return None
    s = str(val).strip().lower()
    if s in {"true", "да", "yes", "1", "разрешена", "допускается"}: return True
    if s in {"false", "нет", "no", "0", "запрещена", "не допускается"}: return False
    return None


@celery_app.task(name="app.workers.tasks_scoring.analyze_tender", bind=True, max_retries=2)
def analyze_tender(self, tender_id: str, document_text: str = "", document_ids: list[str] | None = None):
    try:
        with SyncSessionLocal() as session:
            tender = session.get(Tender, tender_id)
            if not tender:
                return {"status": "failed", "reason": "tender_not_found"}
            session.execute(update(Tender).where(Tender.id == tender_id).values(processing_status=ProcessingStatus.ANALYZING))
            metadata_parts = [
                tender.title,
                tender.description,
                tender.delivery_place,
            ]

            raw_payload = tender.raw_payload or {}
            source_positions = raw_payload.get("positions", [])

            if source_positions:
                position_lines = ["ПОЗИЦИИ ТЕНДЕРА:"]

                for idx, position in enumerate(source_positions, 1):
                    if not isinstance(position, dict):
                        continue

                    name = position.get("name") or ""
                    quantity = position.get("quantity")
                    unit = position.get("unit") or ""

                    line = f"{idx}. {name}"

                    if quantity not in (None, ""):
                        line += f" | количество: {quantity} {unit}".rstrip()

                    position_lines.append(line)

                if len(position_lines) > 1:
                    metadata_parts.append(
                        "\n".join(position_lines)
                    )

            metadata_text = "\n\n".join(
                str(value)
                for value in metadata_parts
                if value not in (None, "")
            )

            session.commit()

        combined_text = (
            metadata_text
            + "\n\n"
            + (document_text or "")
        ).strip()
        if not combined_text:
            raise ValueError("Нет текста для анализа")

        extracted = asyncio.run(extract_tender_positions(combined_text))
        positions = []
        for pos in extracted.positions:
            positions.append({
                "name_product": pos.product_name.value,
                "product_type": pos.product_type.value or pos.product_name.value,
                "alloy": pos.alloy.value,
                "mass_kg": _num(pos.mass_kg.value),
                "quantity_kg": _num(pos.mass_kg.value),
                "thickness_mm": _num(pos.thickness_mm.value),
                "width_mm": _num(pos.width_mm.value),
            })

        partial = _bool(extracted.partial_delivery_allowed.value)
        mp = analyze_positions(positions, partial_delivery_allowed=partial) if positions else None
        any_alloy = any(x.get("alloy") and is_known_alloy(x["alloy"]) for x in positions)
        any_dims = any(x.get("thickness_mm") or x.get("width_mm") for x in positions)
        any_mass = any(x.get("mass_kg") for x in positions)
        standards = [p.standard.value for p in extracted.positions if p.standard.value]
        drawings = any(_bool(p.has_drawings.value) for p in extracted.positions)
        processing = any(p.coating.value or p.machining.value for p in extracted.positions)

        scoring = score_tender(
            text=combined_text,
            has_alloy_match=any_alloy,
            has_dimensions=any_dims,
            has_volume=any_mass,
            has_standard_ref=bool(standards),
            has_drawings=drawings,
            has_processing_services=processing,
        )

        # Position mismatch must force review/not suitable rather than silently "can apply".
        status = scoring.suggested_status
        if mp and mp.can_supply_count == 0:
            status = TenderStatus.NOT_SUITABLE
        elif mp and not mp.can_supply_all and mp.partial_delivery_possible:
            status = TenderStatus.NEEDS_CLARIFICATION
        elif mp and not mp.can_supply_all:
            status = TenderStatus.MANUAL_REVIEW

        _save(tender_id, extracted, mp, scoring, status, document_ids or [])

        if (
            settings.notifications_enabled
            and status in (
                TenderStatus.CAN_APPLY,
                TenderStatus.NEEDS_CLARIFICATION,
                TenderStatus.MANUAL_REVIEW,
            )
        ):
            payload = {
                "total_score": scoring.total_score,
                "category": scoring.category.value,
                "suggested_status": status.value,
                "summary": mp.summary if mp else "Позиции не распознаны",
            }

            from app.workers.tasks_notify import (
                send_telegram_notification,
                send_bitrix_notification,
            )

            send_telegram_notification.delay(
                tender_id,
                payload,
            )

            send_bitrix_notification.delay(
                tender_id,
                payload,
            )

        return {"status": "analyzed", "tender_id": tender_id, "score": scoring.total_score, "decision": status.value, "positions": len(positions)}
    except Exception as exc:
        logger.exception("tender_analysis_failed", tender_id=tender_id, error_type=type(exc).__name__, error=str(exc))
        with SyncSessionLocal() as session:
            session.execute(update(Tender).where(Tender.id == tender_id).values(processing_status=ProcessingStatus.FAILED))
            session.commit()
        status_code = getattr(exc, "status_code", getattr(getattr(exc, "response", None), "status_code", None))
        transient = isinstance(exc, (TimeoutError, httpx.TransportError, anthropic.APIConnectionError)) or status_code in {408, 429, 500, 502, 503, 504}
        if transient and self.request.retries < self.max_retries:
            raise self.retry(exc=exc, countdown=60 * (2 ** self.request.retries))
        # No synthetic successful analysis, automatic approval or notification.
        raise


def _save(tender_id, extracted, mp, scoring, status, document_ids):
    with SyncSessionLocal() as session:
        tender = session.execute(select(Tender).where(Tender.id == tender_id).options(joinedload(Tender.lots).joinedload(Lot.items))).unique().scalar_one()
        # Replace generated analysis snapshot on re-analysis.
        for lot in list(tender.lots):
            session.delete(lot)
        session.execute(delete(Decision).where(Decision.tender_id == tender_id))
        session.flush()

        lots: dict[str, Lot] = {}
        analyses = mp.positions if mp else []
        for idx, pos in enumerate(extracted.positions, 1):
            lot_no = pos.lot_number or "1"
            if lot_no not in lots:
                lot = Lot(tender_id=tender_id, lot_number=str(lot_no), title=f"Лот {lot_no}", currency=tender.currency, delivery_place=tender.delivery_place)
                session.add(lot); session.flush(); lots[lot_no] = lot
            pa = analyses[idx-1] if idx-1 < len(analyses) else None
            item = TenderItem(
                lot_id=lots[lot_no].id,
                position_number=pos.position_number or idx,
                name=pos.product_name.value,
                product_type=pos.product_type.value or pos.product_name.value,
                alloy=pos.alloy.value,
                temper=pos.temper.value,
                thickness_mm=_num(pos.thickness_mm.value), width_mm=_num(pos.width_mm.value),
                length_mm=_num(pos.length_mm.value), diameter_mm=_num(pos.diameter_mm.value),
                quantity=_num(pos.quantity.value), mass_kg=_num(pos.mass_kg.value), unit=pos.unit.value,
                standard=pos.standard.value, coating_required=bool(pos.coating.value), coating_type=pos.coating.value,
                machining_required=bool(pos.machining.value), has_drawings=bool(_bool(pos.has_drawings.value)),
                delivery_place=pos.delivery_place.value, delivery_term=pos.delivery_term.value, payment_terms=pos.payment_terms.value,
                can_supply=pa.can_supply if pa else None, supply_reason=pa.reason if pa else None,
            )
            session.add(item)

        reasons = [s.reason for s in scoring.signals]
        if mp: reasons.append(mp.summary)
        session.add(Decision(
            tender_id=tender_id, score=scoring.total_score, status=status,
            reasons=reasons, risks=scoring.critical_unknowns, model_version=MODEL_VERSION,
        ))

        # Save explainability facts against first available document.
        first_doc = document_ids[0] if document_ids else None
        if first_doc:
            for pi, pos in enumerate(extracted.positions, 1):
                for field_name, field in pos.model_dump().items():
                    if isinstance(field, dict) and field.get("value") is not None:
                        session.add(ExtractedFact(
                            document_id=first_doc, field_name=f"position_{pi}.{field_name}",
                            raw_value=str(field.get("value")), normalized_value=str(field.get("value")),
                            confidence=field.get("confidence") or 0.0, quote=field.get("raw_quote"),
                        ))

        tender.analysis_done = True
        tender.processing_status = ProcessingStatus.ANALYZED
        tender.analysis_version = settings.analysis_version
        tender.score = scoring.total_score
        tender.status = status
        tender.updated_at = datetime.utcnow()
        session.commit()


# Compatibility wrapper for legacy task names.
@celery_app.task(name="app.workers.tasks_scoring.extract_fields_and_score")
def extract_fields_and_score(tender_external_id: str, document_text: str, tender_db_id: str = None, document_db_id: str = None):
    if not tender_db_id:
        return {"status": "deprecated", "reason": "tender_db_id is required in v6"}
    return analyze_tender.run(tender_db_id, document_text, [document_db_id] if document_db_id else [])
