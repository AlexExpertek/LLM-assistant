"""
Celery конфигурация с расписанием для всех источников.
"""
from celery import Celery
from celery.schedules import crontab

from app.core.config import settings

celery_app = Celery(
    "tender_platform",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
    include=[
        "app.workers.tasks_parsing",
        "app.workers.tasks_ocr",
        "app.workers.tasks_scoring",
        "app.workers.tasks_notify",
        "app.workers.tasks_reports",
        "app.workers.tasks_upload",
        "app.workers.tasks_marketplace_discovery",
        "app.workers.tasks_discovery_http",
    ],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Europe/Moscow",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_default_retry_delay=60,
    task_max_retries=3,
)

celery_app.conf.beat_schedule = {
    "marketplace-discovery-4h": {
        "task": (
            "app.workers.tasks_marketplace_discovery."
            "run_connected_marketplaces"
        ),
        "schedule": crontab(
            minute=20,
            hour="*/4",
        ),
        "kwargs": {
            "max_per_platform": 100,
        },
    },

    # ЕИС — каждый день в 03:00
    # Tender.Pro — каждые 4 часа (коммерческие тендеры обновляются чаще)
    "monitor-tender-pro-4h": {
        "task": "app.workers.tasks_parsing.monitor_source",
        "schedule": crontab(minute=30, hour="*/4"),
        "args": ("tender_pro",),
    },
    # Обновление дедлайнов — каждый час
    "mark-inactive-hourly": {
        "task": "app.workers.tasks_parsing.mark_inactive_tenders",
        "schedule": crontab(minute=0),
    },
    # Ежедневный отчёт — в 09:00
    "daily-report": {
        "task": "app.workers.tasks_reports.generate_and_send_report",
        "schedule": crontab(hour=9, minute=0),
    },
}

if settings.eis_monitor_enabled:
    celery_app.conf.beat_schedule["monitor-eis-daily"] = {
        "task": "app.workers.tasks_parsing.monitor_source",
        "schedule": crontab(hour=3, minute=0),
        "args": ("zakupki_gov_ru",),
    }

if settings.marketplace_scout_enabled:
    celery_app.conf.beat_schedule["marketplace-scout-daily"] = {
        "task": "app.workers.tasks_discovery_http.discover_new_sources",
        "schedule": crontab(hour=2, minute=10),
    }

# Credentials do not prove a valid subscription.
if (settings.kontur_monitor_enabled and settings.kontur_api_base_url and settings.kontur_api_key and settings.kontur_search_path
        and (settings.kontur_api_key_header or settings.kontur_api_key_query_param)):
    celery_app.conf.beat_schedule["monitor-kontur-zakupki-4h"] = {
        "task": "app.workers.tasks_parsing.monitor_source",
        "schedule": crontab(minute=45, hour="*/4"),
        "args": ("kontur_zakupki",),
    }
