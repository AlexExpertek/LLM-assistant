"""Celery tasks for automatic marketplace tender discovery."""

from __future__ import annotations

from app.core.logging import get_logger
from app.marketplace_discovery.runner import (
    run_marketplace_discovery,
)
from app.marketplace_discovery.scout.adapter_sync import (
    sync_marketplace_adapters,
)
from app.workers.celery_app import celery_app


logger = get_logger(__name__)


@celery_app.task(
    name=(
        "app.workers.tasks_marketplace_discovery."
        "run_connected_marketplaces"
    ),
)
def run_connected_marketplaces(
    max_per_platform: int = 100,
):
    """
    Synchronize Scout with real adapters and run discovery
    only for marketplaces that have a working adapter.
    """

    sync_result = sync_marketplace_adapters()

    connected_codes = list(dict.fromkeys(
        item["adapter_code"]
        for item in sync_result["connected"]
        if item.get("adapter_code")
    ))

    if not connected_codes:
        logger.warning(
            "marketplace_discovery_no_connected_adapters"
        )

        return {
            "status": "no_connected_adapters",
            "platforms": [],
            "result": {},
        }

    logger.info(
        "marketplace_discovery_started",
        platforms=connected_codes,
        max_per_platform=max_per_platform,
    )

    result = run_marketplace_discovery(
        platforms=connected_codes,
        max_per_platform=max_per_platform,
    )

    from app.sources.run_status import record_run
    for source, outcome in result.items():
        record_run(source, **{key: value for key, value in outcome.items() if key != "errors"},
                   error_count=len(outcome.get("errors", [])))
    logger.info(
        "marketplace_discovery_finished",
        platforms=connected_codes,
        result=result,
    )

    return {
        "status": "completed" if all(v.get("status") == "ok" for v in result.values()) else "partial_or_failed",
        "platforms": connected_codes,
        "result": result,
    }
