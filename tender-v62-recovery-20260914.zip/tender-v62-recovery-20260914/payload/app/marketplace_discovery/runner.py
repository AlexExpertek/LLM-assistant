"""Search external tender marketplaces and persist matches."""

from __future__ import annotations

from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from app.marketplace_discovery.review_store import save_candidate, remove_candidate
from typing import Any

from app.core.logging import get_logger

from app.marketplace_discovery.business_filter import (
    evaluate_business_rules,
)

from app.marketplace_discovery.keywords import (
    DISCOVERY_QUERIES,
)

from app.marketplace_discovery.registry import (
    get_marketplace,
    get_marketplaces,
)

from app.sources.schemas import (
    SourceTender,
)

from app.workers.tasks_parsing import (
    process_new_tender,
)


logger = get_logger(__name__)


def marketplace_to_source_tender(
    tender,
    business,
) -> SourceTender:

    positions = []
    for p in business.positions:
        mass = p.weight_kg if p.quantity_confirmed else None
        length = p.quantity_m if p.quantity_confirmed else None
        positions.append({"name": p.description, "product_type": p.product_type, "alloy": p.alloy,
                          "quantity": mass if mass is not None else length,
                          "unit": "кг" if mass is not None else ("м" if length is not None else ""),
                          "mass_kg": mass})
    return SourceTender(
        source=tender.platform,
        external_id=str(
            tender.external_id
        ),
        title=tender.title,
        customer_name=(
            tender.customer_name
        ),
        amount=tender.amount,
        law_type="commercial",
        publish_date=(
            tender.publish_date
        ),
        submission_deadline=(
            tender.deadline
        ),
        source_url=(
            tender.source_url
        ),
        documents=[],
        raw_payload={
            "positions": positions,
            "discovery": {
                "system":
                    "marketplace_discovery",

                "search_query":
                    tender.search_query,

                "business_score":
                    business.score,

                "business_decision":
                    business.decision,

                "business_reasons":
                    business.reasons,

                "positions": [
                    {
                        "product_type":
                            position.product_type,

                        "alloy":
                            position.alloy,

                        "gosts":
                            position.gosts,

                        "quantity_m":
                            position.quantity_m,

                        "weight_kg":
                            position.weight_kg,

                        "quantity_confirmed":
                            position.quantity_confirmed,
                    }
                    for position
                    in business.positions
                ],
            },

            "raw_text":
                tender.raw_text,
        },
    )


def run_marketplace_discovery(
    *,
    platforms: list[str] | None = None,
    max_per_platform: int = 100,
) -> dict[str, Any]:

    if max_per_platform < 1:
        raise ValueError("max_per_platform must be positive")
    if platforms is not None:
        adapters = []

        for platform_code in platforms:
            adapter = get_marketplace(
                platform_code
            )

            if adapter is None:
                raise ValueError(f"Unknown marketplace: {platform_code}")
            adapters.append(adapter)

    else:
        adapters = get_marketplaces()

    summary: dict[str, Any] = {}

    for adapter in adapters:

        platform_name = (
            adapter.platform_code
        )

        seen: set[str] = set()

        discovered = 0
        relevant = 0
        persisted = 0
        expired = 0
        candidates = 0
        candidates_saved = 0
        successful_queries = 0
        rejected = 0
        errors: list[str] = []

        for query in DISCOVERY_QUERIES:

            if (
                persisted
                >= max_per_platform
            ):
                break

            try:
                items = adapter.search(
                    query
                )
                successful_queries += 1

            except Exception as exc:
                logger.exception(
                    "marketplace_search_failed",
                    platform=platform_name,
                    query=query,
                    error=str(exc),
                )

                errors.append(
                    f"{query}: "
                    f"{type(exc).__name__}: "
                    f"{exc}"
                )

                continue

            for item in items:

                if (
                    persisted
                    >= max_per_platform
                ):
                    break

                key = str(
                    item.external_id
                )

                if key in seen:
                    continue

                seen.add(key)

                discovered += 1

                #
                # Expired procedures are never persisted
                # into the active discovery/dashboard flow.
                #
                if (
                    item.deadline is not None
                    and (item.deadline if item.deadline.tzinfo else item.deadline.replace(tzinfo=ZoneInfo("Europe/Moscow")))
                    <= datetime.now(timezone.utc)
                ):
                    expired += 1
                    remove_candidate(item.platform, item.external_id)

                    logger.info(
                        "marketplace_tender_expired",
                        platform=platform_name,
                        external_id=(
                            item.external_id
                        ),
                        deadline=str(
                            item.deadline
                        ),
                    )

                    continue

                business = (
                    evaluate_business_rules(
                        item.title,
                        item.raw_text,
                    )
                )

                logger.info(
                    "marketplace_business_filter",
                    platform=platform_name,
                    external_id=(
                        item.external_id
                    ),
                    score=business.score,
                    decision=(
                        business.decision
                    ),
                    reasons=(
                        business.reasons
                    ),
                )

                #
                # Candidate is preserved statistically,
                # but not inserted into the active dashboard.
                #
                if (
                    business.decision
                    == "candidate"
                ):
                    candidates += 1
                    try:
                        save_candidate(marketplace_to_source_tender(item, business))
                        candidates_saved += 1
                    except Exception as exc:
                        errors.append(f"review:{item.external_id}:{type(exc).__name__}")
                    continue

                if not business.relevant:
                    rejected += 1
                    remove_candidate(item.platform, item.external_id)
                    continue

                relevant += 1

                source_tender = (
                    marketplace_to_source_tender(
                        item,
                        business,
                    )
                )

                try:
                    result = (
                        process_new_tender.run(
                            source_tender
                            .model_dump(
                                mode="json"
                            ),
                            launch_pipeline=False,
                        )
                    )

                    if result.get("status") not in {"ingested_only", "cached"}:
                        raise RuntimeError(f"Unexpected ingestion status: {result.get('status')}")
                    persisted += 1
                    remove_candidate(item.platform, item.external_id)

                    logger.info(
                        "marketplace_tender_persisted",
                        platform=platform_name,
                        external_id=(
                            item.external_id
                        ),
                        score=(
                            business.score
                        ),
                        decision=(
                            business.decision
                        ),
                        result=result,
                    )

                except Exception as exc:

                    logger.exception(
                        "marketplace_persist_failed",
                        platform=platform_name,
                        external_id=(
                            item.external_id
                        ),
                        error=str(exc),
                    )

                    errors.append(
                        f"{item.external_id}: "
                        f"{type(exc).__name__}: "
                        f"{exc}"
                    )

        summary[
            platform_name
        ] = {
            "status": ("partial" if successful_queries else "error") if errors else "ok",
            "discovered": discovered,
            "relevant": relevant,
            "persisted": persisted,
            "candidates": candidates,
            "candidates_saved": candidates_saved,
            "successful_queries": successful_queries,
            "rejected": rejected,
            "expired": expired,
            "errors": errors,
        }

    return summary
