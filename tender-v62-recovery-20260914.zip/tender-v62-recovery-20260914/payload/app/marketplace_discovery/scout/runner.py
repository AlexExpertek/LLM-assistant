from __future__ import annotations

from app.core.logging import get_logger

from app.marketplace_discovery.scout.store import (
    persist_candidates,
)

from app.marketplace_discovery.scout.web_scout import (
    scout_urls,
)


logger = get_logger(__name__)


DEFAULT_SEEDS = [
    "https://www.b2b-center.ru/search-tender/tendery-aliuminii/",
    "https://www.roseltorg.ru/procedures/search",
    "https://etpgpb.ru/procedures/",
    "https://zakupki.rosatom.ru/?link=brif",
    "https://etp.metal-it.ru/frame/index.html",
    "https://etp.acron.ru/app",
    "https://www.rts-tender.ru/",
    "https://www.fabrikant.ru/",
    "https://www.tektorg.ru/",
    "https://www.zakazrf.ru/",
    "https://www.lot-online.ru/",
]


def run_marketplace_scout(
    seed_urls: list[str] | None = None,
    *,
    persist: bool = True,
):
    candidates = scout_urls(
        seed_urls or DEFAULT_SEEDS
    )

    if persist:
        persisted = persist_candidates(
            candidates
        )

        logger.info(
            "marketplace_scout_persisted",
            candidates=len(candidates),
            persisted=persisted,
        )

    return candidates
