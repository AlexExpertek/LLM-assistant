"""Known and candidate tender marketplace domains."""

KNOWN_MARKETPLACES = {
    "zakupki.rosatom.ru": "Росатом",
    "etp.metal-it.ru": "METAL-IT",
    "etp.acron.ru": "Акрон",
    "zakupki.gov.ru": "ЕИС",
    "tender.pro": "Tender.Pro",
    "b2b-center.ru": "B2B-Center",
    "roseltorg.ru": "Росэлторг",
    "rts-tender.ru": "РТС-тендер",
    "etpgpb.ru": "ЭТП ГПБ",
    "new.etpgpb.ru": "ЭТП ГПБ",
    "fabrikant.ru": "Фабрикант",
    "tektorg.ru": "ТЭК-Торг",
    "zakazrf.ru": "ZakazRF",
    "lot-online.ru": "LOT-ONLINE",
}


BLOCKED_DOMAINS = {
    "google.com",
    "yandex.ru",
    "bing.com",
    "youtube.com",
    "vk.com",
    "wikipedia.org",
}
