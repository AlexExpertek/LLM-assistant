"""Internet scout for tender marketplaces.

Uses search-engine HTML endpoints only as discovery hints.
Actual marketplace integration is always performed by a
dedicated MarketplaceAdapter.
"""

from __future__ import annotations

import re
from urllib.parse import (
    parse_qs,
    quote_plus,
    urlparse,
)

import httpx

from app.core.logging import get_logger
from app.marketplace_discovery.scout.catalog import (
    BLOCKED_DOMAINS,
    KNOWN_MARKETPLACES,
)
from app.marketplace_discovery.scout.evaluator import (
    evaluate_candidate,
)
from app.marketplace_discovery.scout.schemas import (
    MarketplaceCandidate,
)


logger = get_logger(__name__)


HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) "
        "AppleWebKit/537.36 "
        "Chrome/126.0 Safari/537.36"
    ),
    "Accept-Language": "ru-RU,ru;q=0.9",
}


SCOUT_QUERIES = (
    'тендер "алюминиевый лист"',
    'тендер "алюминиевый профиль"',
    'тендер "алюминиевая труба"',
    'закупка "алюминиевый пруток"',
    'закупка "алюминиевый круг"',
    'закупка "АМг5"',
    'закупка "АД31"',
    'закупка "Д16"',
    'закупка "5083"',
    'закупка "6063"',
)


def _registrable_domain(
    url: str,
) -> str | None:
    try:
        host = (
            urlparse(url)
            .hostname
            or ""
        ).lower()
    except Exception:
        return None

    if host.startswith("www."):
        host = host[4:]

    return host or None


def _extract_links(
    html_text: str,
) -> list[str]:

    links = re.findall(
        r'''href=["'](?P<url>https?://[^"']+)["']''',
        html_text,
        flags=re.I,
    )

    return links


def _probe(
    url: str,
    *,
    timeout: float = 20.0,
) -> str | None:

    try:
        with httpx.Client(
            headers=HEADERS,
            timeout=timeout,
            follow_redirects=True,
        ) as client:
            response = client.get(url)

        if response.status_code != 200:
            return None

        content_type = (
            response.headers
            .get("content-type", "")
            .lower()
        )

        if "text/html" not in content_type:
            return None

        return response.text

    except Exception as exc:
        logger.info(
            "marketplace_scout_probe_failed",
            url=url,
            error=str(exc),
        )
        return None


def scout_urls(
    seed_urls: list[str],
) -> list[MarketplaceCandidate]:

    candidates = {}

    for url in seed_urls:

        domain = _registrable_domain(url)

        if not domain:
            continue

        if domain in BLOCKED_DOMAINS:
            continue

        if domain in candidates:
            continue

        html_text = _probe(url)

        candidate = MarketplaceCandidate(
            domain=domain,
            name=KNOWN_MARKETPLACES.get(domain),
            discovered_url=url,
        )

        if not html_text:
            candidate.reasons = ["probe_failed:unavailable_or_non_html"]
        elif any(marker in html_text.lower() for marker in (
            "web application firewall", "ваш веб-браузер не поддерживается", "access denied",
            "подтвердите, что вы", "g-recaptcha", "hcaptcha",
        )):
            candidate.reasons = ["probe_failed:access_challenge_or_browser_required"]
        else:
            candidate = evaluate_candidate(candidate, html_text)

        candidates[domain] = candidate

    return sorted(
        candidates.values(),
        key=lambda item: (
            item.integration_score,
            item.aluminium_hits,
        ),
        reverse=True,
    )
