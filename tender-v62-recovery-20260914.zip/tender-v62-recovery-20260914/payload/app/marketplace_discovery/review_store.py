"""Durable review inbox, separate from qualified dashboard and notifications."""
import hashlib
import json
import os
import tempfile
from pathlib import Path

from app.core.config import settings


def _directory():
    return Path(settings.storage_path) / "marketplace_review"


def _path(source, external_id):
    digest = hashlib.sha256(f"{source}\0{external_id}".encode()).hexdigest()
    return _directory() / f"{digest}.json"


def save_candidate(tender):
    path = _path(tender.source, tender.external_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(tender.model_dump(mode="json"), stream, ensure_ascii=False)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def remove_candidate(source, external_id):
    _path(source, external_id).unlink(missing_ok=True)


def list_review_candidates(limit=100):
    rows = []
    files = sorted(_directory().glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    for path in files[:limit]:
        try:
            rows.append(json.loads(path.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            continue
    return rows
