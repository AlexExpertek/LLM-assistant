"""Public discovery adapter for B2B-Center."""

from __future__ import annotations

import html
import re
from datetime import datetime
from zoneinfo import ZoneInfo
from decimal import Decimal, InvalidOperation
from urllib.parse import urljoin

import httpx

from app.core.logging import get_logger
from app.marketplace_discovery.platforms.base import (
    MarketplaceAdapter,
)
from app.marketplace_discovery.schemas import (
    MarketplaceTender,
)


logger = get_logger(__name__)

BASE_URL = "https://www.b2b-center.ru"
SEARCH_URL = BASE_URL + "/market/"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) "
        "AppleWebKit/537.36 "
        "Chrome/126.0 Safari/537.36"
    ),
    "Accept": (
        "text/html,application/xhtml+xml,"
        "application/xml;q=0.9,*/*;q=0.8"
    ),
    "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.7",
}


def _plain(value: str) -> str:
    value = re.sub(
        r"<script.*?</script>|<style.*?</style>",
        " ",
        value,
        flags=re.I | re.S,
    )

    value = re.sub(
        r"<[^>]+>",
        " ",
        value,
    )

    value = html.unescape(value)

    return re.sub(
        r"\s+",
        " ",
        value,
    ).strip()


def _parse_datetime(
    value: str | None,
) -> datetime | None:
    if not value:
        return None

    value = value.strip()

    for fmt in (
        "%d.%m.%Y %H:%M",
        "%d.%m.%Y",
    ):
        try:
            return datetime.strptime(
                value,
                fmt,
            ).replace(tzinfo=ZoneInfo("Europe/Moscow"))
        except ValueError:
            pass

    return None


def _parse_amount(
    value: str | None,
) -> Decimal | None:
    if not value:
        return None

    normalized = (
        value
        .replace("\xa0", "")
        .replace(" ", "")
        .replace(",", ".")
    )

    match = re.search(
        r"\d+(?:\.\d+)?",
        normalized,
    )

    if not match:
        return None

    try:
        return Decimal(match.group(0))
    except InvalidOperation:
        return None


class B2BCenterDiscoveryClient(
    MarketplaceAdapter
):
    platform_code = "b2b_center"
    platform_name = "B2B-Center"

    def __init__(
        self,
        *,
        verify: bool = True,
        timeout: float = 40.0,
    ):
        self.verify = verify
        self.timeout = timeout

    def search(
        self,
        query: str,
        *,
        page: int = 1,
    ) -> list[MarketplaceTender]:

        # Bare numeric alloy queries are interpreted as procedure numbers.
        search_query = f"алюминий {query.strip()}" if query.strip().isdigit() else query
        params = {
            "f_keyword": search_query,
            "searching": "1",
            "trade": "buy",
        }

        if page > 1:
            params["page"] = str(page)

        with httpx.Client(
            verify=self.verify,
            timeout=self.timeout,
            follow_redirects=True,
            headers=HEADERS,
        ) as client:
            response = client.get(
                SEARCH_URL,
                params=params,
            )

            response.raise_for_status()

        logger.info(
            "b2b_center_search_response",
            query=query,
            page=page,
            status=response.status_code,
            final_url=str(response.url),
            bytes=len(response.content),
        )

        return self._parse(
            response.text,
            query=query,
        )

    def _parse(
        self,
        html_text: str,
        *,
        query: str,
    ) -> list[MarketplaceTender]:

        lowered = html_text.lower()
        if any(marker in lowered for marker in ("g-recaptcha", "hcaptcha", "подтвердите, что вы", "доступ ограничен", "access denied")):
            raise RuntimeError("B2B-Center access challenge; no search result available")
        if "search-results-title" not in lowered and not any(
            marker in lowered for marker in ("ничего не найдено", "по вашему запросу", "найдено 0", "нет торгов")
        ):
            raise RuntimeError("B2B-Center search layout not recognized")
        results: list[MarketplaceTender] = []
        seen: set[str] = set()

        #
        # A B2B result is represented by a table row.
        # Restrict parsing to rows containing
        # search-results-title so neighbouring HTML
        # cannot contaminate the tender.
        #
        rows = re.findall(
            r"<tr\b[^>]*>(.*?)</tr>",
            html_text,
            flags=re.I | re.S,
        )

        for row in rows:

            if "search-results-title" not in row:
                continue

            link_match = re.search(
                r'''<a\b[^>]*'''
                r'''href=["'](?P<url>[^"']*'''
                r'''/tender-(?P<id>\d+)'''
                r'''/[^"']*)["'][^>]*'''
                r'''class=["'][^"']*'''
                r'''search-results-title[^"']*["']'''
                r'''[^>]*>(?P<body>.*?)</a>''',
                row,
                flags=re.I | re.S,
            )

            if not link_match:
                #
                # Some pages place class before href.
                #
                link_match = re.search(
                    r'''<a\b[^>]*'''
                    r'''class=["'][^"']*'''
                    r'''search-results-title[^"']*["']'''
                    r'''[^>]*href=["'](?P<url>[^"']*'''
                    r'''/tender-(?P<id>\d+)'''
                    r'''/[^"']*)["'][^>]*>'''
                    r'''(?P<body>.*?)</a>''',
                    row,
                    flags=re.I | re.S,
                )

            if not link_match:
                continue

            external_id = link_match.group("id")

            if external_id in seen:
                continue

            seen.add(external_id)

            raw_url = html.unescape(
                link_match.group("url")
            )

            body = link_match.group("body")

            #
            # Description is contained in
            # search-results-title-desc.
            #
            desc_match = re.search(
                r'''<div\b[^>]*class=["']'''
                r'''search-results-title-desc["'][^>]*>'''
                r'''(?P<desc>.*?)</div>\s*</div>''',
                body,
                flags=re.I | re.S,
            )

            if desc_match:
                description_html = (
                    desc_match.group("desc")
                )
            else:
                description_html = body

            description = _plain(
                description_html
            )

            #
            # Remove the procedure prefix from title.
            #
            body_text = _plain(body)

            title = re.sub(
                rf"^(?:Запрос\s+предложений|"
                rf"Запрос\s+цен|Тендер|"
                rf"Процедура)\s*№?\s*"
                rf"{re.escape(external_id)}\s*",
                "",
                body_text,
                flags=re.I,
            ).strip()

            #
            # Prefer first description before the
            # highlighted search-context snippet.
            #
            highlighted_pos = re.search(
                r'<div\b[^>]*style=["\'][^"\']*'
                r'color\s*:\s*#?888',
                description_html,
                flags=re.I,
            )

            if highlighted_pos:
                clean_title = _plain(
                    description_html[
                        :highlighted_pos.start()
                    ]
                )

                if clean_title:
                    title = clean_title

            if not title:
                title = (
                    f"B2B-Center procedure "
                    f"{external_id}"
                )

            #
            # Cells after the procedure cell:
            # customer / published / deadline.
            #
            cells = re.findall(
                r"<td\b[^>]*>(.*?)</td>",
                row,
                flags=re.I | re.S,
            )

            customer_name = None
            publish_date = None
            deadline = None
            amount = None

            if len(cells) >= 2:
                customer_name = _plain(
                    cells[-4]
                    if len(cells) >= 4
                    else cells[1]
                ) or None

            dates = re.findall(
                r"\b\d{2}\.\d{2}\.\d{4}"
                r"(?:\s+\d{2}:\d{2})?\b",
                _plain(row),
            )

            if dates:
                publish_date = (
                    _parse_datetime(dates[0])
                )

            if len(dates) >= 2:
                deadline = (
                    _parse_datetime(dates[1])
                )

            #
            # Preserve the complete row as raw_text.
            # Relevance engine can inspect snippets
            # returned by B2B search.
            #
            raw_text = _plain(row)

            source_url = urljoin(
                BASE_URL,
                raw_url,
            )

            results.append(
                MarketplaceTender(
                    platform=self.platform_code,
                    external_id=external_id,
                    title=title[:1500],
                    customer_name=customer_name,
                    amount=amount,
                    publish_date=publish_date,
                    deadline=deadline,
                    source_url=source_url,
                    search_query=query,
                    raw_text=raw_text[:10000],
                )
            )

        logger.info(
            "b2b_center_search_parsed",
            query=query,
            count=len(results),
        )

        return results
