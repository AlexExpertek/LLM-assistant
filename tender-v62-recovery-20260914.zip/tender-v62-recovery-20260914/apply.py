#!/usr/bin/env python3
"""Apply only audited files; refuses a changed server tree. No DB or .env changes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
from datetime import datetime, timezone


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def safe_path(root, name):
    relative = Path(name)
    if relative.is_absolute() or ".." in relative.parts:
        raise SystemExit("Unsafe package path")
    path = root / relative
    if path.resolve() != path.absolute():
        raise SystemExit(f"Symbolic links are not supported: {name}")
    return path


def atomic_copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(dir=target.parent)
    os.close(fd)
    try:
        shutil.copy2(source, temp)
        os.replace(temp, target)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    project = args.project.resolve()
    package = Path(__file__).resolve().parent
    manifest = json.loads((package / "manifest.json").read_text())
    pending = []
    for row in manifest:
        target = safe_path(project, row["path"])
        payload = safe_path(package / "payload", row["path"])
        if digest(payload) != row["after"]:
            raise SystemExit(f"Package checksum mismatch: {row['path']}")
        actual = digest(target)
        if actual == row["after"]:
            continue
        if actual != row["before"]:
            raise SystemExit(f"Server file differs from uploaded snapshot: {row['path']}. No files changed.")
        pending.append(row)
    print(f"Checked: {len(manifest)} files; updates required: {len(pending)}")
    if args.check or not pending:
        return
    backup = Path(tempfile.mkdtemp(prefix="tender-v62-backup-", dir=project.parent))
    os.chmod(backup, 0o700)
    for row in pending:
        original = safe_path(project, row["path"])
        if original.is_file():
            atomic_copy(original, backup / "files" / row["path"])
    (backup / "manifest.json").write_text(json.dumps(pending, indent=2))
    (backup / "project.txt").write_text(str(project))
    shutil.copy2(package / "rollback.py", backup / "rollback.py")
    applied = []
    try:
        for row in pending:
            target = safe_path(project, row["path"])
            if digest(target) != row["before"]:
                raise RuntimeError(f"File changed during installation: {row['path']}")
            atomic_copy(package / "payload" / row["path"], target)
            applied.append(row)
    except BaseException:
        for row in reversed(applied):
            target = safe_path(project, row["path"])
            if row["before"] is None:
                target.unlink(missing_ok=True)
            else:
                atomic_copy(backup / "files" / row["path"], target)
        raise
    print("Applied. Backup:", backup)
    print("Next: build and validate images; then restart application services.")


if __name__ == "__main__":
    main()
