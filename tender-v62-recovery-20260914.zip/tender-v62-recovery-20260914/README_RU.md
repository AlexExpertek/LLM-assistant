# Установка исправлений v6.2

Это точечное обновление к архиву от 14.09.2026. Не заменяйте весь проект этим каталогом: внутри только изменённые файлы.
Исправления подготовлены и проверены локально; рабочий сервер ещё не обновлён.

## 1. Перенос на сервер

Скачайте tender-v62-recovery-20260914.zip. Загрузите его в /home/stdadmin через SCP (команду запускайте в PowerShell компьютера):

```powershell
scp "$env:USERPROFILE\Downloads\tender-v62-recovery-20260914.zip" stdadmin@SERVER_IP:/home/stdadmin/
```

SERVER_IP замените адресом, с которым вы подключаетесь к серверу. При нестандартном SSH-порте используйте `scp -P НОМЕР_ПОРТА ...`.

## 2. Применение на сервере

```bash
cd /home/stdadmin
unzip tender-v62-recovery-20260914.zip
bash tender-v62-recovery-20260914/install.sh
```

Установщик сверяет хеши изменяемых файлов с присланной версией, создаёт резервную копию рядом с каталогом проекта, затем заменяет только перечисленные в manifest.json файлы. `.env`, docker-compose.yml, Dockerfile, данные PostgreSQL/Redis и существующее содержимое storage не заменяются; миграций БД нет.

Исходный Compose встраивает код в образы. Поэтому установщик пересобирает app, celery_worker, celery_beat, flower. До перезапуска проверяет импорт и основные контракты в новом образе. При ошибке сборки работающие контейнеры продолжают использовать старые образы; исправленные файлы остаются на диске, путь отката уже выведен.

Перезапуск ненадолго прерывает приложение и обработчики. При ошибке после остановки beat планировщик остаётся остановленным — смотрите вывод и выполните откат. Не запускайте второй beat вручную.

Если вывод говорит `Server file differs ...`, установщик ничего не меняет. Пришлите имя отличающегося файла: это защита ваших более поздних изменений. Не удаляйте проверку хешей.

## 3. Проверка после установки

```bash
cd /home/stdadmin/LLM-assistant/tender-ai-platform-v6.2
bash scripts/check_recovery.sh
```

Первый контролируемый проход B2B и проверка адресов площадок:

```bash
docker compose exec -T celery_worker python - <<'PY'
from app.workers.tasks_marketplace_discovery import run_connected_marketplaces
from app.workers.tasks_discovery_http import discover_new_sources
print("B2B task:", run_connected_marketplaces.delay(max_per_platform=100).id)
print("Scout task:", discover_new_sources.delay().id)
PY
```

Через несколько минут снова выполните `bash scripts/check_recovery.sh` и пришлите вывод. Не повторяйте постановку задач, пока первый проход не завершился.

Доступны локальные адреса:
- http://127.0.0.1:8000/marketplaces/source-runs — последнее состояние источников; время UTC.
- http://127.0.0.1:8000/marketplaces/review — кандидаты с неизвестным объёмом, не список допущенных закупок.
- http://127.0.0.1:8000/marketplaces/discovered — проверенные адреса площадок и оценки интеграции.

Для браузера на другом компьютере вместо 127.0.0.1 используйте привычный адрес вашего приложения. Исходные настройки доступа этим пакетом не меняются.

ЕИС запустится в 03:00 МСК; Tender.Pro и B2B — по прежнему расписанию. Контур продолжит давать blocked, пока не восстановлен доступ по подписке; это не устраняется перезапуском Docker.

## Настройки, при необходимости

Новые необязательные переменные .env (значения по умолчанию):

```dotenv
EIS_MONITOR_ENABLED=true
KONTUR_MONITOR_ENABLED=true
MARKETPLACE_SCOUT_ENABLED=true
LLM_READ_TIMEOUT_SECONDS=120
LLM_TOTAL_TIMEOUT_SECONDS=180
```

Чтобы временно отключить Контур, задайте `KONTUR_MONITOR_ENABLED=false`, затем пересоздайте `celery_beat`. При изменении тайм-аутов пересоздайте `app celery_worker celery_beat flower`. Не присылайте значения ключей API.

## Откат

Установщик напечатает абсолютный путь резервной копии `tender-v62-backup-...`.

```bash
cd /home/stdadmin/LLM-assistant/tender-ai-platform-v6.2
docker compose stop celery_beat
python3 /ПОЛНЫЙ_ПУТЬ_РЕЗЕРВНОЙ_КОПИИ/rollback.py
docker compose build app celery_worker celery_beat flower
docker compose up -d --no-deps --force-recreate app celery_worker celery_beat flower
```

Подставьте напечатанный путь. Откат вернёт изменённые файлы, удалит только новые файлы обновления, не затронет данные. Он остановится, если файлы редактировали после установки. Старое состояние источников/список проверки в storage останутся как диагностические данные.

Подробности и ограничения: docs/REPORT_RU.md.
