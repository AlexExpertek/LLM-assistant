"""Restore patch-owned files only; run from the backup directory."""
import hashlib
import json
from pathlib import Path
import shutil

base = Path(__file__).resolve().parent
project = Path((base / "project.txt").read_text())
rows = json.loads((base / "manifest.json").read_text())
for row in rows:
    path = project / row["path"]
    if path.is_symlink() or path.resolve() != path.absolute():
        raise SystemExit("Symbolic link detected; rollback stopped")
    actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
    if actual not in (row["before"], row["after"]):
        raise SystemExit(f"Modified since update: {row['path']}. No files changed.")
for row in rows:
    target = project / row["path"]
    if row["before"] is None:
        target.unlink(missing_ok=True)
    else:
        shutil.copy2(base / "files" / row["path"], target)
print("Source files restored. Rebuild and recreate application services to activate rollback.")
