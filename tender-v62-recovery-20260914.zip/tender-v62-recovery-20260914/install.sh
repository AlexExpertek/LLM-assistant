#!/usr/bin/env bash
set -Eeuo pipefail
PATCH_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="${1:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
cd "$PROJECT_DIR"
docker compose config --quiet
python3 "$PATCH_DIR/apply.py" "$PROJECT_DIR" --check
python3 "$PATCH_DIR/apply.py" "$PROJECT_DIR"
# The uploaded Compose embeds source code in images. Rebuild is necessary.
docker compose build app celery_worker celery_beat flower
docker compose run --rm --no-deps app python scripts/verify_recovery.py
# Stop the old scheduler before activating the updated application and worker.
docker compose stop celery_beat
if ! docker compose up -d --no-deps --force-recreate app celery_worker flower; then
    echo 'Application restart failed. Scheduler is stopped. Use the printed backup to roll back.' >&2
    exit 1
fi
WORKER_READY=0
for ATTEMPT in 1 2 3 4 5; do
    if docker compose exec -T celery_worker celery -A app.workers.celery_app inspect ping --timeout=5; then
        WORKER_READY=1
        break
    fi
    sleep 2
done
if [ "$WORKER_READY" -ne 1 ]; then
    echo 'Worker did not respond. Scheduler remains stopped. Check logs or roll back.' >&2
    exit 1
fi
docker compose up -d --no-deps --force-recreate celery_beat
docker compose ps -a
echo 'Update installed. Run: bash scripts/check_recovery.sh'
