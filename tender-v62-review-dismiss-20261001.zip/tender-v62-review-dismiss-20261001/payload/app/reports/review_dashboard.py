"""Read-only review inbox: DB tenders and marketplace candidates."""
from datetime import datetime, timezone
from sqlalchemy import select
from app.db.session import SyncSessionLocal
from app.models.database import Tender, Decision, TenderStatus
from app.marketplace_discovery.review_store import list_review_candidates


def assemble(rows, candidates, now=None):
    now = now or datetime.now(timezone.utc)
    merged = {}
    for row in list(rows) + list(candidates):
        row = dict(row)
        key = (row.get('source'), str(row.get('external_id') or ''))
        if not all(key) or key in merged:
            continue
        deadline = row.get('submission_deadline')
        try:
            dt = datetime.fromisoformat(str(deadline).replace('Z', '+00:00')) if deadline else None
            if dt and dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
        except ValueError:
            dt = None
        if dt and dt <= now: continue
        row['submission_deadline'] = dt.isoformat() if dt else None
        row['deadline_unknown'] = dt is None
        merged[key] = row
    return sorted(merged.values(), key=lambda r: (r['deadline_unknown'], r['submission_deadline'] or '', r.get('title') or ''))


def get_review_dashboard():
    rows=[]
    with SyncSessionLocal() as s:
        tenders=s.execute(select(Tender).where(Tender.is_active.is_(True),
            Tender.status.in_([TenderStatus.MANUAL_REVIEW, TenderStatus.NEEDS_CLARIFICATION]))).scalars().all()
        ids=[t.id for t in tenders]
        decisions={}
        if ids:
            for d in s.execute(select(Decision).where(Decision.tender_id.in_(ids)).order_by(Decision.created_at.desc())).scalars():
                decisions.setdefault(str(d.tender_id), d)
        for t in tenders:
            raw=t.raw_payload or {}
            # Explicit title-based exclusions are not pending specification checks.
            if (raw.get('subject_screening') or {}).get('subject_type') in ('works_service','finished_product'):continue
            d=decisions.get(str(t.id))
            rows.append({'source':t.source,'external_id':t.external_id,'title':t.title,
                'source_url':t.source_url,'submission_deadline':t.submission_deadline,
                'status':getattr(t.status,'value',t.status),
                'analysis_done':bool(t.analysis_done),
                'reason':'; '.join(str(x) for x in (d.reasons or [])) if d else 'Требуется проверка данных или завершение анализа'})
    candidates=[]
    for c in list_review_candidates(500):
        candidates.append({'source':c.get('source'),'external_id':c.get('external_id'),
            'title':c.get('title'),'source_url':c.get('source_url'),
            'submission_deadline':c.get('submission_deadline'),'status':'candidate',
            'analysis_done':False,'reason':'Кандидат площадки: требуется подтвердить позиции и объём; полный анализ не выполнен'})
    from app.reports.review_dismissals import is_dismissed
    items=[r for r in assemble(rows,candidates) if not is_dismissed(r["source"], r["external_id"])]
    return {'count':len(items),'tenders':items,'candidate_limit':500}
