"""Persistent manual exclusions from the review inbox; tender history is retained."""
import hashlib
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from app.core.config import settings

def path_for(source, external_id):
    key = hashlib.sha256(f"{source}\0{external_id}".encode()).hexdigest()
    return Path(settings.storage_path) / "review_dismissals" / (key + ".json")

def is_dismissed(source, external_id):
    return path_for(source, external_id).is_file()

def set_dismissed(source, external_id, dismissed=True):
    path = path_for(source, external_id)
    if not dismissed:
        path.unlink(missing_ok=True)
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(dict(source=source, external_id=external_id,
                reason="Не подходит после ручной проверки",
                recorded_at=datetime.now(timezone.utc).isoformat()), stream, ensure_ascii=False)
        os.replace(name, path)
    finally:
        if os.path.exists(name): os.unlink(name)
