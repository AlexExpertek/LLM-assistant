#!/usr/bin/env bash
set -Eeuo pipefail
PACKAGE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd /home/stdadmin/LLM-assistant/tender-ai-platform-v6.2
python3 "$PACKAGE_DIR/apply.py" "$PWD"
docker compose config --quiet
docker compose build app
docker compose run --rm --no-deps -T app python - < "$PACKAGE_DIR/verify.py"
docker compose up -d --no-deps --timeout 60 app
echo REVIEW_DISMISS_UPDATE_INSTALLED
