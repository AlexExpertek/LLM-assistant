import tempfile
from pathlib import Path
from app.reports import review_dismissals as m
from app.main import app
original = m.settings
class Settings: pass
try:
    with tempfile.TemporaryDirectory() as directory:
        m.settings = Settings(); m.settings.storage_path = directory
        assert not m.is_dismissed("b2b_center", "123")
        m.set_dismissed("b2b_center", "123")
        assert m.is_dismissed("b2b_center", "123")
        assert not m.is_dismissed("zakupki_gov_ru", "123")
        m.set_dismissed("b2b_center", "123")
        assert len(list(Path(directory).rglob("*.json"))) == 1
        m.set_dismissed("b2b_center", "123", False)
        m.set_dismissed("b2b_center", "123", False)
        assert not m.is_dismissed("b2b_center", "123")
finally:
    m.settings = original
assert any(r.path == "/tenders/review/dismiss" for r in app.routes)
print("REVIEW_DISMISS_CHECKS_OK: durable exclusion, source isolation, undo; temporary files only")
