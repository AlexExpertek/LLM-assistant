class Bitrix24Error(RuntimeError):
    """Base error for Bitrix24 REST integration."""


class Bitrix24ConfigurationError(Bitrix24Error):
    """Raised when required Bitrix24 settings are missing."""


class Bitrix24APIError(Bitrix24Error):
    """Raised when Bitrix24 returns an API error."""
