from __future__ import annotations
from datetime import date, datetime
from typing import Any


def _iso(value: Any) -> Any:
    return value.isoformat() if isinstance(value, (datetime, date)) else value


def build_bitrix_fields(tender: dict[str, Any], analysis: dict[str, Any], field_map: dict[str, str]) -> dict[str, Any]:
    values = {
        "external_id": tender.get("external_id"),
        "source": tender.get("source"),
        "source_url": tender.get("source_url"),
        "customer_name": tender.get("customer_name"),
        "customer_inn": tender.get("customer_inn"),
        "amount": tender.get("amount"),
        "region": tender.get("region"),
        "submission_deadline": _iso(tender.get("submission_deadline")),
        "law_type": tender.get("law_type"),
        "decision": analysis.get("decision"),
        "score": analysis.get("score"),
        "match_percent": analysis.get("match_percent"),
        "matched_products": analysis.get("matched_products"),
        "recommended_alloys": analysis.get("recommended_alloys"),
        "llm_summary": analysis.get("summary"),
        "risks": analysis.get("risks"),
        "report_url": analysis.get("report_url"),
    }
    fields: dict[str, Any] = {"title": (tender.get("title") or f"Тендер {tender.get('external_id', '')}")[:255]}
    for semantic_name, bitrix_field in field_map.items():
        value = values.get(semantic_name)
        if value is None or value == "":
            continue
        if isinstance(value, (list, tuple, set)):
            value = "\n".join(str(item) for item in value)
        fields[bitrix_field] = value
    return fields
