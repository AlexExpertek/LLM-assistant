from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any

import httpx

from .exceptions import Bitrix24APIError, Bitrix24ConfigurationError

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Bitrix24Settings:
    webhook_url: str
    entity_type_id: int
    timeout_seconds: float = 30.0
    max_retries: int = 3

    def __post_init__(self) -> None:
        webhook = self.webhook_url.strip().rstrip("/")
        if not webhook:
            raise Bitrix24ConfigurationError("BITRIX24_WEBHOOK_URL is empty")
        if "/rest/" not in webhook:
            raise Bitrix24ConfigurationError("Invalid Bitrix24 inbound webhook URL")
        if self.entity_type_id <= 0:
            raise Bitrix24ConfigurationError("BITRIX24_ENTITY_TYPE_ID must be positive")
        object.__setattr__(self, "webhook_url", webhook)


class Bitrix24Client:
    def __init__(self, settings: Bitrix24Settings) -> None:
        self.settings = settings

    async def call(self, method: str, payload: dict[str, Any] | None = None) -> Any:
        url = f"{self.settings.webhook_url}/{method}.json"
        last_error: Exception | None = None
        async with httpx.AsyncClient(timeout=self.settings.timeout_seconds, follow_redirects=True) as client:
            for attempt in range(1, self.settings.max_retries + 1):
                try:
                    response = await client.post(url, json=payload or {})
                    response.raise_for_status()
                    data = response.json()
                    if "error" in data:
                        raise Bitrix24APIError(f"{data.get('error')}: {data.get('error_description', '')}")
                    return data.get("result")
                except (httpx.HTTPError, ValueError, Bitrix24APIError) as exc:
                    last_error = exc
                    logger.warning("bitrix24_call_failed", extra={"method": method, "attempt": attempt, "error": str(exc)})
                    if attempt < self.settings.max_retries:
                        await asyncio.sleep(min(2 ** (attempt - 1), 8))
        raise Bitrix24APIError(f"Bitrix24 method {method!r} failed: {last_error}")

    async def get_fields(self) -> dict[str, Any]:
        result = await self.call("crm.item.fields", {"entityTypeId": self.settings.entity_type_id})
        return result if isinstance(result, dict) else {}

    async def find_by_external_id(self, external_field: str, external_id: str) -> dict[str, Any] | None:
        result = await self.call("crm.item.list", {
            "entityTypeId": self.settings.entity_type_id,
            "filter": {external_field: external_id},
            "select": ["id", "title", external_field],
            "start": 0,
        })
        if not isinstance(result, dict):
            return None
        items = result.get("items") or []
        return items[0] if items else None

    async def create_item(self, fields: dict[str, Any]) -> int:
        result = await self.call("crm.item.add", {"entityTypeId": self.settings.entity_type_id, "fields": fields})
        item_id = result.get("item", {}).get("id") if isinstance(result, dict) else None
        if not item_id:
            raise Bitrix24APIError(f"Unexpected crm.item.add result: {result!r}")
        return int(item_id)

    async def update_item(self, item_id: int, fields: dict[str, Any]) -> int:
        result = await self.call("crm.item.update", {"entityTypeId": self.settings.entity_type_id, "id": item_id, "fields": fields})
        updated_id = result.get("item", {}).get("id") if isinstance(result, dict) else None
        if not updated_id:
            raise Bitrix24APIError(f"Unexpected crm.item.update result: {result!r}")
        return int(updated_id)

    async def upsert_item(self, *, external_field: str, external_id: str, fields: dict[str, Any]) -> tuple[int, str]:
        existing = await self.find_by_external_id(external_field, external_id)
        if existing:
            return await self.update_item(int(existing["id"]), fields), "updated"
        return await self.create_item(fields), "created"
