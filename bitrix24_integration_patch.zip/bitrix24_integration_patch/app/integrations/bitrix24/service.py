from __future__ import annotations
import json
import os
from typing import Any
from .client import Bitrix24Client, Bitrix24Settings
from .exceptions import Bitrix24ConfigurationError
from .mapper import build_bitrix_fields


def load_field_map() -> dict[str, str]:
    raw = os.getenv("BITRIX24_FIELD_MAP_JSON", "").strip()
    if not raw:
        raise Bitrix24ConfigurationError("BITRIX24_FIELD_MAP_JSON is empty")
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise Bitrix24ConfigurationError(f"Invalid BITRIX24_FIELD_MAP_JSON: {exc}") from exc
    if not isinstance(value, dict) or not value:
        raise Bitrix24ConfigurationError("BITRIX24_FIELD_MAP_JSON must be a non-empty object")
    return {str(k): str(v) for k, v in value.items()}


def build_client() -> Bitrix24Client:
    return Bitrix24Client(Bitrix24Settings(
        webhook_url=os.getenv("BITRIX24_WEBHOOK_URL", ""),
        entity_type_id=int(os.getenv("BITRIX24_ENTITY_TYPE_ID", "0")),
        timeout_seconds=float(os.getenv("BITRIX24_TIMEOUT_SECONDS", "30")),
        max_retries=int(os.getenv("BITRIX24_MAX_RETRIES", "3")),
    ))


async def sync_tender_to_bitrix24(tender: dict[str, Any], analysis: dict[str, Any]) -> dict[str, Any]:
    client = build_client()
    field_map = load_field_map()
    external_field = field_map.get("external_id")
    external_id = str(tender.get("external_id") or "").strip()
    if not external_field:
        raise Bitrix24ConfigurationError("Field map must contain 'external_id'")
    if not external_id:
        raise Bitrix24ConfigurationError("Tender external_id is empty")
    fields = build_bitrix_fields(tender, analysis, field_map)
    item_id, action = await client.upsert_item(external_field=external_field, external_id=external_id, fields=fields)
    return {"status": "success", "action": action, "entity_type_id": client.settings.entity_type_id, "item_id": item_id, "external_id": external_id}
