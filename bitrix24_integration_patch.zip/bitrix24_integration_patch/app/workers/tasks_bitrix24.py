from __future__ import annotations
import asyncio
from typing import Any
from app.integrations.bitrix24.service import sync_tender_to_bitrix24
from app.workers.celery_app import celery_app


@celery_app.task(
    bind=True,
    autoretry_for=(Exception,),
    retry_backoff=True,
    retry_backoff_max=300,
    retry_jitter=True,
    retry_kwargs={"max_retries": 5},
    name="app.workers.tasks_bitrix24.sync_tender_to_bitrix24_task",
)
def sync_tender_to_bitrix24_task(self, tender: dict[str, Any], analysis: dict[str, Any]) -> dict[str, Any]:
    return asyncio.run(sync_tender_to_bitrix24(tender, analysis))
