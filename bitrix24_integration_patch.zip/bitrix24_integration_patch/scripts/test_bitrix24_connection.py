import asyncio
import json
from app.integrations.bitrix24.service import build_client

async def main() -> None:
    client = build_client()
    fields = await client.get_fields()
    print(json.dumps({"status": "success", "entity_type_id": client.settings.entity_type_id, "field_count": len(fields.get("fields", fields))}, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    asyncio.run(main())
