import asyncio
import json
from uuid import uuid4
from app.integrations.bitrix24.service import sync_tender_to_bitrix24

async def main() -> None:
    external_id = f"TEST-{uuid4().hex[:8]}"
    tender = {"external_id": external_id, "source": "manual_test", "source_url": "https://example.org/tender/test", "title": "Тестовая карточка LLM Tender Assistant", "customer_name": "Тестовый заказчик", "customer_inn": "0000000000", "amount": 1000000, "region": "Москва", "law_type": "commercial", "submission_deadline": None}
    analysis = {"decision": "REVIEW", "score": 75, "match_percent": 82, "matched_products": ["Алюминиевая лента"], "recommended_alloys": ["А5", "АД0"], "summary": "Тест интеграции. Карточку можно удалить.", "risks": ["Тестовая запись"], "report_url": ""}
    print(json.dumps(await sync_tender_to_bitrix24(tender, analysis), ensure_ascii=False, indent=2))

if __name__ == "__main__":
    asyncio.run(main())
