# Интеграция LLM Tender Assistant с Битрикс24

Пакет добавляет асинхронный REST-клиент Битрикс24, защиту от дублей по `external_id`, Celery-задачу и два теста.

## 1. Создайте смарт-процесс «Тендеры»

Рекомендуется отдельный смарт-процесс, а не обычная воронка сделок. Создайте поля: ID тендера, источник, URL, заказчик, ИНН, сумма, регион, срок подачи, тип закупки, решение GO/REVIEW/NO GO, скоринг, процент совпадения, продукция, сплавы, резюме LLM, риски и ссылка на отчёт.

## 2. Создайте входящий вебхук

Права: CRM; чтение и изменение выбранного смарт-процесса. Право «Диск» понадобится позднее для загрузки PDF/Excel.

## 3. Скопируйте файлы

```bash
cp -R app/integrations/bitrix24 ~/LLM-assistant/tender-ai-platform/app/integrations/
cp app/workers/tasks_bitrix24.py ~/LLM-assistant/tender-ai-platform/app/workers/
cp scripts/test_bitrix24_*.py ~/LLM-assistant/tender-ai-platform/scripts/
```

## 4. Добавьте зависимость

Если `httpx` отсутствует:

```text
httpx>=0.27,<1
```

## 5. Подключите Celery-задачу

В `app/workers/celery_app.py` добавьте в `include`:

```python
"app.workers.tasks_bitrix24",
```

## 6. Заполните `.env`

Перенесите параметры из `.env.bitrix24.example`. `BITRIX24_ENTITY_TYPE_ID` — ID смарт-процесса. `BITRIX24_FIELD_MAP_JSON` связывает внутренние названия с реальными кодами полей Bitrix24.

## 7. Проверьте подключение

```bash
docker compose run --rm app python scripts/test_bitrix24_connection.py
```

## 8. Проверьте создание карточки

```bash
docker compose run --rm app python scripts/test_bitrix24_upsert.py
```

После проверки удалите тестовую карточку.

## 9. Пересоздайте worker

```bash
docker compose up -d --build --force-recreate celery_worker

docker compose exec celery_worker \
  celery -A app.workers.celery_app.celery_app inspect registered \
  | grep tasks_bitrix24
```

## 10. Подключите к конвейеру

После формирования окончательного `analysis_result`:

```python
from app.workers.tasks_bitrix24 import sync_tender_to_bitrix24_task

sync_tender_to_bitrix24_task.delay(tender_data, analysis_result)
```

Целевая последовательность:

```text
parser → DB → download → OCR → LLM → aluminium matching → scoring → report → Bitrix24 → Telegram (необязательно)
```

## Пока не реализовано

Загрузка PDF/Excel на Диск, привязка файлов к карточке, назначение менеджера, обратная синхронизация статусов и точечный патч к БД добавляются после получения актуального архива проекта и кодов полей портала.
