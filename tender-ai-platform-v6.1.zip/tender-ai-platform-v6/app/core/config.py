"""
Конфигурация приложения — обновлено: добавлены параметры Битрикс24.
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # БД
    database_url: str
    database_url_sync: str

    # Redis / Celery
    redis_url: str
    celery_broker_url: str
    celery_result_backend: str

    # Qdrant
    qdrant_url: str

    # LLM
    anthropic_api_key: str = ""
    anthropic_model_default: str = "claude-sonnet-4-6"
    anthropic_model_cheap: str = "claude-haiku-4-5-20251001"
    yandex_api_key: str = ""
    yandex_folder_id: str = ""
    yandex_model_uri: str = ""
    default_llm_provider: str = "anthropic"

    # Telegram
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""

    # Битрикс24 — коробочная версия
    bitrix24_webhook_url: str = ""   # напр: https://bitrix.tdsm.ru/rest/1/ТОКЕН
    bitrix24_chat_id: str = ""       # ID группового чата (только цифры)
    bitrix24_user_id: str = ""

    # ЕИС zakupki.gov.ru
    eis_token: str = ""  # Токен физлица для SOAP API getDocsIP
    tender_pro_api_key: str = ""
    tender_pro_max_rows: int = 100
    tender_pro_open_only: bool = True
    tender_pro_fetch_details: bool = True
    tender_pro_request_timeout: float = 30.0
    analysis_version: str = "v6.1"

    # Прочее
    environment: str = "development"
    log_level: str = "INFO"
    storage_path: str = "/app/storage"
    max_download_size_mb: int = 200
    max_archive_uncompressed_mb: int = 500
    max_archive_files: int = 500


settings = Settings()
