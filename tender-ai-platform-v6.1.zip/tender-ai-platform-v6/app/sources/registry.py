from app.sources.zakupki_gov.adapter import ZakupkiGovAdapter
from app.sources.tender_pro.adapter import TenderProAdapter

SOURCE_REGISTRY = {
    "zakupki_gov_ru": ZakupkiGovAdapter(),
    "tender_pro": TenderProAdapter(),
}


def get_adapter(source_key: str):
    return SOURCE_REGISTRY.get(source_key)
