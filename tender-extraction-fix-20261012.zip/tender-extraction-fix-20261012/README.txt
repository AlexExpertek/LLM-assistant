Fix 2026-10-12. Only app/llm/extraction.py is replaced; exact original SHA256 is required.
No automatic collection or analysis is started. Existing analyzed tenders are not modified.

Changes:
- Merge empty and populated fields for identical lot/position identities; normalize case and scalar decimal formatting.
- Preserve true conflicts, including null values carrying unresolved quotations.
- Omit only the observed generic printed-aluminium-foil heading when a concrete foil line exists at the same identity. Do not transfer heading contract/coating fields into the line; original evidence stays in snapshots.
- For schema ValidationError, re-extract the original chunk once with validation paths and explicit scalar/position instructions. No array flattening, inferred volumes or new position numbers.

Validation: python test_fix.py (requires Pydantic v2; no application services or LLM).
Install from project root: python3 /tmp/tender-extraction-fix-20261012/install.py
Then rebuild app, celery_worker, celery_discovery when workers are idle.
Replay: docker compose exec -T celery_worker python - < /tmp/tender-extraction-fix-20261012/check_saved.py
Replay only reads database and snapshots and requires exact input/chunk hashes. It does not persist a decision.

Limitations:
- Different product names, addresses, coatings etc. remain conflicts. No semantic guessing or concatenation.
- A snapshot interrupted by validation cannot be completed offline: failed raw responses were not saved by the old code. It will need a controlled future analysis run.
- No changes to notification policy, completed-analysis protection, material suitability or 500 kg per-position rules.
- Local tests use synthetic fixtures from observed structures, not full server documents. Server replay is required.
- B2B access and Tender.Pro connectivity are outside this patch.
Rollback: restore the printed backup to app/llm/extraction.py and rebuild services; no DB rollback needed.
