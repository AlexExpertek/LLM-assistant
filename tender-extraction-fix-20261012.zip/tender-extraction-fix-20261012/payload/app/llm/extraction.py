"""
Извлечение полей из текста тендерной документации.
Реализует требования раздела 5.4 (обязательные извлекаемые поля) и 6.4
(объяснимость и уверенность) ТЗ.

Принцип no-hallucination (раздел 1.3 ТЗ): модель никогда не выдумывает
значения. Если поле не найдено — null. Каждое поле сопровождается
confidence и цитатой-источником.
"""
from typing import Optional

from pydantic import BaseModel, Field, field_validator

from app.llm.router import TaskType, llm_router

# ──────────────────────────────────────────────────────────
# Pydantic-схема для валидации ответа модели (= guardrails из ТЗ FR-EXP-001..003)
# ──────────────────────────────────────────────────────────


class ExtractedField(BaseModel):
    """Одно извлечённое поле с метаданными для объяснимости."""
    @field_validator("value", mode="before")
    @classmethod
    def normalize_scalar_value(cls, value):
        import math
        if value is None or isinstance(value, str):
            return value
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, (int, float)):
            if isinstance(value, float) and not math.isfinite(value):
                raise ValueError("Non-finite extracted value")
            return str(value)
        raise ValueError("Extracted value must be a scalar")

    value: Optional[str] = None         # нормализованное значение, либо None
    raw_quote: Optional[str] = None      # точная цитата из документа
    confidence: float = Field(ge=0.0, le=1.0, default=0.0)


class TenderExtractionResult(BaseModel):
    """
    Полная схема извлекаемых полей по разделу 5.4 ТЗ.
    Каждое поле — объект ExtractedField, а не голое значение,
    чтобы сохранить confidence и источник для каждого факта отдельно.
    """
    # Идентификация
    customer_name: ExtractedField
    customer_inn: ExtractedField
    product_name: ExtractedField

    # Технические параметры
    alloy: ExtractedField                 # марка сплава
    temper: ExtractedField                 # состояние материала
    thickness_mm: ExtractedField
    width_mm: ExtractedField
    length_mm: ExtractedField
    diameter_mm: ExtractedField
    cross_section_shape: ExtractedField
    quantity: ExtractedField
    mass_kg: ExtractedField
    unit: ExtractedField
    tolerance: ExtractedField              # допустимые отклонения
    standard: ExtractedField               # ГОСТ/ОСТ/ТУ

    # Доп. обработка
    coating: ExtractedField
    machining: ExtractedField
    has_drawings: ExtractedField

    # Логистика и договор
    delivery_place: ExtractedField
    delivery_term: ExtractedField
    payment_terms: ExtractedField
    initial_max_price: ExtractedField      # НМЦК
    bid_security: ExtractedField           # обеспечение заявки
    contract_security: ExtractedField      # обеспечение исполнения
    experience_requirements: ExtractedField
    manufacturer_requirements: ExtractedField
    analog_allowed: ExtractedField         # допустимость аналога
    partial_delivery_allowed: ExtractedField
    advance_payment: ExtractedField
    penalties: ExtractedField

    # Результат и источник
    submission_deadline: ExtractedField


EXTRACTION_SYSTEM_PROMPT = """Ты — эксперт по анализу тендерной документации на поставку \
алюминиевого металлопроката (листы, рулоны, профили, трубы, прутки, шины, катанка, проволока) \
и услуг металлообработки (окраска, резка, профилирование).

Твоя задача — извлечь из текста тендерного документа структурированные данные.

ПРАВИЛА (строго обязательны):
1. Извлекай ТОЛЬКО то, что прямо написано в тексте. Никогда не выдумывай и не предполагай значения.
2. Если поле явно не упомянуто в документе — value: null, confidence: 0.0, raw_quote: null.
3. Для каждого найденного значения указывай raw_quote — точную цитату из текста (не более 200 символов),
   подтверждающую это значение.
4. confidence — твоя уверенность от 0.0 до 1.0:
   - 1.0 — значение прямо и однозначно указано
   - 0.5-0.7 — значение выводится косвенно или текст неоднозначен
   - ниже 0.5 — низкая уверенность, скан плохого качества, неполное предложение
5. Марки сплавов могут быть написаны кириллицей и латиницей, с пробелами и дефисами:
   АД31 / AD31 / АД 31 / Д16Т / AMg5M — нормализуй к стандартному виду без пробелов (АД31, Д16Т).
6. Единицы измерения нормализуй: массу к кг, длину к мм, если в документе другие единицы — \
   укажи нормализованное значение, а в raw_quote сохрани оригинальную формулировку.

Ответь СТРОГО в формате JSON, соответствующем описанной структуре, без каких-либо пояснений."""


def build_extraction_user_prompt(document_text: str, json_schema: dict) -> str:
    """Формирует промпт пользователя со схемой и текстом документа."""
    return f"""Извлеки данные из следующего тендерного документа.

JSON-схема ответа (каждое поле — объект {{value, raw_quote, confidence}}):
{json_schema}

Текст документа:
---
{document_text[:15000]}
---

Ответь только JSON-объектом, соответствующим схеме выше."""


async def extract_tender_fields(document_text: str) -> TenderExtractionResult:
    """
    Главная функция извлечения. Вызывает LLM, валидирует ответ через Pydantic
    (это и есть guardrails — невалидный ответ выбросит ValidationError,
    и задача уйдёт в статус "требует проверки" вместо того, чтобы пропустить
    мусорные данные дальше по пайплайну).
    """
    schema_hint = TenderExtractionResult.model_json_schema()

    user_prompt = build_extraction_user_prompt(document_text, schema_hint)

    response = await llm_router.complete(
        task=TaskType.EXTRACT_FIELDS,
        system_prompt=EXTRACTION_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        max_tokens=3000,
        temperature=0.0,
        json_mode=True,
    )

    raw_json = response.as_json()

    # Pydantic выбросит ValidationError если структура не соответствует схеме —
    # это и есть проверка "детерминированных правил и обязательных полей" из FR-EXP-003
    result = TenderExtractionResult.model_validate(raw_json)
    return result


def fields_requiring_review(result: TenderExtractionResult, threshold: float = 0.5) -> list[str]:
    """
    Возвращает список полей с confidence ниже порога —
    это и есть статус "требует проверки" из FR-DOC-004 ТЗ.
    """
    low_confidence_fields = []
    for field_name, field_value in result.model_dump().items():
        if field_value["value"] is not None and field_value["confidence"] < threshold:
            low_confidence_fields.append(field_name)
    return low_confidence_fields


# ───────────────── v6: многопозиционное извлечение ─────────────────
class TenderPositionExtraction(BaseModel):
    position_number: int = 1
    lot_number: Optional[str] = "1"
    product_name: ExtractedField = Field(default_factory=ExtractedField)
    product_type: ExtractedField = Field(default_factory=ExtractedField)
    alloy: ExtractedField = Field(default_factory=ExtractedField)
    temper: ExtractedField = Field(default_factory=ExtractedField)
    thickness_mm: ExtractedField = Field(default_factory=ExtractedField)
    width_mm: ExtractedField = Field(default_factory=ExtractedField)
    length_mm: ExtractedField = Field(default_factory=ExtractedField)
    diameter_mm: ExtractedField = Field(default_factory=ExtractedField)
    quantity: ExtractedField = Field(default_factory=ExtractedField)
    mass_kg: ExtractedField = Field(default_factory=ExtractedField)
    unit: ExtractedField = Field(default_factory=ExtractedField)
    standard: ExtractedField = Field(default_factory=ExtractedField)
    coating: ExtractedField = Field(default_factory=ExtractedField)
    machining: ExtractedField = Field(default_factory=ExtractedField)
    has_drawings: ExtractedField = Field(default_factory=ExtractedField)
    delivery_place: ExtractedField = Field(default_factory=ExtractedField)
    delivery_term: ExtractedField = Field(default_factory=ExtractedField)
    payment_terms: ExtractedField = Field(default_factory=ExtractedField)


class TenderMultiExtractionResult(BaseModel):
    partial_delivery_allowed: ExtractedField = Field(default_factory=ExtractedField)
    positions: list[TenderPositionExtraction] = Field(default_factory=list)


MULTI_EXTRACTION_SYSTEM_PROMPT = EXTRACTION_SYSTEM_PROMPT + """
7. Тендер может содержать несколько лотов и несколько товарных позиций. Не объединяй разные позиции.
8. Верни positions — отдельный объект для каждой фактической товарной позиции. lot_number сохрани как в документе.
9. Если в документе одна позиция — positions содержит ровно один элемент.
10. Изучай таблицы всех переданных документов, включая технические требования в конце текста.
11. Повтор одной и той же позиции в перечне продукции и таблице требований не является дополнительным объемом: не складывай повторенное количество. Разные позиции и лоты не объединяй.
12. Не превращай «не менее», «не более», диапазоны размеров в точный размер: value=null, исходное требование сохраняй в raw_quote. Размер полки уголка не является длиной изделия.
13. Разделяй обозначение сплава и состояние материала, размеры и единицы. Для круглой трубы три размера означают наружный диаметр, толщину стенки и длину. Массу в тоннах переводи в кг, сохраняя исходные quantity и unit. Не рассчитывай массу из размеров без явного основания. Для каждого значения приводи цитату; отсутствующие сведения оставляй null.
"""


def _complete_document_text(document_text: str) -> str:
    """Never silently drop specification tables at the end of the input.

    Character limit is a local safety bound, not a provider token guarantee.
    Provider context-limit errors must remain visible to the caller.
    """
    if not document_text or not document_text.strip():
        raise ValueError("EMPTY_EXTRACTION_INPUT")
    if len(document_text) > 600000:
        raise ValueError(
            f"EXTRACTION_INPUT_TOO_LARGE: {len(document_text)} characters; "
            "limit 600000; no text was sent"
        )
    return document_text


async def _extract_positions_chunk(document_text: str) -> TenderMultiExtractionResult:
    document_text = _complete_document_text(document_text)
    schema_hint = TenderMultiExtractionResult.model_json_schema()
    user_prompt = f"""Извлеки фактические товарные позиции из этого фрагмента. Если есть только общие условия, название закупки, образец незаполненной формы или упоминание товара без конкретной спецификации, верни positions: []. Не придумывай позиции по заголовку. Номера лотов и позиций бери из спецификации.
JSON-схема:\n{schema_hint}\n\nДокументы:\n---\n{document_text}\n---\nОтветь только JSON."""
    from pydantic import ValidationError
    import json
    base_prompt = user_prompt
    for attempt in range(2):
        response = await llm_router.complete(
            task=TaskType.EXTRACT_FIELDS,
            system_prompt=MULTI_EXTRACTION_SYSTEM_PROMPT,
            user_prompt=user_prompt,
            max_tokens=6000,
            temperature=0.0,
            json_mode=True,
        )
        try:
            return TenderMultiExtractionResult.model_validate(response.as_json())
        except ValidationError as exc:
            if attempt:
                raise
            issues = [{'path': '.'.join(map(str, e['loc'])), 'type': e['type']}
                      for e in exc.errors(include_input=False, include_url=False)]
            user_prompt = base_prompt + (
                "\nПредыдущий ответ не прошёл проверку схемы: "
                + json.dumps(issues, ensure_ascii=False)
                + "\nИзвлеки позиции заново из исходного фрагмента. "
                "value — одно скалярное значение или null; raw_quote — строка или null. "
                "Не объединяй изделия разных размеров в одну позицию. "
                "Если в спецификации несколько строк, сохрани каждую с её номером, "
                "размерами, единицей и количеством. Не распределяй общий объём "
                "между размерами, если распределение не указано. "
                "Альтернативные размеры одного изделия не превращай в новые позиции: "
                "оставь value=null и исходное требование в raw_quote."
            )


def _document_chunks(text: str, limit: int = 24000) -> list[str]:
    """Lossless split, preferring document boundaries and then whole lines."""
    _complete_document_text(text)
    import re
    if len(text) <= limit:
        return [text]
    sections = re.split(r"(?=\n\n### DOCUMENT:)", text)
    chunks = []
    for section in sections:
        while len(section) > limit:
            cut = section.rfind("\n", 0, limit + 1)
            if cut < limit // 2:
                cut = limit
            else:
                cut += 1
            chunks.append(section[:cut])
            section = section[cut:]
        if section:
            chunks.append(section)
    return chunks


def _merge_extractions(results):
    """Merge complementary evidence; retain fail-closed handling of real conflicts."""
    import re
    from decimal import Decimal, InvalidOperation

    def canonical(value):
        if value is None or not str(value).strip():
            return None
        value = re.sub(r'\s+', ' ', str(value)).strip().casefold()
        if re.fullmatch(r'[+-]?\d+(?:[.,]\d+)?', value):
            try:
                return ('number', Decimal(value.replace(',', '.')))
            except InvalidOperation:
                pass
        return ('text', value)

    # Only the observed generic foil heading, with no position-specific facts.
    # Never discard an unnumbered/unknown product just because mass is absent.
    def foil_heading(pos):
        name = re.sub(r'\s+', ' ', pos.product_name.value or '').strip().casefold()
        if not re.fullmatch(r'фольг[аи] алюминиев(?:ая|ой) с нанесенной печатью', name):
            return False
        specifics = ('quantity', 'mass_kg', 'unit', 'alloy', 'temper',
                     'thickness_mm', 'width_mm', 'length_mm', 'diameter_mm',
                     'machining', 'has_drawings')
        return not any(canonical(getattr(pos, f).value) is not None
                       or getattr(pos, f).raw_quote for f in specifics)

    numbered = {}
    partial = []
    for result in results:
        if canonical(result.partial_delivery_allowed.value) is not None:
            partial.append(result.partial_delivery_allowed)
        for pos in result.positions:
            identity = (pos.lot_number or '1', pos.position_number)
            numbered.setdefault(identity, []).append(pos)

    merged = []
    for identity, variants in numbered.items():
        # A concrete foil line at the SAME identity must be present before the
        # generic procurement heading can be omitted. Retained in snapshots.
        concrete_foil = any(
            not foil_heading(p)
            and re.match(r'^фольга\s+алюминиевая\b', (p.product_name.value or '').strip(), re.I)
            and any(canonical(getattr(p, f).value) is not None
                    for f in ('quantity', 'mass_kg', 'width_mm', 'thickness_mm'))
            for p in variants
        )
        if concrete_foil:
            variants = [p for p in variants if not foil_heading(p)]
        combined = variants[0].model_copy(deep=True)
        for pos in variants[1:]:
            for field in type(pos).model_fields:
                if field in ('position_number', 'lot_number'):
                    continue
                old, new = getattr(combined, field), getattr(pos, field)
                left, right = canonical(old.value), canonical(new.value)
                if left is not None and right is not None and left != right:
                    raise ValueError('EXTRACTION_POSITION_CONFLICT: differing fragments for lot/position '
                                     + str(identity) + '; field=' + field
                                     + '; review required; no result saved')
                if left is None and right is not None:
                    # A null carrying a quote can be an intentionally unresolved
                    # range/requirement, not a missing value. Do not override it.
                    if old.raw_quote and old.raw_quote != new.raw_quote:
                        raise ValueError('EXTRACTION_POSITION_CONFLICT: unresolved quoted field '
                                         + str(identity) + '; field=' + field)
                    setattr(combined, field, new.model_copy(deep=True))
                elif left is not None and right is None:
                    if new.raw_quote and new.raw_quote != old.raw_quote:
                        raise ValueError('EXTRACTION_POSITION_CONFLICT: unresolved quoted field '
                                         + str(identity) + '; field=' + field)
                elif left == right:
                    quotes = list(dict.fromkeys(q for q in (old.raw_quote, new.raw_quote) if q))
                    setattr(combined, field, ExtractedField(
                        value=old.value, raw_quote='\n'.join(quotes) or None,
                        confidence=min(old.confidence, new.confidence),
                    ))
        merged.append(combined)

    if len({canonical(f.value) for f in partial}) > 1:
        raise ValueError('EXTRACTION_PARTIAL_DELIVERY_CONFLICT: review required')
    if not merged:
        raise ValueError('EXTRACTION_NO_SPECIFICATION_POSITIONS: no result saved')
    return TenderMultiExtractionResult(
        positions=merged,
        partial_delivery_allowed=partial[0] if partial else ExtractedField(),
    )


def _save_extraction_snapshot(path, data):
    import os, json, tempfile
    from pathlib import Path
    path = Path(path)
    fd, temp = tempfile.mkstemp(prefix='.snapshot-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(data, stream, ensure_ascii=False, indent=2)
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


async def extract_tender_positions(document_text: str) -> TenderMultiExtractionResult:
    from pathlib import Path
    import hashlib, tempfile
    from app.core.config import settings
    chunks = _document_chunks(document_text)
    # Persist each validated response before normalization/merge can reject it.
    root = Path(settings.storage_path) / 'extraction_snapshots'
    root.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256(document_text.encode()).hexdigest()
    run = Path(tempfile.mkdtemp(prefix=digest[:16]+'-', dir=root))
    snapshot = {'input_sha256': digest, 'chunk_count': len(chunks),
                'state': 'running', 'responses': []}
    path = run / 'responses.json'
    _save_extraction_snapshot(path, snapshot)
    results = []
    try:
        for index, chunk in enumerate(chunks):
            response = await _extract_positions_chunk(chunk)
            snapshot['responses'].append({'chunk_index': index,
                'chunk_sha256': hashlib.sha256(chunk.encode()).hexdigest(),
                'result': response.model_dump(mode='json')})
            _save_extraction_snapshot(path, snapshot)
            results.append(_normalize_extraction(response, document_text))
        merged = _merge_extractions(results)
        snapshot['state'] = 'completed'
        _save_extraction_snapshot(path, snapshot)
        return merged
    except Exception as exc:
        snapshot['state'] = 'failed'
        snapshot['error_type'] = type(exc).__name__
        snapshot['error'] = str(exc)
        _save_extraction_snapshot(path, snapshot)
        raise


def _normalize_extraction(result, source_text):
    """Conservative repairs from product designation actually present in source."""
    import re
    from decimal import Decimal
    def compact(value):
        return re.sub(r"\s+", " ", value or '').strip().casefold()
    source = compact(source_text)
    # Metadata precedes the DOCUMENT markers. First line is the tender title.
    title = compact(source_text.split('### DOCUMENT:', 1)[0].strip().split('\n')[0])
    normalized = []
    for pos in result.positions:
        data = pos.model_dump()
        name = pos.product_name.value or ''
        name_in_source = bool(name.strip()) and compact(name) in source
        def assign(key, value):
            previous = data[key]['value']
            if previous not in (None, ''):
                try:
                    equal = Decimal(previous.replace(',', '.')) == Decimal(str(value))
                except Exception:
                    equal = compact(previous) == compact(str(value))
                if not equal:
                    raise ValueError('EXTRACTION_DESIGNATION_CONFLICT: '+key)
                return
            data[key] = {'value':str(value),'raw_quote':name,'confidence':1.0}
        if name_in_source:
            # Only explicitly recognized technical-aluminium grades + annealed temper.
            matches = list(re.finditer(r"(?<!\w)(АД(?:000|00|0|1|31|33))\s*(М)(?!\w)",name,re.I))
            if len(matches) == 1:
                alloy, temper = (x.upper() for x in matches[0].groups())
                current = re.sub(r"\s+", '', pos.alloy.value or '').upper()
                if current in ('', alloy, alloy+temper):
                    data['alloy']={'value':alloy,'raw_quote':name,'confidence':1.0}
                    assign('temper',temper)
                else:
                    raise ValueError('EXTRACTION_DESIGNATION_CONFLICT: alloy')
            if re.search(r"\bтруб[аы]\b",name,re.I) and not re.search(r"профильн|квадрат|прямоуголь",name,re.I):
                dimensions = list(re.finditer(r"(?<![\d.,])([0-9]+(?:[.,][0-9]+)?)\s*[хx×]\s*([0-9]+(?:[.,][0-9]+)?)\s*[хx×]\s*([0-9]+(?:[.,][0-9]+)?)(?![\d.,])",name,re.I))
                if len(dimensions)==1:
                    d,w,length=[Decimal(x.replace(',','.')) for x in dimensions[0].groups()]
                    # Restrict shorthand inference to plausible round tube dimensions.
                    if d>0 and 0<w<d/2 and length>d:
                        for key,val in [('diameter_mm',d),('thickness_mm',w),('length_mm',length)]:assign(key,val)
        for key in ('diameter_mm','thickness_mm','width_mm','length_mm'):
            quote = data[key].get('raw_quote') or ''
            if re.search(r'(?:[<>≤≥]|не\s+(?:менее|более)|от\s+\d.+?до\s+\d)', quote, re.I):
                data[key]['value'] = None
        if re.search(r'\bугол', name, re.I):
            quote = data['length_mm'].get('raw_quote') or ''
            if not re.search(r'длин|length', quote, re.I):
                data['length_mm']['value'] = None
        evidence_fields=('alloy' ,'temper','diameter_mm','thickness_mm','width_mm','length_mm','quantity','unit','mass_kg','standard','coating','machining')
        has_details=any(data[k]['value'] not in (None,'') or data[k].get('raw_quote') for k in evidence_fields)
        heading_only=(not has_details and title and compact(name) and compact(name) in title)
        if not heading_only:
            normalized.append(TenderPositionExtraction.model_validate(data))
    return TenderMultiExtractionResult(positions=normalized,partial_delivery_allowed=result.partial_delivery_allowed)
