import asyncio
import importlib.util
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import AsyncMock

# Load the real module and Pydantic schemas without initializing a live router.
router = types.ModuleType('app.llm.router')
router.TaskType = types.SimpleNamespace(EXTRACT_FIELDS='extract_fields')
router.llm_router = types.SimpleNamespace(complete=AsyncMock())
sys.modules['app.llm.router'] = router
p=Path(__file__).parent/'payload/app/llm/extraction.py'
spec=importlib.util.spec_from_file_location('extraction_tested',p)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def pos(number=1, **kw):
    return m.TenderPositionExtraction(position_number=number, **{
        k: (v if isinstance(v,dict) else {'value':v}) for k,v in kw.items()
    })
def result(*positions):
    return m.TenderMultiExtractionResult(positions=list(positions))

class Tests(unittest.TestCase):
    def test_complementary(self):
        a=pos(product_name='Фольга',mass_kg='240',width_mm='265')
        b=pos(product_name='фольга',mass_kg='240.0',thickness_mm='0,023')
        merged=m._merge_extractions([result(a),result(b)]).positions
        self.assertEqual(len(merged),1)
        self.assertEqual(merged[0].width_mm.value,'265')
        self.assertEqual(merged[0].thickness_mm.value,'0,023')
        self.assertEqual(merged[0].mass_kg.value,'240')
        self.assertIsNone(a.thickness_mm.value)
    def test_real_conflicts(self):
        for field in ('mass_kg','width_mm','alloy','coating','product_name'):
            with self.subTest(field=field),self.assertRaisesRegex(ValueError,'field='+field):
                m._merge_extractions([result(pos(**{field:'1'})),result(pos(**{field:'2'}))])
    def test_observed_generic_foil(self):
        generic=pos(product_name='фольга алюминиевая с нанесенной печатью',coating='печать')
        other=pos(product_name='Фольга алюминиевая с нанесенной печатью',coating='Лаковое покрытие',standard='ГОСТ 745-2014')
        concrete=pos(product_name='Фольга алюминиевая «Ривароксабан»',mass_kg='240',width_mm='265±2,0')
        duplicate=pos(product_name='Фольга алюминиевая «Ривароксабан»',mass_kg='240')
        out=m._merge_extractions([result(generic),result(other),result(concrete),result(duplicate)])
        self.assertEqual(len(out.positions),1)
        self.assertEqual(out.positions[0].mass_kg.value,'240')
        self.assertIsNone(out.positions[0].coating.value)
    def test_generic_with_quantity_not_discarded(self):
        with self.assertRaises(ValueError):
            m._merge_extractions([result(pos(product_name='фольга алюминиевая с нанесенной печатью',mass_kg='1000')),
                                  result(pos(product_name='Фольга алюминиевая «Ривароксабан»',mass_kg='240'))])
    def test_different_positions_not_summed(self):
        out=m._merge_extractions([result(pos(mass_kg='240'),pos(2,mass_kg='240'))])
        self.assertEqual([p.mass_kg.value for p in out.positions],['240','240'])
    def test_different_lots(self):
        a=pos(mass_kg='240');b=a.model_copy(deep=True);b.lot_number='2'
        self.assertEqual(len(m._merge_extractions([result(a,b)]).positions),2)
    def test_unknown_range_not_overwritten(self):
        a=pos(width_mm={'value':None,'raw_quote':'от 130 до 206'})
        b=pos(width_mm={'value':'130','raw_quote':'ширина 130'})
        with self.assertRaises(ValueError):m._merge_extractions([result(a,b)])
    def test_no_positions(self):
        with self.assertRaisesRegex(ValueError,'NO_SPECIFICATION'):m._merge_extractions([result()])
    def test_partial_conflict(self):
        a=result(pos());b=result(pos());a.partial_delivery_allowed.value='да';b.partial_delivery_allowed.value='нет'
        with self.assertRaisesRegex(ValueError,'PARTIAL_DELIVERY'):m._merge_extractions([a,b])
    def test_validation_retry_once(self):
        bad={'positions':[{'width_mm':{'value':['130','181','206'],'raw_quote':['a','b','c']}}]}
        good={'positions':[{'position_number':i+1,'width_mm':{'value':v}} for i,v in enumerate(['130','181','206'])]}
        replies=[types.SimpleNamespace(as_json=lambda:bad),types.SimpleNamespace(as_json=lambda:good)]
        router.llm_router.complete=AsyncMock(side_effect=replies)
        out=asyncio.run(m._extract_positions_chunk('Тестовый фрагмент спецификации'))
        self.assertEqual(len(out.positions),3)
        self.assertEqual(router.llm_router.complete.await_count,2)
        self.assertIn('positions.0.width_mm.value',router.llm_router.complete.call_args.kwargs['user_prompt'])
    def test_invalid_retry_stops(self):
        bad=types.SimpleNamespace(as_json=lambda:{'positions':[{'width_mm':{'value':['1','2']}}]})
        router.llm_router.complete=AsyncMock(return_value=bad)
        with self.assertRaises(m.BaseModel.__class__.__base__ if False else ValueError):
            asyncio.run(m._extract_positions_chunk('Тест'))
        self.assertEqual(router.llm_router.complete.await_count,2)
    def test_network_error_not_retried_here(self):
        router.llm_router.complete=AsyncMock(side_effect=TimeoutError('test'))
        with self.assertRaises(TimeoutError):asyncio.run(m._extract_positions_chunk('Тест'))
        self.assertEqual(router.llm_router.complete.await_count,1)

if __name__=='__main__':unittest.main()
