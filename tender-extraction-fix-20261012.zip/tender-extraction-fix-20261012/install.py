import ast, hashlib, json, os, shutil, subprocess, sys, tempfile
from datetime import datetime
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
project=Path(os.environ.get('TENDER_PROJECT_DIR', os.getcwd())).resolve()
target=project/manifest['path']; payload=root/'payload'/manifest['path']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if sha(target)==manifest['after']:
    print('EXTRACTION_FIX_ALREADY_INSTALLED');sys.exit(0)
if sha(target)!=manifest['before']:
    raise SystemExit('SOURCE_VERSION_MISMATCH: ничего не изменено. Пришлите SHA256 app/llm/extraction.py.')
if sha(payload)!=manifest['after']:raise SystemExit('PAYLOAD_HASH_MISMATCH')
ast.parse(payload.read_text())
backup=Path(tempfile.mkdtemp(prefix='tender-extraction-backup-'+datetime.now().strftime('%Y%m%d-') ))
shutil.copy2(target,backup/'extraction.py')
fd,tmp=tempfile.mkstemp(prefix='.extraction-fix-',dir=target.parent);os.close(fd)
try:
    shutil.copy2(payload,tmp);os.chmod(tmp,target.stat().st_mode);os.replace(tmp,target)
finally:
    if os.path.exists(tmp):os.unlink(tmp)
print('BACKUP:',backup/'extraction.py')
print('EXTRACTION_MERGE_FIX_INSTALLED')
print('No tasks, DB writes, LLM calls, container restarts or notifications.')
