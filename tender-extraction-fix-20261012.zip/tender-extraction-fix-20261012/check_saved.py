"""Reconstruct exact saved input; validate snapshot and replay without LLM/DB writes."""
import hashlib,json
from pathlib import Path
from sqlalchemy import select
from app.core.config import settings
from app.db.session import SyncSessionLocal
from app.models.database import Tender,Document
from app.llm.extraction import TenderMultiExtractionResult,_normalize_extraction,_merge_extractions,_document_chunks

for number in ('32616441254','32616440054'):
    print('\nTENDER:',number,flush=True)
    with SyncSessionLocal() as s:
        t=s.execute(select(Tender).where(Tender.source=='zakupki_gov_ru',Tender.external_id==number)).scalar_one()
        metadata=[t.title,t.description,t.delivery_place]
        positions=(t.raw_payload or {}).get('positions',[])
        if positions:
            lines=['ПОЗИЦИИ ТЕНДЕРА:']
            for idx,p in enumerate(positions,1):
                if not isinstance(p,dict):continue
                line=f"{idx}. {p.get('name') or ''}"
                if p.get('quantity') not in (None,''):
                    line+=f" | количество: {p.get('quantity')} {p.get('unit') or ''}".rstrip()
                lines.append(line)
            if len(lines)>1:metadata.append('\n'.join(lines))
        docs=s.execute(select(Document).where(Document.tender_id==t.id).order_by(Document.created_at)).scalars().all()
        document_text=''.join(f'\n\n### DOCUMENT: {d.filename}\n{d.extracted_text}' for d in docs if d.extracted_text)
        text=('\n\n'.join(str(x) for x in metadata if x not in (None,''))+'\n\n'+document_text).strip()
    digest=hashlib.sha256(text.encode()).hexdigest()
    paths=sorted((Path(settings.storage_path)/'extraction_snapshots').glob(digest[:16]+'-*/responses.json'),key=lambda p:p.stat().st_mtime,reverse=True)
    if not paths:
        print('INPUT_HASH_NOT_FOUND: no guessing and no network calls');continue
    data=json.loads(paths[0].read_text())
    responses=data.get('responses',[]);chunks=_document_chunks(text)
    if data.get('input_sha256')!=digest or len(responses)!=len(chunks):
        print('SNAPSHOT_INCOMPLETE:',len(responses),'/',len(chunks))
        print('SAVED_ERROR_TYPE:',data.get('error_type'))
        continue
    if any(r.get('chunk_index')!=i or r.get('chunk_sha256')!=hashlib.sha256(chunks[i].encode()).hexdigest() for i,r in enumerate(responses)):
        print('CHUNK_HASH_MISMATCH');continue
    try:
        results=[_normalize_extraction(TenderMultiExtractionResult.model_validate(r['result']),text) for r in responses]
        merged=_merge_extractions(results)
        print('SAVED_REPLAY_OK; POSITIONS:',len(merged.positions))
        for p in merged.positions:
            print(json.dumps({'lot':p.lot_number,'position':p.position_number,'name':p.product_name.value,
                'mass_kg':p.mass_kg.value,'quantity':p.quantity.value,'unit':p.unit.value,
                'thickness':p.thickness_mm.value,'width':p.width_mm.value},ensure_ascii=False))
    except Exception as exc:
        print('REPLAY_FAILED:',type(exc).__name__,str(exc)[:1200])
print('\nREAD_ONLY: no HTTP, LLM, OCR, queues, file or DB writes')
