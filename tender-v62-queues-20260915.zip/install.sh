#!/usr/bin/env bash
set -Eeuo pipefail
PACKAGE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="${1:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
cd "$PROJECT_DIR"
python3 "$PACKAGE_DIR/apply.py" "$PROJECT_DIR"
docker compose config --quiet
docker compose build app celery_beat celery_discovery
# Validate the exact image that will serve the dedicated queue, without broker calls.
docker compose run --rm --no-deps -T celery_discovery python - < "$PACKAGE_DIR/verify_queues.py"
echo 'Starting discovery worker. Existing OCR worker is not restarted.'
docker compose up -d --no-deps celery_discovery
# A reply from the old worker alone is insufficient: target this new node.
docker compose exec -T celery_discovery python - <<'PY'
import socket
import time
from app.workers.celery_app import celery_app
node = 'discovery@' + socket.gethostname()
for attempt in range(10):
    replies = celery_app.control.ping(destination=[node], timeout=5)
    if any(r.get(node, {}).get('ok') == 'pong' for r in replies):
        print('DISCOVERY_WORKER_READY:', node)
        break
    time.sleep(2)
else:
    raise SystemExit('Discovery worker did not reply. Publishers were not restarted.')
PY
# Refresh publishers only after the dedicated consumer is ready.
docker compose stop celery_beat
docker compose up -d --no-deps app
docker compose up -d --no-deps celery_beat
docker compose exec -T app python - < "$PACKAGE_DIR/verify_queues.py"
docker compose exec -T celery_beat python - < "$PACKAGE_DIR/verify_queues.py"
docker compose ps -a
echo 'QUEUE_UPDATE_INSTALLED. Old queue and active OCR tasks were retained.'
