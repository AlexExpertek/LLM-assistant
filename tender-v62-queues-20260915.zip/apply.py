#!/usr/bin/env python3
"""Apply discovery queue patch to existing v6.2; no service restart."""
import ast, hashlib, json, os, shutil, sys, tempfile
from pathlib import Path
PAYLOAD = json.loads('[{"path": "app/workers/celery_app.py", "before": "27eafc929f12c90c08c30554d4a3748300eb76941604ea35f6db60fb8d7755fe", "text": "\\"\\"\\"\\nCelery конфигурация с расписанием для всех источников.\\n\\"\\"\\"\\nfrom celery import Celery\\nfrom celery.schedules import crontab\\n\\nfrom app.core.config import settings\\n\\ncelery_app = Celery(\\n    \\"tender_platform\\",\\n    broker=settings.celery_broker_url,\\n    backend=settings.celery_result_backend,\\n    include=[\\n        \\"app.workers.tasks_parsing\\",\\n        \\"app.workers.tasks_ocr\\",\\n        \\"app.workers.tasks_scoring\\",\\n        \\"app.workers.tasks_notify\\",\\n        \\"app.workers.tasks_reports\\",\\n        \\"app.workers.tasks_upload\\",\\n        \\"app.workers.tasks_marketplace_discovery\\",\\n        \\"app.workers.tasks_discovery_http\\",\\n    ],\\n)\\n\\ncelery_app.conf.update(\\n    task_serializer=\\"json\\",\\n    accept_content=[\\"json\\"],\\n    result_serializer=\\"json\\",\\n    timezone=\\"Europe/Moscow\\",\\n    enable_utc=True,\\n    task_track_started=True,\\n    task_acks_late=True,\\n    worker_prefetch_multiplier=1,\\n    task_default_retry_delay=60,\\n    task_max_retries=3,\\n    # Only discovery/monitoring use this queue. OCR, ingestion, LLM and\\n    # notifications retain the legacy default queue and its existing backlog.\\n    task_routes={\\n        \\"app.workers.tasks_marketplace_discovery.run_connected_marketplaces\\": {\\"queue\\": \\"discovery\\"},\\n        \\"app.workers.tasks_discovery_http.discover_new_sources\\": {\\"queue\\": \\"discovery\\"},\\n        \\"app.workers.tasks_parsing.monitor_source\\": {\\"queue\\": \\"discovery\\"},\\n    },\\n)\\n\\ncelery_app.conf.beat_schedule = {\\n    \\"marketplace-discovery-4h\\": {\\n        \\"task\\": (\\n            \\"app.workers.tasks_marketplace_discovery.\\"\\n            \\"run_connected_marketplaces\\"\\n        ),\\n        \\"schedule\\": crontab(\\n            minute=20,\\n            hour=\\"*/4\\",\\n        ),\\n        \\"kwargs\\": {\\n            \\"max_per_platform\\": 100,\\n        },\\n    },\\n\\n    # ЕИС — каждый день в 03:00\\n    # Tender.Pro — каждые 4 часа (коммерческие тендеры обновляются чаще)\\n    \\"monitor-tender-pro-4h\\": {\\n        \\"task\\": \\"app.workers.tasks_parsing.monitor_source\\",\\n        \\"schedule\\": crontab(minute=30, hour=\\"*/4\\"),\\n        \\"args\\": (\\"tender_pro\\",),\\n    },\\n    # Обновление дедлайнов — каждый час\\n    \\"mark-inactive-hourly\\": {\\n        \\"task\\": \\"app.workers.tasks_parsing.mark_inactive_tenders\\",\\n        \\"schedule\\": crontab(minute=0),\\n    },\\n    # Ежедневный отчёт — в 09:00\\n    \\"daily-report\\": {\\n        \\"task\\": \\"app.workers.tasks_reports.generate_and_send_report\\",\\n        \\"schedule\\": crontab(hour=9, minute=0),\\n    },\\n}\\n\\nif settings.eis_monitor_enabled:\\n    celery_app.conf.beat_schedule[\\"monitor-eis-daily\\"] = {\\n        \\"task\\": \\"app.workers.tasks_parsing.monitor_source\\",\\n        \\"schedule\\": crontab(hour=3, minute=0),\\n        \\"args\\": (\\"zakupki_gov_ru\\",),\\n    }\\n\\nif settings.marketplace_scout_enabled:\\n    celery_app.conf.beat_schedule[\\"marketplace-scout-daily\\"] = {\\n        \\"task\\": \\"app.workers.tasks_discovery_http.discover_new_sources\\",\\n        \\"schedule\\": crontab(hour=2, minute=10),\\n    }\\n\\n# Credentials do not prove a valid subscription.\\nif (settings.kontur_monitor_enabled and settings.kontur_api_base_url and settings.kontur_api_key and settings.kontur_search_path\\n        and (settings.kontur_api_key_header or settings.kontur_api_key_query_param)):\\n    celery_app.conf.beat_schedule[\\"monitor-kontur-zakupki-4h\\"] = {\\n        \\"task\\": \\"app.workers.tasks_parsing.monitor_source\\",\\n        \\"schedule\\": crontab(minute=45, hour=\\"*/4\\"),\\n        \\"args\\": (\\"kontur_zakupki\\",),\\n    }\\n"}, {"path": "docker-compose.yml", "before": "8d47a01fed621c8666e3508485e2d41c92895a04f38b7e67e7f464946fc918af", "text": "services:\\n  postgres:\\n    image: postgres:16-alpine\\n    restart: unless-stopped\\n    environment:\\n      POSTGRES_USER: ${POSTGRES_USER}\\n      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}\\n      POSTGRES_DB: ${POSTGRES_DB}\\n    volumes:\\n      - postgres_data:/var/lib/postgresql/data\\n    healthcheck:\\n      test: [\\"CMD-SHELL\\", \\"pg_isready -U ${POSTGRES_USER} -d ${POSTGRES_DB}\\"]\\n      interval: 5s\\n      timeout: 5s\\n      retries: 10\\n\\n  redis:\\n    image: redis:7-alpine\\n    restart: unless-stopped\\n    volumes:\\n      - redis_data:/data\\n    healthcheck:\\n      test: [\\"CMD\\", \\"redis-cli\\", \\"ping\\"]\\n      interval: 5s\\n      timeout: 5s\\n      retries: 10\\n\\n  qdrant:\\n    image: qdrant/qdrant:v1.11.5\\n    restart: unless-stopped\\n    volumes:\\n      - qdrant_data:/qdrant/storage\\n\\n  app:\\n    build: .\\n    restart: unless-stopped\\n    env_file: .env\\n    ports:\\n      - \\"8000:8000\\"\\n    volumes:\\n      - ./storage:/app/storage\\n    depends_on:\\n      postgres:\\n        condition: service_healthy\\n      redis:\\n        condition: service_healthy\\n    command: uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2\\n\\n  celery_worker:\\n    build: .\\n    restart: unless-stopped\\n    env_file: .env\\n    volumes:\\n      - ./storage:/app/storage\\n    depends_on:\\n      postgres:\\n        condition: service_healthy\\n      redis:\\n        condition: service_healthy\\n    command: celery -A app.workers.celery_app worker --loglevel=info --concurrency=4\\n\\n  celery_discovery:\\n    build: .\\n    restart: unless-stopped\\n    env_file: .env\\n    volumes:\\n      - ./storage:/app/storage\\n    depends_on:\\n      postgres:\\n        condition: service_healthy\\n      redis:\\n        condition: service_healthy\\n    command: >-\\n      celery -A app.workers.celery_app worker\\n      --loglevel=info --concurrency=1 --queues=discovery\\n      --hostname=discovery@%h --prefetch-multiplier=1\\n      --soft-time-limit=600 --time-limit=660\\n\\n  celery_beat:\\n    build: .\\n    restart: unless-stopped\\n    env_file: .env\\n    volumes:\\n      - ./storage:/app/storage\\n    depends_on:\\n      postgres:\\n        condition: service_healthy\\n      redis:\\n        condition: service_healthy\\n    command: celery -A app.workers.celery_app beat --loglevel=info\\n\\n  flower:\\n    build: .\\n    restart: unless-stopped\\n    env_file: .env\\n    ports:\\n      - \\"5555:5555\\"\\n    depends_on:\\n      redis:\\n        condition: service_healthy\\n    command: celery -A app.workers.celery_app flower --port=5555\\n\\nvolumes:\\n  postgres_data:\\n  redis_data:\\n  qdrant_data:\\n"}]')
project = Path(sys.argv[1]).resolve()
if not (project / 'app').is_dir():
    raise SystemExit('Project app directory not found')
changes = []
for item in PAYLOAD:
    target = project / item['path']
    if target.is_symlink():
        raise SystemExit('Refusing symlink: ' + str(target))
    current = target.read_bytes()
    new = item['text'].encode()
    if target.suffix == '.py':
        ast.parse(item['text'])
    if current == new:
        continue
    if hashlib.sha256(current).hexdigest() != item['before']:
        raise SystemExit('Unexpected version; no files changed: ' + str(target))
    changes.append((target, new))
if not changes:
    print('Already installed')
    raise SystemExit(0)
backup = Path(tempfile.mkdtemp(prefix='tender-v62-queues-backup-', dir=project.parent))
for target, new in changes:
    destination = backup / target.relative_to(project)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(target, destination)
try:
    for target, new in changes:
        fd, temporary = tempfile.mkstemp(dir=target.parent)
        try:
            with os.fdopen(fd, 'wb') as stream:
                stream.write(new)
            os.chmod(temporary, target.stat().st_mode & 0o777)
            os.replace(temporary, target)
        finally:
            if os.path.exists(temporary): os.unlink(temporary)
except BaseException:
    for target, _ in changes:
        shutil.copy2(backup / target.relative_to(project), target)
    raise
print('Applied:', len(changes), 'files. Backup:', backup)
print('Build and verify application images before restarting services.')
