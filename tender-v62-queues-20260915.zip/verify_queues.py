"""Offline verification; use installed config or inject settings for local tests."""
import argparse
import importlib.util
import sys
from pathlib import Path
from types import ModuleType, SimpleNamespace

p = argparse.ArgumentParser()
p.add_argument('--project', default='/app')
p.add_argument('--isolated', action='store_true')
a = p.parse_args()
root = Path(a.project).resolve()
sys.path.insert(0, str(root))
if a.isolated:
    fake = ModuleType('app.core.config')
    fake.settings = SimpleNamespace(
        celery_broker_url='memory://', celery_result_backend='cache+memory://',
        eis_monitor_enabled=True, marketplace_scout_enabled=True,
        kontur_monitor_enabled=False,
    )
    sys.modules['app.core.config'] = fake
from app.workers.celery_app import celery_app

names = [
    'app.workers.tasks_marketplace_discovery.run_connected_marketplaces',
    'app.workers.tasks_discovery_http.discover_new_sources',
    'app.workers.tasks_parsing.monitor_source',
]
router = celery_app.amqp.router
for name in names:
    assert router.route({}, name)['queue'].name == 'discovery', name
for name in [
    'app.workers.tasks_ocr.process_tender_documents',
    'app.workers.tasks_parsing.process_new_tender',
    'app.workers.tasks_scoring.analyze_tender',
    'app.workers.tasks_reports.generate_and_send_report',
    'app.workers.tasks_notify.send_bitrix_notification',
]:
    assert router.route({}, name)['queue'].name == 'celery', name
for entry in celery_app.conf.beat_schedule.values():
    if entry['task'] in names:
        assert router.route(entry.get('options', {}), entry['task'])['queue'].name == 'discovery'
# CLI -Q discovery restricts the extra worker's consumer to this queue.
celery_app.amqp.queues.select(['discovery'])
assert set(celery_app.amqp.queues.consume_from) == {'discovery'}
print('QUEUE_ROUTES_OK: discovery tasks isolated; OCR/LLM stay on celery; no external calls')
