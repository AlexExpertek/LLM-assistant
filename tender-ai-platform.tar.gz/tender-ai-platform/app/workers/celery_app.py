"""
Конфигурация Celery — планировщик и воркеры.
FR-SRC-003: плановый режим 1 раз в сутки для MVP, архитектура должна
поддерживать запуск каждые 30-60 минут и ручной запуск.
"""
from celery import Celery
from celery.schedules import crontab

from app.core.config import settings

celery_app = Celery(
    "tender_platform",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
    include=[
        "app.workers.tasks_parsing",
        "app.workers.tasks_ocr",
        "app.workers.tasks_scoring",
    ],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Europe/Moscow",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,            # задача подтверждается только после успешного выполнения
    worker_prefetch_multiplier=1,    # важно для долгих задач (OCR) — не хватать пачками
    task_default_retry_delay=60,
    task_max_retries=3,
)

# Расписание — раздел FR-SRC-003. На старте 1 раз в сутки в 03:00,
# легко поменять на crontab(minute="*/30") для перехода к получасовому циклу.
celery_app.conf.beat_schedule = {
    "monitor-eis-daily": {
        "task": "app.workers.tasks_parsing.monitor_source",
        "schedule": crontab(hour=3, minute=0),
        "args": ("zakupki_gov_ru",),
    },
    "monitor-commercial-etp-daily": {
        "task": "app.workers.tasks_parsing.monitor_source",
        "schedule": crontab(hour=3, minute=30),
        "args": ("commercial_etp",),
    },
}
