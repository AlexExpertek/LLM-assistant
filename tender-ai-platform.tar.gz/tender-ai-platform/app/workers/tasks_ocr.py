"""
Задачи скачивания и OCR-обработки документов тендера.
Реализует FR-DOC-001..005 ТЗ.
"""
import hashlib
from pathlib import Path

import httpx

from app.core.config import settings
from app.core.logging import get_logger
from app.ocr.pipeline import extract_document
from app.workers.celery_app import celery_app

logger = get_logger(__name__)


def compute_file_hash(file_path: str) -> str:
    """Хэш файла для версионирования документов (FR-DOC-005)."""
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


@celery_app.task(
    name="app.workers.tasks_ocr.download_and_process_documents",
    bind=True,
    max_retries=3,
    default_retry_delay=120,
)
def download_and_process_documents(self, tender_external_id: str, document_urls: list[str]):
    """
    Скачивает все документы тендера и запускает OCR для каждого.
    Поддерживает PDF, DOCX, XLSX, ZIP (FR-DOC-001, FR-DOC-002).
    """
    storage_dir = Path(settings.storage_path) / "tenders" / tender_external_id
    storage_dir.mkdir(parents=True, exist_ok=True)

    results = []

    for url in document_urls:
        try:
            local_path = _download_file(url, storage_dir)

            if local_path.suffix.lower() == ".zip":
                extracted_files = _extract_zip(local_path, storage_dir)
                for f in extracted_files:
                    extract_and_queue.delay(str(f), tender_external_id)
            else:
                extract_and_queue.delay(str(local_path), tender_external_id)

            results.append({"url": url, "status": "downloaded", "path": str(local_path)})

        except Exception as exc:
            logger.error("document_download_failed", url=url, error=str(exc))
            results.append({"url": url, "status": "failed", "error": str(exc)})

    return results


def _download_file(url: str, target_dir: Path) -> Path:
    """Скачивает файл по URL, сохраняет с именем из URL."""
    filename = url.split("/")[-1] or "document"
    target_path = target_dir / filename

    with httpx.stream("GET", url, timeout=60.0, follow_redirects=True) as response:
        response.raise_for_status()
        with open(target_path, "wb") as f:
            for chunk in response.iter_bytes():
                f.write(chunk)

    return target_path


def _extract_zip(zip_path: Path, target_dir: Path) -> list[Path]:
    """Распаковывает ZIP-архив, возвращает список путей к извлечённым файлам."""
    import zipfile

    extracted = []
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(target_dir)
        for name in zf.namelist():
            if not name.endswith("/"):  # пропускаем директории
                extracted.append(target_dir / name)

    return extracted


@celery_app.task(
    name="app.workers.tasks_ocr.extract_and_queue",
    bind=True,
    max_retries=2,
)
def extract_and_queue(self, file_path: str, tender_external_id: str):
    """
    Запускает OCR/извлечение текста для одного файла,
    затем передаёт результат на извлечение структурированных полей через LLM.
    """
    try:
        result = extract_document(file_path)

        logger.info(
            "document_extracted",
            file=file_path,
            status=result.status.value,
            pages=result.pages_count,
        )

        # TODO: сохранить result.full_text и result.status в таблицу Document

        # Следующий шаг — извлечение структурированных полей через LLM
        from app.workers.tasks_scoring import extract_fields_and_score
        extract_fields_and_score.delay(tender_external_id, result.full_text)

        return {"status": "extracted", "ocr_status": result.status.value}

    except ValueError as e:
        # неподдерживаемый тип файла — не ретраим, просто логируем
        logger.warning("unsupported_file_type", file=file_path, error=str(e))
        return {"status": "skipped", "reason": str(e)}

    except Exception as exc:
        logger.error("document_extraction_failed", file=file_path, error=str(exc))
        raise self.retry(exc=exc)
