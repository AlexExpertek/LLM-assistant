"""
Уведомления в Telegram. Реализует FR-OUT-001 ТЗ:
карточка должна содержать заказчика, предмет, сумму, срок подачи,
рейтинг, статус, 3-7 ключевых причин, критические риски и ссылку.
"""
import asyncio

from telegram import Bot

from app.core.config import settings
from app.core.logging import get_logger
from app.workers.celery_app import celery_app

logger = get_logger(__name__)


def format_tender_card(tender_external_id: str, scoring_data: dict) -> str:
    """Формирует текст карточки тендера для Telegram по формату FR-OUT-001."""
    score = scoring_data.get("total_score", 0)
    category = scoring_data.get("category")
    status = scoring_data.get("suggested_status")
    signals = scoring_data.get("signals", [])
    unknowns = scoring_data.get("critical_unknowns", [])

    status_emoji = {
        "can_apply": "✅",
        "needs_clarification": "⚠️",
        "manual_review": "🔍",
        "not_suitable": "❌",
    }
    emoji = status_emoji.get(status.value if hasattr(status, "value") else status, "")

    reasons_text = "\n".join(f"  • {s.reason}" for s in signals[:7])
    risks_text = "\n".join(f"  ⚠ {u}" for u in unknowns) if unknowns else "  нет критических рисков"

    return (
        f"{emoji} *Тендер #{tender_external_id}*\n\n"
        f"*Рейтинг:* {score} баллов ({category.value if hasattr(category, 'value') else category})\n"
        f"*Статус:* {status.value if hasattr(status, 'value') else status}\n\n"
        f"*Причины:*\n{reasons_text}\n\n"
        f"*Критические неизвестные:*\n{risks_text}\n\n"
        f"_Подробности и документы доступны в веб-кабинете._"
    )


@celery_app.task(name="app.workers.tasks_notify.send_telegram_notification")
def send_telegram_notification(tender_external_id: str, scoring_data: dict):
    """Отправляет карточку тендера в Telegram-чат."""
    if not settings.telegram_bot_token or not settings.telegram_chat_id:
        logger.warning("telegram_not_configured")
        return {"status": "skipped", "reason": "not_configured"}

    text = format_tender_card(tender_external_id, scoring_data)

    async def _send():
        bot = Bot(token=settings.telegram_bot_token)
        await bot.send_message(
            chat_id=settings.telegram_chat_id,
            text=text,
            parse_mode="Markdown",
        )

    try:
        asyncio.run(_send())
        logger.info("telegram_notification_sent", tender_id=tender_external_id)
        return {"status": "sent"}
    except Exception as exc:
        logger.error("telegram_send_failed", error=str(exc))
        return {"status": "failed", "error": str(exc)}
