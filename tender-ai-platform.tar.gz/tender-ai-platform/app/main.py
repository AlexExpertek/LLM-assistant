"""
Главное FastAPI приложение.
Эндпоинты для ручного запуска мониторинга, просмотра статуса задач,
и health-check для проверки работоспособности сервисов.
"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from app.core.config import settings
from app.core.logging import configure_logging, get_logger
from app.workers.celery_app import celery_app
from app.workers.tasks_parsing import SOURCE_REGISTRY, monitor_source

configure_logging()
logger = get_logger(__name__)

app = FastAPI(
    title="ИИ-ассистент тендеров и коммерческого развития",
    description="MVP тендерного ассистента — Блок I",
    version="0.1.0",
)


@app.get("/health")
async def health_check():
    """Проверка работоспособности приложения и подключённых сервисов."""
    return {
        "status": "ok",
        "environment": settings.environment,
        "llm_provider_default": settings.default_llm_provider,
    }


@app.get("/sources")
async def list_sources():
    """Список зарегистрированных источников мониторинга (FR-SRC-002)."""
    return {
        "sources": [
            {"key": key, "name": cfg["name"], "law_types": cfg["law_types"]}
            for key, cfg in SOURCE_REGISTRY.items()
        ]
    }


class TriggerMonitoringRequest(BaseModel):
    source_key: str


@app.post("/sources/trigger")
async def trigger_monitoring(payload: TriggerMonitoringRequest):
    """
    Ручной запуск мониторинга конкретного источника (FR-SRC-003:
    архитектура должна поддерживать ручной запуск).
    """
    if payload.source_key not in SOURCE_REGISTRY:
        raise HTTPException(status_code=404, detail="Источник не найден в реестре")

    task = monitor_source.delay(payload.source_key)
    logger.info("manual_trigger", source=payload.source_key, task_id=task.id)

    return {"status": "queued", "task_id": task.id}


@app.get("/tasks/{task_id}")
async def get_task_status(task_id: str):
    """Проверка статуса Celery-задачи по ID."""
    result = celery_app.AsyncResult(task_id)
    return {
        "task_id": task_id,
        "status": result.status,
        "result": result.result if result.ready() else None,
    }
