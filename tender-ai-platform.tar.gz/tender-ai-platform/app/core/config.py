"""
Центральная конфигурация приложения.
Все настройки читаются из переменных окружения (.env файл).
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- БД ---
    database_url: str
    database_url_sync: str

    # --- Redis / Celery ---
    redis_url: str
    celery_broker_url: str
    celery_result_backend: str

    # --- Qdrant ---
    qdrant_url: str

    # --- LLM ---
    anthropic_api_key: str = ""
    anthropic_model_default: str = "claude-sonnet-4-6"
    anthropic_model_cheap: str = "claude-haiku-4-5-20251001"

    yandex_api_key: str = ""
    yandex_folder_id: str = ""
    yandex_model_uri: str = ""

    default_llm_provider: str = "anthropic"  # anthropic | yandex

    # --- Telegram ---
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""

    # --- Bitrix24 ---
    bitrix24_webhook_url: str = ""

    # --- Прочее ---
    environment: str = "development"
    log_level: str = "INFO"
    storage_path: str = "/app/storage"


settings = Settings()
