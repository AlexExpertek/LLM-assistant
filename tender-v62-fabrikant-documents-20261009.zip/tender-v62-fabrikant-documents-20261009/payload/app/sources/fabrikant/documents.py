"""Observed public document rows and bounded, validated downloads."""
import re
from pathlib import Path
from urllib.parse import urlsplit,urljoin
from bs4 import BeautifulSoup
from app.sources.schemas import SourceDocument

HOSTS={'fabrikant.ru','www.fabrikant.ru','storage.fabrikant.ru'}
CARD=re.compile(r'^/v2/trades/procedure/view/([A-Za-z0-9_-]+)$')

def safe(url,storage=False):
    try:
        p=urlsplit(url)
        return p.scheme=='https' and p.hostname in (HOSTS if storage else HOSTS-{'storage.fabrikant.ru'}) and not p.username and not p.password and p.port in (None,443)
    except ValueError:return False

def documentation_url(card_url):
    if not safe(card_url):raise ValueError('fabrikant_invalid_card_host')
    match=CARD.fullmatch(urlsplit(card_url).path)
    if not match:raise ValueError('fabrikant_unsupported_card_kind')
    return 'https://www.fabrikant.ru/v2/trades/procedure/documentation/'+match[1]

def parse_documents(html,page):
    if not safe(page):raise ValueError('fabrikant_invalid_documentation_host')
    procedure=urlsplit(page).path.rsplit('/',1)[-1]
    soup=BeautifulSoup(html,'html.parser')
    docs={}
    expected_prefix='/v2/trades/procedure/documentation/download/single/'+procedure+'/'
    for row in soup.select('tr'):
        cell=row.select_one('td.procedure-document-file')
        a=row.select_one('a[href*="/documentation/download/single/"]')
        if not cell or not a:continue
        name=cell.get_text(' ',strip=True)
        if Path(name).name!=name or '\\' in name or name in ('.','..'):
            raise ValueError('fabrikant_invalid_filename')
        if Path(name).suffix.lower() not in ('.xls','.xlsx','.doc','.docx','.pdf'):continue
        url=urljoin(page,a['href']);p=urlsplit(url)
        if not safe(url) or not p.path.startswith(expected_prefix):
            raise ValueError('fabrikant_document_identity_mismatch')
        uid=p.path.rsplit('/',1)[-1]
        if not re.fullmatch(r'[A-Za-z0-9_-]+',uid):raise ValueError('fabrikant_invalid_file_id')
        docs[uid]=SourceDocument(external_id=uid,name=name,url=url)
    if not docs:raise ValueError('fabrikant_no_supported_document_rows')
    # A truncated/changed listing must not silently masquerade as complete.
    text=soup.get_text(' ',strip=True)
    total=re.search(r'Общее количество загруженных документов:\s*(\d+)',text)
    return list(docs.values()),int(total[1]) if total else None

def select_bundle(docs):
    def norm(d):return re.sub(r'[_\s]+',' ',d.name.lower())
    chosen=[d for d in docs if re.search(r'техническ\w* задан|техническ\w* требован|\bтз\b|\bтт\b|спецификац|описание объекта|^заявка(?:\s|\.)|номенклатур|перечень',norm(d))]
    if not chosen:raise ValueError('fabrikant_specification_not_identified')
    if len(chosen)>6:raise ValueError('fabrikant_document_limit')
    return chosen

def download(client,url,target,validate=None):
    if validate is None:
        from app.sources.public_http import validate_url
        validate=validate_url
    for _ in range(5):
        if not safe(url,storage=True):raise ValueError('fabrikant_unexpected_download_host')
        url=validate(url)
        with client.stream('GET',url) as response:
            if response.is_redirect:
                location=response.headers.get('location')
                if not location:raise ValueError('fabrikant_redirect_without_location')
                url=urljoin(url,location);continue
            if response.status_code!=200:raise ValueError('fabrikant_download_http_'+str(response.status_code))
            data=bytearray()
            for chunk in response.iter_bytes():
                data.extend(chunk)
                if len(data)>20*1024*1024:raise ValueError('fabrikant_file_over_20MB')
            raw=bytes(data);suffix=Path(target).suffix.lower()
            valid=(raw.startswith(b'%PDF-') if suffix=='.pdf' else
                   raw.startswith(b'PK') if suffix in ('.docx','.xlsx') else
                   raw.startswith(bytes.fromhex('D0CF11E0A1B11AE1')))
            if not valid:raise ValueError('fabrikant_file_signature_mismatch')
            Path(target).write_bytes(raw)
            return len(raw)
    raise ValueError('fabrikant_redirect_limit')

def enrich_items(items,fetch):
    """Metadata only, bounded to two commercial listings per collection."""
    attempts=0
    for item in items:
        url=item.get('source_url') or ''
        if not safe(url) or not CARD.fullmatch(urlsplit(url).path):
            item['documents_status']='detail_adapter_required'
            continue
        if attempts>=2:
            item['documents_status']='metadata_batch_limit'
            continue
        attempts+=1
        try:
            page=documentation_url(url)
            docs,total=parse_documents(fetch(page,timeout=25),page)
            selected=select_bundle(docs)
            item['documents']=[d.model_dump(mode='json') for d in selected]
            item['documents_total']=total
            item['documents_supported']=len(docs)
            item['documents_status']='links_found_not_downloaded'
        except Exception as exc:
            item['documents_status']='metadata_unavailable'
            item['documents_error']=str(exc) if isinstance(exc,ValueError) else type(exc).__name__
    return attempts
