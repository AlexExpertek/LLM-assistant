import tempfile
from pathlib import Path
import httpx
from app.sources.public_http import get_html
from app.sources.fabrikant.documents import documentation_url,parse_documents,select_bundle,download

url='https://fabrikant.ru/v2/trades/procedure/view/m-vwpg4KqZTn24GTmWkhfQ'
page=documentation_url(url)
docs,total=parse_documents(get_html(page,timeout=25),page)
selected=select_bundle(docs)
print('DOCUMENTS_TOTAL:',total)
print('SUPPORTED:',len(docs))
print('SELECTED:',[d.name for d in selected])
with tempfile.TemporaryDirectory(prefix='fabrikant-check-') as directory:
    with httpx.Client(timeout=30,follow_redirects=False,trust_env=False) as client:
        doc=next((d for d in selected if d.name=='Заявка.xls'),None)
        if doc is None:raise SystemExit('Control document not found')
        target=Path(directory)/doc.name
        size=download(client,doc.url,target)
        print('FILE:',doc.name,'BYTES:',size)
        from app.ocr.legacy_excel import extract_xls
        text=extract_xls(str(target))
        if not isinstance(text,str) or not text.strip():raise ValueError('Empty XLS extraction')
        print('TEXT_CHARACTERS:',len(text))
        print('XLS_EXTRACTION_OK')
print('Temporary files deleted. No DB writes, tasks, LLM or notifications.')
