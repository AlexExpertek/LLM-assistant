#!/usr/bin/env bash
set -Eeuo pipefail
pkg_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "${TENDER_PROJECT_DIR:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
docker compose exec -T celery_worker python - <<'PY'
from app.ocr.legacy_excel import extract_xls
print('XLS_HANDLER_PRESENT')
PY
python3 "$pkg_dir/apply.py" --project "$PWD"
docker compose build app celery_worker celery_discovery
docker compose run --rm --no-deps -T -e PYTHONPATH=/app celery_discovery python - < "$pkg_dir/test_documents.py"
docker compose up -d --no-deps --timeout 60 app celery_worker celery_discovery
printf '\nFABRIKANT_DOCUMENTS_UPDATE_INSTALLED\nSchedule retained. Document metadata enabled; automatic OCR/LLM not enabled.\n'
