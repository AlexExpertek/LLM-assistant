#!/usr/bin/env bash
set -Eeuo pipefail
pkg_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
test -f app/sources/gpb/adapter.py
python3 "$pkg_dir/apply.py" --project "$PWD"
docker compose build app celery_worker celery_discovery
docker compose run --rm --no-deps -T -e PYTHONPATH=/app -v "$pkg_dir:/gpb-cache-check:ro" celery_discovery python /gpb-cache-check/test_cache.py
docker compose up -d --no-deps --timeout 60 app celery_worker celery_discovery
printf '%s\n' 'GPB_DOCUMENT_CACHE_INSTALLED' 'No immediate collection, LLM or notifications. Existing schedule retained.'
