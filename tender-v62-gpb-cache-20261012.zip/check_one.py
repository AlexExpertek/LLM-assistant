"""Live document-cache probe, no database writes or queued analysis."""
import json
from pathlib import Path
from app.core.config import settings
from app.sources.gpb.transport import fetch
from app.sources.gpb.card import decode_store
from app.sources.gpb.adapter import build_card
from app.sources.gpb.document_cache import cached_downloads, DocumentsIncomplete
url='https://etpgpb.ru/procedures/etp/1297476-materialy-dlya-ehz/'
tender=build_card(decode_store(fetch(url)), '2073064', url)
if tender is None:raise SystemExit('CARD_NO_LONGER_OPEN: no document requests')
try:
    rows=cached_downloads(tender,Path(settings.storage_path)/'gpb_document_cache')
    print('DOCUMENT_BUNDLE_COMPLETE:',len(rows))
except DocumentsIncomplete as exc:
    print(json.dumps(exc.report,ensure_ascii=False,indent=2))
print('CACHE_CHECK: files/status saved; no DB writes, tasks, OCR, LLM or notifications')
