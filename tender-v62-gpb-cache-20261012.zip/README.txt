GPB document cache update 2026-10-12
Run install.sh from project root. Hash guard checks all files before mutation;
backup is printed. Existing transport (including RETRY_V2) is untouched.
Cache stores validated downloads under storage_path/gpb_document_cache. Each
snapshot includes document references and revision metadata. Actual SHA256 is
checked on reuse; declared hash_number is not used as a content checksum.
Partial failures are recorded individually. All listed documents must be
available before OCR/LLM is queued. Shared ingestion records manual_review +
processing failed + gpb_documents diagnostics for incomplete GPB bundles.
This does not claim completed analysis or force dashboard approval.
Existing successful analysis/dismissal and queue limits remain. Next permitted
pipeline attempt reuses valid cached files; this patch creates no new recurring
retry schedule. Existing 24-hour enqueue reservation may defer another attempt.
Cache snapshots remain on disk; no automatic eviction is added in this patch.
No claim is made that the unavailable DOCX endpoint has been fixed.
check_cache.py reads the last ten local cache reports without network/DB writes.
