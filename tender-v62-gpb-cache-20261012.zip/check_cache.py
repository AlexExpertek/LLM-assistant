"""Read-only local cache status: no requests, tasks or LLM."""
import json
from pathlib import Path
from app.core.config import settings
root=Path(settings.storage_path)/'gpb_document_cache'
reports=sorted(root.glob('*/*/status.json'),key=lambda p:p.stat().st_mtime,reverse=True)[:10]
for p in reports: print(p.read_text())
if not reports:print('CACHE: no document attempts with the new loader yet')
print('READ_ONLY: no HTTP, file writes, DB changes, queues or LLM')
