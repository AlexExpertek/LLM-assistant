import copy
import tempfile
import unittest
from pathlib import Path
from app.sources.schemas import SourceTender, SourceDocument
from app.sources.gpb.document_cache import cached_downloads, DocumentsIncomplete

def tender():
    return SourceTender(source='gpb',external_id='123',title='test',documents=[
        SourceDocument(name='a.txt',url='https://etp.gpb.ru/file/get/a'),
        SourceDocument(name='b.txt',url='https://etp.gpb.ru/file/get/b')],
        raw_payload={'gpb':{'public_card':{'procedure':{'relationships':{'docs':{'date':'v1'}}},'lots':[]}}})

class CacheTests(unittest.TestCase):
    def test_partial_retry_only_missing(self):
        calls=[]
        def first(url,**kw):
            calls.append(url)
            if url.endswith('/b'):raise ValueError('gpb_curl_error_56')
            return b'first document'
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(DocumentsIncomplete) as c:cached_downloads(tender(),d,first)
            self.assertEqual(len(c.exception.report['documents']),1)
            self.assertEqual(len(c.exception.report['errors']),1)
            calls.clear()
            rows=cached_downloads(tender(),d,lambda url,**kw:(calls.append(url) or b'second document'))
            self.assertEqual(calls,['https://etp.gpb.ru/file/get/b'])
            self.assertEqual(rows[0][1].read_bytes(),b'first document')
    def test_corrupt_cache_reloaded(self):
        with tempfile.TemporaryDirectory() as d:
            rows=cached_downloads(tender(),d,lambda *a,**k:b'ok')
            rows[0][1].write_bytes(b'corrupted')
            calls=[]
            cached_downloads(tender(),d,lambda url,**kw:(calls.append(url) or b'fixed'))
            self.assertEqual(len(calls),1)
    def test_revision_change(self):
        with tempfile.TemporaryDirectory() as d:
            t=tender();cached_downloads(t,d,lambda *a,**k:b'ok')
            t.raw_payload['gpb']['public_card']['procedure']['relationships']['docs']['date']='v2'
            calls=[];cached_downloads(t,d,lambda url,**kw:(calls.append(url) or b'new'))
            self.assertEqual(len(calls),2)
    def test_empty_not_cached(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(DocumentsIncomplete):cached_downloads(tender(),d,lambda *a,**k:b'')
            self.assertEqual(list(Path(d).rglob('*.bin')),[])
    def test_same_filename_distinct_urls(self):
        with tempfile.TemporaryDirectory() as d:
            t=tender();t.documents[1].name='a.txt'
            rows=cached_downloads(t,d,lambda url,**kw:url.encode())
            self.assertNotEqual(rows[0][1],rows[1][1])
if __name__=='__main__':unittest.main()
