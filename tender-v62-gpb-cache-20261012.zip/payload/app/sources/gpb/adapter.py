import hashlib
import json
import re
import shutil
import tempfile
from pathlib import Path
from app.sources.schemas import SourceTender, SourceDocument
from .transport import fetch, valid_url
from .card import card_path, decode_store, inspect_store, relation


def identity(item):
    card_path(item.get('source_url') or '')
    uid = str(item.get('external_id') or '')
    if not uid.isdigit():
        raise ValueError('gpb_invalid_id')
    return 'gpb', uid


def references(info):
    docs = {}
    for parent in (info['procedure'], info['lot']):
        rows = relation(parent, 'docs')
        if not isinstance(rows, list):
            raise ValueError('gpb_document_list_missing')
        for row in rows:
            a = row.get('attributes') or {}
            name = a.get('file_title') or a.get('file_name') or ''
            if not name or len(name) > 180 or '/' in name or '\\' in name or any(ord(c) < 32 for c in name):
                raise ValueError('gpb_document_name_invalid')
            url = a.get('url') or ''
            if not valid_url(url, document=True):
                raise ValueError('gpb_document_url_invalid')
            from app.sources.metal_it.documents import EXTENSIONS
            if Path(name).suffix.lower() not in EXTENSIONS | {'.zip'}:
                raise ValueError('gpb_document_format_requires_review')
            # Do not deduplicate solely by filename or unverified declared hash.
            docs[url] = SourceDocument(external_id=str(row['id']), name=name, url=url)
    if not docs or len(docs) > 8:
        raise ValueError('gpb_document_count_requires_review')
    return list(docs.values())


def build_card(store, external_id, source_url, now=None):
    info = inspect_store(store, external_id, source_url, now)
    if info is None:
        return None
    p = info['procedure']; a = p['attributes']
    company = relation(p, 'company') or {}
    company = company.get('attributes') or {}
    return SourceTender(source='gpb', external_id=str(external_id),
        title=a.get('title') or '', source_url=source_url,
        customer_name=company.get('name') or company.get('full_name'),
        customer_inn=company.get('inn'), submission_deadline=info['deadline'],
        procurement_method=a.get('humanized_procedure_type'),
        documents=references(info),
        raw_payload={'stage': 'detail', 'procurement_status': 'Прием заявок',
            'suppress_notifications': True, 'positions': info['positions'],
            'gpb': {'public_card': {'procedure': p, 'lots': [info['lot']]},
                    'all_positions_required': info['all_positions_required'],
                    'participation_unknown': info['participation_unknown']}})


class GpbAdapter:
    def fetch_by_id(self, external_id, source_url=None):
        identity({'external_id': external_id, 'source_url': source_url})
        from app.reports.review_dismissals import is_dismissed
        if is_dismissed('gpb', str(external_id)):
            return None
        return build_card(decode_store(fetch(source_url)), external_id, source_url)

    def fetch_by_url(self, url):
        card_path(url)
        store = decode_store(fetch(url))
        uid = str((store.get('procedure') or {}).get('id') or '')
        identity({'external_id': uid, 'source_url': url})
        from app.reports.review_dismissals import is_dismissed
        if is_dismissed('gpb', uid):
            return None
        return build_card(store, uid, url)


def resolve(item):
    _, uid = identity(item)
    return GpbAdapter().fetch_by_id(uid, source_url=item['source_url'])


def materialize(tender):
    from app.core.config import settings
    from app.sources.metal_it.documents import unpack
    fresh = GpbAdapter().fetch_by_id(tender.external_id, tender.source_url)
    if fresh is None:
        raise ValueError('gpb_no_longer_eligible')
    # Ignore countdown fields; compare substantive snapshot and document references.
    if (fresh.documents != tender.documents or fresh.submission_deadline != tender.submission_deadline
            or fresh.raw_payload['positions'] != tender.raw_payload.get('positions')
            or any(fresh.raw_payload['gpb'].get(k) != (tender.raw_payload.get('gpb') or {}).get(k)
                   for k in ('all_positions_required', 'participation_unknown'))):
        raise ValueError('gpb_card_changed_retry_required')
    from .document_cache import cached_downloads
    downloaded = cached_downloads(fresh, Path(settings.storage_path) / 'gpb_document_cache')
    root = Path(settings.storage_path) / 'gpb_prepared'
    root.mkdir(parents=True, exist_ok=True)
    directory = Path(tempfile.mkdtemp(prefix=str(tender.external_id) + '-', dir=root))
    result = []; counter = 0; total = 0; seen = set()
    try:
        for doc, cached_file in downloaded:
            data = cached_file.read_bytes()
            digest = hashlib.sha256(data).hexdigest()
            if digest in seen:
                continue
            seen.add(digest)
            files, counter, total = unpack(data, doc, directory, counter, total)
            result.extend(files)
        snapshot = directory / '00_Позиции_ГПБ.txt'
        lot = fresh.raw_payload['gpb']['public_card']['lots'][0]
        text = {'notice': 'Публичные позиции карточки. Повторения из приложений не суммировать. source_unit_id — идентификатор площадки, не номер строки спецификации.',
                'positions': fresh.raw_payload['positions'],
                'lot_conditions': {k:v for k,v in lot.get('attributes', {}).items() if not k.endswith('_translation')}}
        snapshot.write_text(json.dumps(text, ensure_ascii=False, indent=2), encoding='utf-8')
        result.insert(0, SourceDocument(name=snapshot.name, download_type='local_file', local_path=str(snapshot)))
        return result
    except Exception:
        shutil.rmtree(directory, ignore_errors=True)
        raise
