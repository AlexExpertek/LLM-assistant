#!/usr/bin/env bash
set -Eeuo pipefail
pkg_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
project_dir="${TENDER_PROJECT_DIR:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
cd "$project_dir"
test -f docker-compose.yml
python3 "$pkg_dir/apply.py" --project "$project_dir"
docker compose build app celery_worker celery_discovery
docker compose run --rm --no-deps -T celery_worker python - < "$pkg_dir/verify.py"
docker compose run --rm --no-deps -T celery_worker python - < "$pkg_dir/regression.py"
docker compose up -d --no-deps --timeout 60 app celery_worker celery_discovery
printf '\nCURRENT_ONLY_UPDATE_INSTALLED\nNo immediate collection, LLM requests or DB cleanup started. Existing schedule retained.\n'
