EIS freshness guard 2026-09-30
Scope: EIS only. No mass retries, notifications, migrations or deletion of stored documents/decisions.
Closed search stages are not queued. Incoming expired/inactive records are skipped before resetting analysis.
Before document preparation, OCR and LLM, stored activity/deadline/stage are checked again.
Unknown deadline: automatic expensive processing paused with freshness_unknown, manual_review for unanalyzed records. Unknown does NOT set is_active=False.
Search dates have no exact time/zone and are hydrated first. Existing inactive records are not automatically reopened.
Limitations: no live status refresh at OCR/LLM gate; uses latest stored data. No 44-FZ detail support added. No classification, merge or cache changes. Does not interrupt tasks already executing.
Installation: upload ZIP to GitHub, download to /tmp, verify SHA256, extract, bash install.sh. Installer checks all source hashes, backs up files, builds, tests, imports, then recreates app/worker/discovery. Beat unchanged.
Local verification: 12 policy tests; source compilation; installer dry-run and idempotence. On server the same tests and imports run before restart.
