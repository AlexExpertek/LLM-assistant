import unittest
from datetime import datetime, timezone, timedelta
from app.sources.eis_freshness import eligibility

class Checks(unittest.TestCase):
    def check(self, expected, deadline=None, raw=None, active=True, source='zakupki_gov_ru'):
        self.assertEqual(expected, eligibility(source, deadline, raw, active,
                         datetime(2026,9,30,6,tzinfo=timezone.utc)))
    def test_expired(self):
        self.check('deadline_expired', datetime(2020,7,15,7))
    def test_future(self):
        self.check(None, datetime(2026,10,12,7))
    def test_exact_boundary(self):
        self.check('deadline_expired', datetime(2026,9,30,6))
    def test_timezone(self):
        self.check('deadline_expired', datetime(2026,9,30,9,tzinfo=timezone(timedelta(hours=3))))
    def test_closed_overrides_future(self):
        for status in ['Работа комиссии','Закупка завершена','Закупка отменена','Определение поставщика завершено']:
            self.check('closed_stage', datetime(2026,10,12), {'search_item':{'status':status}})
    def test_inactive(self):
        self.check('inactive',datetime(2026,10,12),active=False)
    def test_unknown(self):
        self.check('freshness_unknown',raw={'stage':'detail'})
    def test_invalid_date(self):
        self.check('freshness_unknown','garbage')
    def test_search_date_not_midnight_deadline(self):
        self.check('needs_detail',datetime(2026,9,30),{'stage':'search'})
    def test_missing_search_date(self):
        self.check('needs_detail',raw={'stage':'search'})
    def test_old_open_status_not_enough(self):
        self.check('freshness_unknown',raw={'procurement_status':'Подача заявок'})
    def test_other_sources_unchanged(self):
        for source in ['kontur_zakupki','tender_pro','b2b_center']:
            self.check(None,datetime(2020,1,1),active=False,source=source)

unittest.main()
