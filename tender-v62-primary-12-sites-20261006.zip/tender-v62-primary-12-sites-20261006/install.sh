#!/usr/bin/env bash
set -Eeuo pipefail
pkg_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
project_dir="${TENDER_PROJECT_DIR:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
cd "$project_dir"
test -f docker-compose.yml
test -f app/marketplace_discovery/product_screening.py
python3 "$pkg_dir/apply.py" --project "$project_dir"
docker compose build app celery_worker celery_discovery celery_beat
docker compose run --rm --no-deps -T celery_discovery python - < "$pkg_dir/test_primary.py"
docker compose stop celery_beat
docker compose up -d --no-deps --timeout 60 app celery_worker celery_discovery
docker compose up -d --no-deps --timeout 60 celery_beat
printf '\nPRIMARY_12_SITES_UPDATE_INSTALLED\nTwelve scheduled sources enabled.\n'

if [[ "${1:-}" == "--start" ]]; then
    docker compose exec -T celery_discovery python - --start < "$pkg_dir/run_once.py"
fi
