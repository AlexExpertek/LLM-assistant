"""Optional immediate run or read-only latest report."""
import sys,json
from app.marketplace_discovery.primary.collector import SITES,reports
if '--start' in sys.argv:
    from app.workers.tasks_primary_discovery import collect_primary
    for site in SITES:
        task=collect_primary.delay(site)
        print(site,'TASK_ID:',task.id)
else:
    rows=reports()
    if not rows:print('NO_RUNS_YET: scheduled collection has not recorded a report')
    for r in rows:
        print(json.dumps(r,ensure_ascii=False,indent=2,default=str))
