"""Low-cost collection of primary public information on known marketplaces."""
from app.workers.celery_app import celery_app
from app.workers.execution_guard import exclusive_task
from app.marketplace_discovery.primary.collector import collect

@celery_app.task(name='app.workers.tasks_primary_discovery.collect_primary')
@exclusive_task('primary-discovery', argument='site')
def collect_primary(site):
    result=collect(site)
    return {k:v for k,v in result.items() if k!='items'} | {'items_saved':len(result['items'])}
