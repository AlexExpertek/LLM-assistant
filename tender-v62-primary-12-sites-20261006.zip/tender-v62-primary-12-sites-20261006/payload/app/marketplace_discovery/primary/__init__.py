"""Bounded public primary-information collection, separate from full tender analysis."""
