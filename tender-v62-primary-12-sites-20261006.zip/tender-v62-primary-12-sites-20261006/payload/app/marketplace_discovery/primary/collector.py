"""Observed HTML links/GET forms only. No undocumented API, login or JS bypass."""
import hashlib
import json
import os
import re
import tempfile
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.parse import urljoin, urlsplit, urlencode, parse_qsl
from bs4 import BeautifulSoup
from app.core.config import settings
from app.sources.public_http import get_html
from app.scoring.selection_policy import FALLBACK_QUERIES, OKPD2_PREFIXES
from app.marketplace_discovery.subject_classifier import classify_tender_subject
from app.marketplace_discovery.product_screening import aluminium_evidence

SITES = {
 'gpb': ('ЭТП ГПБ','https://etpgpb.ru/procedures/'),
 'rosatom': ('Росатом','https://zakupki.rosatom.ru/?link=brif'),
 'metal_it': ('METAL-IT','https://etp.metal-it.ru/frame/index.html'),
 'acron': ('Акрон','https://etp.acron.ru/app'),
 'tektorg': ('ТЭК-Торг','https://www.tektorg.ru/'),
 'roseltorg': ('Росэлторг','https://www.roseltorg.ru/procedures/search'),
 'fabrikant': ('Фабрикант','https://www.fabrikant.ru/'),
 'estp': ('ESTP — 223-ФЗ','https://comm.estp.ru/office/public/announces?type=223'),
 'torgi223': ('Торги223','https://torgi223.ru/reestr-zakupok/'),
 'etprf': ('ЭТПРФ — корпоративные закупки','https://web.etprf.ru/'),
 'etpzakaz': ('ЭТП Заказ','https://etpzakaz.ru/search/index'),
 'goszakupki_by': ('Госзакупки Беларуси','https://goszakupki.by/'),
}
BLOCK = re.compile(r'captcha|access denied|web application firewall|подтвердите,? что вы|техническая поддержка|технические работы',re.I)
CARD = re.compile(r'(?:tender|procedure|purchase|notice|notification|announce|request|zakup|trade|lot)[^?#]*\d|/\d{8,}(?:[/?]|$)',re.I)
DEADLINE = re.compile(r'(?:дата\s+и\s+время\s+)?(?:окончани[ея]\s+(?:срока\s+)?(?:подачи|при[её]ма)\s+заявок|при[её]м\s+заявок\s+до)\s*:?\s*(\d{2}\.\d{2}\.\d{4})\s+(\d{2}:\d{2})(?:\s*\(?\s*(МСК(?:\s*[+-]\s*\d{1,2})?|UTC\s*[+-]\s*\d{1,2})\s*\)?)?',re.I)


def same_site(url, base):
    try:
        p,b=urlsplit(url),urlsplit(base)
        return (p.scheme=='https' and p.hostname==b.hostname and not p.username
                and not p.password and p.port in (None,443))
    except ValueError:return False


def soup_for(html):
    soup=BeautifulSoup(html,'html.parser')
    title=soup.title.get_text(' ',strip=True) if soup.title else ''
    for node in soup(['script','style','nav','footer','header']):node.decompose()
    if BLOCK.search(title+' '+soup.get_text(' ',strip=True)[:3000]):
        raise ValueError('access_or_technical_page')
    return soup


def card_links(soup, base):
    result={}
    for a in soup.select('a[href]'):
        url=urljoin(base,a['href']).split('#')[0]
        title=a.get_text(' ',strip=True)
        if re.search(r'/(?:marketing|purchases-items|plans?)/',urlsplit(url).path,re.I):continue
        if same_site(url,base) and CARD.search(url) and len(title)>12:
            if classify_tender_subject(title).allowed and aluminium_evidence(title):result[url]=title
    return list(result.items())


def search_urls(soup, base, query):
    """Submit only observed read-only search forms, retaining their own field names."""
    urls=[]
    for f in soup.find_all('form'):
        if f.get('method','get').lower()!='get':continue
        action=urljoin(base,f.get('action') or base)
        if not same_site(action,base):continue
        fields=f.select('input[name]')
        field=next((x for x in fields if x.get('name','').lower() in ('q','query','search','searchstring','searchtext','search_text','keyword','text') and x.get('type','text') in ('text','search')),None)
        if field is None or f.select('input[type=password]'):continue
        params=dict(parse_qsl(urlsplit(action).query))
        params.update({x['name']:x.get('value','') for x in fields if x.get('type')=='hidden' and not re.search('token|key|csrf|password',x['name'],re.I)})
        params[field['name']]=query
        urls.append(urlsplit(action)._replace(query=urlencode(params),fragment='').geturl())
    return urls[:1]


def labeled(soup, labels):
    for row in soup.select('tr'):
        cells=row.find_all(['th','td'],recursive=False)
        if len(cells)==2 and re.fullmatch(labels,cells[0].get_text(' ',strip=True).rstrip(':'),re.I):
            return cells[1].get_text(' ',strip=True)[:500]
    for dt in soup.select('dt'):
        if re.fullmatch(labels,dt.get_text(' ',strip=True).rstrip(':'),re.I):
            dd=dt.find_next_sibling('dd')
            if dd:return dd.get_text(' ',strip=True)[:500]
    return None


def parse_card(html, url, link_title, site, now=None):
    soup=soup_for(html);text=soup.get_text(' ',strip=True)
    title=labeled(soup,r'предмет закупки|наименование закупки|наименование процедуры')
    if not title:
        h=soup.find('h1');title=h.get_text(' ',strip=True) if h else link_title
    if re.match(r'\s*(?:продажа|реализация)\b',title,re.I):return None,'sale_not_purchase'
    if not classify_tender_subject(title).allowed or not aluminium_evidence(title):return None,'non_target'
    if re.search(r'\b(?:закупка завершена|закупка отменена|при[её]м заявок заверш[её]н|работа комиссии)\b',text,re.I):return None,'closed'
    deadlines=set()
    for m in DEADLINE.finditer(text):
        zone=m[3]
        # Never infer a timezone or midnight from a calendar-only date.
        if not zone:continue
        zone=re.sub(r'\s+','',zone.upper())
        offset=(3 if zone.startswith('МСК') else 0)
        suffix=re.search(r'([+-]\d+)$',zone)
        if suffix:offset+=int(suffix[1])
        if not -12<=offset<=14:continue
        try:dt=datetime.strptime(m[1]+' '+m[2],'%d.%m.%Y %H:%M').replace(tzinfo=timezone(timedelta(hours=offset))).astimezone(timezone.utc)
        except ValueError:continue
        deadlines.add(dt)
    if len(deadlines)!=1:return None,'deadline_unconfirmed'
    deadline=next(iter(deadlines))
    if deadline<=(now or datetime.now(timezone.utc)):return None,'expired'
    customer=labeled(soup,r'заказчик|наименование заказчика|организатор')
    amount=labeled(soup,r'начальная.*цена.*|НМЦК|НМЦД|сумма.*')
    published=labeled(soup,r'дата публикации.*|дата размещения.*')
    return dict(source=site,source_url=url,title=title,customer=customer,
        submission_deadline=deadline.isoformat(),amount_text=amount,published_text=published,
        analysis_done=False,mass_kg=None,mass_status='not_verified',
        status='primary_information',eligibility='not_confirmed_500kg',
        collected_at=(now or datetime.now(timezone.utc)).isoformat()),None


def folder():return Path(settings.storage_path)/'marketplace_primary'


def save_report(site, report):
    if not re.fullmatch(r'[a-z0-9_]+',site):raise ValueError('Invalid source')
    root=folder();root.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(dir=root,suffix='.tmp')
    try:
        with os.fdopen(fd,'w',encoding='utf8') as f:json.dump(report,f,ensure_ascii=False,default=str)
        os.replace(tmp,root/(site+'.json'))
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def reports():
    output=[]
    for p in sorted(folder().glob('*.json')):
        try:r=json.loads(p.read_text())
        except (ValueError,OSError):continue
        now=datetime.now(timezone.utc)
        # Expired cards disappear even if the next collection has not run yet.
        r['items']=[x for x in r.get('items',[]) if datetime.fromisoformat(x['submission_deadline'])>now]
        output.append(r)
    return output


def collect(site, *, persist=True, base=None, fetch=None):
    name,url=SITES[site] if site in SITES else (site,base)
    if not url:raise ValueError('Unknown source')
    fetch=fetch or (estp_html if site=='estp' else get_html)
    now=datetime.now(timezone.utc)
    queries=(*OKPD2_PREFIXES,*FALLBACK_QUERIES)
    query=queries[(now.toordinal()*6+now.hour//4)%len(queries)]
    report=dict(source=site,name=name,seed_url=url,checked_at=now.isoformat(),query=query,
                status='partial',coverage='bounded_public_html',requests=0,items=[],skipped={},errors=[])
    def read(target):
        if not same_site(target,url):raise ValueError('off_site_link')
        if report['requests']>=8:raise ValueError('request_budget')
        if report['requests']:time.sleep(1.1)
        report['requests']+=1
        return soup_for(fetch(target,timeout=12))
    try:
        landing=read(url)
        if site=='estp':
            inline,skips,count=estp_cards(landing,url)
            report.update(items=inline,skipped=skips,cards_checked=count,
                          status='partial' if inline else ('no_matches_in_checked_html' if count else 'requires_adapter'),
                          coverage='first_public_listing_only',query=None)
            if persist:save_report(site,report)
            return report
        links=card_links(landing,url)
        searches=search_urls(landing,url,query)
        for search in searches:
            links+=card_links(read(search),search)
        links=list(dict(links).items())
        report['links_found']=len(links)
        if not links:
            report['status']='no_matches_in_checked_html' if searches else 'requires_adapter'
        for target,title in links[:5]:
            try:
                soup=read(target)
                item,reason=parse_card(str(soup),target,title,site)
                if item:report['items'].append(item)
                else:report['skipped'][reason]=report['skipped'].get(reason,0)+1
            except Exception as exc:
                report['errors'].append({'phase':'card','type':type(exc).__name__})
    except Exception as exc:
        report['status']='unavailable'
        report['errors'].append({'phase':'listing','type':type(exc).__name__,
            'reason':'technical_or_access_page' if isinstance(exc,ValueError) and str(exc)=='access_or_technical_page' else 'request_failed'})
    if persist:save_report(site,report)
    return report


def estp_html(url, timeout=12):
    """Observed ESTP listing is 3.5 MB; retain a bounded 5 MB read."""
    import httpx
    from app.sources.public_http import validate_url
    url=validate_url(url)
    with httpx.Client(timeout=timeout,follow_redirects=False,trust_env=False) as client:
        with client.stream('GET',url) as response:
            response.raise_for_status()
            if 'text/html' not in response.headers.get('content-type','').lower():raise ValueError('Not HTML')
            data=bytearray()
            for chunk in response.iter_bytes():
                data.extend(chunk)
                if len(data)>5_000_000:raise ValueError('HTML size limit')
            return data.decode(response.encoding or 'utf-8',errors='replace')


def estp_cards(soup, url):
    result=[];skipped={};seen=set()
    for node in soup.select('.tender-card[data-tender-id]'):
        identifier=node.get('data-tender-id')
        if identifier in seen:continue
        seen.add(identifier)
        stage=node.get('data-tender-stage','').strip().lower()
        if stage not in ('приём заявок','прием заявок'):
            skipped['not_open']=skipped.get('not_open',0)+1;continue
        item,reason=parse_card(str(node),url,node.get('data-tender-name',''),'estp')
        if item:
            def value(label):
                for row in node.select('.tender-detail'):
                    key=row.select_one('.detail-label');v=row.select_one('.detail-value')
                    if key and v and key.get_text(strip=True).rstrip(':')==label:return v.get_text(' ',strip=True)
                return None
            item.update(external_id=identifier,eis_number=node.get('data-eis'),
                        customer=value('Заказчик'),published_text=value('Дата публикации'),
                        source_url_kind='listing',region=value('Регион'))
            # Price is the procurement amount, not data-tender-price (participation fee).
            price=node.select_one('.tender-price .price-value')
            item['amount_text']=price.get_text(' ',strip=True) if price else None
            result.append(item)
        else:skipped[reason]=skipped.get(reason,0)+1
    return result,skipped,len(seen)
