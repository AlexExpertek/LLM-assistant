import os,unittest,tempfile
for k,v in dict(DATABASE_URL='postgresql+asyncpg://test:test@127.0.0.1/test',DATABASE_URL_SYNC='postgresql://test:test@127.0.0.1/test',REDIS_URL='redis://127.0.0.1:6379/0',CELERY_BROKER_URL='memory://',CELERY_RESULT_BACKEND='cache+memory://',QDRANT_URL='http://127.0.0.1:6333').items():os.environ[k]=v
from unittest.mock import patch
from datetime import datetime,timezone
from pathlib import Path
from app.marketplace_discovery.primary import collector as c
NOW=datetime(2026,10,6,tzinfo=timezone.utc)
BASE='https://example.test/procedures/'
def card(date='12.10.2026 18:00 (МСК+8)',title='Поставка листа алюминиевого'):
 return f'<html><h1>{title}</h1><dl><dt>Заказчик</dt><dd>Завод</dd><dt>НМЦК</dt><dd>1 200 000 руб.</dd></dl><p>Окончание подачи заявок: {date}</p></html>'
class Tests(unittest.TestCase):
 def test_seven_sites(self):
  self.assertEqual(len(c.SITES),12);self.assertFalse(any('kontur' in x[1] for x in c.SITES.values()))
 def test_public_fields(self):
  r,e=c.parse_card(card(),BASE+'12345','fallback','gpb',NOW)
  self.assertIsNone(e);self.assertEqual(r['customer'],'Завод');self.assertEqual(r['submission_deadline'],'2026-10-12T07:00:00+00:00');self.assertFalse(r['analysis_done']);self.assertIsNone(r['mass_kg'])
 def test_unknown_timezone_not_assumed(self):
  for date in ['12.10.2026','12.10.2026 18:00']:
   self.assertEqual(c.parse_card(card(date),BASE,'','gpb',NOW)[1],'deadline_unconfirmed')
 def test_expired(self):self.assertEqual(c.parse_card(card('01.10.2026 12:00 (МСК)'),BASE,'','gpb',NOW)[1],'expired')
 def test_conflicting_dates(self):self.assertEqual(c.parse_card(card()+'<p>Окончание подачи заявок: 15.10.2026 10:00 (МСК)</p>',BASE,'','gpb',NOW)[1],'deadline_unconfirmed')
 def test_closed(self):self.assertEqual(c.parse_card(card()+'Закупка завершена',BASE,'','gpb',NOW)[1],'closed')
 def test_steel_and_chemicals(self):
  for name in ['Стальной прокат','Сульфат алюминия','Кабельная продукция для ООО Клен']:
   self.assertEqual(c.parse_card(card(title=name),BASE,'','gpb',NOW)[1],'non_target')
 def test_sales(self):self.assertEqual(c.parse_card(card(title='Продажа алюминиевого листа'),BASE,'','gpb',NOW)[1],'sale_not_purchase')
 def test_observed_get_search(self):
  html='<form action="/find"><input type="search" name="q"><input type="hidden" name="mode" value="buy"></form>'
  url=c.search_urls(c.soup_for(html),BASE,'АД31')[0]
  self.assertIn('q=',url);self.assertIn('mode=buy',url);self.assertTrue(url.startswith('https://example.test/find?'))
 def test_no_post_or_password(self):
  for html in ['<form method="post"><input name="q"></form>','<form><input name="q"><input type="password"></form>','<form action="https://other.test"><input name="q"></form>']:
   self.assertEqual(c.search_urls(c.soup_for(html),BASE,'x'),[])
 def test_no_other_host_cards(self):
  html='<a href="https://other.test/tender/12345">Поставка листа алюминиевого</a>'
  self.assertEqual(c.card_links(c.soup_for(html),BASE),[])
 def test_technical_page(self):
  with self.assertRaises(ValueError):c.soup_for('<title>Техническая поддержка</title>')
 def test_js_shell_requires_adapter(self):
  r=c.collect('test',base=BASE,persist=False,fetch=lambda *a,**k:'<div id="app"></div>')
  self.assertEqual(r['status'],'requires_adapter');self.assertEqual(r['items'],[])
 def test_transport_failure_not_no_results(self):
  def fetch(*a,**k):raise TimeoutError()
  self.assertEqual(c.collect('test',base=BASE,persist=False,fetch=fetch)['status'],'unavailable')
 def test_collection_and_dedup(self):
  html='<a href="/procedure/12345">Поставка листа алюминиевого</a>'*2
  with patch.object(c.time,'sleep'):
   r=c.collect('test',base=BASE,persist=False,fetch=lambda u,**k:html if u==BASE else card('12.10.2099 18:00 (МСК)'))
  self.assertEqual(r['requests'],2);self.assertEqual(len(r['items']),1);self.assertEqual(r['status'],'partial')
 def test_latest_snapshot_replaces_old(self):
  with tempfile.TemporaryDirectory() as d, patch.object(c,'folder',return_value=Path(d)):
   c.save_report('test',{'items':[{'submission_deadline':'2000-01-01T00:00:00+00:00'}]})
   self.assertEqual(c.reports()[0]['items'],[])
   c.save_report('test',{'items':[],'status':'unavailable'})
   self.assertEqual(len(list(Path(d).glob('*.json'))),1)
 def test_schedule_and_route(self):
  from app.workers.celery_app import celery_app
  from app.workers.tasks_primary_discovery import collect_primary
  entries=[v for k,v in celery_app.conf.beat_schedule.items() if k.startswith('primary-')]
  self.assertEqual(len(entries),12)
  self.assertEqual(celery_app.conf.task_routes[collect_primary.name]['queue'],'discovery')
  self.assertIn('marketplace-discovery-4h',celery_app.conf.beat_schedule)
  self.assertIn('monitor-tender-pro-4h',celery_app.conf.beat_schedule)
  from app.api.marketplace_scout import router
  self.assertIn('/marketplaces/primary',[r.path for r in router.routes])
 def test_etprf_card_url(self):
  html='<a href="/NotificationEX/id/240000">Поставка прутка Д16</a>'
  self.assertEqual(len(c.card_links(c.soup_for(html),'https://web.etprf.ru/')),1)
 def test_plans_and_marketing_not_tenders(self):
  html='<a href="/purchases-items/view/123456">Поставка прутка Д16</a><a href="/marketing/view/123456">Поставка прутка Д16</a>'
  self.assertEqual(c.card_links(c.soup_for(html),'https://goszakupki.by/'),[])
 def test_schedule_unique_minutes(self):
  from app.workers.celery_app import celery_app
  entries=[v for k,v in celery_app.conf.beat_schedule.items() if k.startswith('primary-')]
  minutes=[tuple(v['schedule'].minute) for v in entries]
  self.assertEqual(len(set(minutes)),12)
 def test_estp_inline_card_and_fee(self):
  html='<div class="tender-card" data-tender-id="123" data-eis="32600000001" data-tender-stage="Приём заявок" data-tender-name="Лист алюминиевый" data-tender-price="12000 рублей"><h4>Лист алюминиевый</h4><div class="tender-detail"><span class="detail-label">Заказчик:</span><span class="detail-value">Завод</span></div><div class="tender-price"><span class="price-value">1500000 руб.</span></div><p>Приём заявок до: 12.10.2099 12:00 (МСК)</p></div>'
  r=c.collect('estp',persist=False,fetch=lambda *a,**k:html)
  self.assertEqual(len(r['items']),1)
  self.assertEqual(r['items'][0]['amount_text'],'1500000 руб.')
  self.assertEqual(r['items'][0]['customer'],'Завод')
  self.assertEqual(r['items'][0]['external_id'],'123')
  self.assertIsNone(r['query'])
if __name__=='__main__':unittest.main()


