import tempfile
import unittest
from pathlib import Path
from datetime import datetime, timezone, timedelta
from app.sources.tektorg.backlog import process_backlog

class BacklogTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.path=Path(self.tmp.name)/'queue.sqlite3'
        self.now=datetime(2026,10,9,tzinfo=timezone.utc)
    def item(self,n):
        return dict(external_id=str(n),source_url='https://www.tektorg.ru/procedures/'+str(n),submission_deadline=(self.now+timedelta(days=2)).isoformat())
    def run_queue(self,items,enqueue,**kw):
        return process_backlog(items,path=self.path,enqueue=enqueue,now=kw.get('now',self.now))
    def test_deferred_survive_next_search_and_process(self):
        def limited(items):
            return [dict(number=x['external_id'],status='queued' if i<2 else 'batch_limit') for i,x in enumerate(items)]
        self.assertEqual(self.run_queue([self.item(n) for n in range(5)],limited)['pending'],3)
        self.assertEqual(self.run_queue([],limited)['pending'],1)
        self.assertEqual(self.run_queue([],limited)['pending'],0)
    def test_enqueue_failure_does_not_lose_discovery(self):
        def broken(items): raise RuntimeError('broker unavailable')
        with self.assertRaises(RuntimeError): self.run_queue([self.item(1)],broken)
        seen=[]
        def check(items): seen.extend(items); return []
        self.assertEqual(self.run_queue([],check)['pending'],1)
        self.assertEqual(seen[0]['external_id'],'1')
    def test_expired_and_unknown_not_sent(self):
        x=self.item(1);x['submission_deadline']=None
        self.assertEqual(self.run_queue([x],lambda items:self.fail('unknown sent'))['pending'],0)
        self.run_queue([self.item(2)],lambda items:[])
        self.assertEqual(self.run_queue([],lambda items:self.fail('expired sent'),now=self.now+timedelta(days=3))['expired_removed'],1)
    def test_cached_and_dismissed_removed(self):
        def result(items): return [dict(number=x['external_id'],status='cached' if i==0 else 'no_longer_eligible') for i,x in enumerate(items)]
        self.assertEqual(self.run_queue([self.item(1),self.item(2)],result)['pending'],0)
    def test_dedup_and_reservation_retained(self):
        def busy(items): return [dict(number=x['external_id'],status='already_queued_or_attempted') for x in items]
        self.assertEqual(self.run_queue([self.item(1)]*3,busy)['pending'],1)
    def test_deadline_priority(self):
        a=self.item(1);a['submission_deadline']=(self.now+timedelta(days=1)).isoformat()
        seen=[]
        self.run_queue([self.item(2),a],lambda items:seen.extend(items) or [])
        self.assertEqual(seen[0]['external_id'],'1')

unittest.main()
