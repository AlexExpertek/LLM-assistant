import copy,json,unittest
from datetime import datetime,timezone
from urllib.parse import parse_qs,urlsplit
from app.marketplace_discovery.primary import tektorg_search as m
NOW=datetime(2026,10,8,tzinfo=timezone.utc)
ROW=dict(id=19546230,title='Лист из алюминия, Протектор магниевый, Фольга алюминиевая',statusName='Приём заявок',dates={'dateEndRegistration':'2026-10-22T14:00:00+03:00'},typeName='Запрос предложений',okpd2=[])
LINK={str(ROW['id']):'https://www.tektorg.ru/rosneft/procedures/19546230'}
def html(rows,pages=2,as_string=False):
 state={'listingProcedures':dict(data=rows,total=len(rows)*pages,totalPages=pages,currentPage=1)}
 if as_string:state=json.dumps(state)
 return '<script id="__NEXT_DATA__">'+json.dumps({'props':{'pageProps':{'initialReduxState':state}}})+'</script>'+''.join('<a href="/rosneft/procedures/'+str(r['id'])+'">card</a>' for r in rows)
class Tests(unittest.TestCase):
 def setUp(self):
  import tempfile
  from pathlib import Path
  from unittest.mock import patch
  self.temp = tempfile.TemporaryDirectory()
  self.addCleanup(self.temp.cleanup)
  self.folder_patch = patch('app.marketplace_discovery.primary.collector.folder',return_value=Path(self.temp.name))
  self.folder_patch.start()
  self.addCleanup(self.folder_patch.stop)

 def check(self,reason,**updates):
  row=copy.deepcopy(ROW);row.update(updates)
  self.assertEqual(m.candidate(row,LINK,NOW,lambda *a:False)[1],reason)
 def test_mixed(self):
  item,reason=m.candidate(ROW,LINK,NOW,lambda *a:False)
  self.assertIsNone(reason);self.assertIsNone(item['mass_kg']);self.assertFalse(item['analysis_done'])
  self.assertEqual(item['submission_deadline'],'2026-10-22T11:00:00+00:00')
 def test_closed(self):self.check('not_open',statusName='Архив')
 def test_expired(self):self.check('expired',dates={'dateEndRegistration':'2026-10-01T14:00:00+03:00'})
 def test_unknown(self):self.check('deadline_unknown',dates={})
 def test_naive(self):self.check('deadline_unknown',dates={'dateEndRegistration':'2026-10-22T14:00:00'})
 def test_chemical(self):self.check('no_product_evidence',title='Поставка сульфата алюминия')
 def test_sale(self):self.check('sale_not_purchase',title='Реализация лома алюминия')
 def test_dismiss(self):self.assertEqual(m.candidate(ROW,LINK,NOW,lambda *a:True)[1],'manually_dismissed')
 def test_missing_url(self):self.assertEqual(m.candidate(ROW,{},NOW,lambda *a:False)[1],'card_url_unconfirmed')
 def test_state_string(self):self.assertEqual(len(m.parse_search(html([ROW],as_string=True))[0]['data']),1)
 def test_pages(self):
  calls=[]
  def fetch(url,timeout):
   q=parse_qs(urlsplit(url).query);calls.append(q)
   row=copy.deepcopy(ROW);row['id']=int(q['page'][0])
   return html([row])
  r=m.collect_tektorg(persist=False,fetch=fetch,now=NOW,pause=lambda x:None,dismissed=lambda *a:False)
  self.assertEqual(len(r['items']),2);self.assertTrue(all(x['complete'] for x in r['searches']))
  self.assertEqual([q['page'][0] for q in calls],['1','2','1','2']);self.assertTrue(all('name' in q for q in calls))
 def test_repeated(self):
  r=m.collect_tektorg(persist=False,fetch=lambda *a,**k:html([ROW]),now=NOW,pause=lambda x:None,dismissed=lambda *a:False)
  self.assertEqual(r['status'],'partial');self.assertTrue(all(x['reason']=='repeated_page' for x in r['errors']))
 def test_resume(self):
  def fetch(url,timeout):
   row=copy.deepcopy(ROW);row['id']=int(parse_qs(urlsplit(url).query)['page'][0])
   return html([row],pages=10)
  r=m._collect(persist=False,fetch=fetch,now=NOW,pause=lambda x:None,dismissed=lambda *a:False,cursors={'алюминий':4})
  self.assertEqual(r['searches'][0]['requested_pages'],[1,4,5])
  self.assertEqual(r['next_pages']['алюминий'],6)
 def test_failed_page_retained(self):
  def fetch(url,timeout):
   page=int(parse_qs(urlsplit(url).query)['page'][0])
   if page==5:raise TimeoutError()
   row=copy.deepcopy(ROW);row['id']=page
   return html([row],pages=10)
  r=m._collect(persist=False,fetch=fetch,now=NOW,pause=lambda x:None,dismissed=lambda *a:False,cursors={'алюминий':4})
  self.assertEqual(r['next_pages']['алюминий'],5)
 def test_end_reset(self):
  def fetch(url,timeout):
   row=copy.deepcopy(ROW);row['id']=int(parse_qs(urlsplit(url).query)['page'][0])
   return html([row],pages=4)
  r=m._collect(persist=False,fetch=fetch,now=NOW,pause=lambda x:None,dismissed=lambda *a:False,cursors={'алюминий':4})
  self.assertEqual(r['next_pages']['алюминий'],2)
  self.assertFalse(r['searches'][0]['complete'])
 def test_read_only_cursor(self):
  import tempfile
  from pathlib import Path
  from unittest.mock import patch
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'tektorg.json';path.write_text(json.dumps({'next_pages':{'алюминий':4}}))
   before=path.read_bytes()
   with patch('app.marketplace_discovery.primary.collector.folder',return_value=Path(d)):
    m.collect_tektorg(persist=False,fetch=lambda *a,**k:html([ROW]),now=NOW,pause=lambda x:None,dismissed=lambda *a:False)
   self.assertEqual(path.read_bytes(),before)
   self.assertFalse((Path(d)/'tektorg.lock').exists())
if __name__=='__main__':unittest.main()
