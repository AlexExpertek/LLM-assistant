"""Durable handoff backlog. Successful Celery submissions leave this queue."""
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path


def deadline(item):
    try:
        value = datetime.fromisoformat(str(item.get('submission_deadline', '')).replace('Z', '+00:00'))
        return value.astimezone(timezone.utc) if value.tzinfo else None
    except (ValueError, TypeError):
        return None


def process_backlog(items, *, path=None, enqueue=None, now=None):
    if path is None:
        from app.core.config import settings
        path = Path(settings.storage_path) / 'tektorg_backlog.sqlite3'
    if enqueue is None:
        from .dispatch import enqueue_candidates
        enqueue = enqueue_candidates
    now = now or datetime.now(timezone.utc)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path, timeout=30) as db:
        db.execute('CREATE TABLE IF NOT EXISTS pending (number TEXT PRIMARY KEY, deadline TEXT NOT NULL, payload TEXT NOT NULL)')
        for item in items:
            end = deadline(item)
            if end is None or end <= now:
                continue
            number = str(item.get('external_id') or '')
            if not number or not item.get('source_url'):
                continue
            db.execute('INSERT INTO pending VALUES (?, ?, ?) ON CONFLICT(number) DO UPDATE SET deadline=excluded.deadline,payload=excluded.payload',
                       (number, end.isoformat(), json.dumps(item, ensure_ascii=False)))
        expired = db.execute('DELETE FROM pending WHERE deadline <= ?', (now.isoformat(),)).rowcount
        # Commit discovery BEFORE any external queue operation or cursor update.
        db.commit()
        rows = db.execute('SELECT payload FROM pending ORDER BY deadline, number LIMIT 200').fetchall()
        outcomes = enqueue([json.loads(row[0]) for row in rows]) if rows else []
        for result in outcomes:
            if result['status'] in {'queued', 'cached', 'no_longer_eligible'}:
                db.execute('DELETE FROM pending WHERE number=?', (str(result['number']),))
        db.commit()
        remaining = db.execute('SELECT count(*) FROM pending').fetchone()[0]
    return {'outcomes': outcomes, 'pending': remaining, 'expired_removed': expired}
