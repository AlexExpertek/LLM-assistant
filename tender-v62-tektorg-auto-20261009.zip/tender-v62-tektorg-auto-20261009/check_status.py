import json,sqlite3
from pathlib import Path
from app.core.config import settings
from app.workers.celery_app import celery_app
from app.marketplace_discovery.primary.collector import folder
for name,entry in celery_app.conf.beat_schedule.items():
    if 'tektorg' in name:
        print('SCHEDULE:', name, str(entry['schedule']), 'TASK:',entry['task'], 'ARGS:',entry.get('args'))
p=Path(settings.storage_path)/'tektorg_backlog.sqlite3'
if p.exists():
    with sqlite3.connect(p.resolve().as_uri()+'?mode=ro',uri=True) as db:
        print('PENDING:',db.execute('SELECT count(*) FROM pending').fetchone()[0])
else: print('PENDING: queue will be created on first scheduled run')
r=folder()/'tektorg.json'
if r.exists():
    data=json.loads(r.read_text())
    print(json.dumps({k:data.get(k) for k in ('checked_at','status','coverage','searches','next_pages','pipeline','backlog_pending')},ensure_ascii=False,indent=2))
print('READ_ONLY: configuration and last report; actual Beat execution requires logs')
