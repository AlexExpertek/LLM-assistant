import sys,types,unittest
from unittest.mock import Mock,patch
from contextlib import ExitStack
from app.sources.tektorg.dispatch import enqueue_candidates
class Tests(unittest.TestCase):
 def run_case(self,completed=False,reserved=True):
  session=Mock();session.execute.return_value.scalar_one_or_none.return_value=object()
  context=Mock();context.__enter__=Mock(return_value=session);context.__exit__=Mock(return_value=False)
  db=types.ModuleType('app.db.session');db.SyncSessionLocal=Mock(return_value=context)
  guard=types.ModuleType('app.workers.completed_analysis');guard.has_completed_analysis=Mock(return_value=completed)
  tasks=types.ModuleType('app.workers.tasks_parsing');tasks.process_new_tender=Mock();tasks.process_new_tender.delay.return_value.id='test-id'
  card=Mock();card.model_dump.return_value={'source':'tektorg'}
  with patch.dict(sys.modules,{'app.db.session':db,'app.workers.completed_analysis':guard,'app.workers.tasks_parsing':tasks}),patch('redis.Redis.from_url') as client,patch('app.sources.tektorg.adapter.TektorgAdapter') as adapter:
   client.return_value.set.return_value=reserved
   adapter.return_value.fetch_by_id.return_value=card
   result=enqueue_candidates([{'external_id':'1','source_url':'https://www.tektorg.ru/procedures/1'}])
   return result,client.return_value.set.call_count,tasks.process_new_tender.delay.call_count
 def test_completed(self):
  r,reserve,queued=self.run_case(completed=True);self.assertEqual((reserve,queued),(0,0));self.assertEqual(r[0]['status'],'cached')
 def test_reserved(self):
  r,reserve,queued=self.run_case(reserved=False);self.assertEqual(queued,0)
 def test_new(self):
  r,reserve,queued=self.run_case();self.assertEqual(queued,1);self.assertEqual(r[0]['task_id'],'test-id')
if __name__=='__main__':unittest.main()
