import unittest, ast, inspect
from app.marketplace_discovery.subject_classifier import classify_tender_subject as classify
CASES = [
 ('№218 Поставка и установка блоков из алюминиевого профиля (без влияния на конструктивную надежность и безопасность здания) для нужд АУЗ УР', 'works_service'),
 ('Поставка дверей из алюминиевого профиля','finished_product'),
 ('Поставка алюминиевого профиля АД31','material_supply'),
 ('Поставка профиля алюминиевого с противоскользящей вставкой','material_supply'),
 ('Поставка профиля для изготовления дверей из алюминиевого профиля','material_supply'),
 ('Поставка алюминиевого профиля для монтажа окон','material_supply'),
 ('Закупка блоков из алюминиевого профиля','finished_product'),
 ('Приобретение дверей из алюминиевого профиля','finished_product'),
 ('Поставка и монтаж перегородок из алюминиевого профиля','works_service'),
 ('Поставка дверей из алюминиевого профиля и алюминиевого профиля АД31','mixed_or_unknown'),
 ('Тендер по остеклению лоджий из алюминиевого профиля ЖК Люмен','works_service'),
 ('Поставка труб алюминиевых АД1','material_supply'),
]
class Checks(unittest.TestCase):
 def test_subjects(self):
  for title, expected in CASES:
   with self.subTest(title=title):self.assertEqual(classify(title).subject_type,expected)
 def test_eis_task_gate_executes(self):
  # Extract exact installed gate and execute it with isolated session/logger.
  from pathlib import Path
  from unittest.mock import MagicMock
  from types import SimpleNamespace
  import app
  path=Path(app.__file__).parent/'workers/tasks_parsing.py' if app.__file__ else Path('app/workers/tasks_parsing.py')
  tree=ast.parse(path.read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='process_new_tender')
  body=fn.body[1].body if isinstance(fn.body[0],ast.Expr) else fn.body[0].body
  gate=next(n for n in body if isinstance(n,ast.If) and any(isinstance(x,ast.Constant) and x.value=='skipped_subject' for x in ast.walk(n)))
  wrapped=ast.FunctionDef(name='run',args=ast.arguments(posonlyargs=[],args=[],kwonlyargs=[],kw_defaults=[],defaults=[]),body=[gate,ast.Return(value=ast.Constant('continue'))],decorator_list=[])
  row=SimpleNamespace(raw_payload={'stage':'detail'},analysis_done=False,status='new')
  session=MagicMock();session.get.return_value=row;session.__enter__.return_value=session
  ns={'source_tender':SimpleNamespace(source='zakupki_gov_ru',title=CASES[0][0]),'classify_tender_subject':classify,'SyncSessionLocal':lambda:session,'Tender':object,'TenderStatus':SimpleNamespace(MANUAL_REVIEW='manual_review'),'tender_id':'test','logger':MagicMock()}
  exec(compile(ast.fix_missing_locations(ast.Module(body=[wrapped],type_ignores=[])),'gate','exec'),ns)
  self.assertEqual(ns['run']()['status'],'skipped_subject');self.assertEqual(row.raw_payload['subject_screening']['subject_type'],'works_service')
  ns['source_tender'].source='kontur_zakupki';self.assertEqual(ns['run'](),'continue')
  ns['source_tender'].source='zakupki_gov_ru';ns['source_tender'].title=CASES[3][0];self.assertEqual(ns['run'](),'continue')
unittest.main()
