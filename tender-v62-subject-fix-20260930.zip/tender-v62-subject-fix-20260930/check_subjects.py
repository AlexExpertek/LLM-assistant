from sqlalchemy import select
from app.db.session import SyncSessionLocal
from app.models.database import Tender
from app.marketplace_discovery.subject_classifier import classify_tender_subject
numbers=['32616400622','32616409026','0119200000126016262','32616417112']
with SyncSessionLocal() as s:
 for t in s.execute(select(Tender).where(Tender.source=='zakupki_gov_ru',Tender.external_id.in_(numbers))).scalars():
  c=classify_tender_subject(t.title)
  print(t.external_id,'|',c.subject_type,'| allowed=',c.allowed,'|',t.title)
print('READ_ONLY: no tasks, DB changes, LLM or notifications')
