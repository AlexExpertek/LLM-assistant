Subject fix 20260930
2 modified files with exact before/after hash guards; backup before installation.
Classifier: anchored supply/install and product-made-of-profile rules. Protection for material supplied FOR door manufacture or window installation. Explicit mixed title examples remain allowed for detailed review.
EIS process_new_tender checks title after upsert and before detail fetch/document downloads. Rejected titles retain raw_payload.subject_screening with title, reason/version. Unanalyzed records stay manual_review, not a fabricated not_suitable scoring Decision. processing_status may remain ingested: screening reason is recorded separately. Existing cached analyzed records follow existing cache behavior.
launch_pipeline=False remains ingestion-only, without screening. Queued OCR/LLM tasks already past ingestion are NOT retroactively screened. Historical records NOT mass-reprocessed. No migrations, no notifications tests.
Shared classifier used by other discovery consumers also gains corrected rules. New ingestion gate applies ONLY to EIS; Kontur/TenderPro tasks/schedules unchanged.
Tests: 12 title cases plus exact AST gate execution isolated from database; source compilation and installer idempotence. Not a live full pipeline test. Broad linguistic coverage is not guaranteed; ambiguous mixed titles require review.
check_subjects.py reads four existing tenders; no mutation or enqueue.
