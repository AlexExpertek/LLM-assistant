import os,sys,unittest
from datetime import datetime
from unittest.mock import patch,MagicMock
sys.path.insert(0,os.environ.get('OCR_PROJECT','/app'))
os.environ.update(DATABASE_URL='postgresql+asyncpg://test:test@localhost/test',DATABASE_URL_SYNC='postgresql+psycopg2://test:test@localhost/test',REDIS_URL='redis://localhost:1/0',QDRANT_URL='http://localhost:1',CELERY_BROKER_URL='memory://',CELERY_RESULT_BACKEND='cache+memory://')
from app.sources.zakupki_gov_public.detail_client import _extract_card_dates,EisPublicDetailClient,EisPurchaseDetail
from app.sources.zakupki_gov_public.adapter import ZakupkiGovPublicAdapter
from app.workers.tasks_parsing import _incoming_date
class Checks(unittest.TestCase):
 def test_actual_fragment(self):
  self.assertEqual(_extract_card_dates('Размещено 21.08.2026 Обновлено 21.08.2026 Договор План закупки Дата размещения извещения 21.08.2026 Дата размещения текущей редакции извещения 21.08.2026'),('21.08.2026',None))
 def test_original_not_revision(self):
  self.assertEqual(_extract_card_dates('Дата размещения текущей редакции извещения 22.08.2026 Дата размещения извещения 21.08.2026')[0],'21.08.2026')
 def test_no_fabricated_dates(self):
  self.assertEqual(_extract_card_dates('Договор 21.08.2026 Дата окончания подачи заявок не указана Дата протокола 25.08.2026'),(None,None))
 def test_deadline_not_assumed(self):
  self.assertIsNone(_extract_card_dates('Дата и время окончания подачи заявок: 30.09.2026 12:30 (МСК)')[1])
 def test_invalid(self):
  self.assertEqual(_extract_card_dates('Размещено 31.02.2026'),(None,None))
 def test_whitespace(self):
  self.assertEqual(_extract_card_dates('Размещено\n21.08.2026')[0],'21.08.2026')
 def test_mapping(self):
  detail=EisPurchaseDetail(external_id='32616311539',source_url='https://zakupki.gov.ru/',publish_date='21.08.2026')
  source=ZakupkiGovPublicAdapter._detail_to_source(detail)
  self.assertEqual(source.publish_date,datetime(2026,8,21))
  self.assertIsNone(source.submission_deadline)
 def test_keep_known(self):
  previous=datetime(2026,9,30)
  for missing in (None,'','invalid'):
   self.assertEqual(_incoming_date('zakupki_gov_ru',missing,previous),previous)
 def test_update_known(self):
  self.assertEqual(_incoming_date('zakupki_gov_ru',datetime(2026,10,1),datetime(2026,9,30)),datetime(2026,10,1))
 def test_fetch(self):
  response=MagicMock();response.url='https://zakupki.gov.ru/';response.text='<div>Размещено 21.08.2026 Обновлено 22.08.2026</div><a href="?noticeGuid=12345678-1234-1234-1234-123456789012">Карточка</a>'
  with patch('app.sources.zakupki_gov_public.detail_client.httpx.Client') as client:
   client.return_value.__enter__.return_value.get.return_value=response
   detail=EisPublicDetailClient().fetch_223('32616311539','https://zakupki.gov.ru/')
  self.assertEqual(detail.publish_date,'21.08.2026');self.assertIsNone(detail.submission_deadline)
if __name__=='__main__':unittest.main()
