"""Refresh dates of one known EIS card; no OCR/LLM/notifications or status changes."""
import sys,json,argparse
sys.path.insert(0,'/app')
from sqlalchemy import select
from app.db.session import SyncSessionLocal
from app.models.database import Tender
from app.sources.registry import get_adapter
from app.workers.tasks_parsing import _incoming_date
p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');args=p.parse_args()
number='32616311539'
detail=get_adapter('zakupki_gov_ru').fetch_by_id(number)
if detail is None or detail.external_id!=number:raise SystemExit('Detail unavailable or identity mismatch; no changes')
with SyncSessionLocal() as s:
 t=s.execute(select(Tender).where(Tender.source=='zakupki_gov_ru',Tender.external_id==number).with_for_update()).scalar_one()
 published=_incoming_date(t.source,detail.publish_date,t.publish_date)
 deadline=_incoming_date(t.source,detail.submission_deadline,t.submission_deadline)
 print(json.dumps({'number':number,'publish_date_before':t.publish_date,'publish_date_after':published,'deadline_before':t.submission_deadline,'deadline_after':deadline,'document_links_found':len(detail.documents)},default=str,ensure_ascii=False,indent=2))
 if args.apply:
  t.publish_date=published;t.submission_deadline=deadline;s.commit()
  print('EIS_DATES_SAVED: no OCR, LLM, notifications or status changes')
 else:print('PREVIEW_ONLY: add --apply to save dates')
