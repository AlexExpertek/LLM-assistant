#!/usr/bin/env bash
set -Eeuo pipefail
pkg_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "${TENDER_PROJECT_DIR:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
python3 "$pkg_dir/apply.py" --project "$PWD"
docker compose build app celery_worker celery_discovery
docker compose run --rm --no-deps -T -e PYTHONPATH=/app celery_discovery python - < "$pkg_dir/test_metal_it.py"
docker compose up -d --no-deps --timeout 60 app celery_worker celery_discovery
printf '%s\n' 'METAL_IT_SEARCH_UPDATE_INSTALLED' 'Existing schedule retained. Primary search only; no immediate collection, LLM or notifications.'
