import copy
import unittest
from datetime import datetime, timezone
from unittest.mock import patch
from app.marketplace_discovery.primary import metal_it_search as m

NOW=datetime(2026,10,9,tzinfo=timezone.utc)
def card():
    return dict(id=1,title='Поставка алюминиевого листа АМг2',registeredNumber='1-ТТ',
        published=True,request=False,status={'code':'active'},processStatus='BID_SUBMISSION',
        bidSubmissionEndDate=1791896400000,organizer={'title':'Заказчик'},
        lots=[dict(id=2,processStatus='BID_SUBMISSION',purchaseItems=[dict(id=3,number=1,
            title='Лист алюминиевый АМг2',quantity=500,unit={'title':'кг'},canceled=False)])])

class Tests(unittest.TestCase):
    def test_pass_500(self):
        item,reason=m.parse_trade(card(),NOW)
        self.assertIsNone(reason); self.assertEqual(item['mass_kg'],500)
        self.assertFalse(item['analysis_done'])
    def test_no_summing(self):
        c=card();p=c['lots'][0]['purchaseItems'][0];p['quantity']=350
        c['lots'][0]['purchaseItems'].append(copy.deepcopy(p))
        self.assertEqual(m.parse_trade(c,NOW)[1],'below_500kg')
    def test_tonnes(self):
        c=card();p=c['lots'][0]['purchaseItems'][0];p.update(quantity='0,5',unit={'title':'Тонна'})
        self.assertEqual(m.parse_trade(c,NOW)[0]['mass_kg'],500)
    def test_expired(self):
        c=card();c['bidSubmissionEndDate']=1700000000000
        self.assertEqual(m.parse_trade(c,NOW)[1],'expired')
    def test_no_seconds_or_naive_date(self):
        for x in [1791896400,True,None,'2026-10-13T16:00:00',float('nan')]:
            self.assertIsNone(m.deadline(x))
    def test_not_open(self):
        c=card();c['processStatus']='COMPLETED'
        self.assertEqual(m.parse_trade(c,NOW)[1],'not_open')
    def test_unpublished(self):
        c=card();c['published']=False
        self.assertEqual(m.parse_trade(c,NOW)[1],'not_published_trade')
    def test_dismissal(self):
        self.assertEqual(m.parse_trade(card(),NOW,True)[1],'manually_dismissed')
    def test_steel_no_target(self):
        c=card();c['lots'][0]['purchaseItems'][0]['title']='Лист стальной'
        self.assertEqual(m.parse_trade(c,NOW)[1],'no_target_positions')
    def test_canceled_row(self):
        c=card();c['lots'][0]['purchaseItems'][0]['canceled']=True
        self.assertEqual(m.parse_trade(c,NOW)[1],'no_target_positions')
    def test_unknown_mass(self):
        c=card();c['lots'][0]['purchaseItems'][0]['unit']={'title':'шт'}
        self.assertEqual(m.parse_trade(c,NOW)[1],'mass_unconfirmed')
    def test_invalid_and_restricted_card(self):
        self.assertEqual(m.parse_trade(None,NOW)[1],'invalid_card')
        c=card();c['lots'][0]['purchaseItems']=None
        self.assertEqual(m.parse_trade(c,NOW)[1],'positions_unavailable')
    def test_document_allowlist(self):
        c=card();c['otherAttachments']=[{'name':'x','href':'https://evil.test/files/get/1'},
            {'name':'y','href':'/files/get/1/test.pdf'}]
        self.assertEqual(len(m.parse_trade(c,NOW)[0]['documents']),1)
    def collect(self,fn):
        with patch.object(m.time,'sleep'), patch('app.marketplace_discovery.primary.collector.save_report') as save:
            r=m.collect_metal_it(fetch=fn,persist=False,now=NOW,previous={},dismissed=lambda *a:False)
            save.assert_not_called()
            return r
    def test_read_only_dedup(self):
        def fetch(op,q,v):
            if op=='trades':return {'trades':{'items':[{'id':1}],'total':1}}
            return {'trade':card()}
        r=self.collect(fetch)
        self.assertEqual(len(r['items']),1);self.assertEqual(r['cards_checked'],1)
    def test_empty_not_silently_success(self):
        r=self.collect(lambda *a:{})
        self.assertTrue(r['errors']);self.assertEqual(r['status'],'partial')
    def test_repeated_page(self):
        def fetch(op,q,v):
            if op=='trades':return {'trades':{'items':[{'id':1}]*m.LIMIT,'total':40}}
            return {'trade':card()}
        r=self.collect(fetch)
        self.assertTrue(any(e['reason']=='repeated_page' for e in r['errors']))
    def test_offset_budget_retains_unfinished_page(self):
        def fetch(op,q,v):
            if op=='trades':return {'trades':{'items':[{'id':i+1} for i in range(m.LIMIT)],'total':100}}
            c=card();c['id']=v['id'];return {'trade':c}
        with patch.object(m, 'MAX_REQUESTS', 3):
            r=self.collect(fetch)
        self.assertLessEqual(r['requests'],3)
        self.assertTrue(any(e['reason']=='request_budget' for e in r['errors']))
        self.assertNotIn('алюм',r['next_offsets'])


    def test_cursor_progress_full_budget(self):
        def fetch(op,q,v):
            if op=='trades':
                base=1000 if v['tradeQueryDto']['fullTextString']=='алюм' else 2000
                return {'trades':{'items':[{'id':base+i} for i in range(v['skip'],v['skip']+v['limit'])],'total':100}}
            c=card();c['id']=v['id'];return {'trade':c}
        r=self.collect(fetch)
        self.assertFalse(r['errors'])
        self.assertEqual(r['next_offsets']['алюм'],3*m.LIMIT)
        self.assertEqual(r['requests'],36)

if __name__=='__main__':unittest.main()
