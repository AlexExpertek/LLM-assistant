import json
from app.marketplace_discovery.primary.metal_it_search import collect_metal_it
r=collect_metal_it(persist=False)
print(json.dumps(r,ensure_ascii=False,indent=2,default=str))
print('READ_ONLY: no report writes, DB writes, tasks, documents, LLM or notifications')
