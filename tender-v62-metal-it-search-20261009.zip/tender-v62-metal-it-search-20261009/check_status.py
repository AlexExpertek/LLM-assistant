import json
from app.workers.celery_app import celery_app
from app.marketplace_discovery.primary.collector import folder
for name, spec in celery_app.conf.beat_schedule.items():
    if 'metal' in name or 'metal_it' in str(spec.get('args',())):
        print('SCHEDULE:', name, str(spec.get('schedule')), 'TASK:', spec.get('task'), 'ARGS:', spec.get('args'))
p=folder()/'metal_it.json'
if p.exists():
    d=json.loads(p.read_text())
    print(json.dumps({k:v for k,v in d.items() if k!='items'},ensure_ascii=False,indent=2))
    print('ITEMS:',len(d.get('items') or []))
else: print('REPORT: not created yet')
print('READ_ONLY: no HTTP, tasks, DB changes or LLM')
