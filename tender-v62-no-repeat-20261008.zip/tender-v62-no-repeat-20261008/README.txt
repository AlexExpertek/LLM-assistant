NO REPEAT — 2026-10-08
Stops automatic re-analysis of completed tenders regardless of source hash.
Guards ingestion, queued OCR and queued analysis. Recognizes a committed Decision
from scoring-v6.2-20260915 even if later ingestion reset analysis_done.
Does not mark unanalysed failures as completed. Does not change qualification rules.
Does not repair chunk extraction or alter dashboard filtering in this update.

Install: bash install.sh from the extracted package. All source hashes are checked
before writes; mismatching versions stop without changes. Backup path is printed.
Build and offline tests precede service recreation. Existing schedule is retained.

Restore the specific old result, initially read-only:
docker compose exec -T celery_worker python - < /tmp/tender-v62-no-repeat-20261008/restore_one.py
Apply after inspection (requires stored score 67, can_apply, matching Tender and a
supplyable position >=500kg; otherwise refuses):
docker compose exec -T celery_worker python - --apply < /tmp/tender-v62-no-repeat-20261008/restore_one.py
No new decision or score is invented. Existing score/items are never changed.

Explicit operator re-analysis only: analyze_tender supports keyword
force_reanalysis=True. Caller must pass the current text/document snapshot and
respect normal freshness checks. Do not add force_reanalysis to scheduled jobs.
Existing failed tenders without a committed successful analysis remain eligible
for separately controlled recovery; this patch does not enqueue them.

Source lock scope: each task retains its existing overlap guards. Installation
should be performed when no previous-version analysis is actively running.
Rollback source files from printed backup and rebuild services. No schema change.
