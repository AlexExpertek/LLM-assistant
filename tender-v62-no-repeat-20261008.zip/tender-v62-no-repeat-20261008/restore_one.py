"""Restore processing flags from the existing committed result; never generate a score."""
import sys,json,tempfile
from pathlib import Path
from sqlalchemy import select
from app.core.config import settings
from app.db.session import SyncSessionLocal
from app.models.database import Tender,Decision,Lot,TenderItem,ProcessingStatus

def value(v):return getattr(v,'value',v)
with SyncSessionLocal() as s:
 t=s.execute(select(Tender).where(Tender.source=='zakupki_gov_ru',Tender.external_id=='32616417112').with_for_update()).scalar_one_or_none()
 if t is None:raise SystemExit('NOT_FOUND')
 d=s.execute(select(Decision).where(Decision.tender_id==t.id).order_by(Decision.created_at.desc()).limit(1)).scalar_one_or_none()
 items=s.execute(select(TenderItem).join(Lot,TenderItem.lot_id==Lot.id).where(Lot.tender_id==t.id)).scalars().all()
 report={'number':t.external_id,'id':str(t.id),'analysis_done':t.analysis_done,'processing':value(t.processing_status),'score':t.score,'status':value(t.status),'decision':None if d is None else {'id':str(d.id),'score':d.score,'status':value(d.status),'model_version':d.model_version},'positions':[{'name':i.name,'alloy':i.alloy,'mass_kg':i.mass_kg,'can_supply':i.can_supply} for i in items]}
 print(json.dumps(report,ensure_ascii=False,indent=2,default=str))
 if '--apply' not in sys.argv:raise SystemExit('READ_ONLY: add --apply to restore verified saved result')
 if not(d and d.model_version=='scoring-v6.2-20260915' and d.score==67 and value(d.status)=='can_apply' and t.score==d.score and t.status==d.status and items and any(i.can_supply is True and i.mass_kg is not None and i.mass_kg>=500 for i in items)):
  raise SystemExit('RESTORE_REFUSED: saved result does not match the verified score/positions; no changes')
 if t.analysis_done and t.processing_status==ProcessingStatus.ANALYZED:raise SystemExit('ALREADY_RESTORED')
 root=Path(settings.storage_path)/'analysis_backups';root.mkdir(parents=True,exist_ok=True)
 with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=root,prefix=str(t.id)+'-restore-',suffix='.json',delete=False) as f:
  json.dump(report,f,ensure_ascii=False,indent=2,default=str);print('BACKUP:',f.name)
 t.analysis_done=True;t.processing_status=ProcessingStatus.ANALYZED
 s.commit()
 print('SAVED_RESULT_RESTORED: score and positions unchanged; no OCR, LLM or notifications')
