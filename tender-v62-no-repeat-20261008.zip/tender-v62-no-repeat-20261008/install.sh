#!/usr/bin/env bash
set -Eeuo pipefail
pkg_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
project_dir="${TENDER_PROJECT_DIR:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
cd "$project_dir"
python3 "$pkg_dir/apply.py" --project "$project_dir"
docker compose build app celery_worker celery_discovery
docker compose run --rm --no-deps -T celery_worker python - < "$pkg_dir/verify.py"
docker compose up -d --no-deps --timeout 60 app celery_worker celery_discovery
printf '\nNO_REPEAT_UPDATE_INSTALLED\nSchedule retained. No immediate analysis or DB repair started.\n'
