"""Source-neutral tender ingestion and source monitoring for v6."""
from app.sources.eis_freshness import eligibility, gate_saved_tender
import hashlib
import json
from datetime import datetime, timezone

from sqlalchemy import select, update

from app.core.config import settings
from app.core.logging import get_logger
from app.db.session import SyncSessionLocal
from app.models.database import LawType, ProcessingStatus, Tender, TenderStatus
from app.sources.registry import get_adapter
from app.sources.run_status import record_run
from app.sources.schemas import SourceTender
from app.marketplace_discovery.subject_classifier import classify_tender_subject
from app.sources.kontur_zakupki.client import KonturAccessError, KonturConfigurationError
from app.workers.completed_analysis import has_completed_analysis, cached_result
from app.workers.celery_app import celery_app
from app.workers.execution_guard import exclusive_task

logger = get_logger(__name__)


def _incoming_date(source, incoming, previous):
    parsed = _dt(incoming)
    # Missing/unparsed EIS metadata must not erase a previously known date.
    return previous if source == "zakupki_gov_ru" and parsed is None else parsed


def _enum_law(value: str | None) -> LawType:
    mapping = {"44-FZ": LawType.FZ_44, "223-FZ": LawType.FZ_223, "commercial": LawType.COMMERCIAL}
    return mapping.get(value or "", LawType.OTHER)


def _dt(value):
    if value is None:
        return value
    try:
        parsed = value if isinstance(value, datetime) else datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if parsed.tzinfo is not None:
            parsed = parsed.astimezone(timezone.utc).replace(tzinfo=None)
        return parsed
    except (ValueError, TypeError):
        return None


def compute_source_hash(tender: SourceTender) -> str:
    payload = tender.model_dump(mode="json", exclude={"raw_payload"})
    metadata = tender.raw_payload or {}
    payload["source_content"] = {key: metadata.get(key) for key in ("positions", "discovery", "raw_text", "b2b_public", "selection_version") if key in metadata}
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def find_existing_tender(session, source: str, external_id: str):
    return session.execute(select(Tender).where(
        Tender.source == source, Tender.external_id == external_id
    )).scalar_one_or_none()


@celery_app.task(name="app.workers.tasks_parsing.monitor_source", bind=True, max_retries=3, default_retry_delay=300)
@exclusive_task('monitor', 'source_key')
def monitor_source(self, source_key: str):
    if source_key == "kontur_zakupki":
        return {"status": "skipped", "reason": "disabled_by_owner", "source": source_key}
    adapter = get_adapter(source_key)
    if not adapter:
        return {"status": "error", "reason": "unknown_source", "source": source_key}
    try:
        tenders = adapter.search()
        queued_count = 0
        skipped_count = 0
        for item in tenders:
            reason = eligibility(item.source, item.submission_deadline, item.raw_payload)
            if reason not in (None, 'needs_detail'):
                skipped_count += 1
                continue
            process_new_tender.delay(item.model_dump(mode="json"))
            queued_count += 1
        logger.info("monitor_source_completed", source=source_key, count=len(tenders))
        record_run(source_key, status="queued", found_count=len(tenders), queued_count=queued_count, skipped_count=skipped_count)
        return {"status": "success", "source": source_key, "found_count": len(tenders), "queued_count": queued_count, "skipped_count": skipped_count}
    except (KonturAccessError, KonturConfigurationError) as exc:
        logger.error("monitor_source_blocked", source=source_key, error_type=type(exc).__name__, error=str(exc))
        record_run(source_key, status="blocked", reason=type(exc).__name__)
        return {"status": "blocked", "source": source_key, "reason": type(exc).__name__}
    except Exception as exc:
        from app.sources.http_refusal import refusal_status
        denied = refusal_status(exc)
        if denied is not None:
            record_run(source_key, status='blocked', reason='http_refused', http_status=denied)
            logger.warning('source_http_refused', http_status=denied, retry=False)
            return {'status':'blocked','reason':'http_refused','http_status':denied}
        record_run(source_key, status="failed", error_type=type(exc).__name__)
        logger.error("monitor_source_failed", source=source_key, error=str(exc))
        raise self.retry(exc=exc)


@celery_app.task(name="app.workers.tasks_parsing.process_new_tender", bind=True, max_retries=3)
def process_new_tender(
    self,
    tender_data: dict,
    launch_pipeline: bool = True,
):
    """Upsert canonical SourceTender.

    launch_pipeline=False is used for controlled ingestion tests
    without starting OCR/LLM/scoring.
    """
    try:
        source_tender = SourceTender.model_validate(tender_data)
        from app.reports.review_dismissals import is_dismissed
        if is_dismissed(source_tender.source, source_tender.external_id):
            return {'status':'skipped','reason':'manually_dismissed','external_id':source_tender.external_id}
        reason = eligibility(source_tender.source, source_tender.submission_deadline, source_tender.raw_payload)
        if reason == 'needs_detail':
            subject = classify_tender_subject(source_tender.title)
            if not subject.allowed:
                return {'status':'skipped_subject','reason':subject.reason,'external_id':source_tender.external_id}
            detail = get_adapter(source_tender.source).fetch_by_id(
                source_tender.external_id, source_url=source_tender.source_url)
            if detail is None:
                return {'status':'skipped','reason':'detail_unavailable','external_id':source_tender.external_id}
            if detail.source != source_tender.source or detail.external_id != source_tender.external_id:
                raise ValueError('EIS detail identity mismatch')
            if (detail.raw_payload or {}).get('stage') == 'search':
                raise ValueError('EIS detail returned search metadata')
            for field in ('customer_name', 'customer_inn', 'amount', 'region'):
                if getattr(detail, field) is None:
                    setattr(detail, field, getattr(source_tender, field))
            source_tender = detail
            reason = eligibility(detail.source, detail.submission_deadline, detail.raw_payload)
        if reason is not None:
            return {'status':'skipped','reason':reason,'external_id':source_tender.external_id}
        source_hash = compute_source_hash(source_tender)
        tender_id = None
        should_process = True

        with SyncSessionLocal() as session:
            existing = find_existing_tender(session, source_tender.source, source_tender.external_id)
            early_reason = eligibility(source_tender.source, source_tender.submission_deadline, source_tender.raw_payload,
                                       existing.is_active if existing else True)
            if early_reason in ('inactive', 'closed_stage', 'deadline_expired'):
                if existing:
                    existing.is_active = False
                    session.commit()
                return {'status': 'skipped', 'reason': early_reason, 'external_id': source_tender.external_id}
            if existing:
                tender_id = str(existing.id)
                if has_completed_analysis(session, existing):
                    # Refresh a known deadline without replacing the analyzed input,
                    # documents, decision, score or notification flags.
                    incoming_deadline = _dt(source_tender.submission_deadline)
                    if incoming_deadline is not None:
                        existing.submission_deadline = incoming_deadline
                    session.commit()
                    logger.info("tender_analysis_reused", tender_id=tender_id)
                    return cached_result(tender_id)
                changed = existing.source_hash != source_hash
                if not changed and existing.analysis_done:
                    should_process = False
                elif (source_tender.source == "zakupki_gov_ru"
                      and (source_tender.raw_payload or {}).get("stage") == "search"
                      and (existing.raw_payload or {}).get("stage") == "detail"):
                    # Do not replace a detailed record/analysis with an empty search summary.
                    # Hydration below will compare the refreshed detailed content instead.
                    pass
                else:
                    existing.title = source_tender.title
                    existing.description = source_tender.description
                    existing.customer_name = source_tender.customer_name
                    existing.customer_inn = source_tender.customer_inn
                    existing.law_type = _enum_law(source_tender.law_type)
                    existing.procurement_method = source_tender.procurement_method
                    existing.amount = source_tender.amount
                    existing.currency = source_tender.currency
                    existing.region = source_tender.region
                    existing.delivery_place = source_tender.delivery_place
                    existing.publish_date = _incoming_date(source_tender.source, source_tender.publish_date, existing.publish_date)
                    existing.submission_deadline = _incoming_date(source_tender.source, source_tender.submission_deadline,
                        None if (source_tender.source == 'zakupki_gov_ru'
                                 and (existing.raw_payload or {}).get('stage') == 'search'
                                 and (source_tender.raw_payload or {}).get('stage') == 'detail')
                        else existing.submission_deadline)
                    existing.source_url = source_tender.source_url
                    existing.source_hash = source_hash
                    existing.raw_payload = source_tender.raw_payload
                    existing.analysis_done = False
                    existing.processing_status = ProcessingStatus.INGESTED
                    existing.analysis_version = settings.analysis_version
                    existing.notified_bitrix = False
                    existing.notified_telegram = False
            else:
                row = Tender(
                    source=source_tender.source,
                    external_id=source_tender.external_id,
                    title=source_tender.title,
                    description=source_tender.description,
                    customer_name=source_tender.customer_name,
                    customer_inn=source_tender.customer_inn,
                    law_type=_enum_law(source_tender.law_type),
                    procurement_method=source_tender.procurement_method,
                    amount=source_tender.amount,
                    currency=source_tender.currency,
                    region=source_tender.region,
                    delivery_place=source_tender.delivery_place,
                    publish_date=_dt(source_tender.publish_date),
                    submission_deadline=_dt(source_tender.submission_deadline),
                    status=TenderStatus.NEW,
                    processing_status=ProcessingStatus.INGESTED,
                    source_url=source_tender.source_url,
                    source_hash=source_hash,
                    raw_payload=source_tender.raw_payload,
                    analysis_done=False,
                    analysis_version=settings.analysis_version,
                    is_active=True,
                )
                session.add(row)
                session.flush()
                tender_id = str(row.id)
            session.commit()

        if not should_process:
            logger.info("tender_unchanged_cached", tender_id=tender_id)
            return {"status": "cached", "tender_id": tender_id}

        if not launch_pipeline:
            logger.info(
                "tender_ingested_without_pipeline",
                tender_id=tender_id,
                source=source_tender.source,
                external_id=source_tender.external_id,
            )
            return {
                "status": "ingested_only",
                "tender_id": tender_id,
                "documents": len(source_tender.documents),
            }

        if source_tender.source == 'zakupki_gov_ru':
            subject = classify_tender_subject(source_tender.title)
            if not subject.allowed:
                screening = {'version': 'subject-20260930', 'subject_type': subject.subject_type,
                             'reason': subject.reason, 'basis': 'title', 'title': source_tender.title}
                with SyncSessionLocal() as session:
                    row = session.get(Tender, tender_id)
                    row.raw_payload = {**(row.raw_payload or {}), 'subject_screening': screening}
                    # A title-based exclusion is not a new full scoring decision.
                    if not row.analysis_done:
                        row.status = TenderStatus.MANUAL_REVIEW
                    session.commit()
                logger.info('eis_subject_skipped', tender_id=tender_id, **screening)
                return {'status': 'skipped_subject', 'tender_id': tender_id, **screening}

        with SyncSessionLocal() as session:
            blocked = gate_saved_tender(session, tender_id)
            if blocked:
                logger.info('eis_freshness_skipped', **blocked)
                return blocked

        from app.sources.document_preparer import (
            prepare_tender_documents,
        )
        from app.workers.tasks_ocr import (
            process_tender_documents,
        )

        prepared_documents = (
            prepare_tender_documents(
                source_tender
            )
        )

        process_tender_documents.delay(
            tender_id,
            [
                document.model_dump(
                    mode="json"
                )
                for document
                in prepared_documents
            ],
        )

        return {
            "status": "queued_for_documents",
            "tender_id": tender_id,
            "documents_total": len(
                source_tender.documents
            ),
            "documents_prepared": len(
                prepared_documents
            ),
        }
    except Exception as exc:
        from app.sources.http_refusal import refusal_status
        denied = refusal_status(exc)
        if denied is not None:
            logger.warning('source_http_refused', http_status=denied, retry=False)
            return {'status':'blocked','reason':'http_refused','http_status':denied}
        logger.error("process_tender_failed", error=str(exc))
        raise self.retry(exc=exc)


@celery_app.task(name="app.workers.tasks_parsing.analyze_tender_url", bind=True, max_retries=2)
def analyze_tender_url(self, url: str, source_hint: str | None = None):
    from app.sources.resolver import fetch_tender_from_url
    try:
        tender = fetch_tender_from_url(url, source_hint)
        if not tender:
            return {"status": "failed", "reason": "source_or_tender_not_resolved"}
        process_new_tender.delay(tender.model_dump(mode="json"))
        return {"status": "resolved", "source": tender.source, "external_id": tender.external_id}
    except Exception as exc:
        from app.sources.http_refusal import refusal_status
        denied = refusal_status(exc)
        if denied is not None:
            logger.warning('source_http_refused', http_status=denied, retry=False)
            return {'status':'blocked','reason':'http_refused','http_status':denied}
        raise self.retry(exc=exc)


@celery_app.task(name="app.workers.tasks_parsing.mark_inactive_tenders")
def mark_inactive_tenders():
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    with SyncSessionLocal() as session:
        result = session.execute(update(Tender).where(
            Tender.is_active.is_(True),
            Tender.submission_deadline.is_not(None),
            Tender.submission_deadline < now,
        ).values(is_active=False))
        session.commit()
        return {"marked_inactive": result.rowcount}
