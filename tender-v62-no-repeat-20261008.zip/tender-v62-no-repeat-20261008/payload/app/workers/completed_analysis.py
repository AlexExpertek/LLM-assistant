"""Reuse a committed successful analysis, independent of a refreshed source hash."""
from sqlalchemy import select
from app.models.database import Decision


def has_completed_analysis(session, tender):
    if tender is None:
        return False
    if tender.analysis_done:
        return True
    # This version writes Decision and its result in the same successful transaction.
    # A later ingestion may have reset analysis_done; a failed LLM call does not
    # delete this committed Decision. Other/manual decisions are not proof.
    return session.execute(select(Decision.id).where(
        Decision.tender_id == tender.id,
        Decision.model_version == "scoring-v6.2-20260915",
        Decision.score.is_not(None),
    ).limit(1)).scalar_one_or_none() is not None


def cached_result(tender_id):
    return {"status": "cached", "reason": "analysis_already_completed",
            "tender_id": str(tender_id)}
