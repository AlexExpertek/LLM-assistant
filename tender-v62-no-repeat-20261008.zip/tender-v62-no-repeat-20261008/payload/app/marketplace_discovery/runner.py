"""Bounded public marketplace discovery -> verified positions -> common analysis."""
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from app.core.logging import get_logger
from app.marketplace_discovery.registry import get_marketplace, get_marketplaces
from app.marketplace_discovery.subject_classifier import classify_tender_subject
from app.marketplace_discovery.review_store import save_candidate, remove_candidate
from app.reports.review_dismissals import is_dismissed
from app.scoring.selection_policy import FALLBACK_QUERIES, OKPD2_PREFIXES, material_status, mass_kg, MIN_WEIGHT_KG
from app.marketplace_discovery.b2b_public import fetch_public, to_source

from app.marketplace_discovery.product_screening import title_excluded, screen_candidate

logger=get_logger(__name__)

def expired(deadline):
    if deadline is None: return False
    if deadline.tzinfo is None: deadline=deadline.replace(tzinfo=ZoneInfo('Europe/Moscow'))
    return deadline<=datetime.now(timezone.utc)


def _already_processed(source):
    from sqlalchemy import select
    from app.db.session import SyncSessionLocal
    from app.models.database import Tender
    from app.workers.tasks_parsing import compute_source_hash
    with SyncSessionLocal() as s:
        t=s.execute(select(Tender).where(Tender.source==source.source,Tender.external_id==source.external_id)).scalar_one_or_none()
        from app.workers.completed_analysis import has_completed_analysis
        if has_completed_analysis(s, t): return True
        if not t or t.source_hash!=compute_source_hash(source): return False
        state=getattr(t.processing_status,'value',t.processing_status)
        # Failed unchanged input needs explicit operator retry, not periodic LLM spending.
        return bool(t.analysis_done or state in ('ingested','documents_pending','documents_ready','analyzing','failed'))


def run_marketplace_discovery(*,platforms=None,max_per_platform=100):
    from app.workers.tasks_parsing import process_new_tender
    if max_per_platform<1: raise ValueError('max_per_platform must be positive')
    adapters=[get_marketplace(p) for p in platforms] if platforms is not None else get_marketplaces()
    if any(a is None for a in adapters): raise ValueError('Unknown marketplace')
    summary={}
    for adapter in adapters:
        stats=dict(status='ok',discovered=0,relevant=0,persisted=0,queued=0,candidates=0,candidates_saved=0,
            successful_queries=0,rejected=0,unconfirmed_product=0,expired=0,dismissed=0,cached=0,errors=[])
        seen=set();details=0;search_blocked=False
        if adapter.platform_code!='b2b_center':
            stats.update(status='unsupported',errors=['Public detail adapter not installed'])
            summary[adapter.platform_code]=stats;continue
        # B2B public search has a text input. Codes and product words are both searched;
        # this is not represented as a native OKPD2 filter.
        for query in (*OKPD2_PREFIXES,*FALLBACK_QUERIES):
            if search_blocked or details>=max_per_platform: break
            for page in range(1,4):
                if details>=max_per_platform: break
                try:
                    items=adapter.search(query,page=page);stats['successful_queries']+=1
                except Exception as exc:
                    message = str(exc)[:240] if isinstance(exc, RuntimeError) else type(exc).__name__
                    logger.warning('b2b_search_failed', query=query, page=page, error=message)
                    stats['errors'].append(f'search:{type(exc).__name__}:{message}')
                    from app.sources.http_refusal import refusal_status
                    if refusal_status(exc) is not None or (isinstance(exc,RuntimeError) and 'B2B_PAGINATION_REPEATED' not in str(exc)):
                        search_blocked=True
                    break
                if not items: break
                new=0
                for item in items:
                    key=str(item.external_id)
                    if key in seen:continue
                    seen.add(key);new+=1;stats['discovered']+=1
                    if is_dismissed(item.platform,key):
                        stats['dismissed']+=1;remove_candidate(item.platform,key);continue
                    if expired(item.deadline):
                        stats['expired']+=1;remove_candidate(item.platform,key);continue
                    if title_excluded(item.title, getattr(item, 'raw_text', '')):
                        stats['rejected']+=1;remove_candidate(item.platform,key);continue
                    if details>=max_per_platform:break
                    details+=1
                    try:
                        public=fetch_public(item,verify=adapter.verify,timeout=adapter.timeout)
                        source=to_source(item,public)
                        if expired(source.submission_deadline):
                            stats['expired']+=1;remove_candidate(item.platform,key);continue
                        if source.submission_deadline is None:
                            stats['rejected']+=1;remove_candidate(item.platform,key);continue
                        decision=screen_candidate(source.model_dump(mode='json'))
                        logger.info('b2b_candidate_screened',external_id=key,action=decision['action'],reason=decision['reason'])
                        if decision['action']=='reject':
                            stats['rejected']+=1;remove_candidate(item.platform,key);continue
                        if decision['action']=='review':
                            source.raw_payload['review_reason']=decision['message']
                            save_candidate(source);stats['candidates']+=1;stats['candidates_saved']+=1;continue
                        if _already_processed(source):
                            stats['cached']+=1;remove_candidate(item.platform,key);continue
                        # Persist once before queueing; duplicate worker delivery is handled downstream.
                        result=process_new_tender.run(source.model_dump(mode='json'),launch_pipeline=False)
                        if result.get('status')=='skipped':continue
                        task=process_new_tender.delay(source.model_dump(mode='json'),launch_pipeline=True)
                        stats['persisted']+=1;stats['queued']+=1;stats['relevant']+=1
                        source.raw_payload['review_reason']='Публичные позиции получены; ожидается автоматический анализ'
                        save_candidate(source)
                        logger.info('b2b_analysis_queued',external_id=key,task_id=task.id)
                    except Exception as exc:
                        logger.warning('b2b_public_failed',external_id=key,error_type=type(exc).__name__)
                        stats['errors'].append(f'{key}:{type(exc).__name__}')
                        # Keep a visible retry reason without asserting that extraction succeeded.
                        from app.marketplace_discovery.b2b_public import PublicCard
                        source=to_source(item,PublicCard(reason='public_fetch_failed'))
                        if source.submission_deadline is None or expired(source.submission_deadline):
                            remove_candidate(item.platform,key);continue
                        if screen_candidate(source.model_dump(mode='json'))['action']=='reject':
                            stats['unconfirmed_product']+=1;remove_candidate(item.platform,key);continue
                        source.raw_payload['review_reason']='Не удалось получить публичные позиции: '+type(exc).__name__
                        save_candidate(source);stats['candidates']+=1;stats['candidates_saved']+=1
                if not new: break
        if stats['errors']:stats['status']='partial' if stats['successful_queries'] else 'error'
        stats['detail_requests_limit']=max_per_platform
        summary[adapter.platform_code]=stats
    return summary
