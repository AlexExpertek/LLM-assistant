ESTP public search update 2026-10-07
Requires primary-12-sites-20261006. Guarded hashes and backup.
14 filters: six OKPD2 prefixes and title substring алюm (Cyrillic алюм), in 223 and comm sections; req_get only. 50/page, max 3 pages/filter. Repeated pages and incomplete coverage reported.
Primary information only: no mass inference, no OCR/LLM, no main-dashboard promotion. Existing schedule retained. No immediate task from install.
27 offline tests passed. Live public search replies verified for 223 title алюм, 223 OKPD2 24.42.22, commercial title алюм: explicit zero results. Full direct Python network run unavailable in build environment (DNS). Run check_live.py on server. Positive matching live tender and live pagination not yet verified.
