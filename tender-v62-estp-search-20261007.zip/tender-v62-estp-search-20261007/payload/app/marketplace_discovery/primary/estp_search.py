"""ESTP public UI search, observed in public_announces.js on 2026-10-07."""
import re
import time
from datetime import datetime, timezone
from urllib.parse import urlencode

PREFIXES = ('24.42.11','24.42.22','24.42.23','24.42.24','24.42.25','24.42.26')
BASE = 'https://comm.estp.ru/office/public/announces/search'

def search_url(section, field, value, page):
    if section not in ('223','comm') or field not in ('okpdCode','search'):
        raise ValueError('Invalid filter')
    return BASE+'?'+urlencode(dict(regulationType=section,stagesCodes='req_get',perPage=50,page=page,**{field:value}))

def collect_estp(*, persist=True, fetch=None):
    from .collector import estp_html, soup_for, estp_cards, save_report
    fetch = fetch or estp_html
    report = dict(source='estp',name='ESTP — 223-ФЗ и коммерческие',
        checked_at=datetime.now(timezone.utc).isoformat(),status='partial',
        coverage='filtered_search_max_3_pages_per_filter',requests=0,
        items=[],skipped={},errors=[],searches=[],cards_checked=0)
    unique={}
    for section in ('223','comm'):
        for field,value in [('okpdCode',x) for x in PREFIXES]+[('search','алюм')]:
            run=dict(section=section,field=field,value=value,pages=0,complete=False)
            report['searches'].append(run)
            seen=set()
            for page in range(1,4):
                url=search_url(section,field,value,page)
                try:
                    if report['requests']:time.sleep(1.1)
                    report['requests']+=1
                    soup=soup_for(fetch(url,timeout=20));run['pages']+=1
                    nodes=soup.select('.tender-card[data-tender-id]')
                    ids={n.get('data-tender-id') for n in nodes}
                    if not ids:
                        if re.search(r'Найдено\s+0\s+закупок|По вашему запросу закупки не найдены',soup.get_text(' ',strip=True),re.I):
                            run['complete']=True
                        else:run['error']='layout_not_recognized'
                        break
                    if ids <= seen:
                        run['error']='repeated_page';break
                    seen.update(ids)
                    items,skips,count=estp_cards(soup,url)
                    report['cards_checked']+=count
                    for key,count in skips.items():report['skipped'][key]=report['skipped'].get(key,0)+count
                    for item in items:
                        item['section']=section
                        unique[(section,item['external_id'])]=item
                    next_pages=[]
                    for node in soup.select('[onclick]'):
                        m=re.fullmatch(r'applyTenderFilters\((\d+)\);?',node['onclick'].strip())
                        if m and not node.has_attr('disabled'):next_pages.append(int(m[1]))
                    if not any(p>page for p in next_pages):
                        if len(ids)<50:run['complete']=True
                        else:run['error']='pagination_unconfirmed'
                        break
                    if page==3:run['error']='page_limit'
                except Exception as exc:
                    run['error']=type(exc).__name__;break
            if run.get('error'):report['errors'].append(dict(section=section,field=field,value=value,reason=run['error']))
    report['items']=list(unique.values())
    report['status']=('completed_filtered_search' if report['items'] else 'no_matches_in_checked_filters') if all(r['complete'] for r in report['searches']) else 'partial'
    if persist:save_report('estp',report)
    return report
