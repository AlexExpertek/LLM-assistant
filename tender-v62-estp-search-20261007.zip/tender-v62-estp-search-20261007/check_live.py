import json
from app.marketplace_discovery.primary.estp_search import collect_estp
print(json.dumps(collect_estp(persist=False),ensure_ascii=False,indent=2))
print('READ_ONLY: no DB, OCR, LLM or notifications')
