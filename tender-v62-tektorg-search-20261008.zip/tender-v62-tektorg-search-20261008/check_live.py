import json
from app.marketplace_discovery.primary.tektorg_search import collect_tektorg
print(json.dumps(collect_tektorg(persist=False), ensure_ascii=False, indent=2))
print('READ_ONLY: no DB, tasks, OCR, LLM, notifications or report writes')
