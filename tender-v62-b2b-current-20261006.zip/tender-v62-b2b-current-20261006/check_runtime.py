from app.reports.review_dashboard import get_review_dashboard
from app.reports.active_tenders import get_tender_dashboard
from datetime import datetime,timezone
from collections import Counter
for name,rows in [('dashboard',get_tender_dashboard()),('review',get_review_dashboard()['tenders'])]:
    print(name,'count=',len(rows),'sources=',dict(Counter(r.get('source') for r in rows)))
    if name=='review':
        for row in rows:
            dt=datetime.fromisoformat(row['submission_deadline'].replace('Z','+00:00'))
            assert dt>datetime.now(timezone.utc),row.get('external_id')
print('CURRENT_LISTS_OK: read only; no tasks, LLM or notifications')
