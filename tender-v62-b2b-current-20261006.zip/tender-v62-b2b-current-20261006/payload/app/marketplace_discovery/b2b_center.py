"""Public discovery adapter for B2B-Center."""

from __future__ import annotations

import html
import re
from datetime import datetime
from zoneinfo import ZoneInfo
from decimal import Decimal, InvalidOperation
from urllib.parse import urljoin, urlsplit

import httpx

from app.core.logging import get_logger
from app.marketplace_discovery.platforms.base import (
    MarketplaceAdapter,
)
from app.marketplace_discovery.schemas import (
    MarketplaceTender,
)


logger = get_logger(__name__)

BASE_URL = "https://www.b2b-center.ru"
SEARCH_URL = BASE_URL + "/site/api/v1/market-search/"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) "
        "AppleWebKit/537.36 "
        "Chrome/126.0 Safari/537.36"
    ),
    "Accept": (
        "text/html,application/xhtml+xml,"
        "application/xml;q=0.9,*/*;q=0.8"
    ),
    "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.7",
}


def _plain(value: str) -> str:
    value = re.sub(
        r"<script.*?</script>|<style.*?</style>",
        " ",
        value,
        flags=re.I | re.S,
    )

    value = re.sub(
        r"<[^>]+>",
        " ",
        value,
    )

    value = html.unescape(value)

    return re.sub(
        r"\s+",
        " ",
        value,
    ).strip()


def _parse_datetime(
    value: str | None,
) -> datetime | None:
    if not value:
        return None

    value = value.strip()

    for fmt in (
        "%d.%m.%Y %H:%M",
        "%d.%m.%Y",
    ):
        try:
            return datetime.strptime(
                value,
                fmt,
            ).replace(tzinfo=ZoneInfo("Europe/Moscow"))
        except ValueError:
            pass

    return None


def _parse_amount(
    value: str | None,
) -> Decimal | None:
    if not value:
        return None

    normalized = (
        value
        .replace("\xa0", "")
        .replace(" ", "")
        .replace(",", ".")
    )

    match = re.search(
        r"\d+(?:\.\d+)?",
        normalized,
    )

    if not match:
        return None

    try:
        return Decimal(match.group(0))
    except InvalidOperation:
        return None


class B2BCenterDiscoveryClient(
    MarketplaceAdapter
):
    platform_code = "b2b_center"
    platform_name = "B2B-Center"

    def __init__(
        self,
        *,
        verify: bool = True,
        timeout: float = 40.0,
    ):
        self.verify = verify
        self.timeout = timeout
        self._pages = {}

    def search(
        self,
        query: str,
        *,
        page: int = 1,
    ) -> list[MarketplaceTender]:

        # Bare numeric alloy queries are interpreted as procedure numbers.
        search_query = f"алюминий {query.strip()}" if query.strip().isdigit() else query
        if page < 1:
            raise ValueError("B2B page must be positive")
        # Public GET used by the guest search UI (October 2026).
        params = {
            "query": search_query,
            "macro_trade_type": "buy",
            "tab": "actual",
            "sort": "date_desc",
            "page": page,
            "page_size": 20,
            "is_seo": 0,
        }

        with httpx.Client(
            verify=self.verify,
            timeout=self.timeout,
            follow_redirects=False,
            headers=HEADERS,
        ) as client:
            response = client.get(
                SEARCH_URL,
                params=params,
            )

            response.raise_for_status()

        logger.info(
            "b2b_center_search_response",
            query=query,
            page=page,
            status=response.status_code,
            final_url=str(response.url),
            bytes=len(response.content),
        )

        if response.is_redirect:
            raise RuntimeError("B2B public search redirected; collection stopped")
        if len(response.content) > 4_000_000:
            raise RuntimeError("B2B public search response too large")
        try:
            data = response.json()
        except ValueError as exc:
            raise RuntimeError("B2B public search returned non-JSON; collection stopped") from exc
        items = self._parse_api(data, query=query)
        fingerprint = tuple(sorted(x.external_id for x in items))
        if page == 1:
            self._pages[query] = {1: fingerprint}
        else:
            previous = self._pages.setdefault(query, {})
            if fingerprint and any(p != page and f == fingerprint for p, f in previous.items()):
                raise RuntimeError("B2B_PAGINATION_REPEATED: public search repeated an earlier page")
            previous[page] = fingerprint
        return items

    def _parse_api(self, data, *, query):
        if not isinstance(data, dict) or data.get("mode") not in ("guest", "guest_light", "user", "user_light"):
            raise RuntimeError("B2B public search unavailable or unrecognized")
        if data.get("current_tab") != "actual":
            raise RuntimeError("B2B returned a non-current search tab; collection stopped")
        rows = data.get("trades")
        if not isinstance(rows, list):
            raise RuntimeError("B2B public search trades missing")
        results = []
        seen = set()
        for row in rows:
            if not isinstance(row, dict):
                raise RuntimeError("B2B malformed search card")
            # Recommendations are not evidence of a match to this search.
            if row.get("is_recommended") is True:
                continue
            key = str(row.get("trade_id") or "")
            url = urljoin(BASE_URL, str(row.get("url") or ""))
            parts = urlsplit(url)
            if (not key.isdigit() or parts.scheme != "https" or parts.hostname != "www.b2b-center.ru"
                    or parts.username or parts.password or parts.port not in (None, 443)
                    or not re.search(r"/tender-" + re.escape(key) + r"(?:/|$)", parts.path)):
                raise RuntimeError("B2B search card identity or URL mismatch")
            title = _plain(str(row.get("description") or ""))
            if not title:
                raise RuntimeError("B2B search card title missing")
            if key in seen:
                continue
            seen.add(key)
            # Require a time; date-only means unconfirmed, not midnight.
            date = str(row.get("date_actual") or "")
            deadline = _parse_datetime(date) if re.fullmatch(r"\d{2}\.\d{2}\.\d{4} \d{2}:\d{2}", date.strip()) else None
            price = _plain(str(row.get("price") or ""))
            amount = _parse_amount(price) if "₽" in price or "руб" in price.lower() else None
            results.append(MarketplaceTender(
                platform=self.platform_code, external_id=key, title=title[:1500],
                customer_name=_plain(str(row.get("org_name_short") or "")) or None,
                amount=amount, publish_date=_parse_datetime(str(row.get("date_published") or "")),
                deadline=deadline, source_url=url, search_query=query,
                raw_text=_plain(title + " " + str(row.get("snippet") or ""))[:10000],
            ))
        logger.info("b2b_center_search_parsed", query=query, count=len(results), layout="public_json", tab="actual")
        return results

    def _parse(
        self,
        html_text: str,
        *,
        query: str,
    ) -> list[MarketplaceTender]:

        if 'panel-procedure__card' in html_text:
            return self._parse_new_html(html_text, query=query)
        lowered = html_text.lower()
        if any(marker in lowered for marker in ("g-recaptcha", "hcaptcha", "подтвердите, что вы", "доступ ограничен", "access denied")):
            raise RuntimeError("B2B-Center access challenge; no search result available")
        if "search-results-title" not in lowered and not any(
            marker in lowered for marker in ("ничего не найдено", "по вашему запросу", "найдено 0", "нет торгов")
        ):
            raise RuntimeError("B2B-Center search layout not recognized")
        results: list[MarketplaceTender] = []
        seen: set[str] = set()

        #
        # A B2B result is represented by a table row.
        # Restrict parsing to rows containing
        # search-results-title so neighbouring HTML
        # cannot contaminate the tender.
        #
        rows = re.findall(
            r"<tr\b[^>]*>(.*?)</tr>",
            html_text,
            flags=re.I | re.S,
        )

        for row in rows:

            if "search-results-title" not in row:
                continue

            link_match = re.search(
                r'''<a\b[^>]*'''
                r'''href=["'](?P<url>[^"']*'''
                r'''/tender-(?P<id>\d+)'''
                r'''/[^"']*)["'][^>]*'''
                r'''class=["'][^"']*'''
                r'''search-results-title[^"']*["']'''
                r'''[^>]*>(?P<body>.*?)</a>''',
                row,
                flags=re.I | re.S,
            )

            if not link_match:
                #
                # Some pages place class before href.
                #
                link_match = re.search(
                    r'''<a\b[^>]*'''
                    r'''class=["'][^"']*'''
                    r'''search-results-title[^"']*["']'''
                    r'''[^>]*href=["'](?P<url>[^"']*'''
                    r'''/tender-(?P<id>\d+)'''
                    r'''/[^"']*)["'][^>]*>'''
                    r'''(?P<body>.*?)</a>''',
                    row,
                    flags=re.I | re.S,
                )

            if not link_match:
                continue

            external_id = link_match.group("id")

            if external_id in seen:
                continue

            seen.add(external_id)

            raw_url = html.unescape(
                link_match.group("url")
            )

            body = link_match.group("body")

            #
            # Description is contained in
            # search-results-title-desc.
            #
            desc_match = re.search(
                r'''<div\b[^>]*class=["']'''
                r'''search-results-title-desc["'][^>]*>'''
                r'''(?P<desc>.*?)</div>\s*</div>''',
                body,
                flags=re.I | re.S,
            )

            if desc_match:
                description_html = (
                    desc_match.group("desc")
                )
            else:
                description_html = body

            description = _plain(
                description_html
            )

            #
            # Remove the procedure prefix from title.
            #
            body_text = _plain(body)

            title = re.sub(
                rf"^(?:Запрос\s+предложений|"
                rf"Запрос\s+цен|Тендер|"
                rf"Процедура)\s*№?\s*"
                rf"{re.escape(external_id)}\s*",
                "",
                body_text,
                flags=re.I,
            ).strip()

            #
            # Prefer first description before the
            # highlighted search-context snippet.
            #
            highlighted_pos = re.search(
                r'<div\b[^>]*style=["\'][^"\']*'
                r'color\s*:\s*#?888',
                description_html,
                flags=re.I,
            )

            if highlighted_pos:
                clean_title = _plain(
                    description_html[
                        :highlighted_pos.start()
                    ]
                )

                if clean_title:
                    title = clean_title

            if not title:
                title = (
                    f"B2B-Center procedure "
                    f"{external_id}"
                )

            #
            # Cells after the procedure cell:
            # customer / published / deadline.
            #
            cells = re.findall(
                r"<td\b[^>]*>(.*?)</td>",
                row,
                flags=re.I | re.S,
            )

            customer_name = None
            publish_date = None
            deadline = None
            amount = None

            if len(cells) >= 2:
                customer_name = _plain(
                    cells[-4]
                    if len(cells) >= 4
                    else cells[1]
                ) or None

            dates = re.findall(
                r"\b\d{2}\.\d{2}\.\d{4}"
                r"(?:\s+\d{2}:\d{2})?\b",
                _plain(row),
            )

            if dates:
                publish_date = (
                    _parse_datetime(dates[0])
                )

            if len(dates) >= 2:
                deadline = (
                    _parse_datetime(dates[1])
                )

            #
            # Preserve the complete row as raw_text.
            # Relevance engine can inspect snippets
            # returned by B2B search.
            #
            raw_text = _plain(row)

            source_url = urljoin(
                BASE_URL,
                raw_url,
            )

            results.append(
                MarketplaceTender(
                    platform=self.platform_code,
                    external_id=external_id,
                    title=title[:1500],
                    customer_name=customer_name,
                    amount=amount,
                    publish_date=publish_date,
                    deadline=deadline,
                    source_url=source_url,
                    search_query=query,
                    raw_text=raw_text[:10000],
                )
            )

        logger.info(
            "b2b_center_search_parsed",
            query=query,
            count=len(results),
        )

        return results

    def _parse_new_html(self, html_text, *, query):
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html_text, "html.parser")
        field = soup.select_one('input[name="q"]')
        normalize = lambda v: " ".join(str(v).split()).casefold()
        if field is None or normalize(field.get("value", "")) != normalize(query):
            raise RuntimeError("B2B HTML search query mismatch; collection stopped")
        # Do not infer the status from words anywhere on the page.
        values = {x.get("value") for x in soup.select('input[readonly]')}
        if 'actual' not in values or 'archive' in values or 'all' in values:
            raise RuntimeError("B2B HTML current tab not confirmed; collection stopped")
        rows = []
        for card in soup.select('.panel-procedure__card'):
            link = card.select_one('a.panel-procedure__number-link[href]')
            title = card.select_one('.panel-procedure__dscr-main')
            date = card.select_one('.panel-procedure__dscr-date')
            customer = card.select_one('.panel-procedure__dscr-branch')
            if link is None or title is None:
                raise RuntimeError("B2B HTML malformed search card")
            match = re.search(r'/tender-(\d+)(?:/|$)', link['href'])
            if match is None:
                raise RuntimeError("B2B HTML card ID missing")
            dates = re.findall(r'\d{2}\.\d{2}\.\d{4} \d{2}:\d{2}', date.get_text(' ',strip=True) if date else '')
            rows.append(dict(trade_id=match[1],url=link['href'],description=title.get_text(' ',strip=True),
                org_name_short=customer.get_text(' ',strip=True) if customer else '',date_actual=dates[0] if dates else ''))
        return self._parse_api(dict(mode='guest',current_tab='actual',trades=rows),query=query)
