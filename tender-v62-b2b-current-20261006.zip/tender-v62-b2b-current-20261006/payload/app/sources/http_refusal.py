"""Classify explicit access/rate refusals, without logging request credentials."""
def refusal_status(exc):
    seen = set()
    while exc is not None and id(exc) not in seen:
        seen.add(id(exc))
        response = getattr(exc, 'response', None)
        status = getattr(response, 'status_code', None)
        if status in (401, 403, 429):
            return status
        exc = exc.__cause__ or exc.__context__
    return None
