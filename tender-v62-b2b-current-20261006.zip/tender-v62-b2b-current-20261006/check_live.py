"""Read-only probe: two search requests, no detail/OCR/LLM/DB writes."""
from datetime import datetime,timezone
import time
from app.marketplace_discovery.b2b_center import B2BCenterDiscoveryClient
client=B2BCenterDiscoveryClient()
rows=client.search('алюминий',page=1)
print('SEARCH_PAGE_1:',len(rows))
future=[r for r in rows if r.deadline and r.deadline>datetime.now(timezone.utc)]
print('FUTURE_DEADLINES:',len(future))
for row in future[:5]:print(row.external_id,row.deadline.isoformat(),row.title[:120])
time.sleep(1.1)
try:
    more=client.search('алюминий',page=2)
    print('SEARCH_PAGE_2:',len(more))
except RuntimeError as exc:
    if 'B2B_PAGINATION_REPEATED' not in str(exc):raise
    print('COVERAGE_PARTIAL: source repeated page 1; duplicates will not be processed')
print('READ_ONLY: no DB writes, tasks, OCR, LLM or notifications')
