Roseltorg public primary search — 2026-10-08
Requires installed PRIMARY_12_SITES and ESTP_SEARCH updates.
Changes only collector.py and adds roseltorg_search.py. Other sources, no-repeat
protection and manual dashboard workflow are unchanged.

Uses the public GET search form observed in server HTML:
/procedures/search_ajax?query_field=...&status[]=0
Only observed same-site pagination links are followed; no page parameter guessing.
Each scheduled run searches алюминий plus one rotating configured code/product query.
OKPD2 values here are TEXT queries, not a native classification-code filter.
Bounded: at most 3 pages/query, 12 detail cards and 20 requests/run, 1.1s interval.
Regional/customer/alloy restrictions are not added.
The existing Roseltorg schedule invokes the new adapter after installation.

Open search-stage + one unambiguous future detail deadline with explicit (МСК).
Date formats dd.mm.yy/dd.mm.yyyy. Converts to UTC. Closed timeline labels alone
are not treated as the current stage. Current closed status rejects the card.
Non-target titles and price-information monitoring are skipped.
Dismissals apply by Roseltorg ID and matching numeric EIS ID.
No mass is fabricated: primary_information / not_confirmed_500kg.
These reports are NOT full analysis or qualifying dashboard records.
Same-site document links are collected, not downloaded or OCRed.

Missing pagination -> partial / pagination_unconfirmed, never full coverage.
Repeated page -> partial / repeated_page. Unknown layout -> partial, not zero results.
No live server result is claimed by the offline tests.

Install: bash install.sh. Hash validation precedes writes; backup path is printed.
Run check_live.py through celery_discovery to check without saving reports:
docker compose exec -T celery_discovery python - < /tmp/tender-v62-roseltorg-search-20261008/check_live.py
Normal scheduled execution stores the result in storage/marketplace_primary/roseltorg.json.
No extra schedule, immediate collection, DB cleanup, OCR, LLM or notifications on install.
