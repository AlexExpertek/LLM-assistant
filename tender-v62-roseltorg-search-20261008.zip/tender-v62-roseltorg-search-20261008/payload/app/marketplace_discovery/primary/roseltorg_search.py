"""Roseltorg public HTML form/search adapter. Primary information only."""
import re,time
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
from urllib.parse import urlencode,urljoin,urlsplit,parse_qs
from bs4 import BeautifulSoup
from app.sources.public_http import get_html
from app.scoring.selection_policy import OKPD2_PREFIXES,FALLBACK_QUERIES
from app.marketplace_discovery.product_screening import aluminium_evidence,title_excluded
from app.marketplace_discovery.subject_classifier import classify_tender_subject
from app.reports.review_dismissals import is_dismissed
BASE='https://www.roseltorg.ru'
PATH='/procedures/search_ajax'
CARD=re.compile(r'^/procedure/([A-Za-z0-9_-]+)/(\d+)/?$')
DATES=re.compile(r'При[её]м\s+заявок\s+до\s*:?\s*(\d{2}\.\d{2}\.(?:\d{4}|\d{2}))\s+(\d{2}:\d{2})\s*\(МСК\)',re.I)

def safe(url):
 try:
  p=urlsplit(url)
  return p.scheme=='https' and p.hostname=='www.roseltorg.ru' and not p.username and not p.password and p.port in (None,443)
 except ValueError:return False

def search_url(query,page=None):
 params={'query_field':query,'status[]':'0'}
 if page is not None:params['page']=page
 return BASE+PATH+'?'+urlencode(params)

def soup(html):
 s=BeautifulSoup(html,'html.parser')
 for n in s(['script','style','header','footer','nav']):n.decompose()
 title=s.title.get_text(' ',strip=True) if s.title else ''
 if re.search(r'captcha|access denied|подтвердите.*что вы|технические работы',title+' '+s.get_text(' ',strip=True)[:1200],re.I):raise ValueError('access_or_technical_page')
 return s

def listings(s):
 items=[]
 for node in s.select('.search-results__item'):
  a=node.select_one('a.search-results__link--description[href]')
  if not a:continue
  url=urljoin(BASE,a['href']);m=CARD.fullmatch(urlsplit(url).path)
  if not safe(url) or not m:continue
  def text(selector):
   n=node.select_one(selector);return n.get_text(' ',strip=True) if n else ''
  items.append(dict(external_id=m[1],lot_number=m[2],source_url=url,title=a.get_text(' ',strip=True),
   search_stage=text('.search-results__status'),amount_text=text('.search-results__sum p.desktop'),
   customer=text('.search-results__customer a'),region=text('.search-results__region'),
   procurement_method=text('.search-results__type')))
 return items

def next_page(s,current):
 pages=[]
 for a in s.select('a[href]'):
  url=urljoin(BASE,a['href'])
  if not safe(url) or urlsplit(url).path not in (PATH,'/procedures/search'):continue
  vals=parse_qs(urlsplit(url).query).get('page',[])
  if len(vals)==1 and vals[0].isdigit() and int(vals[0])>current:pages.append(int(vals[0]))
 return min(pages) if pages else None

def parse_detail(html,item,now=None):
 s=soup(html);text=s.get_text(' ',strip=True);dates=set()
 for match in DATES.finditer(text):
  try:dates.add(datetime.strptime(match[1]+' '+match[2],'%d.%m.%Y %H:%M' if len(match[1])==10 else '%d.%m.%y %H:%M').replace(tzinfo=ZoneInfo('Europe/Moscow')).astimezone(timezone.utc))
  except ValueError:pass
 if len(dates)!=1:return None,'deadline_unconfirmed'
 deadline=next(iter(dates))
 if deadline<=(now or datetime.now(timezone.utc)):return None,'expired'
 # Timeline contains all stages including "Завершен": it is not current status.
 current=s.select_one('.procedure-status, .procedure__status')
 if current and re.search(r'заверш|отмен|комисси|приостанов',current.get_text(' ',strip=True),re.I):return None,'closed'
 documents=[]
 for a in s.select('a[href]'):
  url=urljoin(item['source_url'],a['href']);p=urlsplit(url)
  if safe(url) and re.search(r'download|filestore|\.(?:pdf|docx?|xlsx?|zip)(?:$)',p.path,re.I):
   if url not in [d['url'] for d in documents]:documents.append({'name':a.get('title') or a.get_text(' ',strip=True),'url':url})
 return dict(**item,source='roseltorg',submission_deadline=deadline.isoformat(),documents=documents,
  status='primary_information',analysis_done=False,mass_kg=None,mass_status='not_verified',
  eligibility='not_confirmed_500kg',collected_at=(now or datetime.now(timezone.utc)).isoformat()),None

def collect_roseltorg(*,persist=True,fetch=None,now=None):
 from .collector import save_report
 fetch=fetch or get_html;now=now or datetime.now(timezone.utc)
 # Cover all configured queries across scheduled runs; one broad query every run.
 rotated=(*OKPD2_PREFIXES,*FALLBACK_QUERIES)
 queries=list(dict.fromkeys(('алюминий',rotated[(now.toordinal()*6+now.hour//4)%len(rotated)])))
 report=dict(source='roseltorg',name='Росэлторг',checked_at=now.isoformat(),status='partial',
  coverage='bounded_public_search_max_3_pages_12_cards_20_requests',requests=0,items=[],skipped={},errors=[],searches=[],cards_checked=0)
 seen_cards=set()
 def skip(reason):report['skipped'][reason]=report['skipped'].get(reason,0)+1
 def read(url):
  if not safe(url):raise ValueError('off_site_url')
  if report['requests']>=20:raise ValueError('request_budget')
  if report['requests']:time.sleep(1.1)
  report['requests']+=1;return fetch(url,timeout=25)
 for query in queries:
  run=dict(query=query,filter_type='text',stage='0',pages=0,complete=False);report['searches'].append(run)
  page=None;page_ids=set()
  try:
   for step in range(3):
    s=soup(read(search_url(query,page)));run['pages']+=1
    items=listings(s)
    if not items:
     if re.search(r'ничего не найдено|по вашему запросу.*не найден|найдено\s*0',s.get_text(' ',strip=True),re.I):run['complete']=True
     else:run['reason']='layout_not_recognized'
     break
    ids={(i['external_id'],i['lot_number']) for i in items}
    if ids<=page_ids:run['reason']='repeated_page';break
    page_ids.update(ids)
    for item in items:
     key=(item['external_id'],item['lot_number'])
     if key in seen_cards:continue
     seen_cards.add(key)
     if not re.match(r'При[её]м заявок\b',item['search_stage'],re.I):skip('not_open');continue
     if is_dismissed('roseltorg',item['external_id']) or (item['external_id'].isdigit() and is_dismissed('zakupki_gov_ru',item['external_id'])):skip('manually_dismissed');continue
     if re.search(r'ценовой информации|мониторинг.*цен',item['procurement_method'],re.I):skip('price_monitoring');continue
     if title_excluded(item['title']) or not classify_tender_subject(item['title']).allowed or not aluminium_evidence(item['title']):skip('non_target');continue
     if report['cards_checked']>=12:run['reason']='card_limit';break
     report['cards_checked']+=1
     result,reason=parse_detail(read(item['source_url']),item,now)
     if result:report['items'].append(result)
     else:skip(reason)
    if run.get('reason'):break
    next_number=next_page(s,page or 0)
    if next_number is None:run['reason']='pagination_unconfirmed';break
    page=next_number
    if step==2:run['reason']='page_limit'
  except Exception as exc:
   run['reason']=str(exc) if isinstance(exc,ValueError) else type(exc).__name__
  if run.get('reason'):report['errors'].append({'query':query,'reason':run['reason']})
 report['status']='partial' if any(not r['complete'] for r in report['searches']) else ('completed_checked_filters' if report['items'] else 'no_matches_in_checked_filters')
 if persist:save_report('roseltorg',report)
 return report
