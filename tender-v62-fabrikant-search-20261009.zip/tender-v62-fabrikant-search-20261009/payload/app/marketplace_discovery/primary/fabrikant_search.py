"""Public Fabrikant purchase listings. No document download or LLM dispatch."""
import json
import re
import time
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from urllib.parse import urlencode, urlsplit, urljoin, parse_qs
from bs4 import BeautifulSoup
from app.sources.public_http import get_html
from app.marketplace_discovery.product_screening import aluminium_evidence, subject_block_reason
from app.reports.review_dismissals import is_dismissed

BASE = 'https://www.fabrikant.ru/procedure/search/purchases'
# Exact public rubricator selections supplied by the user. Do not infer numeric
# code mappings for opaque IDs or collapse several child IDs to one parent.
FILTERS = (
 ('selection_1', ('Ekr09fMvnr3KRFWyOp12ew',)),
 ('selection_2', ('zN-tJ4ydPbaa2_KkvHhtxg',)),
 ('selection_3', ('flqrldHR65sPxNL51Sngcw','ZCQhEf0ZZvZ134_sMi4a6Q','TyrG45Yrfz-tkDoPWcOt1A','_pzDcxfBdAk3jj38uDgvhw','DHvAr_b7_Fdk4ldNg4cIdw','jFUziuybUSKZOCFxW5pm0A','X707R71X9Rt2ev-RplR2-w','37vAhapFNufkq2mU49fskg')),
 ('selection_4', ('v7nnwgIyaYs_az3eYINQow','rZnVTcb0HxdF8jgpnBLwJw')),
 ('selection_5', ('lxUiubwJPTRc95kQAhqrTg',)),
 ('selection_6', ('HDyI4DZpERzUgALweypRNQ','k5jwaKYtjYlmVG8rHj1I0Q','AdA0aZIHjnC_2moTUDwY6g','jEqvDAkcsFxbrdfRYSt47A','jP4D9BgI84ivqw-R-kOW5g','eaThHgIyP5EmZCLL3jgd2Q')),
)
MAX_REQUESTS = 24

def search_url(ids, page, query=None):
    params = [('okpd2[]', x) for x in ids]
    params += [('page_number', str(page)), ('statuses[]', '1')]
    if query:
        params.append(('query', query))
    return BASE + '?' + urlencode(params)

def safe(url):
    try:
        p = urlsplit(url)
        return (p.scheme == 'https' and not p.username and not p.password
                and p.port in (None,443) and (p.hostname == 'fabrikant.ru'
                or (p.hostname or '').endswith('.fabrikant.ru')))
    except ValueError:
        return False

def normalized(value):
    return re.sub(r'\s+', ' ', value).strip().lower().replace('ё','е')

def field(card, name):
    for node in card.select('[data-slot="text"]'):
        if normalized(node.get_text(' ', strip=True)) == normalized(name):
            sibling = node.find_next_sibling()
            return sibling.get_text(' ', strip=True) if sibling else ''
    return ''

def parse_listing(html):
    soup = BeautifulSoup(html, 'html.parser')
    for node in soup(['script','style','header','footer','nav']):
        node.decompose()
    text = soup.get_text(' ', strip=True)
    if re.search(r'captcha|access denied|подтвердите.*что вы|технические работы', text[:2500], re.I):
        raise ValueError('access_or_technical_page')
    totals = {int(re.sub(r'\s','',m)) for m in re.findall(r'Всего:\s*([0-9][0-9\s\u00a0\u202f]*)',text)}
    if len(totals) != 1:
        raise ValueError('search_total_unrecognized')
    total = next(iter(totals))
    nodes = soup.select('[data-slot="card"][data-id]')
    if total > 0 and not nodes:
        raise ValueError('search_cards_unrecognized')
    if total == 0 and nodes:
        raise ValueError('inconsistent_empty_search')
    return nodes, total

def candidate(card, *, now, dismissed, ids=()):
    identifier = str(card.get('data-id') or '')
    badges = {normalized(x.get_text(' ',strip=True)) for x in card.select('[data-slot="badge"]')}
    if not badges.intersection({'прием заявок','прием предложений'}):
        return None,'not_open'
    if badges.intersection({'завершенные','завершен','отменен','работа комиссии','подведение итогов'}):
        return None,'not_open'
    a = card.select_one('a.font-heading[href]')
    if not a:
        return None,'title_link_unrecognized'
    title = a.get_text(' ',strip=True)
    url = urljoin(BASE,a['href'])
    if not identifier.isdigit() or not title or not safe(url) or '/procedure/search' in urlsplit(url).path:
        return None,'invalid_card'
    registry = None
    for link in card.select('a[href]'):
        parsed = urlsplit(link['href'])
        if parsed.hostname == 'zakupki.gov.ru':
            number = parse_qs(parsed.query).get('searchString',[''])[0]
            if re.fullmatch(r'\d{11}|\d{19}',number):
                registry = number
                break
    if dismissed('fabrikant',identifier) or (registry and (
            dismissed('fabrikant',registry) or dismissed('zakupki_gov_ru',registry))):
        return None,'manually_dismissed'
    raw_date = field(card,'Дата окончания приёма заявок')
    try:
        # Public SSR listing renders Moscow wall time (observed publication and
        # countdown together). Keep source text and timezone provenance.
        end = datetime.strptime(raw_date,'%d.%m.%Y %H:%M').replace(tzinfo=ZoneInfo('Europe/Moscow')).astimezone(timezone.utc)
    except ValueError:
        return None,'deadline_unknown'
    if end <= now:
        return None,'expired'
    if re.search(r'\b(?:реализация|продажа)\b',title,re.I):
        return None,'sale_not_purchase'
    if subject_block_reason(title):
        return None,'non_target_subject'
    if not aluminium_evidence(title):
        # Rubricator selections alone do not establish product or mass.
        return None,'product_unconfirmed_in_listing'
    return dict(source='fabrikant',external_id=identifier,registry_number=registry,
        source_url=url,title=title,customer=field(card,'Заказчик') or field(card,'Организатор'),
        submission_deadline=end.isoformat(),deadline_text=raw_date,
        deadline_timezone='Europe/Moscow',search_stage='Прием заявок',
        matched_filter_ids=list(ids),status='primary_information',analysis_done=False,
        mass_kg=None,mass_status='not_verified',eligibility='not_confirmed_500kg',
        documents=[],documents_status='not_checked',collected_at=now.isoformat()),None

def collect_fabrikant(*,persist=True,fetch=None,now=None,pause=time.sleep,dismissed=None):
    from .collector import folder,save_report
    fetch = fetch or get_html
    now = now or datetime.now(timezone.utc)
    dismissed = dismissed or is_dismissed
    cursors = {}
    try:
        cursors = json.loads((folder()/'fabrikant.json').read_text()).get('next_pages',{})
    except FileNotFoundError:
        pass
    report = dict(source='fabrikant',name='Фабрикант',checked_at=now.isoformat(),
        status='partial',coverage='first_page_plus_2_cursor_pages_per_filter',
        filter_mapping='user_selected_opaque_ids; numeric_mapping_not_verified',
        requests=0,items=[],skipped={},errors=[],searches=[],next_pages=dict(cursors),
        cards_checked=0,pipeline_status='primary_only_no_automatic_analysis')
    seen = set()
    searches = list(FILTERS) + [('query_aluminium',()),('query_sheet',())]
    for label,ids in searches:
        query = 'Алюминий' if label=='query_aluminium' else ('алюминиевый лист' if label=='query_sheet' else None)
        run = dict(filter=label,ids=list(ids),query=query,pages=[],complete=False)
        report['searches'].append(run)
        signatures = set()
        start = max(2,int(cursors.get(label,2)))
        pages = [1,start,start+1]
        try:
            for page in pages:
                if report['requests'] >= MAX_REQUESTS:
                    raise ValueError('request_budget')
                if report['requests']:
                    pause(1.2)
                report['requests'] += 1
                cards,total = parse_listing(fetch(search_url(ids,page,query),timeout=25))
                run['pages'].append(page);run['total']=total
                signature = tuple(sorted(c['data-id'] for c in cards))
                if signature and signature in signatures:
                    raise ValueError('repeated_page')
                signatures.add(signature)
                # Default listing limit observed as 10; do not request page 2
                # when first-page cards already cover the reported total.
                if page==1 and start > max(1,(total+9)//10):
                    pages[1:]=[2,3];start=2
                for card in cards:
                    identifier = card['data-id']
                    if identifier in seen:
                        continue
                    seen.add(identifier);report['cards_checked']+=1
                    item,reason = candidate(card,now=now,dismissed=dismissed,ids=ids)
                    if item:
                        report['items'].append(item)
                    else:
                        report['skipped'][reason]=report['skipped'].get(reason,0)+1
                if page>1:
                    report['next_pages'][label]=page+1
                if total <= len(cards) or page*10 >= total:
                    report['next_pages'][label]=2
                    run['complete']=start==2 or page==1
                    run['cycle_finished']=True
                    break
            if not run['complete']:
                run['reason']='cycle_tail_checked' if run.get('cycle_finished') else 'page_limit'
        except Exception as exc:
            run['reason']=str(exc) if isinstance(exc,ValueError) else type(exc).__name__
        if run.get('reason'):
            report['errors'].append(dict(filter=label,reason=run['reason']))
    if all(x['complete'] for x in report['searches']):
        report['status']='completed_checked_filters' if report['items'] else 'no_matches_in_checked_filters'
    if persist:
        save_report('fabrikant',report)
    return report
