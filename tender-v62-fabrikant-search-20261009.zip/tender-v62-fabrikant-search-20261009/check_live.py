import json
from app.marketplace_discovery.primary.fabrikant_search import collect_fabrikant
print(json.dumps(collect_fabrikant(persist=False),ensure_ascii=False,indent=2))
print('READ_ONLY: no report writes, DB, tasks, OCR, LLM or notifications')
