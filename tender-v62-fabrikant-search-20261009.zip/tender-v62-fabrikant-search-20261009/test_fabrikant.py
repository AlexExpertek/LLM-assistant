import unittest,tempfile
from pathlib import Path
from datetime import datetime,timezone
from urllib.parse import parse_qs,urlsplit
from unittest.mock import patch
from app.marketplace_discovery.primary import fabrikant_search as f

NOW=datetime(2026,10,9,6,tzinfo=timezone.utc)
def card(number='12',title='Лист алюминиевый АМг2',stage='Прием заявок',end='12.10.2026 10:00'):
    return f'''<div data-slot="card" data-id="{number}"><span data-slot="badge">{stage}</span>
    <a class="font-heading" href="https://44.fabrikant.ru/44/procedure/ea21/0816500000626015495">{title}</a>
    <a href="https://zakupki.gov.ru/epz/order/extendedsearch/results.html?searchString=0816500000626015495">ЕИС</a>
    <div><div data-slot="text">Дата окончания приёма заявок</div><div>{end}</div></div></div>'''
def html(cards='',total=0):return f'<html><body>Всего: {total} {cards}</body></html>'
class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.p=patch('app.marketplace_discovery.primary.collector.folder',return_value=Path(self.tmp.name));self.p.start();self.addCleanup(self.p.stop)
    def parse(self,**kw):return f.candidate(f.parse_listing(html(card(**kw),1))[0][0],now=NOW,dismissed=lambda *a:False)
    def collect(self,fetch):return f.collect_fabrikant(persist=False,fetch=fetch,now=NOW,pause=lambda n:None,dismissed=lambda *a:False)
    def test_url(self):
        q=parse_qs(urlsplit(f.search_url(f.FILTERS[2][1],2)).query)
        self.assertEqual(q['statuses[]'],['1']);self.assertEqual(len(q['okpd2[]']),8);self.assertEqual(q['page_number'],['2'])
    def test_target(self):
        x,r=self.parse();self.assertIsNone(r);self.assertEqual(x['submission_deadline'],'2026-10-12T07:00:00+00:00');self.assertFalse(x['analysis_done']);self.assertIsNone(x['mass_kg']);self.assertEqual(x['registry_number'],'0816500000626015495')
    def test_closed(self):self.assertEqual(self.parse(stage='Подведение итогов')[1],'not_open')
    def test_expired(self):self.assertEqual(self.parse(end='09.10.2026 08:59')[1],'expired')
    def test_unknown(self):self.assertEqual(self.parse(end='')[1],'deadline_unknown')
    def test_non_target(self):self.assertIsNone(self.parse(title='Поставка буфетных приборов')[0])
    def test_dismissal(self):
        node=f.parse_listing(html(card(),1))[0][0]
        self.assertEqual(f.candidate(node,now=NOW,dismissed=lambda source,id:source=='zakupki_gov_ru')[1],'manually_dismissed')
    def test_zero(self):
        r=self.collect(lambda *a,**k:html());self.assertEqual(r['requests'],8);self.assertEqual(r['status'],'no_matches_in_checked_filters');self.assertFalse(list(Path(self.tmp.name).iterdir()))
    def test_two_cards_stop_and_dedup(self):
        r=self.collect(lambda *a,**k:html(card('1')+card('2'),2));self.assertEqual(r['requests'],8);self.assertEqual(len(r['items']),2)
    def test_repeated_real_second_page(self):
        r=self.collect(lambda *a,**k:html(''.join(card(str(i)) for i in range(10)),21));self.assertEqual(r['status'],'partial');self.assertTrue(all(x['reason']=='repeated_page' for x in r['errors']))
    def test_distinct_pages(self):
        def fetch(url,**kw):
            page=int(parse_qs(urlsplit(url).query)['page_number'][0])
            return html(''.join(card(str(i)) for i in range((page-1)*10,min(page*10,12))),12)
        r=self.collect(fetch);self.assertEqual(len(r['items']),12);self.assertTrue(all(x['complete'] for x in r['searches']))
    def test_layout_error_not_zero(self):
        r=self.collect(lambda *a,**k:'<html>Something changed</html>');self.assertEqual(r['status'],'partial');self.assertEqual(len(r['errors']),8)
    def test_safe(self):
        self.assertFalse(f.safe('https://fabrikant.ru.evil.test/'));self.assertFalse(f.safe('https://user@www.fabrikant.ru/'))
    def test_short_nonempty_total_is_not_success(self):
        with self.assertRaises(ValueError):f.parse_listing(html('',20))

unittest.main()
