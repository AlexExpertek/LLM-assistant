#!/usr/bin/env bash
set -Eeuo pipefail
PACKAGE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="${1:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
cd "$PROJECT_DIR"
python3 "$PACKAGE_DIR/apply.py" "$PROJECT_DIR"
docker compose config --quiet
docker compose build app celery_worker
docker compose run --rm --no-deps -T celery_worker python - < "$PACKAGE_DIR/verify_ocr.py"
echo 'Offline checks passed. Restarting OCR worker; unfinished late-ack tasks may be redelivered.'
docker compose up -d --no-deps --timeout 60 celery_worker app
docker compose exec -T celery_worker python - <<'PY'
import os
import socket
import time
from app.workers.celery_app import celery_app
from app.workers.tasks_ocr import process_tender_documents
assert process_tender_documents.soft_time_limit == 840
assert process_tender_documents.time_limit == 900
assert os.environ.get('OMP_THREAD_LIMIT') == '1'
node = 'celery@' + socket.gethostname()
for attempt in range(10):
    info = celery_app.control.inspect(destination=[node], timeout=5).stats() or {}
    if node in info:
        assert info[node]['pool']['max-concurrency'] == 2, info[node]['pool']
        print('OCR_WORKER_READY:', node, 'concurrency=2, limits=840/900, OMP=1')
        break
    time.sleep(2)
else:
    raise SystemExit('OCR worker did not reply; inspect logs before continuing.')
PY
docker compose ps -a
echo 'OCR_UPDATE_INSTALLED. Discovery worker and existing queues were retained.'
