"""Offline regression checks: no live DB, HTTP, LLM or Tesseract requests."""
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace, ModuleType
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.environ.get('OCR_PROJECT', '/app'))
for key, value in {
 'REDIS_URL':'redis://127.0.0.1:1/0','QDRANT_URL':'http://127.0.0.1:1',
 'DATABASE_URL':'postgresql+asyncpg://test:test@127.0.0.1:1/test',
 'DATABASE_URL_SYNC':'postgresql+psycopg2://test:test@127.0.0.1:1/test',
 'CELERY_BROKER_URL':'memory://','CELERY_RESULT_BACKEND':'cache+memory://',
}.items(): os.environ[key] = value
from app.ocr.task_guard import OCRGuard, OCRBusy
from app.ocr import pipeline
from app.workers import tasks_ocr as tasks
from app.models.database import OCRStatus
from PIL import Image

class Checks(unittest.TestCase):
    def test_exclusive_tender_lock_and_release(self):
        with tempfile.TemporaryDirectory() as directory:
            with OCRGuard(directory,'tender','a'):
                with self.assertRaises(OCRBusy):
                    with OCRGuard(directory,'tender','b'): pass
                with OCRGuard(directory,'other','b'): pass
            with OCRGuard(directory,'tender','b'): pass

    def test_receipt_survives_new_instance_and_is_task_specific(self):
        with tempfile.TemporaryDirectory() as directory:
            with OCRGuard(directory,'t','id') as g: g.finish({'status':'manual_review'})
            with OCRGuard(directory,'t','id') as g: self.assertEqual(g.previous()['status'],'manual_review')
            with OCRGuard(directory,'t','other') as g: self.assertIsNone(g.previous())

    def test_task_redelivery_does_not_process_again(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(tasks.settings,'storage_path',directory), patch.object(tasks,'_process_documents',return_value={'status':'documents_ready'}) as process:
            tasks.process_tender_documents.push_request(id='same-task')
            try:
                tasks.process_tender_documents.run('t',[])
                tasks.process_tender_documents.run('t',[])
            finally: tasks.process_tender_documents.pop_request()
            self.assertEqual(process.call_count,1)

    def test_soft_timeout_requires_review(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(tasks.settings,'storage_path',directory), patch.object(tasks,'_process_documents',side_effect=tasks.SoftTimeLimitExceeded), patch.object(tasks,'_mark_incomplete') as mark:
            tasks.process_tender_documents.push_request(id='timeout')
            try: result=tasks.process_tender_documents.run('t',[])
            finally: tasks.process_tender_documents.pop_request()
            self.assertEqual(result['status'],'manual_review');mark.assert_called_once_with('t')

    def test_empty_documents_are_not_ready(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(tasks.settings,'storage_path',directory), patch.object(tasks,'SyncSessionLocal') as factory, patch.object(tasks,'_mark_incomplete') as mark:
            factory.return_value.__enter__.return_value.execute.return_value.scalars.return_value.all.return_value=[]
            result=tasks._process_documents('t',[])
            self.assertEqual(result['status'],'manual_review');mark.assert_called_once()

    def run_document(self, status=OCRStatus.DONE, failure=None, suffix='.pdf'):
        session=MagicMock()
        session.execute.return_value.scalars.return_value.all.return_value=[]
        session.refresh.side_effect=lambda row:setattr(row,'id','document-id')
        fake=ModuleType('app.workers.tasks_scoring');fake.analyze_tender=MagicMock()
        with tempfile.TemporaryDirectory() as directory, patch.object(tasks.settings,'storage_path',directory), patch.object(tasks,'SyncSessionLocal') as factory, patch.object(tasks,'_materialize',return_value=Path(directory)/('x'+suffix)), patch.object(tasks,'extract_document',return_value=SimpleNamespace(status=status,full_text='Text',pages_count=1),side_effect=failure), patch.object(tasks,'compute_file_hash',return_value='hash'), patch.object(tasks,'_mark_incomplete') as mark, patch.dict(sys.modules,{'app.workers.tasks_scoring':fake}):
            factory.return_value.__enter__.return_value=session
            result=tasks._process_documents('t',[{'name':'x'+suffix,'url':'https://example.invalid/file'}])
            return result, fake.analyze_tender.delay.call_count, mark.call_count

    def test_valid_text_goes_to_analysis(self):
        result,calls,marks=self.run_document()
        self.assertEqual((result['status'],calls,marks),('documents_ready',1,0))

    def test_low_confidence_stops_analysis(self):
        result,calls,marks=self.run_document(OCRStatus.LOW_CONFIDENCE)
        self.assertEqual((result['status'],calls,marks),('manual_review',0,1))

    def test_timeout_stops_analysis(self):
        result,calls,marks=self.run_document(failure=RuntimeError('Tesseract timeout'))
        self.assertEqual((result['status'],calls,marks),('manual_review',0,1))

    def test_unsupported_doc_stops_analysis(self):
        result,calls,marks=self.run_document(suffix='.doc')
        self.assertEqual((result['status'],calls,marks),('manual_review',0,1))

    def test_tesseract_timeout_pixels_and_fractional_confidence(self):
        seen={}
        def fake(image, **kw):
            seen.update(kw);seen['pixels']=image.width*image.height
            return {'text':['test'], 'conf':['72.5']}
        with patch.object(pipeline.pytesseract,'image_to_data',side_effect=fake):
            result=pipeline._ocr_image(Image.new('RGB',(4000,2000)))
        self.assertEqual(result.confidence,72.5)
        self.assertEqual(seen['timeout'],45)
        self.assertLessEqual(seen['pixels'],6_000_000)

    def test_large_pdf_requires_review(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'large.pdf'
            with pipeline.fitz.open() as doc:
                for _ in range(101):doc.new_page()
                doc.save(path)
            with self.assertRaises(ValueError):pipeline.extract_pdf(str(path))

    def test_old_analysis_message_cannot_use_failed_documents(self):
        from app.workers import tasks_scoring as scoring
        from app.models.database import ProcessingStatus
        session=MagicMock()
        session.get.return_value=SimpleNamespace(processing_status=ProcessingStatus.FAILED)
        session.execute.return_value.scalars.return_value.all.return_value=['document-id']
        with patch.object(scoring,'SyncSessionLocal') as factory, patch.object(scoring,'extract_tender_positions') as llm:
            factory.return_value.__enter__.return_value=session
            result=scoring.analyze_tender.run('t','old text',['document-id'])
            self.assertEqual(result['status'],'skipped');llm.assert_not_called()

    def test_old_analysis_message_cannot_use_replaced_documents(self):
        from app.workers import tasks_scoring as scoring
        from app.models.database import ProcessingStatus
        session=MagicMock()
        session.get.return_value=SimpleNamespace(processing_status=ProcessingStatus.DOCUMENTS_READY)
        session.execute.return_value.scalars.return_value.all.return_value=['new-document-id']
        with patch.object(scoring,'SyncSessionLocal') as factory, patch.object(scoring,'extract_tender_positions') as llm:
            factory.return_value.__enter__.return_value=session
            result=scoring.analyze_tender.run('t','old text',['old-document-id'])
            self.assertEqual(result['status'],'skipped');llm.assert_not_called()

    def test_task_limits(self):
        self.assertEqual(tasks.process_tender_documents.soft_time_limit,840)
        self.assertEqual(tasks.process_tender_documents.time_limit,900)

if __name__=='__main__': unittest.main(verbosity=1)
