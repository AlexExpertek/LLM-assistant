# Tender AI Platform v6 — изменения архитектуры

## Цель

Все тендерные площадки имеют собственный способ поиска и получения данных, но после адаптера обязаны возвращать единый `SourceTender`. Внутри платформы источник больше не влияет на OCR, LLM, БД, скоринг и Excel.

## Ключевые исправления

- единый контракт `SourceTender` / `SourceDocument`;
- интерфейс `TenderSourceAdapter` и реестр адаптеров;
- ЕИС и Tender.Pro переведены на adapters;
- весь Celery pipeline использует внутренний `Tender.id` UUID;
- документы реально сохраняются в таблицу `documents` вместе с текстом OCR;
- архивные документы ЕИС обрабатываются как `archive_member`, а не как фиктивный HTTP URL;
- LLM запускается один раз после обработки всего комплекта документов;
- модель данных разделена на `Tender -> Lot -> TenderItem`;
- добавлен многопозиционный LLM extraction;
- Excel строится по принципу «одна товарная позиция = одна строка»;
- ручная загрузка идет через тот же ingestion pipeline;
- URL маршрутизируется через source resolver;
- добавлен `processing_status` отдельно от бизнес-решения;
- добавлены `source_hash` и `analysis_version` для повторного анализа измененных закупок;
- Tender.Pro API key вынесен в `.env`;
- `.env` с секретами не входит в архив;
- migration history пересобрана с единственной корректной v6 migration.

## Как добавить новую площадку

1. Создать `app/sources/<source>/adapter.py`.
2. Реализовать `TenderSourceAdapter.search()` и при возможности `fetch_by_url()` / `fetch_by_id()`.
3. Преобразовать собственный ответ площадки в `SourceTender`.
4. Зарегистрировать адаптер в `app/sources/registry.py`.

После этого OCR, LLM, БД, scoring и отчет менять не требуется.

## v6.1 — сверка с официальным Tender.Pro API (12.08.2026)

- Tender.Pro переведен с legacy-функции на отдельный `TenderProClient` + `TenderProAdapter`.
- Общая лента вызывается документированным `_info.tenderlist_by_set` с `set_type_id=2`, `open_only=t` и `max_rows`; старый hard-coded `set_id=7964` удален, поскольку при `set_type_id=2` он игнорируется.
- Детализация вызывается документированным `_tender.info` по `id + company_id`.
- Неподтвержденный `_tender.files` удален. Документы извлекаются из detail payload `_tender.info`; если Tender.Pro предоставит отдельный документированный endpoint файлов, его можно добавить в `TenderProClient` без изменения общего pipeline.
- Исправлены публичные URL карточек Tender.Pro: основной формат `https://www.tender.pro/api/tender/{id}/view_public`, resolver также понимает старый `view_tender_public.shtml?...tenderid={id}`.
- Фильтрация по алюминиевой тематике выполняется после detail-запроса, чтобы учитывать комментарии, товарные данные и имена документов, а не только заголовок ленты.
- Добавлены настройки `TENDER_PRO_MAX_ROWS`, `TENDER_PRO_OPEN_ONLY`, `TENDER_PRO_FETCH_DETAILS`, `TENDER_PRO_REQUEST_TIMEOUT`.
- `ANALYSIS_VERSION` поднята до `v6.1` для контролируемого повторного анализа после изменения адаптера.


## v6.2 — Контур.Закупки

- добавлен `app/sources/kontur_zakupki/client.py`;
- добавлен `KonturZakupkiAdapter`;
- источник зарегистрирован как `kontur_zakupki`;
- `resolver.py` распознает `zakupki.kontur.ru`;
- карточка Контур проходит общий `SourceTender -> DB -> Documents -> LLM -> Items -> Excel`;
- API key, base URL, auth mode и endpoint paths вынесены в `.env`;
- поддержаны GET/POST search и отдельная/встроенная документация;
- mapper устойчив к нескольким вариантам имен полей JSON и сохраняет полный `raw_payload`;
- фильтр по алюминию выполняется после detail-запроса, если он включен;
- Celery Beat запускает Контур автоматически только при наличии `KONTUR_API_BASE_URL` и `KONTUR_API_KEY`;
- в веб-интерфейс добавлены Контур.Закупки и ручной запуск мониторинга;
- добавлены тесты адаптера и URL resolver;
- `ANALYSIS_VERSION=v6.2`.
