# Контур.Закупки — подключение к v6.2

## Что реализовано

Контур.Закупки подключен как третий source adapter и возвращает общий `SourceTender`.
После этого используются те же БД, документы, OCR, LLM, scoring и Excel, что для ЕИС и Tender.Pro.

Поток:

```text
Контур API -> KonturZakupkiClient -> KonturZakupkiAdapter -> SourceTender
           -> process_new_tender -> Documents -> LLM -> Lot/Item -> единый отчет
```

## Почему URL и авторизация вынесены в `.env`

Переданные HTML-файлы документации являются SPA-shell и не содержат контракт методов API:
основной текст загружается JavaScript. Контур выдает API-лицензию и ключ разработчика;
точный host, способ передачи ключа и доступные методы необходимо брать из документации,
выданной для вашей лицензии. Поэтому эти значения не зашиты в Python.

## Настройка

```env
KONTUR_API_BASE_URL=
KONTUR_API_KEY=

# Заполните один вариант авторизации по документации Контур:
KONTUR_API_KEY_HEADER=
KONTUR_API_KEY_PREFIX=
KONTUR_API_KEY_QUERY_PARAM=

KONTUR_SEARCH_PATH=
KONTUR_SEARCH_METHOD=POST
KONTUR_PURCHASE_PATH=
KONTUR_DOCUMENTS_PATH=

KONTUR_REQUEST_TIMEOUT=30
KONTUR_MAX_ROWS=100
KONTUR_FETCH_DETAILS=true
KONTUR_FETCH_DOCUMENTS=true
KONTUR_FILTER_ALUMINIUM=true
KONTUR_SEARCH_QUERY=алюминий
KONTUR_SEARCH_QUERY_FIELD=query
KONTUR_LIMIT_FIELD=limit
KONTUR_SEARCH_PAYLOAD={}
```

Если API использует сложный объект фильтра, задайте его через `KONTUR_SEARCH_PAYLOAD`, например JSON.
Поля `KONTUR_SEARCH_QUERY_FIELD` и `KONTUR_LIMIT_FIELD` позволяют не менять код при отличающихся именах параметров.

## Проверка после настройки

```bash
docker compose up -d --build app celery_worker celery_beat
curl http://localhost:8000/sources
curl -X POST http://localhost:8000/sources/trigger \
  -H 'Content-Type: application/json' \
  -d '{"source_key":"kontur_zakupki"}'

docker compose logs -f celery_worker
```

Проверка URL-карточки:

```bash
curl -X POST http://localhost:8000/tenders/analyze-url \
  -H 'Content-Type: application/json' \
  -d '{"url":"https://zakupki.kontur.ru/ID_ЗАКУПКИ","source":"auto"}'
```

## Безопасность

Не помещайте `KONTUR_API_KEY` в Python, README, `.env.example` или GitHub Actions logs.
`.env` должен оставаться локальным на сервере и иметь права `chmod 600 .env`.
