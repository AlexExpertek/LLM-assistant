"""Контур.Закупки -> canonical SourceTender adapter."""
from __future__ import annotations

import re
from datetime import datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable
from urllib.parse import urlparse

from app.core.config import settings
from app.core.logging import get_logger
from app.sources.base import TenderSourceAdapter
from app.sources.kontur_zakupki.client import KonturZakupkiClient
from app.sources.schemas import SourceDocument, SourceTender

logger = get_logger(__name__)

ALUMINIUM_KEYWORDS = (
    "алюмин", "aluminium", "aluminum", "амг", "ад31", "ад0", "ад1", "а5", "а5е",
    "д16", "1561", "5083", "5754", "5251", "6060", "6063", "6082",
    "алюминиевая лента", "алюминиевый лист", "алюминиевый профиль",
    "алюминиевая труба", "алюминиевая шина", "алюминиевая фольга",
)


def _first(data: dict[str, Any], *paths: str, default=None):
    for path in paths:
        cur: Any = data
        ok = True
        for part in path.split("."):
            if isinstance(cur, dict) and part in cur:
                cur = cur[part]
            else:
                ok = False
                break
        if ok and cur not in (None, ""):
            return cur
    return default


def _as_decimal(value: Any) -> Decimal | None:
    if value in (None, ""):
        return None
    if isinstance(value, Decimal):
        return value
    if isinstance(value, (int, float)):
        return Decimal(str(value))
    text = str(value).replace("\xa0", " ").replace(" ", "").replace(",", ".")
    text = re.sub(r"[^0-9.\-]", "", text)
    try:
        return Decimal(text) if text else None
    except InvalidOperation:
        return None


def _as_datetime(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value
    text = str(value).strip()
    for normalized in (text, text.replace("Z", "+00:00")):
        try:
            return datetime.fromisoformat(normalized)
        except ValueError:
            pass
    for fmt in ("%d.%m.%Y %H:%M", "%d.%m.%Y", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            pass
    return None


def _items(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if not isinstance(payload, dict):
        return []
    for key in ("items", "purchases", "results", "data", "tenders"):
        value = payload.get(key)
        if isinstance(value, list):
            return [x for x in value if isinstance(x, dict)]
        if isinstance(value, dict):
            nested = _items(value)
            if nested:
                return nested
    return []


def _law_type(value: Any) -> str | None:
    text = str(value or "").lower()
    if "44" in text:
        return "44-FZ"
    if "223" in text:
        return "223-FZ"
    if any(x in text for x in ("commercial", "коммерч")):
        return "commercial"
    return None


def _documents_from_payload(payload: Any) -> list[SourceDocument]:
    docs: list[SourceDocument] = []
    seen: set[str] = set()

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            url = _first(node, "url", "downloadUrl", "download_url", "href", "link", "fileUrl")
            name = _first(node, "name", "fileName", "filename", "title", "caption")
            content_type = _first(node, "contentType", "content_type", "mimeType", "mime_type")
            if isinstance(url, str) and url.startswith(("http://", "https://")):
                key = url
                if key not in seen:
                    seen.add(key)
                    docs.append(SourceDocument(
                        external_id=str(_first(node, "id", "documentId", "fileId") or "") or None,
                        name=str(name or url.rsplit("/", 1)[-1] or "document"),
                        url=url,
                        content_type=str(content_type) if content_type else None,
                    ))
            for key, value in node.items():
                if key.lower() in {"documents", "docs", "files", "attachments", "documentation", "data"}:
                    walk(value)
        elif isinstance(node, list):
            for value in node:
                walk(value)

    walk(payload)
    return docs


def _looks_aluminium(data: dict[str, Any]) -> bool:
    text_parts: list[str] = []
    for key in ("title", "name", "description", "subject", "object", "summary"):
        value = data.get(key)
        if value:
            text_parts.append(str(value))
    # Include nested procurement objects/doc names when returned by details.
    for key in ("objects", "positions", "items", "products", "documents", "files"):
        value = data.get(key)
        if value:
            text_parts.append(str(value))
    haystack = " ".join(text_parts).lower()
    return any(word in haystack for word in ALUMINIUM_KEYWORDS)


class KonturZakupkiAdapter(TenderSourceAdapter):
    source_code = "kontur_zakupki"

    def __init__(self, client: KonturZakupkiClient | None = None) -> None:
        self.client = client or KonturZakupkiClient()

    def _search_payload(self) -> dict[str, Any]:
        # The API licence may expose slightly different filter fields. Keep the
        # configured JSON untouched and only add a safe result limit when absent.
        payload = dict(settings.kontur_search_payload)
        if settings.kontur_search_query and not payload:
            payload[settings.kontur_search_query_field] = settings.kontur_search_query
        if settings.kontur_max_rows > 0 and settings.kontur_limit_field not in payload:
            payload[settings.kontur_limit_field] = settings.kontur_max_rows
        return payload

    def search(self) -> list[SourceTender]:
        response = self.client.search(self._search_payload())
        summaries = _items(response)
        result: list[SourceTender] = []
        seen: set[str] = set()

        for summary in summaries:
            purchase_id = str(_first(summary, "id", "purchaseId", "purchase_id", "tenderId", "number") or "").strip()
            if not purchase_id or purchase_id in seen:
                continue
            seen.add(purchase_id)

            detail = summary
            if settings.kontur_fetch_details:
                try:
                    fetched = self.client.get_purchase(purchase_id)
                    if isinstance(fetched, dict):
                        detail = {**summary, **fetched}
                except Exception as exc:
                    logger.warning("kontur_details_failed", purchase_id=purchase_id, error=str(exc))

            if settings.kontur_filter_aluminium and not _looks_aluminium(detail):
                continue
            result.append(self._map(detail, purchase_id))

        return result

    def _map(self, data: dict[str, Any], purchase_id: str | None = None) -> SourceTender:
        pid = purchase_id or str(_first(data, "id", "purchaseId", "purchase_id", "tenderId", "number") or "").strip()
        if not pid:
            raise ValueError("Kontur purchase has no id")

        title = str(_first(data, "title", "name", "subject", "purchaseName", default=f"Закупка {pid}"))
        customer_name = _first(data, "customer.name", "customerName", "organization.name", "buyer.name", "customer")
        if isinstance(customer_name, dict):
            customer_name = _first(customer_name, "name", "fullName")
        customer_inn = _first(data, "customer.inn", "customerInn", "organization.inn", "buyer.inn")

        docs = _documents_from_payload(data)
        if settings.kontur_fetch_documents:
            try:
                extra = self.client.get_documents(pid)
                docs.extend(_documents_from_payload(extra))
            except Exception as exc:
                logger.warning("kontur_documents_failed", purchase_id=pid, error=str(exc))
        # deterministic dedupe
        unique_docs: dict[str, SourceDocument] = {}
        for doc in docs:
            unique_docs[doc.url or f"{doc.external_id}:{doc.name}"] = doc

        public_url = _first(data, "url", "purchaseUrl", "webUrl", "sourceUrl")
        if not public_url:
            public_url = f"https://zakupki.kontur.ru/{pid}"

        raw_law = _first(data, "law", "lawType", "purchaseType", "type", "regulation")
        return SourceTender(
            source=self.source_code,
            external_id=pid,
            title=title,
            description=_first(data, "description", "summary", "objectDescription", "purchaseDescription"),
            customer_name=str(customer_name) if customer_name else None,
            customer_inn=str(customer_inn) if customer_inn else None,
            law_type=_law_type(raw_law),
            procurement_method=_first(data, "procurementMethod", "method", "procedureType", "purchaseMethod"),
            amount=_as_decimal(_first(data, "amount", "maxPrice", "initialPrice", "price", "nmck")),
            currency=str(_first(data, "currency", "currencyCode", default="RUB")),
            region=_first(data, "region.name", "region", "deliveryRegion", "customer.region"),
            delivery_place=_first(data, "deliveryPlace", "deliveryAddress", "placeOfDelivery"),
            publish_date=_as_datetime(_first(data, "publishDate", "publishedAt", "publicationDate", "datePublished")),
            submission_deadline=_as_datetime(_first(data, "submissionDeadline", "deadline", "applicationEndDate", "endDate")),
            source_url=str(public_url),
            documents=list(unique_docs.values()),
            raw_payload=data,
        )

    def fetch_by_id(self, external_id: str) -> SourceTender | None:
        data = self.client.get_purchase(external_id)
        if not isinstance(data, dict):
            return None
        return self._map(data, external_id)

    def fetch_by_url(self, url: str) -> SourceTender | None:
        host = (urlparse(url).hostname or "").lower()
        if "zakupki.kontur.ru" not in host:
            return None
        path = urlparse(url).path.strip("/")
        if not path:
            return None
        # Public Kontur URLs may contain prefixed IDs (e.g. IS..., RQ...) as well as procurement numbers.
        external_id = path.split("/", 1)[0]
        return self.fetch_by_id(external_id)
