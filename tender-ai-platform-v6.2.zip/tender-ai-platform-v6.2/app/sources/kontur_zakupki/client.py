"""HTTP client for Контур.Закупки API.

The exact host/auth header and endpoint paths are contract-dependent and therefore
are configured through environment variables. This prevents hard-coding an API
shape that may differ between API licences (Search / Purchase details).
"""
from __future__ import annotations

from typing import Any
from urllib.parse import urljoin

import httpx

from app.core.config import settings


class KonturConfigurationError(RuntimeError):
    pass


class KonturApiError(RuntimeError):
    pass


class KonturZakupkiClient:
    def __init__(self) -> None:
        self.base_url = settings.kontur_api_base_url.rstrip("/")
        self.api_key = settings.kontur_api_key.strip()
        self.timeout = settings.kontur_request_timeout

    def _require_config(self) -> None:
        if not self.base_url:
            raise KonturConfigurationError(
                "KONTUR_API_BASE_URL is not configured. Use the API host supplied with your Контур.Закупки licence."
            )
        if not self.api_key:
            raise KonturConfigurationError(
                "KONTUR_API_KEY is not configured. Put the developer key in .env, never in source code."
            )

    def _url(self, path: str) -> str:
        if not path:
            raise KonturConfigurationError("Kontur API endpoint path is empty")
        return urljoin(self.base_url + "/", path.lstrip("/"))

    def _auth(self) -> tuple[dict[str, str], dict[str, str]]:
        """Return (headers, query params) according to env-configured auth mode."""
        headers = {"Accept": "application/json"}
        params: dict[str, str] = {}

        if settings.kontur_api_key_header:
            value = self.api_key
            if settings.kontur_api_key_prefix:
                value = f"{settings.kontur_api_key_prefix} {value}".strip()
            headers[settings.kontur_api_key_header] = value
        elif settings.kontur_api_key_query_param:
            params[settings.kontur_api_key_query_param] = self.api_key
        else:
            raise KonturConfigurationError(
                "Configure KONTUR_API_KEY_HEADER or KONTUR_API_KEY_QUERY_PARAM according to your Kontur API documentation."
            )
        return headers, params

    def _request(self, method: str, path: str, *, params: dict[str, Any] | None = None,
                 json_body: dict[str, Any] | None = None) -> Any:
        self._require_config()
        headers, auth_params = self._auth()
        merged_params = dict(auth_params)
        if params:
            merged_params.update({k: v for k, v in params.items() if v is not None})

        try:
            with httpx.Client(timeout=self.timeout, follow_redirects=True) as client:
                response = client.request(
                    method.upper(),
                    self._url(path),
                    headers=headers,
                    params=merged_params,
                    json=json_body,
                )
                response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            body = exc.response.text[:1000]
            raise KonturApiError(
                f"Kontur API HTTP {exc.response.status_code}: {body}"
            ) from exc
        except httpx.HTTPError as exc:
            raise KonturApiError(f"Kontur API transport error: {exc}") from exc

        if not response.content:
            return None
        try:
            return response.json()
        except ValueError as exc:
            raise KonturApiError("Kontur API returned a non-JSON response") from exc

    def search(self, payload: dict[str, Any]) -> Any:
        method = settings.kontur_search_method.upper()
        if method == "POST":
            return self._request("POST", settings.kontur_search_path, json_body=payload)
        return self._request("GET", settings.kontur_search_path, params=payload)

    def get_purchase(self, purchase_id: str) -> Any:
        path = settings.kontur_purchase_path.format(id=purchase_id)
        return self._request("GET", path)

    def get_documents(self, purchase_id: str) -> Any:
        if not settings.kontur_documents_path:
            return None
        path = settings.kontur_documents_path.format(id=purchase_id)
        return self._request("GET", path)
