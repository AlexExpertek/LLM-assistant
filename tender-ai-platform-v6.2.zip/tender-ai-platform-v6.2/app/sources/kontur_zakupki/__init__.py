"""Контур.Закупки source adapter."""

from app.sources.kontur_zakupki.adapter import KonturZakupkiAdapter

__all__ = ["KonturZakupkiAdapter"]
