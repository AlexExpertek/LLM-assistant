import re

from app.parsers import zakupki_gov as legacy
from app.sources.base import TenderSourceAdapter
from app.sources.schemas import SourceDocument, SourceTender


class ZakupkiGovAdapter(TenderSourceAdapter):
    source_code = "zakupki_gov_ru"

    @staticmethod
    def _map(data: dict) -> SourceTender:
        docs = []
        for raw in data.get("document_urls", []):
            if raw.startswith("__archive__") and "#" in raw:
                archive_url, member = raw[len("__archive__"):].split("#", 1)
                docs.append(SourceDocument(
                    name=member,
                    download_type="archive_member",
                    archive_url=archive_url,
                    archive_member=member,
                ))
            else:
                docs.append(SourceDocument(name=raw.rsplit("/", 1)[-1] or "document", url=raw))
        return SourceTender(
            source=self_or(data.get("source"), "zakupki_gov_ru"),
            external_id=str(data["external_id"]),
            title=data.get("title") or f"Закупка {data['external_id']}",
            customer_name=data.get("customer_name"),
            customer_inn=data.get("customer_inn"),
            law_type=data.get("law_type"),
            amount=data.get("amount"),
            region=data.get("region"),
            source_url=data.get("source_url"),
            submission_deadline=data.get("submission_deadline"),
            documents=docs,
            raw_payload=data.get("_raw", {}),
        )

    def search(self) -> list[SourceTender]:
        return [self._map(x) for x in legacy.fetch_new_tenders()]

    def fetch_by_id(self, external_id: str) -> SourceTender | None:
        data = legacy.fetch_tender_by_number(external_id)
        return self._map(data) if data else None

    def fetch_by_url(self, url: str) -> SourceTender | None:
        match = re.search(r"regNumber=(\d+)", url)
        if not match:
            match = re.search(r"(\d{19,})", url)
        return self.fetch_by_id(match.group(1)) if match else None


def self_or(value, fallback):
    return value or fallback
