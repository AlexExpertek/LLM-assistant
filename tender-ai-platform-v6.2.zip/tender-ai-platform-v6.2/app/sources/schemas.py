from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any, Literal

from pydantic import BaseModel, Field


class SourceDocument(BaseModel):
    """Document reference returned by any tender source adapter."""
    external_id: str | None = None
    name: str
    url: str | None = None
    content_type: str | None = None
    download_type: Literal["url", "archive_member", "local_file"] = "url"
    archive_url: str | None = None
    archive_member: str | None = None
    local_path: str | None = None


class SourceTender(BaseModel):
    """Canonical source-neutral tender contract."""
    source: str
    external_id: str
    title: str
    description: str | None = None
    customer_name: str | None = None
    customer_inn: str | None = None
    law_type: str | None = None
    procurement_method: str | None = None
    amount: Decimal | None = None
    currency: str = "RUB"
    region: str | None = None
    delivery_place: str | None = None
    publish_date: datetime | None = None
    submission_deadline: datetime | None = None
    source_url: str | None = None
    documents: list[SourceDocument] = Field(default_factory=list)
    raw_payload: dict[str, Any] = Field(default_factory=dict)
