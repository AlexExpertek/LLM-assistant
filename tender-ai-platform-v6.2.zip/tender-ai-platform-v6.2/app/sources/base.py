from __future__ import annotations

from abc import ABC, abstractmethod

from app.sources.schemas import SourceTender


class TenderSourceAdapter(ABC):
    source_code: str

    @abstractmethod
    def search(self) -> list[SourceTender]:
        raise NotImplementedError

    def fetch_by_url(self, url: str) -> SourceTender | None:
        return None

    def fetch_by_id(self, external_id: str) -> SourceTender | None:
        return None
