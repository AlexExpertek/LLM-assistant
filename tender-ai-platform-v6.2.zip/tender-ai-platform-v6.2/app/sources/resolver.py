from urllib.parse import urlparse

from app.sources.registry import get_adapter


def resolve_source_by_url(url: str) -> str | None:
    host = (urlparse(url).hostname or "").lower()
    if "zakupki.gov.ru" in host:
        return "zakupki_gov_ru"
    if "tender.pro" in host:
        return "tender_pro"
    if "zakupki.kontur.ru" in host:
        return "kontur_zakupki"
    return None


def fetch_tender_from_url(url: str, source_hint: str | None = None):
    source = source_hint or resolve_source_by_url(url)
    if not source:
        return None
    adapter = get_adapter(source)
    if not adapter:
        return None
    return adapter.fetch_by_url(url)
