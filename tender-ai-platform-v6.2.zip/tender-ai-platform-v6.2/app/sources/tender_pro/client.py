"""HTTP client for the official Tender.Pro public integration API.

Official references:
- https://help.tender.pro/vigruzka_lenti_procedur.html
- https://www.tender.pro/api/docs/smd

The API key is supplied only through TENDER_PRO_API_KEY.
"""
from __future__ import annotations

from typing import Any

import httpx

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

BASE_URL = "https://www.tender.pro/api"


class TenderProAPIError(RuntimeError):
    pass


class TenderProClient:
    """Small, defensive client around documented Tender.Pro JSON methods."""

    def __init__(self, api_key: str | None = None, timeout: float | None = None):
        self.api_key = api_key or settings.tender_pro_api_key
        self.timeout = timeout or settings.tender_pro_request_timeout

    def _get(self, method: str, **params: Any) -> Any:
        if not self.api_key:
            raise TenderProAPIError("TENDER_PRO_API_KEY is not configured")

        query = {k: v for k, v in params.items() if v is not None}
        query["_key"] = self.api_key
        url = f"{BASE_URL}/{method}.json"

        try:
            with httpx.Client(
                timeout=self.timeout,
                follow_redirects=True,
                headers={"Accept": "application/json", "User-Agent": "TenderAIPlatform/6.1"},
            ) as client:
                response = client.get(url, params=query)
                response.raise_for_status()
                payload = response.json()
        except httpx.HTTPStatusError as exc:
            status = exc.response.status_code if exc.response is not None else None
            logger.error("tender_pro_http_status", method=method, status=status)
            raise TenderProAPIError(f"Tender.Pro {method}: HTTP {status}") from exc
        except (httpx.HTTPError, ValueError) as exc:
            logger.error("tender_pro_request_failed", method=method, error=str(exc))
            raise TenderProAPIError(f"Tender.Pro {method}: {exc}") from exc

        # Some Tender.Pro methods may wrap successful data in result/data.
        if isinstance(payload, dict):
            # Do not silently swallow a clearly reported API error.
            error = payload.get("error") or payload.get("err")
            if error and not payload.get("result") and not payload.get("data"):
                raise TenderProAPIError(f"Tender.Pro {method}: {error}")
        return payload

    @staticmethod
    def unwrap_list(payload: Any) -> list[dict[str, Any]]:
        if isinstance(payload, list):
            return [x for x in payload if isinstance(x, dict)]
        if not isinstance(payload, dict):
            return []

        for key in ("result", "tenders", "data", "rows", "items"):
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
            if isinstance(value, dict):
                for nested_key in ("rows", "items", "tenders", "data"):
                    nested = value.get(nested_key)
                    if isinstance(nested, list):
                        return [x for x in nested if isinstance(x, dict)]
        return []

    @staticmethod
    def unwrap_object(payload: Any) -> dict[str, Any]:
        if not isinstance(payload, dict):
            return {}
        for key in ("result", "data", "tender"):
            value = payload.get(key)
            if isinstance(value, dict):
                return value
        return payload

    def list_tenders(self, max_rows: int | None = None, open_only: bool | None = None) -> list[dict[str, Any]]:
        """Return the common procedures feed.

        Tender.Pro documents set_type_id=2 as "all procedures" and states that
        set_id is ignored for this mode. Therefore v6.1 intentionally does not
        send the old hard-coded set_id=7964.
        """
        payload = self._get(
            "_info.tenderlist_by_set",
            set_type_id=2,
            max_rows=max_rows or settings.tender_pro_max_rows,
            open_only="t" if (settings.tender_pro_open_only if open_only is None else open_only) else "f",
        )
        return self.unwrap_list(payload)

    def tender_info(self, tender_id: str | int, company_id: str | int) -> dict[str, Any]:
        """Return documented tender details by tender id + company id."""
        payload = self._get("_tender.info", id=tender_id, company_id=company_id)
        return self.unwrap_object(payload)
