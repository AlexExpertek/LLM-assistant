"""Tender.Pro source adapter using the official integration API."""
from __future__ import annotations

import re
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import PurePosixPath
from typing import Any, Iterable
from urllib.parse import urlparse

from app.core.config import settings
from app.core.logging import get_logger
from app.sources.base import TenderSourceAdapter
from app.sources.schemas import SourceDocument, SourceTender
from app.sources.tender_pro.client import TenderProAPIError, TenderProClient

logger = get_logger(__name__)

PUBLIC_TENDER_URL = "https://www.tender.pro/api/tender/{id}/view_public"

KEYWORDS = (
    "алюминиев", "алюминий", "aluminium", "aluminum",
    "лента алюм", "лист алюм", "профиль алюм", "труба алюм",
    "пруток алюм", "шина алюм", "фольга алюм", "прокат цветн",
    "цветной металл", "металлопрокат",
    "а5", "а5е", "ад0", "ад1", "ад31", "амг2", "амг3", "амг5", "амг6", "д16",
)

_DOCUMENT_EXTENSIONS = {
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".xlsb", ".rtf", ".txt",
    ".csv", ".zip", ".rar", ".7z", ".tar", ".gz", ".tgz", ".jpg", ".jpeg", ".png",
}
_URL_KEYS = {"url", "href", "file_url", "download_url", "link", "src"}
_NAME_KEYS = {"name", "filename", "file_name", "title", "caption"}


def _first(data: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        value = data.get(key)
        if value not in (None, ""):
            return value
    return None


def _as_decimal(value: Any) -> Decimal | None:
    if value in (None, ""):
        return None
    if isinstance(value, Decimal):
        return value
    text = str(value).strip().replace("\xa0", "").replace(" ", "").replace(",", ".")
    # Preserve only numeric sign/decimal characters for common formatted prices.
    text = re.sub(r"[^0-9.\-]", "", text)
    if not text:
        return None
    try:
        return Decimal(text)
    except InvalidOperation:
        return None


def _as_datetime(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value
    text = str(value).strip()
    candidates = (
        text.replace("Z", "+00:00"),
        text,
    )
    for candidate in candidates:
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            pass
    for fmt in ("%d.%m.%Y %H:%M", "%d.%m.%Y", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    return None


def _stringify_for_filter(value: Any, depth: int = 0) -> str:
    if depth > 4:
        return ""
    if isinstance(value, dict):
        return " ".join(_stringify_for_filter(v, depth + 1) for v in value.values())
    if isinstance(value, list):
        return " ".join(_stringify_for_filter(v, depth + 1) for v in value)
    if isinstance(value, (str, int, float, Decimal)):
        return str(value)
    return ""


def _matches_keywords(*objects: Any) -> bool:
    text = " ".join(_stringify_for_filter(o) for o in objects).lower().replace("ё", "е")
    return any(keyword in text for keyword in KEYWORDS)


def _looks_like_document_url(url: str) -> bool:
    try:
        path = urlparse(url).path.lower()
    except ValueError:
        return False
    suffix = PurePosixPath(path).suffix
    return suffix in _DOCUMENT_EXTENSIONS or any(token in path for token in ("download", "file", "document", "attach"))


def _extract_documents(payload: Any) -> list[SourceDocument]:
    """Extract document references from the documented detail payload defensively.

    The public help confirms that attached files can be part of integration, but
    does not name a separate public file-list method on the referenced page.
    We therefore derive downloadable references from `_tender.info` instead of
    relying on the previously hard-coded, unverified `_tender.files` call.
    """
    found: dict[str, SourceDocument] = {}

    def walk(node: Any, depth: int = 0) -> None:
        if depth > 7:
            return
        if isinstance(node, list):
            for item in node:
                walk(item, depth + 1)
            return
        if not isinstance(node, dict):
            return

        url = None
        name = None
        external_id = None
        for key, value in node.items():
            lk = str(key).lower()
            if lk in _URL_KEYS and isinstance(value, str) and value.startswith(("http://", "https://")):
                if _looks_like_document_url(value):
                    url = value
            elif lk in _NAME_KEYS and isinstance(value, str):
                name = value
            elif lk in {"id", "file_id", "document_id", "attachment_id"} and value not in (None, ""):
                external_id = str(value)

        if url:
            fallback_name = PurePosixPath(urlparse(url).path).name or "document"
            found[url] = SourceDocument(
                external_id=external_id,
                name=name or fallback_name,
                url=url,
                download_type="url",
            )

        for value in node.values():
            walk(value, depth + 1)

    walk(payload)
    return list(found.values())


def _extract_company_id(item: dict[str, Any]) -> str | None:
    value = _first(item, "company_id", "companyid", "organizer_id", "organizer_company_id")
    if value not in (None, ""):
        return str(value)
    company = item.get("company") or item.get("organizer")
    if isinstance(company, dict):
        value = _first(company, "id", "company_id")
        return str(value) if value not in (None, "") else None
    return None


def _extract_tender_id(item: dict[str, Any]) -> str | None:
    value = _first(item, "id", "tender_id", "tenderid", "contest_id")
    return str(value) if value not in (None, "") else None


class TenderProAdapter(TenderSourceAdapter):
    source_code = "tender_pro"

    def __init__(self, client: TenderProClient | None = None):
        self.client = client or TenderProClient()

    @staticmethod
    def _map(list_item: dict[str, Any], detail: dict[str, Any] | None = None) -> SourceTender:
        detail = detail or {}
        merged = {**list_item, **detail}
        tender_id = _extract_tender_id(merged) or _extract_tender_id(list_item)
        if not tender_id:
            raise ValueError("Tender.Pro record has no tender id")

        title = str(_first(merged, "name", "title", "subject", "tender_name") or f"Tender.Pro {tender_id}")
        description = _first(merged, "description", "comment", "comments", "note")

        organizer = merged.get("organizer") or merged.get("company")
        organizer_name = None
        organizer_inn = None
        if isinstance(organizer, dict):
            organizer_name = _first(organizer, "name", "company_name", "short_name")
            organizer_inn = _first(organizer, "inn", "tax_id")
        elif isinstance(organizer, str):
            organizer_name = organizer

        amount = _as_decimal(_first(merged, "start_price", "price", "amount", "sum", "total_price"))
        publish_date = _as_datetime(_first(merged, "open_date", "date_open", "publish_date", "date_create", "created_at"))
        deadline = _as_datetime(_first(merged, "date_close", "close_date", "end_date", "date_end", "submission_deadline"))

        currency = str(_first(merged, "currency", "currency_code", "currency_name") or "RUB").upper()
        region = _first(merged, "region", "region_name")
        delivery_place = _first(merged, "delivery_address", "delivery_place", "place_delivery")

        return SourceTender(
            source="tender_pro",
            external_id=tender_id,
            title=title,
            description=str(description) if description not in (None, "") else None,
            customer_name=str(_first(merged, "company_name", "customer_name") or organizer_name or "") or None,
            customer_inn=str(_first(merged, "inn", "customer_inn") or organizer_inn or "") or None,
            law_type="commercial",
            procurement_method=str(_first(merged, "tender_type", "procedure_type", "type_name") or "") or None,
            amount=amount,
            currency=currency,
            region=str(region) if region not in (None, "") else None,
            delivery_place=str(delivery_place) if delivery_place not in (None, "") else None,
            publish_date=publish_date,
            submission_deadline=deadline,
            source_url=PUBLIC_TENDER_URL.format(id=tender_id),
            documents=_extract_documents(detail),
            raw_payload={"list": list_item, "detail": detail},
        )

    def search(self) -> list[SourceTender]:
        logger.info("tender_pro_fetch_started", max_rows=settings.tender_pro_max_rows)
        items = self.client.list_tenders()
        results: list[SourceTender] = []
        skipped = 0
        detail_errors = 0

        for item in items:
            tender_id = _extract_tender_id(item)
            company_id = _extract_company_id(item)
            if not tender_id:
                skipped += 1
                continue

            detail: dict[str, Any] = {}
            if settings.tender_pro_fetch_details and company_id:
                try:
                    detail = self.client.tender_info(tender_id, company_id)
                except TenderProAPIError as exc:
                    detail_errors += 1
                    logger.warning("tender_pro_detail_failed", tender_id=tender_id, error=str(exc))

            # Filter after detail enrichment so goods/comments/doc names can match too.
            if not _matches_keywords(item, detail):
                skipped += 1
                continue

            try:
                results.append(self._map(item, detail))
            except Exception as exc:
                skipped += 1
                logger.warning("tender_pro_mapping_failed", tender_id=tender_id, error=str(exc))

        logger.info(
            "tender_pro_fetch_done",
            total=len(items),
            accepted=len(results),
            skipped=skipped,
            detail_errors=detail_errors,
        )
        return results

    def fetch_by_id(self, external_id: str) -> SourceTender | None:
        # `_tender.info` needs company_id, so resolve it from the common feed.
        external_id = str(external_id)
        for item in self.client.list_tenders():
            if _extract_tender_id(item) != external_id:
                continue
            company_id = _extract_company_id(item)
            detail = {}
            if company_id:
                try:
                    detail = self.client.tender_info(external_id, company_id)
                except TenderProAPIError as exc:
                    logger.warning("tender_pro_detail_failed", tender_id=external_id, error=str(exc))
            return self._map(item, detail)
        return None

    def fetch_by_url(self, url: str) -> SourceTender | None:
        patterns: Iterable[str] = (
            r"/api/tender/(\d+)/view_public",
            r"[?&]tenderid=(\d+)",
            r"/procedure/(\d+)",  # backward compatibility with old stored links
        )
        for pattern in patterns:
            match = re.search(pattern, url, flags=re.IGNORECASE)
            if match:
                return self.fetch_by_id(match.group(1))
        return None
