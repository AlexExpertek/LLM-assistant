"""Unified report: one row per tender item, independent of source platform."""
from io import BytesIO
from sqlalchemy import select
from sqlalchemy.orm import joinedload

from app.core.logging import get_logger
from app.db.session import SyncSessionLocal
from app.models.database import Lot, Tender, TenderStatus

logger = get_logger(__name__)
REPORT_STATUSES = {TenderStatus.CAN_APPLY, TenderStatus.NEEDS_CLARIFICATION, TenderStatus.MANUAL_REVIEW}


def get_active_tenders() -> list[dict]:
    try:
        with SyncSessionLocal() as session:
            stmt = (select(Tender)
                    .where(Tender.is_active.is_(True), Tender.analysis_done.is_(True), Tender.status.in_(REPORT_STATUSES))
                    .options(joinedload(Tender.lots).joinedload(Lot.items), joinedload(Tender.decisions))
                    .order_by(Tender.score.desc()))
            tenders = session.execute(stmt).unique().scalars().all()
            rows = []
            for t in tenders:
                decision = max(t.decisions, key=lambda x: x.created_at) if t.decisions else None
                lots = t.lots or [None]
                for lot in lots:
                    items = lot.items if lot and lot.items else [None]
                    for item in items:
                        rows.append({
                            "id": str(t.id), "external_id": t.external_id, "source": t.source,
                            "title": t.title, "customer_name": t.customer_name or "", "customer_inn": t.customer_inn or "",
                            "law_type": t.law_type.value if t.law_type else "", "status": t.status.value if t.status else "",
                            "score": t.score or 0, "amount": float(t.amount) if t.amount else None,
                            "currency": t.currency or "RUB", "region": t.region or "", "source_url": t.source_url or "",
                            "submission_deadline": t.submission_deadline.strftime("%d.%m.%Y %H:%M") if t.submission_deadline else "",
                            "lot_number": lot.lot_number if lot else "", "position_number": item.position_number if item else "",
                            "product_name": item.name if item else "", "product_type": item.product_type if item else "",
                            "alloy": item.alloy if item else "", "temper": item.temper if item else "",
                            "thickness_mm": item.thickness_mm if item else None, "width_mm": item.width_mm if item else None,
                            "length_mm": item.length_mm if item else None, "diameter_mm": item.diameter_mm if item else None,
                            "quantity": item.quantity if item else None, "unit": item.unit if item else "",
                            "mass_kg": item.mass_kg if item else None, "standard": item.standard if item else "",
                            "delivery_place": (item.delivery_place if item else None) or (lot.delivery_place if lot else None) or t.delivery_place or "",
                            "delivery_term": item.delivery_term if item else "", "payment_terms": item.payment_terms if item else "",
                            "can_supply": item.can_supply if item else None, "supply_reason": item.supply_reason if item else "",
                            "reasons": decision.reasons if decision else [], "risks": decision.risks if decision else [],
                            "model_version": decision.model_version if decision else t.analysis_version or "",
                        })
            return rows
    except Exception as exc:
        logger.error("get_active_tenders_failed", error=str(exc)); return []


def get_all_tenders_stats() -> dict:
    try:
        with SyncSessionLocal() as session:
            all_tenders = session.execute(select(Tender)).scalars().all()
            return {"total": len(all_tenders), "active": sum(bool(t.is_active) for t in all_tenders),
                    "analyzed": sum(bool(t.analysis_done) for t in all_tenders),
                    "can_apply": sum(t.status == TenderStatus.CAN_APPLY for t in all_tenders),
                    "manual_review": sum(t.status in (TenderStatus.MANUAL_REVIEW, TenderStatus.NEEDS_CLARIFICATION) for t in all_tenders),
                    "not_analyzed_yet": sum(not t.analysis_done for t in all_tenders)}
    except Exception as exc:
        logger.error("get_stats_failed", error=str(exc)); return {}


def generate_excel_report(tenders: list[dict]) -> bytes:
    import openpyxl
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Тендерные позиции"
    headers = ["№", "Источник", "Внешний ID", "44/223/коммерч.", "Заказчик", "ИНН", "Предмет закупки",
               "Лот", "Позиция", "Наименование", "Тип продукции", "Сплав", "Состояние", "Толщина, мм", "Ширина, мм",
               "Длина, мм", "Диаметр, мм", "Количество", "Ед.", "Масса, кг", "ГОСТ/ТУ", "НМЦК", "Валюта",
               "Место поставки", "Срок поставки", "Условия оплаты", "Регион", "Можем поставить", "Причина по позиции",
               "Статус ИИ", "Балл", "Срок подачи", "Ссылка", "Причины решения", "Риски", "Версия анализа"]
    fill=PatternFill("solid", fgColor="1F4E79"); font=Font(color="FFFFFF", bold=True)
    for c,h in enumerate(headers,1):
        cell=ws.cell(1,c,h); cell.fill=fill; cell.font=font; cell.alignment=Alignment(horizontal="center",wrap_text=True)
    for i,t in enumerate(tenders,1):
        values=[i,t.get("source"),t.get("external_id"),t.get("law_type"),t.get("customer_name"),t.get("customer_inn"),t.get("title"),
                t.get("lot_number"),t.get("position_number"),t.get("product_name"),t.get("product_type"),t.get("alloy"),t.get("temper"),
                t.get("thickness_mm"),t.get("width_mm"),t.get("length_mm"),t.get("diameter_mm"),t.get("quantity"),t.get("unit"),t.get("mass_kg"),
                t.get("standard"),t.get("amount"),t.get("currency"),t.get("delivery_place"),t.get("delivery_term"),t.get("payment_terms"),t.get("region"),
                "Да" if t.get("can_supply") is True else "Нет" if t.get("can_supply") is False else "Уточнить", t.get("supply_reason"),
                t.get("status"),t.get("score"),t.get("submission_deadline"),t.get("source_url"),"; ".join(t.get("reasons") or []),
                "; ".join(t.get("risks") or []),t.get("model_version")]
        for c,v in enumerate(values,1): ws.cell(i+1,c,v)
    ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
    for c in range(1,len(headers)+1): ws.column_dimensions[get_column_letter(c)].width=min(max(12,len(headers[c-1])+2),32)
    out=BytesIO(); wb.save(out); return out.getvalue()


def format_report_text(tenders: list[dict]) -> str:
    if not tenders: return "Активных проанализированных тендеров нет."
    unique=len({t["id"] for t in tenders})
    return f"Активных тендеров: {unique}; товарных позиций в едином отчёте: {len(tenders)}."


# Backward-compatible name used by tasks_reports.py
format_report_summary = format_report_text
