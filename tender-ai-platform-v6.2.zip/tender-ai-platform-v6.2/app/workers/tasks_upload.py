"""Manual upload now enters the same canonical ingestion pipeline as external sources."""
from app.sources.schemas import SourceDocument, SourceTender
from app.workers.celery_app import celery_app


@celery_app.task(name="app.workers.tasks_upload.process_uploaded_tender")
def process_uploaded_tender(tender_data: dict, file_path: str):
    source = SourceTender(
        source=tender_data.get("source") or "manual_upload",
        external_id=tender_data["external_id"],
        title=tender_data.get("title") or "Ручная загрузка",
        source_url=tender_data.get("source_url"),
        documents=[SourceDocument(
            name=tender_data.get("filename") or file_path.rsplit("/", 1)[-1],
            download_type="local_file",
            local_path=file_path,
        )],
        raw_payload={"upload_id": tender_data.get("upload_id")},
    )
    from app.workers.tasks_parsing import process_new_tender
    process_new_tender.delay(source.model_dump(mode="json"))
    return {"status": "queued_to_canonical_pipeline", "external_id": source.external_id}
