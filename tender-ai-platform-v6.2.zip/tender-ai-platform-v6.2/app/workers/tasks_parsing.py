"""Source-neutral tender ingestion and source monitoring for v6."""
import hashlib
import json
from datetime import datetime, timezone

from sqlalchemy import select, update

from app.core.config import settings
from app.core.logging import get_logger
from app.db.session import SyncSessionLocal
from app.models.database import LawType, ProcessingStatus, Tender, TenderStatus
from app.sources.registry import get_adapter
from app.sources.schemas import SourceTender
from app.workers.celery_app import celery_app

logger = get_logger(__name__)


def _enum_law(value: str | None) -> LawType:
    mapping = {"44-FZ": LawType.FZ_44, "223-FZ": LawType.FZ_223, "commercial": LawType.COMMERCIAL}
    return mapping.get(value or "", LawType.OTHER)


def _dt(value):
    if value is None or isinstance(value, datetime):
        return value
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).replace(tzinfo=None)
    except (ValueError, TypeError):
        return None


def compute_source_hash(tender: SourceTender) -> str:
    payload = tender.model_dump(mode="json", exclude={"raw_payload"})
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def find_existing_tender(session, source: str, external_id: str):
    return session.execute(select(Tender).where(
        Tender.source == source, Tender.external_id == external_id
    )).scalar_one_or_none()


@celery_app.task(name="app.workers.tasks_parsing.monitor_source", bind=True, max_retries=3, default_retry_delay=300)
def monitor_source(self, source_key: str):
    adapter = get_adapter(source_key)
    if not adapter:
        return {"status": "error", "reason": "unknown_source", "source": source_key}
    try:
        tenders = adapter.search()
        for item in tenders:
            process_new_tender.delay(item.model_dump(mode="json"))
        logger.info("monitor_source_completed", source=source_key, count=len(tenders))
        return {"status": "success", "new_tenders": len(tenders)}
    except Exception as exc:
        logger.error("monitor_source_failed", source=source_key, error=str(exc))
        raise self.retry(exc=exc)


@celery_app.task(name="app.workers.tasks_parsing.process_new_tender", bind=True, max_retries=3)
def process_new_tender(self, tender_data: dict):
    """Upsert canonical SourceTender and launch one document pipeline by internal tender UUID."""
    try:
        source_tender = SourceTender.model_validate(tender_data)
        source_hash = compute_source_hash(source_tender)
        tender_id = None
        should_process = True

        with SyncSessionLocal() as session:
            existing = find_existing_tender(session, source_tender.source, source_tender.external_id)
            if existing:
                tender_id = str(existing.id)
                changed = existing.source_hash != source_hash
                if not changed and existing.analysis_done:
                    should_process = False
                else:
                    existing.title = source_tender.title
                    existing.description = source_tender.description
                    existing.customer_name = source_tender.customer_name
                    existing.customer_inn = source_tender.customer_inn
                    existing.law_type = _enum_law(source_tender.law_type)
                    existing.procurement_method = source_tender.procurement_method
                    existing.amount = source_tender.amount
                    existing.currency = source_tender.currency
                    existing.region = source_tender.region
                    existing.delivery_place = source_tender.delivery_place
                    existing.publish_date = _dt(source_tender.publish_date)
                    existing.submission_deadline = _dt(source_tender.submission_deadline)
                    existing.source_url = source_tender.source_url
                    existing.source_hash = source_hash
                    existing.raw_payload = source_tender.raw_payload
                    existing.analysis_done = False
                    existing.processing_status = ProcessingStatus.INGESTED
                    existing.analysis_version = settings.analysis_version
                    existing.notified_bitrix = False
                    existing.notified_telegram = False
            else:
                row = Tender(
                    source=source_tender.source,
                    external_id=source_tender.external_id,
                    title=source_tender.title,
                    description=source_tender.description,
                    customer_name=source_tender.customer_name,
                    customer_inn=source_tender.customer_inn,
                    law_type=_enum_law(source_tender.law_type),
                    procurement_method=source_tender.procurement_method,
                    amount=source_tender.amount,
                    currency=source_tender.currency,
                    region=source_tender.region,
                    delivery_place=source_tender.delivery_place,
                    publish_date=_dt(source_tender.publish_date),
                    submission_deadline=_dt(source_tender.submission_deadline),
                    status=TenderStatus.NEW,
                    processing_status=ProcessingStatus.INGESTED,
                    source_url=source_tender.source_url,
                    source_hash=source_hash,
                    raw_payload=source_tender.raw_payload,
                    analysis_done=False,
                    analysis_version=settings.analysis_version,
                    is_active=True,
                )
                session.add(row)
                session.flush()
                tender_id = str(row.id)
            session.commit()

        if not should_process:
            logger.info("tender_unchanged_cached", tender_id=tender_id)
            return {"status": "cached", "tender_id": tender_id}

        from app.workers.tasks_ocr import process_tender_documents
        process_tender_documents.delay(tender_id, [d.model_dump(mode="json") for d in source_tender.documents])
        return {"status": "queued_for_documents", "tender_id": tender_id, "documents": len(source_tender.documents)}
    except Exception as exc:
        logger.error("process_tender_failed", error=str(exc))
        raise self.retry(exc=exc)


@celery_app.task(name="app.workers.tasks_parsing.analyze_tender_url", bind=True, max_retries=2)
def analyze_tender_url(self, url: str, source_hint: str | None = None):
    from app.sources.resolver import fetch_tender_from_url
    try:
        tender = fetch_tender_from_url(url, source_hint)
        if not tender:
            return {"status": "failed", "reason": "source_or_tender_not_resolved"}
        process_new_tender.delay(tender.model_dump(mode="json"))
        return {"status": "resolved", "source": tender.source, "external_id": tender.external_id}
    except Exception as exc:
        raise self.retry(exc=exc)


@celery_app.task(name="app.workers.tasks_parsing.mark_inactive_tenders")
def mark_inactive_tenders():
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    with SyncSessionLocal() as session:
        result = session.execute(update(Tender).where(
            Tender.is_active.is_(True),
            Tender.submission_deadline.is_not(None),
            Tender.submission_deadline < now,
        ).values(is_active=False))
        session.commit()
        return {"marked_inactive": result.rowcount}
