"""
Celery конфигурация с расписанием для всех источников.
"""
from celery import Celery
from celery.schedules import crontab

from app.core.config import settings

celery_app = Celery(
    "tender_platform",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
    include=[
        "app.workers.tasks_parsing",
        "app.workers.tasks_ocr",
        "app.workers.tasks_scoring",
        "app.workers.tasks_notify",
        "app.workers.tasks_reports",
        "app.workers.tasks_upload",
    ],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Europe/Moscow",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_default_retry_delay=60,
    task_max_retries=3,
)

celery_app.conf.beat_schedule = {
    # ЕИС — каждый день в 03:00
    "monitor-eis-daily": {
        "task": "app.workers.tasks_parsing.monitor_source",
        "schedule": crontab(hour=3, minute=0),
        "args": ("zakupki_gov_ru",),
    },
    # Tender.Pro — каждые 4 часа (коммерческие тендеры обновляются чаще)
    "monitor-tender-pro-4h": {
        "task": "app.workers.tasks_parsing.monitor_source",
        "schedule": crontab(minute=30, hour="*/4"),
        "args": ("tender_pro",),
    },
    # Обновление дедлайнов — каждый час
    "mark-inactive-hourly": {
        "task": "app.workers.tasks_parsing.mark_inactive_tenders",
        "schedule": crontab(minute=0),
    },
    # Ежедневный отчёт — в 09:00
    "daily-report": {
        "task": "app.workers.tasks_reports.generate_and_send_report",
        "schedule": crontab(hour=9, minute=0),
    },
}

# Контур.Закупки включается в расписание только после настройки API-лицензии.
if (settings.kontur_api_base_url and settings.kontur_api_key and settings.kontur_search_path
        and (settings.kontur_api_key_header or settings.kontur_api_key_query_param)):
    celery_app.conf.beat_schedule["monitor-kontur-zakupki-4h"] = {
        "task": "app.workers.tasks_parsing.monitor_source",
        "schedule": crontab(minute=45, hour="*/4"),
        "args": ("kontur_zakupki",),
    }
