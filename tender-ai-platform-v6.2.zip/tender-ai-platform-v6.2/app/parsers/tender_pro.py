"""Deprecated compatibility facade for Tender.Pro.

v6.1 moved source integration to ``app.sources.tender_pro``. New code must use
``TenderProAdapter`` / ``TenderProClient``. This module remains temporarily so
older imports do not break during deployment.
"""
from __future__ import annotations

from typing import Any

from app.sources.tender_pro.adapter import TenderProAdapter
from app.sources.tender_pro.client import TenderProClient


def fetch_new_tenders(max_rows: int = 100) -> list[dict[str, Any]]:
    client = TenderProClient()
    adapter = TenderProAdapter(client=client)
    # max_rows is supported by the client; this compatibility layer uses a
    # one-off override without changing global settings.
    original = client.list_tenders
    client.list_tenders = lambda: original(max_rows=max_rows)  # type: ignore[method-assign]
    return [x.model_dump(mode="json") for x in adapter.search()]


def fetch_tender_details(tender_id: str, company_id: str) -> dict[str, Any]:
    return TenderProClient().tender_info(tender_id, company_id)


def fetch_tender_files(tender_id: str, company_id: str) -> list[str]:
    """Removed in v6.1: `_tender.files` was not confirmed by supplied docs.

    Kept only for compatibility. Document URLs are now derived from the
    documented `_tender.info` payload by TenderProAdapter.
    """
    detail = TenderProClient().tender_info(tender_id, company_id)
    from app.sources.tender_pro.adapter import _extract_documents
    return [d.url for d in _extract_documents(detail) if d.url]
