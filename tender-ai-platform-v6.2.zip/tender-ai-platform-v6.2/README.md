# Tender AI Platform v6.2

Версия v6.2 продолжает архитектуру v6 и добавляет Контур.Закупки как третий источник. v6 перестраивает проект под несколько независимых тендерных площадок и единый итоговый отчет.

## Архитектура

```text
Площадка A ─┐
Площадка B ─┼─> SourceAdapter -> SourceTender -> PostgreSQL
Площадка C ─┘                              |
                                              v
                              Documents -> OCR/extract
                                              |
                                              v
                                   tender-level LLM
                                              |
                                              v
                                   Lot -> TenderItem
                                              |
                                              v
                                      scoring/decision
                                              |
                         +--------------------+------------------+
                         v                    v                  v
                       Excel               Telegram           Bitrix24
```

Главный принцип: код конкретной площадки заканчивается в `app/sources/.../adapter.py`. Все остальные компоненты работают только с единым контрактом `SourceTender`.

## Важное отличие от v5

v6 имеет новую схему БД и новую migration history. Если на v5 уже есть ценные производственные данные, сначала сделайте backup PostgreSQL и не применяйте v6 migration поверх старой БД без отдельной миграции данных.

Для MVP/тестовой БД проще создать чистую БД v6.

## Быстрый запуск на чистой БД

```bash
cp .env.example .env
chmod 600 .env
nano .env
mkdir -p storage

docker compose config
docker compose build
docker compose up -d postgres redis qdrant

docker compose run --rm app alembic upgrade head

docker compose up -d app celery_worker celery_beat flower

curl --fail http://localhost:8000/health/ready
```

Не выполняйте `alembic init migrations` на сервере. Каталог migrations уже находится в репозитории.

## Проверка

```bash
docker compose ps
docker compose exec app alembic current
docker compose exec app alembic history
docker compose exec app pytest tests/ -v

docker compose logs --tail=200 app
docker compose logs --tail=200 celery_worker
docker compose logs --tail=200 celery_beat
```

Ожидаемая migration history:

```text
<base> -> 0001_v6_initial (head)
```

## Переменные окружения

Минимально проверьте:

```env
DATABASE_URL=...
DATABASE_URL_SYNC=...
REDIS_URL=...
CELERY_BROKER_URL=...
CELERY_RESULT_BACKEND=...
QDRANT_URL=...

EIS_TOKEN=...
TENDER_PRO_API_KEY=...
KONTUR_API_BASE_URL=...
KONTUR_API_KEY=...

DEFAULT_LLM_PROVIDER=...
ANTHROPIC_API_KEY=...
# или YandexGPT параметры

TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHAT_ID=...
BITRIX24_WEBHOOK_URL=...
BITRIX24_CHAT_ID=...

ANALYSIS_VERSION=v6.2
```

Никогда не коммитьте `.env`.

## Источники

Сейчас зарегистрированы:

- `zakupki_gov_ru` — ЕИС;
- `tender_pro` — Tender.Pro;
- `kontur_zakupki` — Контур.Закупки (API-лицензия, параметры доступа через `.env`).

Реестр находится в:

```text
app/sources/registry.py
```

### Подключение новой площадки

Создайте:

```text
app/sources/my_platform/
    __init__.py
    adapter.py
```

Адаптер должен реализовать:

```python
from app.sources.base import TenderSourceAdapter
from app.sources.schemas import SourceTender

class MyPlatformAdapter(TenderSourceAdapter):
    source_code = "my_platform"

    def search(self) -> list[SourceTender]:
        ...
```

Каждая площадка может использовать собственный API, HTML/XML/SOAP или другой разрешенный способ получения информации, но наружу возвращает только `SourceTender`.

После этого зарегистрируйте:

```python
SOURCE_REGISTRY = {
    ...,
    "my_platform": MyPlatformAdapter(),
}
```

Основной pipeline менять не нужно.

## Единый отчет

API:

```text
GET /reports/active.xlsx
```

В v6 одна строка Excel соответствует одной товарной позиции, а не одному тендеру. Поэтому закупка с несколькими лотами/позициями корректно разворачивается в несколько строк с одним `external_id`.

Основные поля отчета:

```text
Источник
Внешний ID
44-ФЗ / 223-ФЗ / commercial
Заказчик / ИНН
Предмет закупки
Лот
Позиция
Наименование
Тип продукции
Сплав / состояние
Размеры
Количество / масса
ГОСТ/ТУ
НМЦК
Место и срок поставки
Можем поставить
Причина по позиции
Статус ИИ
Балл
Дедлайн
Ссылка
Риски
Версия анализа
```

## Ручная загрузка

`POST /upload/tender` больше не имеет отдельной логики анализа. Загруженный файл превращается в `SourceTender` с источником `manual_upload` и проходит тот же pipeline, что ЕИС/Tender.Pro/Контур.Закупки.

## Анализ по URL

`POST /tenders/analyze-url` передает URL в `app/sources/resolver.py`.

Поддержанные домены определяют площадку, после чего вызывается `adapter.fetch_by_url()`. Если площадка неизвестна, API возвращает ошибку вместо запуска пустого pipeline.

## Документы

Все документы теперь сохраняются в таблицу `documents`:

- имя;
- source URL;
- локальный путь;
- SHA-256;
- OCR status;
- число страниц;
- извлеченный текст.

ЕИС archive member обрабатывается как член ZIP-архива. Фиктивные URL вида `__archive__...#file.pdf` больше не передаются напрямую в `httpx`.

## Повторный анализ

`source_hash` вычисляется из нормализованного `SourceTender`.

Если закупка не изменилась и `analysis_done=True`, повторный LLM вызов не выполняется. Если данные источника изменились, тендер переводится на повторную обработку.

## Статусы

Технический ход обработки хранится отдельно:

```text
DISCOVERED
INGESTED
DOCUMENTS_PENDING
DOCUMENTS_READY
ANALYZING
ANALYZED
FAILED
```

Бизнес-решение остается отдельным:

```text
CAN_APPLY
NEEDS_CLARIFICATION
NOT_SUITABLE
MANUAL_REVIEW
```

## Тесты сборки v6

При подготовке архива выполнены:

```text
python -m compileall app migrations tests   -> OK
pytest -q                                  -> 41 passed
alembic history                            -> 0001_v6_initial (head)
```

## Безопасность ключей

В v5 API-ключ Tender.Pro был зашит непосредственно в Python-файл, а в шаблоне окружения присутствовало значение токена ЕИС. В v6 ключи удалены из исходного кода и читаются только из окружения.

Если прежние значения уже публиковались в GitHub, их рекомендуется перевыпустить у соответствующих сервисов.

Подробнее о сделанных изменениях: `V6_CHANGES.md`.

## Tender.Pro API — v6.1

Интеграция использует официальный алгоритм Tender.Pro:

1. `_info.tenderlist_by_set` — получение общей ленты процедур (`set_type_id=2`, `open_only=t`, `max_rows=N`).
2. `_tender.info` — детализация выбранной процедуры по `id` и `company_id`.
3. Ответ адаптера всегда преобразуется в общий `SourceTender`, поэтому Tender.Pro попадает в ту же БД и тот же Excel-отчет, что ЕИС и будущие площадки.

Настройки `.env`:

```env
TENDER_PRO_API_KEY=ВАШ_КЛЮЧ
TENDER_PRO_MAX_ROWS=100
TENDER_PRO_OPEN_ONLY=true
TENDER_PRO_FETCH_DETAILS=true
TENDER_PRO_REQUEST_TIMEOUT=30
```

Ключ не следует коммитить в GitHub. Даже если используется общий ключ Tender.Pro, храните его только в `.env` на сервере.

### Проверка Tender.Pro после развертывания

Проверьте наличие ключа внутри контейнера без вывода самого значения:

```bash
docker compose exec app python -c "from app.core.config import settings; print(bool(settings.tender_pro_api_key))"
```

Проверка адаптера вручную:

```bash
docker compose exec app python - <<'PY'
from app.sources.tender_pro.adapter import TenderProAdapter
items = TenderProAdapter().search()
print('accepted:', len(items))
for item in items[:5]:
    print(item.external_id, item.title, len(item.documents), item.source_url)
PY
```

Если API Tender.Pro возвращает структуру, отличающуюся от ожидаемой, сохраните один обезличенный JSON-ответ `_info.tenderlist_by_set` и `_tender.info`: mapper специально отделен от общего pipeline, поэтому его можно поправить без изменений БД, Celery и отчетов.


## Контур.Закупки (v6.2)

В `app/sources/kontur_zakupki/` добавлены `client.py` и `adapter.py`.
Контур.Закупки использует тот же `SourceTender` и единый downstream pipeline.

Подробная настройка: `docs/kontur_zakupki_setup.md`.

Переданные HTML-файлы документации являются JavaScript SPA-shell и не содержат сам контракт API,
поэтому host, способ передачи ключа и endpoint paths задаются через `.env` и должны быть сверены
с документацией, выданной Контуром для конкретной API-лицензии. Реальный ключ никогда не хранится в GitHub.
