import os

os.environ.setdefault("DATABASE_URL", "postgresql+asyncpg://u:p@localhost/db")
os.environ.setdefault("DATABASE_URL_SYNC", "postgresql+psycopg2://u:p@localhost/db")
os.environ.setdefault("REDIS_URL", "redis://localhost:6379/0")
os.environ.setdefault("CELERY_BROKER_URL", "redis://localhost:6379/1")
os.environ.setdefault("CELERY_RESULT_BACKEND", "redis://localhost:6379/2")
os.environ.setdefault("QDRANT_URL", "http://localhost:6333")

from app.sources.tender_pro.adapter import TenderProAdapter


class FakeTenderProClient:
    def list_tenders(self):
        return [
            {
                "id": 1182907,
                "company_id": 12299,
                "name": "Поставка алюминиевого листа АМг2",
                "company_name": "ООО Заказчик",
                "open_date": "2026-04-22T10:00:00",
                "date_close": "2026-04-24T23:00:00",
            },
            {
                "id": 1182908,
                "company_id": 12299,
                "name": "Услуги клининга",
            },
        ]

    def tender_info(self, tender_id, company_id):
        assert str(company_id) == "12299"
        if str(tender_id) == "1182907":
            return {
                "currency": "RUB",
                "comment": "Лист алюминиевый 2х1500х3000",
                "documents": [
                    {
                        "id": 55,
                        "name": "Техническое задание.pdf",
                        "url": "https://www.tender.pro/files/specification.pdf",
                    }
                ],
            }
        return {}


def test_search_uses_detail_and_returns_canonical_tender():
    adapter = TenderProAdapter(client=FakeTenderProClient())
    tenders = adapter.search()
    assert len(tenders) == 1
    tender = tenders[0]
    assert tender.source == "tender_pro"
    assert tender.external_id == "1182907"
    assert tender.customer_name == "ООО Заказчик"
    assert tender.currency == "RUB"
    assert tender.source_url == "https://www.tender.pro/api/tender/1182907/view_public"
    assert len(tender.documents) == 1
    assert tender.documents[0].name == "Техническое задание.pdf"


def test_fetch_by_url_supports_current_public_url():
    adapter = TenderProAdapter(client=FakeTenderProClient())
    tender = adapter.fetch_by_url("https://www.tender.pro/api/tender/1182907/view_public")
    assert tender is not None
    assert tender.external_id == "1182907"


def test_fetch_by_url_supports_legacy_public_url():
    adapter = TenderProAdapter(client=FakeTenderProClient())
    tender = adapter.fetch_by_url(
        "https://www.tender.pro/view_tender_public.shtml?tab=common&tenderid=1182907"
    )
    assert tender is not None
    assert tender.external_id == "1182907"
