from app.sources.schemas import SourceDocument, SourceTender


def test_source_tender_contract_accepts_multiple_documents():
    tender = SourceTender(
        source="test", external_id="123", title="Алюминиевая лента",
        law_type="commercial",
        documents=[
            SourceDocument(name="spec.pdf", url="https://example.org/spec.pdf"),
            SourceDocument(name="lot.xlsx", download_type="archive_member", archive_url="https://example.org/a.zip", archive_member="lot.xlsx"),
        ],
    )
    assert tender.external_id == "123"
    assert len(tender.documents) == 2
    assert tender.documents[1].download_type == "archive_member"
