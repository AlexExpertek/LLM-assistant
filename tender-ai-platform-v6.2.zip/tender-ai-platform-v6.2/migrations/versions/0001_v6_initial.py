"""v6 initial schema

Revision ID: 0001_v6_initial
Revises:
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0001_v6_initial"
down_revision = None
branch_labels = None
depends_on = None

law_type = sa.Enum("FZ_44", "FZ_223", "COMMERCIAL", "OTHER", name="lawtype")
tender_status = sa.Enum("NEW", "PROCESSING", "CAN_APPLY", "NEEDS_CLARIFICATION", "NOT_SUITABLE", "MANUAL_REVIEW", name="tenderstatus")
processing_status = sa.Enum("DISCOVERED", "INGESTED", "DOCUMENTS_PENDING", "DOCUMENTS_READY", "ANALYZING", "ANALYZED", "FAILED", name="processingstatus")
doc_type = sa.Enum("TENDER_DOC", "CONTRACT", "SPECIFICATION", "DRAWING", "PROTOCOL", "OTHER", name="documenttype")
ocr_status = sa.Enum("NOT_REQUIRED", "PENDING", "DONE", "LOW_CONFIDENCE", "FAILED", name="ocrstatus")


def upgrade():
    op.create_table("tenders",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("source", sa.String(100), nullable=False), sa.Column("external_id", sa.String(255), nullable=False),
        sa.Column("title", sa.Text(), nullable=False), sa.Column("description", sa.Text()),
        sa.Column("customer_name", sa.String(500)), sa.Column("customer_inn", sa.String(20)),
        sa.Column("law_type", law_type), sa.Column("procurement_method", sa.String(100)),
        sa.Column("amount", sa.Numeric(18,2)), sa.Column("currency", sa.String(10)), sa.Column("region", sa.String(255)),
        sa.Column("delivery_place", sa.Text()), sa.Column("publish_date", sa.DateTime()), sa.Column("submission_deadline", sa.DateTime()),
        sa.Column("status", tender_status), sa.Column("processing_status", processing_status), sa.Column("source_url", sa.Text()),
        sa.Column("source_hash", sa.String(64)), sa.Column("documents_hash", sa.String(64)), sa.Column("analysis_version", sa.String(100)),
        sa.Column("raw_payload", sa.JSON()), sa.Column("analysis_done", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()), sa.Column("score", sa.Integer()),
        sa.Column("notified_bitrix", sa.Boolean(), server_default=sa.false()), sa.Column("notified_telegram", sa.Boolean(), server_default=sa.false()),
        sa.Column("created_at", sa.DateTime()), sa.Column("updated_at", sa.DateTime()),
        sa.UniqueConstraint("source","external_id",name="uq_tender_source_external_id"))
    op.create_index("ix_tenders_not_analyzed","tenders",["analysis_done","is_active"])
    op.create_index("ix_tenders_source_hash","tenders",["source_hash"])
    op.create_index("ix_tenders_processing_status","tenders",["processing_status"])
    op.create_index("ix_tenders_status","tenders",["status"])
    op.create_index("ix_tenders_is_active","tenders",["is_active"])

    op.create_table("lots",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("tender_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("tenders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("lot_number", sa.String(50)), sa.Column("title", sa.Text()), sa.Column("amount", sa.Numeric(18,2)),
        sa.Column("currency", sa.String(10)), sa.Column("delivery_place", sa.Text()), sa.Column("created_at", sa.DateTime()))
    op.create_index("ix_lots_tender_id","lots",["tender_id"])

    op.create_table("tender_items",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("lot_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("lots.id", ondelete="CASCADE"), nullable=False),
        sa.Column("position_number", sa.Integer(), nullable=False), sa.Column("name", sa.Text()), sa.Column("product_type", sa.String(255)),
        sa.Column("alloy", sa.String(100)), sa.Column("temper", sa.String(50)), sa.Column("thickness_mm", sa.Float()), sa.Column("width_mm", sa.Float()),
        sa.Column("length_mm", sa.Float()), sa.Column("diameter_mm", sa.Float()), sa.Column("cross_section_shape", sa.String(100)),
        sa.Column("quantity", sa.Float()), sa.Column("mass_kg", sa.Float()), sa.Column("unit", sa.String(50)), sa.Column("standard", sa.String(255)),
        sa.Column("coating_required", sa.Boolean()), sa.Column("coating_type", sa.String(255)), sa.Column("machining_required", sa.Boolean()),
        sa.Column("has_drawings", sa.Boolean()), sa.Column("delivery_place", sa.Text()), sa.Column("delivery_term", sa.String(255)),
        sa.Column("payment_terms", sa.Text()), sa.Column("raw_text", sa.Text()), sa.Column("can_supply", sa.Boolean()),
        sa.Column("supply_reason", sa.Text()), sa.Column("created_at", sa.DateTime()))
    op.create_index("ix_tender_items_lot_id","tender_items",["lot_id"])

    op.create_table("documents",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("tender_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("tenders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("external_id", sa.String(255)), sa.Column("doc_type", doc_type), sa.Column("filename", sa.String(500)),
        sa.Column("version", sa.Integer()), sa.Column("file_hash", sa.String(64)), sa.Column("storage_uri", sa.Text()), sa.Column("source_url", sa.Text()),
        sa.Column("ocr_status", ocr_status), sa.Column("pages_count", sa.Integer()), sa.Column("extracted_text", sa.Text()), sa.Column("created_at", sa.DateTime()))
    op.create_index("ix_documents_tender_id","documents",["tender_id"]); op.create_index("ix_documents_file_hash","documents",["file_hash"])

    op.create_table("extracted_facts",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("document_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("documents.id", ondelete="CASCADE"), nullable=False),
        sa.Column("field_name", sa.String(255), nullable=False), sa.Column("raw_value", sa.Text()), sa.Column("normalized_value", sa.Text()),
        sa.Column("confidence", sa.Float()), sa.Column("page_or_cell", sa.String(100)), sa.Column("quote", sa.Text()), sa.Column("created_at", sa.DateTime()))

    op.create_table("decisions",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("tender_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("tenders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("score", sa.Integer()), sa.Column("status", tender_status), sa.Column("reasons", sa.JSON()), sa.Column("risks", sa.JSON()),
        sa.Column("model_version", sa.String(100)), sa.Column("reviewer", sa.String(255)), sa.Column("final_feedback", sa.Text()),
        sa.Column("is_manual_override", sa.Boolean()), sa.Column("created_at", sa.DateTime()))
    op.create_index("ix_decisions_tender_id","decisions",["tender_id"])

    op.create_table("companies",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True), sa.Column("inn", sa.String(20)), sa.Column("ogrn", sa.String(20)),
        sa.Column("name", sa.String(500)), sa.Column("okved", sa.String(20)), sa.Column("site", sa.Text()), sa.Column("region", sa.String(255)),
        sa.Column("segment", sa.String(255)), sa.Column("signals", sa.JSON()), sa.Column("consent_status", sa.String(50)), sa.Column("created_at", sa.DateTime()),
        sa.UniqueConstraint("inn"))
    op.create_index("ix_companies_inn","companies",["inn"])
    op.create_table("contacts",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True), sa.Column("company_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("companies.id")),
        sa.Column("contact_type", sa.String(50)), sa.Column("value", sa.String(500)), sa.Column("person_name", sa.String(255)),
        sa.Column("role", sa.String(255)), sa.Column("source", sa.String(255)), sa.Column("discovered_at", sa.DateTime()), sa.Column("is_opted_out", sa.Boolean()))
    op.create_table("knowledge_items",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True), sa.Column("item_type", sa.String(100)), sa.Column("title", sa.String(500)),
        sa.Column("content", sa.Text()), sa.Column("metadata_json", sa.JSON()), sa.Column("qdrant_point_id", sa.String(100)),
        sa.Column("version", sa.Integer()), sa.Column("access_scope", sa.String(50)), sa.Column("created_at", sa.DateTime()), sa.Column("updated_at", sa.DateTime()))


def downgrade():
    for table in ["knowledge_items","contacts","companies","decisions","extracted_facts","documents","tender_items","lots","tenders"]:
        op.drop_table(table)
    for enum in [ocr_status, doc_type, processing_status, tender_status, law_type]:
        enum.drop(op.get_bind(), checkfirst=True)
