import ast,unittest
from pathlib import Path
from typing import Optional
from pydantic import BaseModel,Field
path=Path('app/llm/extraction.py')
if not path.exists():path=Path(__file__).parent/'payload/app/llm/extraction.py'
tree=ast.parse(path.read_text())
names={'ExtractedField','TenderPositionExtraction','TenderMultiExtractionResult','_normalize_extraction','_merge_extractions'}
ns={'BaseModel':BaseModel,'Field':Field,'Optional':Optional}
exec(compile(ast.Module(body=[n for n in tree.body if getattr(n,'name',None) in names],type_ignores=[]),str(path),'exec'),ns)
P=ns['TenderPositionExtraction'];R=ns['TenderMultiExtractionResult'];F=ns['ExtractedField']
TITLE='ОКПД2 24.42.26.110. Трубы алюминиевые для нужд ОП «Сахалинская ГРЭС»'
NAME='Труба АД1М 23х1,0х6000 ГОСТ 18475-82'
TEXT=TITLE+'\n\n### DOCUMENT: ТТ.docx\n'+NAME+' | тн | 8'
def pos(name=NAME,**kwargs):return P(product_name=F(value=name),**{k:F(value=v) for k,v in kwargs.items()})
def norm(positions,text=TEXT):return ns['_normalize_extraction'](R(positions=positions),text)
class Checks(unittest.TestCase):
 def test_real_three(self):
  a=pos('Трубы алюминиевые для нужд ОП «Сахалинская ГРЭС»',product_type='трубы');a.lot_number='0269'
  b=pos('Трубы алюминиевые',product_type='трубы');b.lot_number='0269-РЕМ ПРОД-2026-СЭ'
  c=pos(alloy='АД1М',thickness_mm='1',length_mm='6000',mass_kg='8000',quantity='8',unit='тн')
  r=norm([a,b,c]);self.assertEqual(len(r.positions),1)
  v=r.positions[0]
  self.assertEqual([v.alloy.value,v.temper.value,v.diameter_mm.value,v.mass_kg.value],['АД1','М','23','8000'])
  self.assertEqual(v.diameter_mm.raw_quote,NAME)
 def test_unseen_name(self):self.assertIsNone(norm([pos()],text=TITLE).positions[0].diameter_mm.value)
 def test_real_incomplete_retained(self):self.assertEqual(len(norm([pos('Трубы алюминиевые',quantity='8')]).positions),1)
 def test_other_incomplete_retained(self):self.assertEqual(len(norm([pos('Лист алюминиевый')]).positions),1)
 def test_conflicting_diameter(self):
  with self.assertRaisesRegex(ValueError,'CONFLICT'):norm([pos(diameter_mm='25')])
 def test_unknown_alloy_not_rewritten(self):
  n='Труба АМг61 23х1х6000'
  r=norm([pos(n,alloy='АМг61')],TITLE+'\n'+n)
  self.assertEqual(r.positions[0].alloy.value,'АМг61')
 def test_profile_not_round(self):
  n='Труба профильная АД1М 23х10х6000'
  self.assertIsNone(norm([pos(n)],TITLE+'\n'+n).positions[0].diameter_mm.value)
 def test_no_mass_invention(self):self.assertIsNone(norm([pos()]).positions[0].mass_kg.value)
 def test_exact_duplicates_not_summed(self):
  r=norm([pos(mass_kg='8000'),pos(mass_kg='8000')]);merged=ns['_merge_extractions']([r]);self.assertEqual(len(merged.positions),1);self.assertEqual(merged.positions[0].mass_kg.value,'8000')
 def test_temper_conflict(self):
  with self.assertRaisesRegex(ValueError,'CONFLICT'):norm([pos(temper='Т')])
unittest.main()
