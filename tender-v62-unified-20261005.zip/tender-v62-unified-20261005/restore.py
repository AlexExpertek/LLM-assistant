"""Restore source files only; refuses to overwrite subsequent edits."""
import argparse,hashlib,json,shutil
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('backup');args=p.parse_args()
backup=Path(args.backup).resolve();data=json.loads((backup/'restore.json').read_text());root=Path(data['project']).resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
for item in data['files']:
    rel=Path(item['path']);dest=root/rel
    if rel.is_absolute() or '..' in rel.parts or dest.is_symlink():raise SystemExit('Unsafe path')
    if sha(dest)!=item['after']:raise SystemExit('New edits found; stop: '+str(rel))
    if item['before'] and sha(backup/rel)!=item['before']:raise SystemExit('Backup checksum mismatch')
for item in data['files']:
    dest=root/item['path']
    if item['before'] is None:dest.unlink()
    else:shutil.copy2(backup/item['path'],dest)
print('SOURCES_RESTORED: rebuild images before switching services; review decisions retained')
