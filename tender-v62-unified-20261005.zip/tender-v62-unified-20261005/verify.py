import os
# Offline verification never uses production connection settings.
for k,v in dict(DATABASE_URL='postgresql+asyncpg://test:test@127.0.0.1/test',DATABASE_URL_SYNC='postgresql://test:test@127.0.0.1/test',REDIS_URL='redis://127.0.0.1:6379/0',CELERY_BROKER_URL='memory://',CELERY_RESULT_BACKEND='cache+memory://',QDRANT_URL='http://127.0.0.1:6333').items():os.environ[k]=v
import unittest,tempfile,asyncio
from unittest.mock import patch,MagicMock
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime,timezone,timedelta
import httpx
from app.core.config import settings
from app.scoring.selection_policy import *
from app.scoring.multiposition import analyze_positions
from app.reports.dashboard_eligibility import evaluate_dashboard_tender
from app.marketplace_discovery.b2b_public import fetch_public,to_source,prepare_public_snapshot
from app.marketplace_discovery.schemas import MarketplaceTender
from app.reports.review_dismissals import set_dismissed,is_dismissed
from app.workers.execution_guard import exclusive_task

class Checks(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.old=settings.storage_path;settings.storage_path=self.tmp.name
 def tearDown(self):settings.storage_path=self.old;self.tmp.cleanup()
 def pos(self,**kw):return dict(name='Лист алюминиевый АМг2',product_type='лист',alloy='АМг2',thickness_mm=1.5,**kw)
 def test_weight_boundary(self):
  self.assertFalse(qualifies(self.pos(mass_kg=499.99)));self.assertTrue(qualifies(self.pos(mass_kg=500)))
 def test_no_sum(self):
  ps=[dict(self.pos(mass_kg=250),can_supply=True)]*2
  self.assertFalse(evaluate_dashboard_tender(dict(status='can_apply',analysis_done=True,positions=ps)).eligible)
 def test_meters_not_mass(self):
  self.assertIsNone(mass_kg(self.pos(quantity=3000,unit='пог. м')))
  self.assertFalse(qualifies(self.pos(quantity=3000,unit='пог. м')))
 def test_units_finite(self):
  self.assertEqual(mass_kg(dict(quantity='0,5',unit='тн')),500)
  for x in (True,'nan','inf',-1):self.assertIsNone(number(x))
 def test_non_target(self):
  for name in ('Уголок стальной Ст3','Кабель алюминиевый СИП-4','Двери из алюминиевого профиля'):
   self.assertFalse(qualifies(dict(name=name,product_type='профиль',mass_kg=900)))
 def test_unknown_alloy_not_rejected(self):
  p=dict(name_product='Лист алюминиевый',product_type='лист',alloy='CUSTOM123',thickness_mm=2,mass_kg=800)
  self.assertTrue(analyze_positions([p]).positions[0].can_supply)
 def test_false_processing(self):
  for x in ('false','нет',False,'не требуется','без покрытия'):self.assertFalse(processing_required(x))
  for x in ('true','да','Резка в размер'):self.assertTrue(processing_required(x))
 def test_mixed_underweight(self):
  ps=[dict(name_product='Уголок стальной',product_type='уголок',mass_kg=5000),dict(self.pos(mass_kg=60),name_product='Лист алюминиевый')]
  self.assertEqual(analyze_positions(ps).cannot_supply_count,2)
 def test_price(self):
  self.assertEqual(price_priority(None),'price_unknown');self.assertEqual(price_priority(500000),'normal');self.assertEqual(price_priority(1000000),'high')
 def test_manual_reject_before_db(self):
  from app.workers.tasks_parsing import process_new_tender
  set_dismissed('b2b_center','4549069',reason='Две позиции по 10 кг')
  with patch('app.workers.tasks_parsing.SyncSessionLocal',side_effect=AssertionError('DB forbidden')):
   r=process_new_tender.run(dict(source='b2b_center',external_id='4549069',title='Металлопродукция'))
  self.assertEqual(r['reason'],'manually_dismissed')
  self.assertTrue(is_dismissed('b2b_center','4549069'))
 def test_kontur_off(self):
  from app.workers.tasks_parsing import monitor_source
  from app.workers.celery_app import celery_app
  with patch('app.workers.tasks_parsing.get_adapter',side_effect=AssertionError('Adapter forbidden')):
   self.assertEqual(monitor_source.run('kontur_zakupki')['reason'],'disabled_by_owner')
  self.assertFalse(any('kontur' in str(v) for v in celery_app.conf.beat_schedule.values()))
 def test_overlap_guard(self):
  @exclusive_task('test','key')
  def recurse(key):return recurse(key)
  self.assertEqual(recurse('one')['reason'],'already_running')
 def fixture(self,n=1,more=''):
  return f'<p>Закупочные позиции - {n}</p><table><tr><th>№</th><th>Наименование</th><th>Количество</th><th>Единицы измерения</th></tr><tr><td>1</td><td>Пруток Д16</td><td>500</td><td>кг</td></tr></table>'+more
 def item(self):return MarketplaceTender(platform='b2b_center',external_id='123',title='Поставка алюминиевого прутка',source_url='https://www.b2b-center.ru/market/test/tender-123/',deadline=datetime.now(timezone.utc)+timedelta(days=2))
 def fetch(self,html):
  with httpx.Client(transport=httpx.MockTransport(lambda r:httpx.Response(200,text=html))) as c:return fetch_public(self.item(),client=c)
 def test_b2b_complete(self):
  card=self.fetch(self.fixture());self.assertTrue(card.complete)
  source=to_source(self.item(),card);docs=prepare_public_snapshot(source)
  self.assertEqual(len(docs),1);self.assertTrue(Path(docs[0].local_path).is_file())
 def test_b2b_incomplete(self):self.assertFalse(self.fetch(self.fixture(28)).complete)
 def test_b2b_hidden(self):
  c=self.fetch('<p>Позиции • 20</p><p>Документация от организатора Доступно зарегистрированным пользователям.</p>')
  self.assertFalse(c.complete);self.assertTrue(c.documents_restricted)
 def test_b2b_redirect_guard(self):
  with httpx.Client(transport=httpx.MockTransport(lambda r:httpx.Response(302,headers={'location':'https://example.com/'}))) as c:
   with self.assertRaises(ValueError):fetch_public(self.item(),client=c)
 def test_short_extraction_once(self):
  from app.llm.extraction import _document_chunks
  self.assertEqual(len(_document_chunks('Спецификация\nЛист АМг2 500 кг\n'*50)),1)
 def test_dimension_uncertainty(self):
  from app.llm.extraction import TenderMultiExtractionResult,_normalize_extraction
  r=TenderMultiExtractionResult.model_validate({'positions':[{'product_name':{'value':'Лист алюминиевый'},'width_mm':{'value':300,'raw_quote':'Ширина не менее 300 мм'}}]})
  n=_normalize_extraction(r,'Лист алюминиевый\nШирина не менее 300 мм')
  self.assertIsNone(n.positions[0].width_mm.value);self.assertEqual(n.positions[0].width_mm.raw_quote,'Ширина не менее 300 мм')
 def test_angle_leg_not_length(self):
  from app.llm.extraction import TenderMultiExtractionResult,_normalize_extraction
  r=TenderMultiExtractionResult.model_validate({'positions':[{'product_name':{'value':'Уголок стальной'},'length_mm':{'value':25,'raw_quote':'Уголок 25х25х2'}}]})
  n=_normalize_extraction(r,'Поставка\nУголок стальной 25х25х2')
  self.assertIsNone(n.positions[0].length_mm.value)
 def test_catalog_excludes_kontur(self):
  from app.marketplace_discovery.scout.catalog_discovery import parse_catalog
  self.assertEqual(parse_catalog('<a href="https://zakupki.kontur.ru">Закупки</a><a href="https://etpgpb.ru">ЭТП ГПБ</a>'),['https://etpgpb.ru'])

 def test_b2b_pagination(self):
  base=self.item().source_url
  first=self.fixture(2, '<a href="?action=positions&page=2">2</a>')
  second=self.fixture(2).replace('<td>1</td>','<td>2</td>')
  def respond(r):return httpx.Response(200,text=second if 'page=2' in str(r.url) else first)
  with httpx.Client(transport=httpx.MockTransport(respond)) as client:
   card=fetch_public(self.item(),client=client)
  self.assertTrue(card.complete);self.assertEqual(len(card.positions),2)
 def test_analysis_b2b_restricted_stays_review(self):
  from app.workers import tasks_scoring as mod
  from app.llm.extraction import TenderMultiExtractionResult
  from app.models.database import TenderStatus
  tender=SimpleNamespace(source='b2b_center',title='Поставка листа',description='',delivery_place='',raw_payload={'b2b_public':{'documents_restricted':True}},processing_status=None)
  session=MagicMock();session.__enter__.return_value=session;session.get.return_value=tender
  result=TenderMultiExtractionResult.model_validate({'positions':[{'product_name':{'value':'Лист алюминиевый АМг2'},'product_type':{'value':'лист'},'alloy':{'value':'АМг2'},'thickness_mm':{'value':'2'},'quantity':{'value':'0.8'},'unit':{'value':'тн'},'coating':{'value':'false'},'machining':{'value':'нет'}}]})
  async def extract(text):return result
  scoring=SimpleNamespace(signals=[],critical_unknowns=[],suggested_status=TenderStatus.CAN_APPLY,total_score=70,category=SimpleNamespace(value='test'))
  with patch.object(mod,'SyncSessionLocal',return_value=session),patch.object(mod,'gate_saved_tender',return_value=None),patch.object(mod,'extract_tender_positions',side_effect=extract),patch.object(mod,'score_tender',return_value=scoring) as score,patch.object(mod,'_save') as save,patch.object(settings,'notifications_enabled',False):
   answer=mod.analyze_tender.run('fake','Лист алюминиевый АМг2')
  self.assertEqual(answer['decision'],'manual_review');self.assertFalse(score.call_args.kwargs['has_processing_services'])
  self.assertEqual(save.call_args.args[2].positions[0].mass_kg,800)
 def test_dashboard_aggregation_uses_single_mass(self):
  from app.reports import active_tenders as mod
  rows=[dict(self.pos(mass_kg=800),id='one',external_id='1',product_name='Лист алюминиевый АМг2',status='can_apply',analysis_done=True,can_supply=True,price_priority='normal'),dict(self.pos(mass_kg=900),id='one',external_id='1',product_name='Лист алюминиевый АМг2',status='can_apply',analysis_done=True,can_supply=True,price_priority='normal')]
  with patch.object(mod,'get_active_tenders',return_value=rows):result=mod.get_tender_dashboard()
  self.assertEqual(len(result),1);self.assertEqual(result[0]['relevant_weight_kg'],800);self.assertEqual(result[0]['matched_count'],2)
 def test_eis_freshness_retained(self):
  from app.sources.eis_freshness import eligibility
  self.assertEqual(eligibility('zakupki_gov_ru',raw={'stage':'search'}),'needs_detail')
  self.assertEqual(eligibility('zakupki_gov_ru',raw={'procurement_status':'Закупка завершена'}),'closed_stage')
  self.assertIsNone(eligibility('zakupki_gov_ru',datetime.now(timezone.utc)+timedelta(days=1),{'stage':'detail'}))
 def test_tenderpro_no_sum(self):
  from app.sources.tender_pro.relevance import analyse_tender_positions
  result=analyse_tender_positions([{'name':'Лист алюминиевый АМг2','quantity':250,'unit':'кг'}]*2)
  self.assertFalse(result['weight_ok']);self.assertEqual(result['relevant_weight_kg'],250)
 def test_tenderpro_shared_interval(self):
  from app.sources import request_pacing as mod
  with patch.object(mod.time,'monotonic',side_effect=[10,10,10.2,11.1]),patch.object(mod.time,'sleep') as wait:
   mod.tender_pro_request_hook(None);mod.tender_pro_request_hook(None)
  wait.assert_called_once();self.assertAlmostEqual(wait.call_args.args[0],0.9)
 def test_worker_and_api_imports(self):
  import app.workers.tasks_ocr
  import app.workers.tasks_discovery_http
  import app.workers.tasks_marketplace_discovery
  import app.main
  self.assertTrue(any(r.path=='/tenders/selection-policy' for r in app.main.app.routes))

if __name__=='__main__':unittest.main(verbosity=2)
