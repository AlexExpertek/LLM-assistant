"""Start one normal run; subsequent runs are dispatched by Celery Beat."""
from app.workers.tasks_parsing import monitor_source
from app.workers.tasks_marketplace_discovery import run_connected_marketplaces
from app.workers.tasks_discovery_http import discover_new_sources
for name,task,args,kwargs in (
    ('ЕИС',monitor_source,('zakupki_gov_ru',),{}),
    ('B2B-Center',run_connected_marketplaces,(),{'max_per_platform':20}),
    ('Поиск новых площадок',discover_new_sources,(),{}),
):
    result=task.apply_async(args=args,kwargs=kwargs,queue='discovery')
    print(name,'TASK_ID:',result.id,flush=True)
print('QUEUED: success must be confirmed in worker logs and dashboard')
