from app.reports.review_dismissals import is_dismissed,set_dismissed
for source,number,reason in (
    ('b2b_center','4549069','Отклонено пользователем: 18 стальных позиций; два прутка Д16 по 10 кг, ниже 500 кг на позицию'),
    ('zakupki_gov_ru','32616424753','Отклонено пользователем: алюминиевый лист около 60 кг; остальные позиции стальные'),
    ('b2b_center','4619387','Отклонено пользователем: кабельная продукция вне ассортимента'),
):
    if not is_dismissed(source,number):set_dismissed(source,number,reason=reason)
    print('DISMISSED:',source,number)
