import time,json
from app.core.config import settings
from app.workers.celery_app import celery_app
from app.scoring.selection_policy import policy
from app.reports.active_tenders import get_tender_dashboard
from app.reports.review_dashboard import get_review_dashboard
inspector=celery_app.control.inspect(timeout=3)
for attempt in range(12):
    replies=inspector.active_queues() or {}
    queues={q['name'] for values in replies.values() for q in values}
    if {'celery','discovery'}<=queues:break
    time.sleep(2)
else:raise SystemExit('WORKERS_NOT_READY: celery/discovery queue consumer missing')
print('QUEUES_OK:',sorted(queues))
print('POLICY:',json.dumps(policy(),ensure_ascii=False))
print('SCHEDULE:')
for name,value in celery_app.conf.beat_schedule.items():print(name,str(value['schedule']),value.get('args',()))
print('DASHBOARD_COUNT:',len(get_tender_dashboard()))
print('REVIEW_COUNT:',get_review_dashboard()['count'])
print('UNIFIED_RUNTIME_READY')
