"""Single-host overlap guard using the existing shared storage mount."""
import fcntl
import hashlib
import inspect
from functools import wraps
from pathlib import Path
from app.core.config import settings


def exclusive_task(namespace, argument=None):
    def decorate(fn):
        signature=inspect.signature(fn)
        @wraps(fn)
        def wrapped(*args, **kwargs):
            bound=signature.bind(*args, **kwargs);bound.apply_defaults()
            identity=str(bound.arguments.get(argument, 'all')) if argument else 'all'
            key=hashlib.sha256((namespace+'\0'+identity).encode()).hexdigest()
            root=Path(settings.storage_path)/'execution_locks';root.mkdir(parents=True,exist_ok=True)
            with (root/(key+'.lock')).open('a+') as stream:
                try:fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
                except BlockingIOError:return {'status':'skipped','reason':'already_running'}
                try:return fn(*args,**kwargs)
                finally:fcntl.flock(stream,fcntl.LOCK_UN)
        return wrapped
    return decorate
