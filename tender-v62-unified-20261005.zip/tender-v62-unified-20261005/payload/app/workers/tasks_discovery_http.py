"""Daily inspection of configured marketplace seeds, not tender ingestion."""
from app.workers.celery_app import celery_app
from app.workers.execution_guard import exclusive_task
from app.marketplace_discovery.scout.runner import run_marketplace_scout


@celery_app.task(name="app.workers.tasks_discovery_http.discover_new_sources")
@exclusive_task('site-scout')
def discover_new_sources():
    candidates = run_marketplace_scout(persist=True)
    from app.marketplace_discovery.scout.adapter_sync import sync_marketplace_adapters
    synced=sync_marketplace_adapters()
    failed = sum(any(reason.startswith("probe_failed:") for reason in c.reasons) for c in candidates)
    return {"status": "partial" if failed else "completed", "checked": len(candidates),
            "unavailable": failed, "scope": "catalog_and_seed_urls", "connected":synced["connected"],
            "requires_adapter":synced["recommended"] + synced["new_sources"], "tender_adapters_added": 0}
