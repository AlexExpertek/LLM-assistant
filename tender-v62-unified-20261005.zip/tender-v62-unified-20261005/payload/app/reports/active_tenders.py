"""Unified HTTP/Excel tender report for v6.2.

Shows:
1. fully analysed tenders from TenderItem;
2. ingested/failed/waiting tenders from source raw_payload positions.

One output row = one tender position.
"""

from io import BytesIO
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from app.reports.review_dismissals import is_dismissed
from app.scoring.selection_policy import price_priority, qualifies, mass_kg, material_status
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import joinedload

from app.reports.dashboard_eligibility import (
    evaluate_dashboard_tender,
)
from app.core.logging import get_logger
from app.db.session import SyncSessionLocal
from app.models.database import Lot, Tender, TenderStatus


logger = get_logger(__name__)


REPORT_STATUSES = {
    TenderStatus.CAN_APPLY,
    TenderStatus.NEEDS_CLARIFICATION,
    TenderStatus.MANUAL_REVIEW,
}


def _value(obj: Any) -> Any:
    return obj.value if hasattr(obj, "value") else obj


def _deadline(tender: Tender) -> str:
    if not tender.submission_deadline:
        return ""

    dt = tender.submission_deadline
    if dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(ZoneInfo('Europe/Moscow')).strftime(
        "%d.%m.%Y %H:%M"
    )


def _source_relevance(tender: Tender) -> dict:
    """Return stored relevance or safely rebuild it from source positions."""

    raw = tender.raw_payload or {}

    if not isinstance(raw, dict):
        return {}

    public = raw.get("public") or {}

    if isinstance(public, dict):
        relevance = public.get("relevance")

        if isinstance(relevance, dict) and relevance:
            return relevance

    relevance = raw.get("relevance")

    if isinstance(relevance, dict) and relevance:
        return relevance

    positions = raw.get("positions") or []

    if not isinstance(positions, list) or not positions:
        return {}

    try:
        from app.sources.tender_pro.relevance import (
            analyse_tender_positions,
        )

        return analyse_tender_positions(positions)

    except Exception as exc:
        logger.warning(
            "report_relevance_rebuild_failed",
            tender_id=str(tender.id),
            error=str(exc),
        )
        return {}


def _source_positions(tender: Tender) -> list[dict]:
    raw = tender.raw_payload or {}

    if not isinstance(raw, dict):
        return []

    positions = raw.get("positions") or []

    return [
        item
        for item in positions
        if isinstance(item, dict)
    ]


def _base_row(t: Tender) -> dict:
    relevance = _source_relevance(t)

    processing_status = _value(
        t.processing_status
    ) or ""

    status = _value(t.status) or ""

    if t.analysis_done:
        analysis_state = "Готов"
    elif str(processing_status).upper() == "FAILED":
        analysis_state = "Ошибка анализа"
    else:
        analysis_state = "Ожидает анализа"

    return {
        "id": str(t.id),
        "external_id": t.external_id,
        "source": t.source,
        "title": t.title,
        "customer_name": t.customer_name or "",
        "customer_inn": t.customer_inn or "",
        "law_type": _value(t.law_type) or "",
        "status": status,
        "score": t.score or 0,
        "amount": (
            float(t.amount)
            if t.amount is not None
            else None
        ),
        "currency": t.currency or "RUB",
        "price_priority": price_priority(t.amount,t.currency),
        "deadline_timezone": "Europe/Moscow",
        "region": t.region or "",
        "delivery_place": t.delivery_place or "",
        "source_url": t.source_url or "",
        "submission_deadline": _deadline(t),
        "processing_status": processing_status,
        "analysis_done": bool(t.analysis_done),
        "analysis_state": analysis_state,
        "analysis_version": t.analysis_version or "",
        "notified_bitrix": bool(
            getattr(t, "notified_bitrix", False)
        ),
        "notified_telegram": bool(
            getattr(t, "notified_telegram", False)
        ),
        "relevant_weight_kg": relevance.get(
            "relevant_weight_kg"
        ),
        "weight_status": relevance.get(
            "weight_status"
        ) or "",
        "matched_count": relevance.get(
            "matched_count"
        ) or 0,
    }


def get_active_tenders() -> list[dict]:
    """Return active relevant tenders for HTTP and Excel.

    Analysed tenders use normalized TenderItem rows.
    Not-yet-analysed tenders fall back to raw source positions.
    """

    try:
        with SyncSessionLocal() as session:
            stmt = (
                select(Tender)
                .where(Tender.is_active.is_(True))
                .options(
                    joinedload(Tender.lots)
                    .joinedload(Lot.items),
                    joinedload(Tender.decisions),
                )
                .order_by(
                    Tender.analysis_done.desc(),
                    Tender.score.desc(),
                    Tender.submission_deadline.asc(),
                )
            )

            tenders = (
                session.execute(stmt)
                .unique()
                .scalars()
                .all()
            )

            rows: list[dict] = []

            for t in tenders:
                if is_dismissed(t.source,t.external_id):continue
                deadline=t.submission_deadline
                if deadline and (deadline.replace(tzinfo=timezone.utc) if deadline.tzinfo is None else deadline)<=datetime.now(timezone.utc):continue
                # Do not expose analysed tenders which AI has
                # explicitly classified outside the report statuses.
                if (
                    t.analysis_done
                    and t.status not in REPORT_STATUSES
                ):
                    continue

                decision = (
                    max(
                        t.decisions,
                        key=lambda x: x.created_at,
                    )
                    if t.decisions
                    else None
                )

                base = _base_row(t)

                normalized_items = []

                for lot in t.lots or []:
                    for item in lot.items or []:
                        normalized_items.append(
                            (lot, item)
                        )

                # -----------------------------------------
                # Fully normalized LLM/analysis positions
                # -----------------------------------------
                if normalized_items:
                    for lot, item in normalized_items:
                        row = dict(base)

                        row.update({
                            "lot_number":
                                lot.lot_number or "",
                            "position_number":
                                item.position_number,
                            "product_name":
                                item.name or "",
                            "product_type":
                                item.product_type or "",
                            "alloy":
                                item.alloy or "",
                            "temper":
                                item.temper or "",
                            "thickness_mm":
                                item.thickness_mm,
                            "width_mm":
                                item.width_mm,
                            "length_mm":
                                item.length_mm,
                            "diameter_mm":
                                item.diameter_mm,
                            "quantity":
                                item.quantity,
                            "unit":
                                item.unit or "",
                            "mass_kg":
                                item.mass_kg,
                            "standard":
                                item.standard or "",
                            "delivery_place":
                                item.delivery_place
                                or lot.delivery_place
                                or t.delivery_place
                                or "",
                            "delivery_term":
                                item.delivery_term or "",
                            "payment_terms":
                                item.payment_terms or "",
                            "can_supply":
                                item.can_supply,
                            "supply_reason":
                                item.supply_reason or "",
                            "reasons":
                                decision.reasons
                                if decision else [],
                            "risks":
                                decision.risks
                                if decision else [],
                            "model_version":
                                decision.model_version
                                if decision
                                else t.analysis_version or "",
                            "position_source":
                                "analysis",
                        })

                        rows.append(row)

                    continue

                # -----------------------------------------
                # Source positions before successful LLM
                # -----------------------------------------
                source_positions = _source_positions(t)

                if source_positions:
                    for number, item in enumerate(
                        source_positions,
                        1,
                    ):
                        row = dict(base)

                        quantity = item.get("quantity")
                        unit = item.get("unit") or ""

                        mass_kg = None

                        try:
                            if quantity not in (None, ""):
                                q = float(
                                    str(quantity)
                                    .replace(",", ".")
                                )

                                u = str(unit).lower().strip()

                                if u in (
                                    "кг",
                                    "kg",
                                    "килограмм",
                                    "килограммы",
                                ):
                                    mass_kg = q

                                elif u in (
                                    "т",
                                    "тн",
                                    "тонн",
                                    "тонна",
                                    "ton",
                                    "tons",
                                ):
                                    mass_kg = q * 1000
                        except (
                            TypeError,
                            ValueError,
                        ):
                            mass_kg = None

                        row.update({
                            "lot_number": "",
                            "position_number":
                                item.get(
                                    "position_number"
                                )
                                or item.get(
                                    "position_id"
                                )
                                or number,
                            "product_name":
                                item.get("name") or "",
                            "product_type": "",
                            "alloy": "",
                            "temper": "",
                            "thickness_mm": None,
                            "width_mm": None,
                            "length_mm": None,
                            "diameter_mm": None,
                            "quantity": quantity,
                            "unit": unit,
                            "mass_kg": mass_kg,
                            "standard": "",
                            "delivery_term": "",
                            "payment_terms": "",
                            "can_supply": None,
                            "supply_reason":
                                "Ожидает LLM-анализа",
                            "reasons": [],
                            "risks": [],
                            "model_version":
                                t.analysis_version or "",
                            "position_source":
                                "source",
                        })

                        rows.append(row)

                    continue

                # Tender without positions: keep visible.
                row = dict(base)

                row.update({
                    "lot_number": "",
                    "position_number": "",
                    "product_name": "",
                    "product_type": "",
                    "alloy": "",
                    "temper": "",
                    "thickness_mm": None,
                    "width_mm": None,
                    "length_mm": None,
                    "diameter_mm": None,
                    "quantity": None,
                    "unit": "",
                    "mass_kg": None,
                    "standard": "",
                    "delivery_term": "",
                    "payment_terms": "",
                    "can_supply": None,
                    "supply_reason":
                        "Позиции отсутствуют",
                    "reasons": [],
                    "risks": [],
                    "model_version":
                        t.analysis_version or "",
                    "position_source": "tender",
                })

                rows.append(row)

            return rows

    except Exception as exc:
        logger.exception(
            "get_active_tenders_failed",
            error=str(exc),
        )
        return []


def get_all_tenders_stats() -> dict:
    try:
        with SyncSessionLocal() as session:
            all_tenders = (
                session.execute(
                    select(Tender)
                )
                .scalars()
                .all()
            )

            return {
                "total": len(all_tenders),
                "active": sum(
                    bool(t.is_active)
                    for t in all_tenders
                ),
                "analyzed": sum(
                    bool(t.analysis_done)
                    for t in all_tenders
                ),
                "can_apply": sum(
                    t.status == TenderStatus.CAN_APPLY
                    for t in all_tenders
                ),
                "manual_review": sum(
                    t.status in (
                        TenderStatus.MANUAL_REVIEW,
                        TenderStatus.NEEDS_CLARIFICATION,
                    )
                    for t in all_tenders
                ),
                "not_analyzed_yet": sum(
                    not t.analysis_done
                    for t in all_tenders
                ),
            }

    except Exception as exc:
        logger.exception(
            "get_stats_failed",
            error=str(exc),
        )
        return {}


def generate_excel_report(
    tenders: list[dict],
) -> bytes:
    import openpyxl
    from openpyxl.styles import (
        Alignment,
        Font,
        PatternFill,
    )
    from openpyxl.utils import get_column_letter

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Тендерные позиции"

    headers = [
        "№",
        "Источник",
        "Внешний ID",
        "Заказчик",
        "ИНН",
        "Предмет закупки",
        "Срок подачи",
        "Регион",
        "Место поставки",
        "Позиция",
        "Наименование",
        "Тип продукции",
        "Сплав",
        "Состояние",
        "Толщина, мм",
        "Ширина, мм",
        "Длина, мм",
        "Диаметр, мм",
        "Количество",
        "Ед.",
        "Масса позиции, кг",
        "Релевантная масса тендера, кг",
        "Весовой статус",
        "ГОСТ/ТУ",
        "Релевантная позиция",
        "Score первичного фильтра",
        "Сплав по фильтру",
        "Состояние по фильтру",
        "Можем поставить",
        "Причина по позиции",
        "Статус анализа",
        "Статус ИИ",
        "Балл",
        "Bitrix24",
        "Ссылка",
        "Причины решения",
        "Риски",
        "Версия анализа",
    ]

    fill = PatternFill(
        "solid",
        fgColor="1F4E79",
    )

    font = Font(
        color="FFFFFF",
        bold=True,
    )

    for column, header in enumerate(
        headers,
        1,
    ):
        cell = ws.cell(
            1,
            column,
            header,
        )

        cell.fill = fill
        cell.font = font
        cell.alignment = Alignment(
            horizontal="center",
            vertical="center",
            wrap_text=True,
        )

    for index, tender in enumerate(
        tenders,
        1,
    ):
        can_supply = tender.get(
            "can_supply"
        )

        if can_supply is True:
            can_supply_text = "Да"
        elif can_supply is False:
            can_supply_text = "Нет"
        else:
            can_supply_text = "Уточнить"

        bitrix = (
            "Отправлено"
            if tender.get("notified_bitrix")
            else "Не отправлено"
        )

        try:
            from app.sources.tender_pro.relevance import (
                analyse_position,
            )

            pre_filter = analyse_position(
                tender.get("product_name") or ""
            ) or {}

        except Exception:
            pre_filter = {}

        pre_filter_relevant = (
            "Да"
            if pre_filter.get("relevant")
            else "Нет"
        )

        pre_filter_score = pre_filter.get(
            "score",
            0,
        )

        pre_filter_alloys = ", ".join(
            pre_filter.get("alloys") or []
        )

        pre_filter_tempers = ", ".join(
            pre_filter.get("tempers") or []
        )

        values = [
            index,
            tender.get("source"),
            tender.get("external_id"),
            tender.get("customer_name"),
            tender.get("customer_inn"),
            tender.get("title"),
            tender.get("submission_deadline"),
            tender.get("region"),
            tender.get("delivery_place"),
            tender.get("position_number"),
            tender.get("product_name"),
            tender.get("product_type"),
            tender.get("alloy"),
            tender.get("temper"),
            tender.get("thickness_mm"),
            tender.get("width_mm"),
            tender.get("length_mm"),
            tender.get("diameter_mm"),
            tender.get("quantity"),
            tender.get("unit"),
            tender.get("mass_kg"),
            tender.get("relevant_weight_kg"),
            tender.get("weight_status"),
            tender.get("standard"),
            pre_filter_relevant,
            pre_filter_score,
            pre_filter_alloys,
            pre_filter_tempers,
            can_supply_text,
            tender.get("supply_reason"),
            tender.get("analysis_state"),
            tender.get("status"),
            tender.get("score"),
            bitrix,
            tender.get("source_url"),
            "; ".join(
                tender.get("reasons") or []
            ),
            "; ".join(
                tender.get("risks") or []
            ),
            tender.get("model_version"),
        ]

        for column, value in enumerate(
            values,
            1,
        ):
            ws.cell(
                index + 1,
                column,
                value,
            )

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    ws.row_dimensions[1].height = 38

    for column in range(
        1,
        len(headers) + 1,
    ):
        width = min(
            max(
                12,
                len(headers[column - 1]) + 2,
            ),
            36,
        )

        ws.column_dimensions[
            get_column_letter(column)
        ].width = width

    # Wider text columns.
    for column in (
        "D",
        "F",
        "K",
        "Z",
        "AE",
        "AF",
        "AG",
    ):
        ws.column_dimensions[column].width = 38

    for row in ws.iter_rows(
        min_row=2,
    ):
        for cell in row:
            cell.alignment = Alignment(
                vertical="top",
                wrap_text=True,
            )

    out = BytesIO()
    wb.save(out)

    return out.getvalue()


def format_report_text(
    tenders: list[dict],
) -> str:
    if not tenders:
        return "Активных тендеров нет."

    unique = len({
        item["id"]
        for item in tenders
    })

    return (
        f"Активных тендеров: {unique}; "
        f"товарных позиций: {len(tenders)}."
    )


format_report_summary = format_report_text


def get_tender_dashboard() -> list[dict]:
    """
    Aggregate position-level active tender rows into one record per tender.

    Excel keeps using get_active_tenders() with one row per position.
    HTTP dashboard uses this function with one row per tender.

    Final HTTP output is additionally protected by
    evaluate_dashboard_tender(): a tender is shown only when at least
    one individual aluminium position satisfies the business threshold.
    """

    rows = get_active_tenders()

    grouped: dict[str, dict] = {}

    for row in rows:

        tender_id = str(
            row.get("id")
            or row.get("external_id")
            or ""
        )

        if not tender_id:
            continue

        if tender_id not in grouped:

            tender = dict(row)

            #
            # Dashboard object represents the whole tender.
            # Position-specific fields must live only inside "positions".
            #
            for field in (
                "lot_number",
                "position_number",
                "product_name",
                "product_type",
                "alloy",
                "temper",
                "thickness_mm",
                "width_mm",
                "length_mm",
                "diameter_mm",
                "quantity",
                "unit",
                "mass_kg",
                "standard",
                "delivery_term",
                "payment_terms",
                "can_supply",
                "supply_reason",
                "position_source",
            ):
                tender.pop(
                    field,
                    None,
                )

            tender["positions"] = []
            tender["positions_count"] = 0

            #
            # Existing source-level weight is retained only as
            # informational metadata.
            #
            # Dashboard admission itself is based on ONE individual
            # position inside evaluate_dashboard_tender().
            #
            tender[
                "relevant_weight_kg"
            ] = row.get(
                "relevant_weight_kg"
            )

            tender[
                "weight_status"
            ] = row.get(
                "weight_status"
            )

            grouped[
                tender_id
            ] = tender

        tender = grouped[
            tender_id
        ]

        position_name = (
            row.get(
                "product_name"
            )
            or row.get(
                "name_product"
            )
            or ""
        )

        pre_filter = {}

        try:
            from app.sources.tender_pro.relevance import (
                analyse_position,
            )

            pre_filter = (
                analyse_position(
                    position_name
                )
                or {}
            )

        except Exception as exc:

            logger.warning(
                "dashboard_position_relevance_failed",
                tender_id=tender_id,
                position_name=position_name,
                error=str(exc),
            )

        position = {
            "position_number":
                row.get(
                    "position_number"
                ),

            "name":
                position_name,

            "name_product":
                position_name,

            "product_type":
                row.get(
                    "product_type"
                ),

            "alloy":
                row.get(
                    "alloy"
                ),

            "temper":
                row.get(
                    "temper"
                ),

            "thickness_mm":
                row.get(
                    "thickness_mm"
                ),

            "width_mm":
                row.get(
                    "width_mm"
                ),

            "quantity":
                row.get(
                    "quantity"
                ),

            "unit":
                row.get(
                    "unit"
                ),

            "mass_kg":
                row.get(
                    "mass_kg"
                ),

            "can_supply":
                row.get(
                    "can_supply"
                ),

            "supply_reason":
                row.get(
                    "supply_reason"
                ),

            #
            # Deterministic pre-filter result.
            #
            "pre_filter_relevant":
                bool(
                    pre_filter.get(
                        "relevant"
                    )
                ),

            "pre_filter_score":
                pre_filter.get(
                    "score",
                    0,
                ),

            "pre_filter_products":
                pre_filter.get(
                    "products",
                    [],
                ),

            "pre_filter_alloys":
                pre_filter.get(
                    "alloys",
                    [],
                ),

            "pre_filter_tempers":
                pre_filter.get(
                    "tempers",
                    [],
                ),

            "pre_filter_reasons":
                pre_filter.get(
                    "reasons",
                    [],
                ),
        }

        tender[
            "positions"
        ].append(
            position
        )

    #
    # Finalize position counts.
    #
    dashboard_candidates = list(
        grouped.values()
    )

    for tender in dashboard_candidates:

        tender[
            "positions_count"
        ] = len(
            tender[
                "positions"
            ]
        )

    #
    # Final HTTP eligibility gate.
    #
    eligible_dashboard = []

    for tender in dashboard_candidates:

        eligibility = (
            evaluate_dashboard_tender(
                tender
            )
        )

        if not eligibility.eligible:

            logger.info(
                "dashboard_tender_filtered",
                source=tender.get(
                    "source"
                ),
                external_id=tender.get(
                    "external_id"
                ),
                reason=eligibility.reason,
            )

            continue

        tender[
            "dashboard_eligibility_reason"
        ] = eligibility.reason

        tender['matched_count'] = sum(p.get('can_supply') is True and qualifies(p) for p in tender['positions'])
        tender['relevant_weight_kg'] = mass_kg(eligibility.qualifying_position)
        tender['weight_status'] = 'ok'
        tender['weight_basis'] = 'one_qualifying_position'
        for position in tender['positions']:
            position['pre_filter_relevant'] = material_status(position) is True
        eligible_dashboard.append(tender)

    priority_order={'high':0,'normal':1,'price_unknown':2,'currency_review':3,'low':4}
    return sorted(eligible_dashboard,key=lambda t:priority_order.get(t.get('price_priority'),5))
