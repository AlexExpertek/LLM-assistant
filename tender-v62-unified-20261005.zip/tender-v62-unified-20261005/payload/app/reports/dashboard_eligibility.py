"""Dashboard admission uses the same mass criterion as scoring."""
from dataclasses import dataclass
from app.scoring.selection_policy import qualifies, mass_kg

@dataclass
class DashboardEligibility:
    eligible: bool
    reason: str
    qualifying_position: dict | None = None

def evaluate_dashboard_tender(tender):
    if not tender.get('analysis_done') or tender.get('status') not in ('can_apply',):
        return DashboardEligibility(False, 'analysis_not_approved')
    for pos in tender.get('positions') or []:
        if pos.get('can_supply') is True and qualifies(pos):
            return DashboardEligibility(True, f'position_weight_ok:{mass_kg(pos):g}kg', pos)
    return DashboardEligibility(False, 'no_single_position_above_threshold')
