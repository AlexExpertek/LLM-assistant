from __future__ import annotations

import re
from typing import Any


PRODUCT_WORDS = (
    "лента",
    "лист",
    "рулон",
    "рулонный",
    "полоса",
    "штрипс",
    "плита",
    "профиль",
    "труба",
    "пруток",
    "уголок",
    "тавp",
    "тавр",
    "двутавр",
)

ALLOYS = (
    # Российские марки
    "ад00",
    "ад0",
    "ад1",
    "ад31е",
    "ад31",
    "ад33",
    "ад35",
    "амг2",
    "амг3",
    "амг5",
    "амг6",
    "амц",
    "д16ат",
    "д16т",
    "д16",
    "вд1",
    "а5е",
    "а5",
    "а6",
    "а7",
    "а0",
    "1105",
    "1561",

    # EN / AA
    "1050a",
    "1050",
    "1070",
    "1100",
    "1235",
    "2017",
    "2024",
    "3003",
    "3105",
    "5005",
    "5052",
    "5083",
    "5182",
    "5251",
    "5754",
    "6060",
    "6061",
    "6063",
    "6082",
)

TEMPER_PATTERNS = (
    r"\bм\b",
    r"\bм1\b",
    r"\bм2\b",
    r"\bм3\b",
    r"\bн\b",
    r"\bн1\b",
    r"\bн2\b",
    r"\bн3\b",
    r"\bн4\b",
    r"\bт\b",
    r"\bт1\b",
    r"\bт4\b",
    r"\bт5\b",
    r"\bт6\b",
    r"\bт66\b",
    r"\bo\b",
    r"\bh12\b",
    r"\bh14\b",
    r"\bh16\b",
    r"\bh18\b",
    r"\bh22\b",
    r"\bh24\b",
    r"\bh26\b",
    r"\bh32\b",
    r"\bh34\b",
    r"\bh36\b",
    r"\bh111\b",
    r"\bh112\b",
)

EXCLUDE_WORDS = (
    "кабель",
    "кабельный",
    "провод",
    "аввг",
    "сип ",
    "шина грузовая",
    "шина легковая",
    "шина автомобильная",
    "шина автопогрузчика",
    "шина пневматическая",
    "шина цельнолитая",
    "покрышка",
    "колесо",
)


def normalize(text: Any) -> str:
    return (
        str(text or "")
        .lower()
        .replace("ё", "е")
        .replace("×", "х")
        .strip()
    )


def _unique(values: list[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()

    for value in values:
        key = value.lower()

        if key in seen:
            continue

        seen.add(key)
        result.append(value)

    return result


def detect_exclusions(text: Any) -> list[str]:
    normalized = normalize(text)
    found: list[str] = []

    for word in EXCLUDE_WORDS:
        if word in normalized:
            found.append(word)

    # Типовые размеры автомобильных шин:
    # 275/65R17, 10.00R20 и т.п.
    if re.search(
        r"\b\d{2,3}/\d{2,3}r\d{2}\b",
        normalized,
        flags=re.I,
    ):
        found.append("tyre_size")

    return _unique(found)


def detect_products(text: Any) -> list[str]:
    normalized = normalize(text)
    found: list[str] = []

    for product in PRODUCT_WORDS:
        if product in normalized:
            found.append(product)

    # "Шина" является допустимым алюминиевым полуфабрикатом,
    # но только при наличии металлического/электротехнического контекста.
    if "шина" in normalized:
        if (
            "алюмини" in normalized
            or "электротехническ" in normalized
            or "токопроводящ" in normalized
            or "токоведущ" in normalized
        ):
            found.append("шина")

    return _unique(found)



def detect_alloys(text: Any) -> list[str]:
    """
    Detect aluminium alloy designations without confusing
    standard numbers/years with numeric EN/AA alloy grades.

    Examples:
        ГОСТ 1050-2013     -> NOT alloy 1050
        ГОСТ Р 57837-2017    -> NOT alloy 2017
        ГОСТ 21631-2023     -> NOT alloy 2023

        Лист 5083 H111     -> alloy 5083
        EN AW-5754 H22     -> alloy 5754
        Сплав 6063 T6        -> alloy 6063
        АД31Т1             -> alloy АД31
        Д16Т                 -> alloy Д16
    """

    normalized = normalize(text)

    #
    # Remove standard identifiers BEFORE searching for alloy grades.
    #
    # Numeric aluminium grades such as 1050, 2017 and 2024 can also
    # occur as GOST numbers or revision years.
    #
    searchable = re.sub(
        r"""
        \bгост
        (?:\s*р)?
        \s*
        \d+(?:\.\d+)*
        (?:-\d{2,4})?
        \b
        """,
        " ",
        normalized,
        flags=re.I | re.X,
    )

    searchable = re.sub(
        r"""
        \bту
        \s*
        [0-9][0-9a-zа-я.\-/]*
        """,
        " ",
        searchable,
        flags=re.I | re.X,
    )

    #
    # Also mask ISO / EN standard references when they are explicitly
    # written as standards rather than alloy designations.
    #
    searchable = re.sub(
        r"""
        \b(?:iso|din)
        \s*
        \d+(?:[-:]\d+)*
        """,
        " ",
        searchable,
        flags=re.I | re.X,
    )

    found: list[str] = []

    alloys = sorted(
        ALLOYS,
        key=len,
        reverse=True,
    )

    occupied: list[
        tuple[int, int]
    ] = []

    for alloy in alloys:

        pattern = (
            rf"(?<![а-яa-z0-9])"
            rf"{re.escape(alloy)}"
            rf"(?=(?:м\d*|н\d*|т\d*|h\d+|o)?"
            rf"(?![а-яa-z0-9]))"
        )

        for match in re.finditer(
            pattern,
            searchable,
            flags=re.I,
        ):

            span = match.span()

            overlaps = any(
                span[0] >= start
                and span[1] <= end
                for start, end
                in occupied
            )

            if overlaps:
                continue

            found.append(
                alloy
            )

            occupied.append(
                span
            )

    return _unique(
        found
    )

def quantity_to_kg(quantity: Any, unit: Any) -> float | None:
    try:
        value = float(
            str(quantity or "")
            .replace(",", ".")
            .replace(" ", "")
        )
    except (TypeError, ValueError):
        return None

    normalized_unit = normalize(unit)

    if normalized_unit in {
        "кг",
        "kg",
        "килограмм",
        "килограммов",
    }:
        return value

    if normalized_unit in {
        "т",
        "тн",
        "тонна",
        "тонн",
        "тонны",
        "ton",
        "tons",
    }:
        return value * 1000.0

    return None



def calculate_relevant_weight_kg(
    positions: list[dict[str, Any]],
) -> float:
    """
    Return the largest relevant position weight.

    CRITICAL BUSINESS RULE:
    weights of different product positions are NEVER summed.

    Examples:
        200 kg + 200 kg + 200 kg
            -> relevant_weight_kg = 200
            -> NOT 600

        700 kg aluminium sheet + 56 kg busbar
            -> relevant_weight_kg = 700
    """

    max_weight = 0.0

    for position in positions:

        quantity_kg = (
            quantity_to_kg(
                position.get("quantity"),
                position.get("unit"),
            )
        )

        if quantity_kg is None:
            continue

        max_weight = max(
            max_weight,
            quantity_kg,
        )

    return max_weight


def detect_tempers(text: Any) -> list[str]:
    normalized = normalize(text)
    found: list[str] = []

    # Отдельно записанное состояние:
    # АМг2 М
    # 5754 H22
    for pattern in TEMPER_PATTERNS:
        for match in re.finditer(
            pattern,
            normalized,
            flags=re.I,
        ):
            found.append(match.group(0))

    # Состояние, присоединённое непосредственно к сплаву:
    # АМг5М
    # АД31Т1
    # Д16Т
    # 6063T6
    # 5754H22
    for alloy in sorted(
        ALLOYS,
        key=len,
        reverse=True,
    ):
        pattern = (
            rf"(?<![а-яa-z0-9])"
            rf"{re.escape(alloy)}"
            rf"(м\d*|н\d*|т\d*|h\d+|o)"
            rf"(?![а-яa-z0-9])"
        )

        for match in re.finditer(
            pattern,
            normalized,
            flags=re.I,
        ):
            found.append(match.group(1))

    return _unique(found)


def analyse_position(text: Any) -> dict[str, Any]:
    normalized = normalize(text)

    exclusions = detect_exclusions(normalized)
    products = detect_products(normalized)
    alloys = detect_alloys(normalized)
    tempers = detect_tempers(normalized)

    aluminium_context = (
        "алюмини" in normalized
        or "aluminium" in normalized
        or "aluminum" in normalized
    )

    if exclusions:
        return {
            "relevant": False,
            "score": -100,
            "products": products,
            "alloys": alloys,
            "tempers": tempers,
            "exclusions": exclusions,
            "reasons": [
                "excluded:" + ",".join(exclusions)
            ],
        }

    score = 0
    reasons: list[str] = []

    if products:
        score += 40
        reasons.append(
            "product:" + ",".join(products)
        )

    if aluminium_context:
        score += 30
        reasons.append("aluminium")

    if alloys:
        score += 30
        reasons.append(
            "alloy:" + ",".join(alloys)
        )

    if tempers and (
        aluminium_context
        or alloys
    ):
        score += 10
        reasons.append(
            "temper:" + ",".join(tempers)
        )

    # Основное правило релевантности:
    #
    # 1. алюминиевый полуфабрикат:
    #    "лист алюминиевый"
    #
    # ИЛИ
    #
    # 2. полуфабрикат + известная марка:
    #    "лента А5 М"
    #    "труба АМг5М"
    #
    valid_context = (
        bool(products)
        and (
            aluminium_context
            or bool(alloys)
        )
    )

    relevant = (
        valid_context
        and score >= 60
    )

    if not valid_context:
        reasons.append(
            "no_aluminium_product_context"
        )

    return {
        "relevant": relevant,
        "score": score,
        "products": products,
        "alloys": alloys,
        "tempers": tempers,
        "exclusions": exclusions,
        "reasons": reasons,
    }


def analyse_tender_positions(
    positions: list[dict[str, Any]],
) -> dict[str, Any]:
    matched: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []

    best_score = 0

    for position in positions:
        name = position.get("name") or ""

        analysis = analyse_position(name)

        record = {
            **position,
            "relevance": analysis,
        }

        if analysis["relevant"]:
            matched.append(record)
            best_score = max(
                best_score,
                int(analysis["score"]),
            )
        else:
            rejected.append(record)

    known_weight_positions = 0
    unknown_weight_positions = 0
    relevant_weight_kg = 0.0

    for position in matched:
        quantity_kg = quantity_to_kg(
            position.get("quantity"),
            position.get("unit"),
        )

        if quantity_kg is None:
            unknown_weight_positions += 1
            continue

        known_weight_positions += 1
        relevant_weight_kg = max(relevant_weight_kg, quantity_kg)

    minimum_weight_kg = 500.0

    if known_weight_positions == 0 and matched:
        weight_status = "unknown"
        weight_ok = True
    elif relevant_weight_kg >= minimum_weight_kg:
        weight_status = "ok"
        weight_ok = True
    elif unknown_weight_positions > 0:
        weight_status = "unknown"
        weight_ok = True
    else:
        weight_status = "below_minimum"
        weight_ok = False

    return {
        "relevant": bool(matched) and weight_ok,
        "score": best_score,
        "matched_positions": matched,
        "rejected_positions": rejected,
        "total_positions": len(positions),
        "matched_count": len(matched),
        "relevant_weight_kg": relevant_weight_kg,
        "minimum_weight_kg": minimum_weight_kg,
        "weight_basis": "maximum_single_position",
        "weight_status": weight_status,
        "known_weight_positions": known_weight_positions,
        "unknown_weight_positions": unknown_weight_positions,
        "weight_ok": weight_ok,
    }
