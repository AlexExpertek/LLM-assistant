"""HTTP client for the official Tender.Pro public integration API.

Official references:
- https://help.tender.pro/vigruzka_lenti_procedur.html
- https://www.tender.pro/api/docs/smd

The API key is supplied only through TENDER_PRO_API_KEY.
"""
from __future__ import annotations

from typing import Any

import httpx
from app.sources.request_pacing import tender_pro_request_hook

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

BASE_URL = "https://www.tender.pro/api"


class TenderProAPIError(RuntimeError):
    pass


class TenderProClient:
    """Small, defensive client around documented Tender.Pro JSON methods."""

    def __init__(self, api_key: str | None = None, timeout: float | None = None):
        self.api_key = api_key or settings.tender_pro_api_key
        self.timeout = timeout or settings.tender_pro_request_timeout

    def _get(self, method: str, **params: Any) -> Any:
        if not self.api_key:
            raise TenderProAPIError("TENDER_PRO_API_KEY is not configured")

        import logging
        class RedactKey(logging.Filter):
            def filter(self, record):
                import re
                msg=record.getMessage()
                record.msg=re.sub(r'([?&]_key=)[^&\s"\']+',r'\1[REDACTED]',msg)
                record.args=()
                return True
        http_logger=logging.getLogger('httpx')
        if not getattr(http_logger,'_std_key_redaction',False):
            http_logger.addFilter(RedactKey());http_logger._std_key_redaction=True
        query = {k: v for k, v in params.items() if v is not None}
        query["_key"] = self.api_key
        url = f"{BASE_URL}/{method}.json"

        try:
            with httpx.Client(
                event_hooks={"request": [tender_pro_request_hook]},
                timeout=self.timeout,
                follow_redirects=True,
                headers={"Accept": "application/json", "User-Agent": "TenderAIPlatform/6.1"},
            ) as client:
                response = client.get(url, params=query)
                response.raise_for_status()
                payload = response.json()
        except httpx.HTTPStatusError as exc:
            status = exc.response.status_code if exc.response is not None else None
            logger.error("tender_pro_http_status", method=method, status=status)
            raise TenderProAPIError(f"Tender.Pro {method}: HTTP {status}") from None
        except (httpx.HTTPError, ValueError) as exc:
            logger.error("tender_pro_request_failed", method=method, error_type=type(exc).__name__)
            raise TenderProAPIError(f"Tender.Pro {method}: {type(exc).__name__}") from None

        # Some Tender.Pro methods may wrap successful data in result/data.
        if isinstance(payload, dict):
            # Do not silently swallow a clearly reported API error.
            error = payload.get("error") or payload.get("err")
            if error and not payload.get("result") and not payload.get("data"):
                raise TenderProAPIError(f"Tender.Pro {method}: API reported an error")
        return payload

    @staticmethod
    def unwrap_list(payload: Any) -> list[dict[str, Any]]:
        if isinstance(payload, list):
            return [x for x in payload if isinstance(x, dict)]
        if not isinstance(payload, dict):
            return []

        for key in ("result", "tenders", "data", "rows", "items"):
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
            if isinstance(value, dict):
                for nested_key in ("rows", "items", "tenders", "data"):
                    nested = value.get(nested_key)
                    if isinstance(nested, list):
                        return [x for x in nested if isinstance(x, dict)]
        return []

    @staticmethod
    def unwrap_object(payload: Any) -> dict[str, Any]:
        """Unwrap Tender.Pro object responses such as result -> data."""
        if not isinstance(payload, dict):
            return {}

        current = payload

        for _ in range(4):
            if not isinstance(current, dict):
                return {}

            if isinstance(current.get("result"), dict):
                current = current["result"]
                continue

            if isinstance(current.get("data"), dict):
                current = current["data"]
                continue

            if isinstance(current.get("tender"), dict):
                current = current["tender"]
                continue

            break

        return current if isinstance(current, dict) else {}

    def list_tenders(
        self,
        max_rows: int | None = None,
        open_only: bool | None = None,
    ) -> list[dict[str, Any]]:
        """Return Tender.Pro procedures feed with pagination."""

        requested = max_rows or settings.tender_pro_max_rows
        requested = max(1, int(requested))

        page_size = min(200, requested)

        is_open_only = (
            settings.tender_pro_open_only
            if open_only is None
            else open_only
        )

        results: list[dict[str, Any]] = []
        seen_ids: set[str] = set()

        offset = 0

        while len(results) < requested:
            remaining = requested - len(results)
            current_page_size = min(page_size, remaining)

            payload = self._get(
                "_info.tenderlist_by_set",
                set_id=7964,
                set_type_id=2,
                max_rows=current_page_size,
                offset=offset,
                open_only="t" if is_open_only else "f",
            )

            page = self.unwrap_list(payload)

            if not page:
                break

            added = 0

            for item in page:
                tender_id = item.get("id")

                if tender_id is None:
                    continue

                tender_id_str = str(tender_id)

                if tender_id_str in seen_ids:
                    continue

                seen_ids.add(tender_id_str)
                results.append(item)
                added += 1

                if len(results) >= requested:
                    break

            if len(page) < current_page_size:
                break

            if added == 0:
                break

            offset += current_page_size

        return results

    def tender_info(self, tender_id: str | int, company_id: str | int) -> dict[str, Any]:
        """Return documented tender details by tender id + company id."""
        payload = self._get("_tender.info", id=tender_id, company_id=company_id)
        return self.unwrap_object(payload)


    def public_tender_page(self, tender_id: str | int) -> dict[str, Any]:
        """Parse public Tender.Pro page for positions and document metadata."""
        import re
        from urllib.parse import urljoin

        from bs4 import BeautifulSoup

        url = f"https://www.tender.pro/api/tender/{tender_id}/view_public"

        try:
            with httpx.Client(
                event_hooks={"request": [tender_pro_request_hook]},
                timeout=self.timeout,
                follow_redirects=True,
                headers={
                    "Accept": "text/html",
                    "User-Agent": "TenderAIPlatform/6.2",
                },
            ) as client:
                response = client.get(url)
                response.raise_for_status()
        except httpx.HTTPError as exc:
            raise TenderProAPIError(
                f"Tender.Pro public tender {tender_id}: {exc}"
            ) from None

        soup = BeautifulSoup(response.text, "html.parser")

        company_id = None

        company_link = soup.find(
            "a",
            href=lambda h: h and re.search(
                r"/api/company/\d+/view",
                h,
            ),
        )

        if company_link:
            match = re.search(
                r"/api/company/(\d+)/view",
                company_link.get("href", ""),
            )
            if match:
                company_id = match.group(1)

        positions: list[dict[str, Any]] = []
        documents: list[dict[str, Any]] = []

        goods = soup.find(id="tGoods")

        if goods:
            for row in goods.select(".table-history-row"):
                link = row.find(
                    "a",
                    href=lambda h: h and "/api/position/" in h,
                )

                if not link:
                    continue

                href = link.get("href", "")
                match = re.search(r"/api/position/(\d+)/view", href)

                if not match:
                    continue

                cols = row.select(".table-history-col")

                quantity = None
                unit = None

                if len(cols) >= 4:
                    quantity = cols[-2].get_text(" ", strip=True)
                    unit = cols[-1].get_text(" ", strip=True)

                positions.append(
                    {
                        "position_id": int(match.group(1)),
                        "name": link.get_text(" ", strip=True),
                        "quantity": quantity,
                        "unit": unit,
                        "url": urljoin("https://www.tender.pro", href),
                    }
                )

        docs = soup.find(id="tender_docs")

        if docs:
            for link in docs.find_all("a", href=True):
                title = (
                    link.get("title")
                    or link.get_text(" ", strip=True)
                ).strip()

                if not title:
                    continue

                href = link.get("href", "")

                documents.append(
                    {
                        "name": title,
                        "url": urljoin("https://www.tender.pro", href),
                        "direct_download": False,
                    }
                )

        return {
            "tender_id": int(tender_id),
            "company_id": company_id,
            "public_url": url,
            "positions": positions,
            "documents": documents,
        }
