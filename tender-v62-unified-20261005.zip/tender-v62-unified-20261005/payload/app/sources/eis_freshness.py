"""Conservative eligibility gate for automatic EIS processing, no network calls."""
from datetime import datetime, timezone

CLOSED = {'работа комиссии', 'закупка завершена', 'закупка отменена',
          'определение поставщика завершено'}

def eligibility(source, deadline=None, raw=None, active=True, now=None):
    if source != 'zakupki_gov_ru':
        return None
    if active is False:
        return 'inactive'
    raw = raw if isinstance(raw, dict) else {}
    search = raw.get('search_item') or {}
    status = str(raw.get('procurement_status') or search.get('status') or '').strip().lower()
    if status in CLOSED:
        return 'closed_stage'
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    if deadline is not None and raw.get('stage') != 'search':
        try:
            dt = deadline if isinstance(deadline, datetime) else datetime.fromisoformat(str(deadline).replace('Z', '+00:00'))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            if dt <= now:
                return 'deadline_expired'
            return None
        except (TypeError, ValueError):
            pass
    # Search dates have no time/zone: hydrate rather than invent midnight UTC.
    if raw.get('stage') == 'search':
        return 'needs_detail'
    # A past search status alone cannot prove the current card is still open.
    return 'freshness_unknown'

def gate_saved_tender(session, tender_id):
    from app.models.database import Tender, TenderStatus
    tender = session.get(Tender, tender_id)
    if tender is None:
        return {'status': 'skipped', 'reason': 'tender_not_found', 'tender_id': str(tender_id)}
    from app.reports.review_dismissals import is_dismissed
    if is_dismissed(tender.source, tender.external_id):
        return {'status':'skipped','reason':'manually_dismissed','tender_id':str(tender_id)}
    if tender.source == 'b2b_center':
        deadline = tender.submission_deadline
        if not tender.is_active:
            return {'status':'skipped','reason':'inactive','tender_id':str(tender_id)}
        if deadline is None or (deadline.replace(tzinfo=timezone.utc) if deadline.tzinfo is None else deadline) <= datetime.now(timezone.utc):
            return {'status':'skipped','reason':'deadline_unknown_or_expired','tender_id':str(tender_id)}
    reason = eligibility(tender.source, tender.submission_deadline, tender.raw_payload, tender.is_active)
    if reason is None:
        return None
    if reason in ('inactive', 'closed_stage', 'deadline_expired'):
        tender.is_active = False
    elif not tender.analysis_done:
        tender.status = TenderStatus.MANUAL_REVIEW
    session.commit()
    return {'status': 'skipped', 'reason': reason, 'tender_id': str(tender_id)}
