"""Single-host, cross-process pacing on the shared storage volume."""
import fcntl
import time
from pathlib import Path
from app.core.config import settings


def tender_pro_request_hook(request):
    root=Path(settings.storage_path)/'request_pacing';root.mkdir(parents=True,exist_ok=True)
    with (root/'tender_pro.lock').open('a+') as f:
        fcntl.flock(f,fcntl.LOCK_EX)
        try:
            f.seek(0)
            try: last=float(f.read() or '0')
            except ValueError:last=0
            now=time.monotonic()
            delay=last+1.1-now
            if 0<delay<=2:time.sleep(delay)
            f.seek(0);f.truncate();f.write(str(time.monotonic()));f.flush()
        finally:fcntl.flock(f,fcntl.LOCK_UN)
