"""Bounded public HTML retrieval for discovered URLs. No private network targets."""
import ipaddress
import socket
from urllib.parse import urlsplit, urljoin
import httpx


def validate_url(url):
    p=urlsplit(url)
    if p.scheme!='https' or not p.hostname or p.username or p.password or p.port not in (None,443):
        raise ValueError('Only public HTTPS URLs are supported')
    addresses=socket.getaddrinfo(p.hostname,443,type=socket.SOCK_STREAM)
    if not addresses or any(not ipaddress.ip_address(row[4][0]).is_global for row in addresses):
        raise ValueError('Private address rejected')
    return p._replace(fragment='').geturl()


def get_html(url,timeout=20):
    with httpx.Client(timeout=timeout,follow_redirects=False,trust_env=False,
        headers={'User-Agent':'TenderAIPlatform/6.2','Accept':'text/html','Accept-Language':'ru'}) as client:
        for _ in range(4):
            url=validate_url(url)
            with client.stream('GET',url) as r:
                if r.is_redirect:
                    url=urljoin(url,r.headers.get('location',''));continue
                r.raise_for_status()
                if 'text/html' not in r.headers.get('content-type','').lower():raise ValueError('Not HTML')
                chunks=[];size=0
                for chunk in r.iter_bytes():
                    size+=len(chunk)
                    if size>2_000_000:raise ValueError('HTML size limit')
                    chunks.append(chunk)
                return b''.join(chunks).decode(r.encoding or 'utf-8',errors='replace')
    raise ValueError('Redirect limit')
