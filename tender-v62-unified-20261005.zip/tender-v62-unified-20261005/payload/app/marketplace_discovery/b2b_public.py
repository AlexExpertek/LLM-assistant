"""Public B2B positions. Follow only observed same-procedure links; no sign-in bypass."""
import re
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlsplit, parse_qs
from bs4 import BeautifulSoup
import httpx
from app.marketplace_discovery.b2b_center import HEADERS, _parse_datetime
from app.sources.schemas import SourceTender

MAX_HTML_BYTES = 3_000_000

@dataclass
class PublicCard:
    positions: list[dict] = field(default_factory=list)
    expected_count: int | None = None
    complete: bool = False
    documents_restricted: bool = False
    reason: str = 'positions_unavailable'
    deadline: object = None
    all_positions_required: bool = False
    positions_url: str | None = None


def safe_url(url, external_id):
    p = urlsplit(url)
    if p.scheme != 'https' or p.hostname not in ('www.b2b-center.ru','b2b-center.ru') or p.username or p.password or p.port not in (None,443):
        raise ValueError('Unexpected B2B host')
    if not re.search(r'/tender-' + re.escape(str(external_id)) + r'/',p.path):
        raise ValueError('Unexpected B2B procedure identity')
    return p._replace(fragment='').geturl()


def parse_page(html):
    soup = BeautifulSoup(html,'html.parser')
    for node in soup(['script','style','nav','footer']): node.decompose()
    text = soup.get_text(' ',strip=True)
    if any(x in text.lower() for x in ('подтвердите, что вы','access denied','доступ ограничен','verify you are human')):
        raise ValueError('B2B access challenge')
    count = re.search(r'(?:Закупочные\s+позиции|Позиции|Количество\s+позиций)\s*[•—–:\-]?\s*(\d+)',text,re.I)
    rows = []
    for table in soup.find_all('table'):
        indexes = None
        for tr in table.find_all('tr'):
            cols = [c.get_text(' ',strip=True) for c in tr.find_all(['th','td'],recursive=False)]
            if not cols: continue
            lower=[v.lower() for v in cols]
            if 'наименование' in lower and 'количество' in lower:
                unit = next((i for i,v in enumerate(lower) if v.startswith(('единиц','ед.'))),None)
                if unit is not None: indexes=(lower.index('наименование'),lower.index('количество'),unit)
                continue
            if indexes is None or max(indexes) >= len(cols) or not re.fullmatch(r'\d+[.]?',cols[0]): continue
            n,q,u=indexes
            rows.append({'position_number':int(cols[0].rstrip('.')), 'name':cols[n], 'quantity':cols[q], 'unit':cols[u]})
    links=[(a.get_text(' ',strip=True), a['href']) for a in soup.find_all('a',href=True)]
    deadline=re.search(r'(?:Дата окончания подачи заявок\s*:?|до)\s*(\d{2}\.\d{2}\.\d{4}\s+\d{2}:\d{2})',text,re.I)
    return text, rows, int(count.group(1)) if count else None, links, _parse_datetime(deadline.group(1)) if deadline else None


def fetch_public(item, verify=True, timeout=30, client=None):
    own=client is None
    client=client or httpx.Client(verify=verify,timeout=timeout,follow_redirects=False,headers=HEADERS)
    def read(url):
        url=safe_url(url,item.external_id)
        for _ in range(4):
            with client.stream('GET',url) as response:
                if response.is_redirect:
                    url=safe_url(urljoin(url,response.headers.get('location','')),item.external_id)
                    continue
                response.raise_for_status()
                chunks=[]; size=0
                for b in response.iter_bytes():
                    size+=len(b)
                    if size>MAX_HTML_BYTES: raise ValueError('B2B page too large')
                    chunks.append(b)
                encoding=response.encoding or 'utf-8'
                return b''.join(chunks).decode(encoding,errors='replace'), url
        raise ValueError('B2B redirect limit')
    try:
        html,url=read(item.source_url)
        text,rows,count,links,deadline=parse_page(html)
        result=PublicCard(expected_count=count,deadline=deadline,documents_restricted=bool(re.search(r'документаци.{0,100}доступно зарегистрированным',text,re.I)),
            all_positions_required='по всем позициям лота' in text.lower())
        seen={}; pending=[]; visited={url}
        def add_rows(rows):
            for row in rows:
                n=row['position_number']
                if n in seen and seen[n]!=row: raise ValueError('B2B conflicting position rows')
                seen[n]=row
        def add_links(links, base):
            for label,href in links:
                target=urljoin(base,href)
                try: target=safe_url(target,item.external_id)
                except (ValueError,TypeError): continue
                if parse_qs(urlsplit(target).query).get('action')==['positions'] and target not in visited and target not in pending:
                    pending.append(target)
        add_rows(rows);add_links(links,url)
        for _ in range(10):
            if not pending: break
            page=pending.pop(0);visited.add(page)
            html,final=read(page)
            _,more,advertised,links,_=parse_page(html)
            if result.expected_count is None: result.expected_count=advertised
            if not more: continue
            result.positions_url=final
            add_rows(more);add_links(links,final)
            if result.expected_count and len(seen)>=result.expected_count: break
        result.positions=[seen[k] for k in sorted(seen)]
        result.complete=bool(result.expected_count and len(seen)==result.expected_count and set(seen)==set(range(1,result.expected_count+1)))
        result.reason='public_positions_complete' if result.complete else ('public_positions_incomplete' if seen else 'positions_require_browser_or_login')
        return result
    finally:
        if own: client.close()


def to_source(item, card):
    from app.scoring.selection_policy import VERSION
    return SourceTender(source=item.platform, external_id=str(item.external_id), title=item.title,
        customer_name=item.customer_name,amount=item.amount,law_type='commercial',
        publish_date=item.publish_date,submission_deadline=card.deadline or item.deadline,
        source_url=safe_url(item.source_url,item.external_id),
        raw_payload={'stage':'detail','positions':card.positions,'selection_version':VERSION,
            'b2b_public':{'complete':card.complete,'expected_count':card.expected_count,
                'documents_restricted':card.documents_restricted,'reason':card.reason,
                'all_positions_required':card.all_positions_required,'positions_url':card.positions_url},
            'review_reason': None if card.complete else 'Полный список позиций недоступен: требуется проверка на площадке'})


def prepare_public_snapshot(tender):
    """Persist the public table as a labelled evidence document, never as organizer's file."""
    import hashlib, os, tempfile
    from pathlib import Path
    from docx import Document
    from app.core.config import settings
    from app.sources.schemas import SourceDocument
    raw=tender.raw_payload or {}; public=raw.get('b2b_public') or {}
    if not public.get('complete') or not raw.get('positions'):
        raise ValueError('B2B complete public positions required')
    root=Path(settings.storage_path)/'source_cache'/'b2b_center'/str(tender.external_id)
    if not str(tender.external_id).isdigit(): raise ValueError('Invalid B2B id')
    root.mkdir(parents=True,exist_ok=True)
    doc=Document();doc.add_heading('Публичные закупочные позиции B2B-Center',0)
    doc.add_paragraph('Источник: '+str(public.get('positions_url') or tender.source_url))
    doc.add_paragraph(tender.title)
    if public.get('all_positions_required'):doc.add_paragraph('Подача заявок по всем позициям лота. Частичная поставка не подтверждена.')
    if public.get('documents_restricted'):doc.add_paragraph('Документация организатора требует авторизации; анализ основан только на публичных позициях.')
    table=doc.add_table(rows=1,cols=4)
    for c,v in zip(table.rows[0].cells,['№','Наименование','Количество','Единица']):c.text=v
    for p in raw['positions']:
        for c,v in zip(table.add_row().cells,[p['position_number'],p['name'],p['quantity'],p['unit']]):c.text=str(v or '')
    fd,tmp=tempfile.mkstemp(dir=root,suffix='.docx');os.close(fd)
    try:
        doc.save(tmp);digest=hashlib.sha256(Path(tmp).read_bytes()).hexdigest()
        path=root/(digest+'.docx');os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    return [SourceDocument(name='Публичные позиции B2B-Center.docx',url=public.get('positions_url') or tender.source_url,
        download_type='local_file',local_path=str(path))]
