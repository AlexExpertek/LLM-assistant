"""Discover marketplace links from a public catalogue; never invent adapters."""
from urllib.parse import urljoin,urlsplit
from bs4 import BeautifulSoup
from app.core.logging import get_logger
from app.sources.public_http import get_html

CATALOG_URL='https://tenderplan.ru/landing/platforms'
logger=get_logger(__name__)
EXCLUDED={'tenderplan.ru','www.tenderplan.ru','t.me','vk.com','youtube.com','www.youtube.com'}


def parse_catalog(html):
    soup=BeautifulSoup(html,'html.parser');links=[];seen=set()
    for node in soup(['script','style','nav','footer','header']):node.decompose()
    for a in soup.find_all('a',href=True):
        url=urljoin(CATALOG_URL,a['href']);p=urlsplit(url)
        if p.scheme!='https' or not p.hostname or p.hostname in EXCLUDED or 'kontur' in p.hostname or p.username or p.password:continue
        label=a.get_text(' ',strip=True).lower()
        if not any(k in label for k in ('торг','закуп','тендер','площад','этп','tender')):continue
        if p.hostname not in seen:
            seen.add(p.hostname);links.append(p._replace(fragment='').geturl())
    return links[:100]


def discover_urls():
    try:return parse_catalog(get_html(CATALOG_URL))
    except Exception as exc:
        logger.warning('marketplace_catalog_unavailable',error_type=type(exc).__name__)
        return []
