"""A confirmed 500 kg position is mandatory; metres never replace mass."""
from dataclasses import dataclass
from app.scoring.selection_policy import MIN_WEIGHT_KG, number

MIN_POSITION_WEIGHT_KG = MIN_WEIGHT_KG
LONG_PRODUCTS = {'profile','angle','pipe','bar','round'}
WEIGHT_CONTROLLED_PRODUCTS = {'sheet','strip','plate','busbar','flat_bar','wire_rod','foil'}

@dataclass
class PositionQualification:
    qualified: bool
    status: str
    reasons: list[str]

def qualify_position(position):
    if position.product_type not in LONG_PRODUCTS | WEIGHT_CONTROLLED_PRODUCTS:
        return PositionQualification(False, 'unsupported_product', ['unsupported_product_type'])
    weight = number(position.weight_kg) if position.quantity_confirmed else None
    if weight is None:
        return PositionQualification(False, 'quantity_unknown', ['weight_not_confirmed'])
    if weight < MIN_WEIGHT_KG:
        return PositionQualification(False, 'below_minimum', [f'weight_below_min:{weight:g}kg'])
    return PositionQualification(True, 'qualified', [f'weight_ok:{weight:g}kg'])
