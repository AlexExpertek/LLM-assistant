"""Classification of what the customer is actually purchasing."""

from __future__ import annotations

from dataclasses import dataclass
import re


@dataclass
class SubjectClassification:
    subject_type: str
    allowed: bool
    reason: str


WORK_PATTERNS = (
    r"\bкомплекс\s+работ\b",
    r"\bстроительно[- ]монтажн\w*\b",
    r"\bмонтажн\w*\s+работ\w*\b",
    r"\bфасадн\w*\s+работ\w*\b",
    r"\bизготовлени\w*\s+и\s+монтаж\w*\b",
    r"\bмонтаж\w*\s+витраж\w*\b",
    r"\bмонтаж\w*\s+остеклен\w*\b",
    r"\bмонтаж\w*\s+окон\w*\b",
    r"\bмонтаж\w*\s+двер\w*\b",
    r"\bразработк\w*\s+кмд\b",
)


FINISHED_PRODUCT_PATTERNS = (
    r"\bдушев\w*\s+кабин\w*\b",
    r"\bсветильник\w*\b",
    r"\bтехническ\w*\s+освещени\w*\b",
    r"\bсветодиодн\w*\s+лент\w*\b",
    r"\bвитражн\w*\s+остеклен\w*\b",
    r"\bвитражн\w*\s+конструкц\w*\b",
    r"\bалюминиев\w*\s+двер\w*\b",
    r"\bалюминиев\w*\s+окон\w*\b",
    r"\bоконн\w*\s+конструкц\w*\b",
    r"\bдверн\w*\s+конструкц\w*\b",
    r"\bалюминиев\w*\s+конструкц\w*\b",
    r"\bготов\w*\s+конструкц\w*\b",
)


TARGET_MATERIAL_PATTERNS = (
    r"\bалюминиев\w*\s+лист\w*\b",
    r"\bлист\w*\s+алюминиев\w*\b",

    r"\bалюминиев\w*\s+лент\w*\b",
    r"\bлент\w*\s+алюминиев\w*\b",

    r"\bалюминиев\w*\s+плит\w*\b",
    r"\bплит\w*\s+алюминиев\w*\b",

    r"\bалюминиев\w*\s+профил\w*\b",
    r"\bпрофил\w*\s+алюминиев\w*\b",

    r"\bалюминиев\w*\s+угол\w*\b",
    r"\bугол\w*\s+алюминиев\w*\b",

    r"\bалюминиев\w*\s+труб\w*\b",
    r"\bтруб\w*\s+алюминиев\w*\b",

    r"\bалюминиев\w*\s+прут\w*\b",
    r"\bпрут\w*\s+алюминиев\w*\b",

    r"\bалюминиев\w*\s+круг\w*\b",
    r"\bкруг\w*\s+алюминиев\w*\b",

    r"\bалюминиев\w*\s+шин\w*\b",
    r"\bшин\w*\s+алюминиев\w*\b",

    r"\bалюминиев\w*\s+полос\w*\b",
    r"\bполос\w*\s+алюминиев\w*\b",

    r"\bалюминиев\w*\s+катанк\w*\b",
    r"\bкатанк\w*\s+алюминиев\w*\b",

    r"\bалюминиев\w*\s+фольг\w*\b",
    r"\bфольг\w*\s+алюминиев\w*\b",
)


SUPPLY_PATTERN = re.compile(
    r"\b(?:поставка|поставк[аи]|закупка|закупк[аи])\b",
    flags=re.I,
)


def _normalize(text: str) -> str:
    return " ".join(
        (text or "")
        .lower()
        .replace("ё", "е")
        .split()
    )


def _matches(
    patterns: tuple[str, ...],
    text: str,
) -> bool:
    return any(
        re.search(
            pattern,
            text,
            flags=re.I,
        )
        for pattern in patterns
    )


def classify_tender_subject(
    title: str,
    raw_text: str = "",
) -> SubjectClassification:
    """
    Determine WHAT is being purchased.

    Title has priority because marketplace raw text can contain
    technical characteristics of finished products, where aluminium
    is only a component.
    """

    title_text = _normalize(title)

    full_text = _normalize(
        f"{title or ''} {raw_text or ''}"
    )

    # Explicit cable-only procurement titles; mixed metal titles stay eligible for detail.
    if re.match(r'^(?:поставка\s*[:—-]?\s*)?(?:кабельн\w*\s+продукци\w*|кабел\w*\s+для|провод\w*\s+сип)\b',title_text):
        return SubjectClassification('finished_product', False, 'cable_or_wire_product')

    # Anchor to the purchased object, not to its intended application.
    subject = re.sub(r"^\s*(?:№\s*[\w/-]+\s*)", "", title_text)
    subject = subject.lstrip('«" ')
    material_head = re.match(
        r"^(?:поставка|закупка|приобретение)\s+(?:алюминиев\w*\s+)?"
        r"(?:профил\w*|лист\w*|труб\w*|прут\w*|лент\w*)\b", subject)
    if material_head and re.search(r"\bдля\s+(?:изготовлен\w*|монтаж\w*|установк\w*)\b", subject):
        return SubjectClassification('material_supply', True, 'material_for_manufacturing_or_works')
    mixed = re.search(r"\bи\s+(?:алюминиев\w*\s+)?(?:профил\w*|лист\w*|труб\w*|прут\w*)\b", subject)
    installation = re.match(
        r"^(?:поставка|закупка|приобретение)\s+(?:и|с)\s+"
        r"(?:установк\w*|монтаж\w*)\s+(?:алюминиев\w*\s+)?"
        r"(?:блок\w*|двер\w*|окон\w*|перегород\w*|конструкц\w*)\b", subject)
    doors = re.match(
        r"^(?:поставка|закупка|приобретение)\s+"
        r"(?:двер\w*|окон\w*|блок\w*|перегород\w*)\s+из\s+"
        r"алюминиев\w*\s+профил\w*\b", subject)
    if (installation or doors) and mixed:
        return SubjectClassification('mixed_or_unknown', True, 'mixed_subject_requires_review')
    if installation:
        return SubjectClassification('works_service', False, 'subject_is_supply_with_installation')
    if doors:
        return SubjectClassification('finished_product', False, 'subject_is_product_made_of_profile')

    # Match the procurement subject, not material supplied FOR these works.
    explicit_building_work = re.match(
        r"^(?:(?:тендер|запрос\s+цен|запрос\s+предложений)\s+(?:на|по)\s+)?"
        r"(?:остеклен\w*\s+лоджи\w*|устройств\w*\s+фасад\w*)\b",
        title_text,
    )
    if explicit_building_work:
        return SubjectClassification(
            subject_type="works_service", allowed=False,
            reason="subject_is_works_or_service",
        )

    #
    # 1. Explicit works / services.
    #
    if _matches(
        WORK_PATTERNS,
        title_text,
    ):
        return SubjectClassification(
            subject_type="works_service",
            allowed=False,
            reason="subject_is_works_or_service",
        )

    #
    # 2. Finished products.
    #
    if _matches(
        FINISHED_PRODUCT_PATTERNS,
        title_text,
    ):
        return SubjectClassification(
            subject_type="finished_product",
            allowed=False,
            reason="subject_is_finished_product",
        )

    #
    # 3. Target aluminium semi-finished product is itself
    #    explicitly named in the procurement title.
    #
    if _matches(
        TARGET_MATERIAL_PATTERNS,
        title_text,
    ):
        return SubjectClassification(
            subject_type="material_supply",
            allowed=True,
            reason="target_material_in_subject",
        )

    #
    # 4. Generic "supply ..." title:
    #    inspect the specification.
    #
    if SUPPLY_PATTERN.search(
        title_text
    ):
        #
        # Finished product wins over incidental aluminium.
        #
        if _matches(
            FINISHED_PRODUCT_PATTERNS,
            full_text,
        ):
            return SubjectClassification(
                subject_type="finished_product",
                allowed=False,
                reason="supply_of_finished_product",
            )

        if _matches(
            TARGET_MATERIAL_PATTERNS,
            full_text,
        ):
            return SubjectClassification(
                subject_type="material_supply",
                allowed=True,
                reason="target_material_in_supply_specification",
            )

    #
    # 5. Generic multi-position procurement.
    #
    # Do not approve it simply because a search snippet contains
    # aluminium. Position + quantity must prove relevance downstream.
    #
    return SubjectClassification(
        subject_type="mixed_or_unknown",
        allowed=True,
        reason="requires_position_confirmation",
    )
