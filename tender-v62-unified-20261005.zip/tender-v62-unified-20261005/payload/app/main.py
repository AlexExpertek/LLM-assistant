"""
FastAPI приложение — v0.6.2
Новое: веб-интерфейс на русском, ФЗ-152, загрузка файлов, анализ по URL,
многопозиционные тендеры, сжатие файлов.
"""
from fastapi import FastAPI, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from app.core.config import settings
from app.core.logging import configure_logging, get_logger
from app.db.health import check_postgres, check_redis
from app.security.fz152 import SecurityHeadersMiddleware
from app.workers.celery_app import celery_app
from app.sources.registry import SOURCE_REGISTRY
from app.workers.tasks_parsing import monitor_source
from app.api.upload import router as upload_router

configure_logging()
logger = get_logger(__name__)

app = FastAPI(
    title="Тендерный ассистент ТДСМ",
    description="Блок I MVP — мониторинг, анализ, отчёты, Битрикс24",
    version="0.6.2",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

# Middleware
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])

# Роутеры
app.include_router(upload_router)

from app.api.marketplace_scout import (
    router as marketplace_scout_router,
)

app.include_router(
    marketplace_scout_router
)

# Статические файлы (интерфейс)
from pathlib import Path
static_dir = Path(__file__).parent / "static"
if static_dir.exists():
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


# ── Главная страница ─────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def root():
    index_path = Path(__file__).parent / "static" / "index.html"
    if index_path.exists():
        return HTMLResponse(content=index_path.read_text(encoding='utf-8'))
    return HTMLResponse(content="<h1>Тендерный ассистент ТДСМ</h1><p><a href='/api/docs'>API документация</a></p>")


# ── Health ───────────────────────────────────────────────────────────────────
@app.get("/health/live")
async def liveness():
    return {"status": "ok"}


@app.get("/health/ready")
@app.get("/health")
async def readiness():
    services = {"postgres": await check_postgres(), "redis": await check_redis()}
    if not all(services.values()):
        raise HTTPException(503, detail={"status": "not_ready", "services": services})
    return {"status": "ready", "services": services,
            "environment": settings.environment,
            "llm_provider_default": settings.default_llm_provider}


# ── Источники ────────────────────────────────────────────────────────────────
@app.get("/sources")
async def list_sources():
    return {"sources": [
        {"key": key, "adapter": adapter.__class__.__name__}
        for key, adapter in SOURCE_REGISTRY.items()
    ]}


class TriggerRequest(BaseModel):
    source_key: str


@app.post("/sources/trigger")
async def trigger_monitoring(payload: TriggerRequest):
    if payload.source_key not in SOURCE_REGISTRY:
        raise HTTPException(404, "Источник не найден")
    task = monitor_source.delay(payload.source_key)
    return {"status": "queued", "task_id": task.id}


# ── Тендеры ──────────────────────────────────────────────────────────────────

@app.get("/tenders/stats", summary="Статистика по тендерам")
async def get_tenders_stats():
    from app.reports.active_tenders import get_all_tenders_stats
    return get_all_tenders_stats()

@app.get("/tenders/active", summary="Активные тендеры")
async def get_active_tenders():
    from app.reports.active_tenders import get_active_tenders as _get
    from app.security.fz152 import log_data_access
    log_data_access("web_ui", "read", "tenders")
    tenders = _get()
    return {"count": len(tenders), "tenders": tenders}



@app.get(
    "/tenders/dashboard",
    summary="Активные тендеры для Dashboard",
)
async def get_tenders_dashboard():
    from app.reports.active_tenders import (
        get_tender_dashboard,
    )
    from app.security.fz152 import log_data_access

    log_data_access(
        "web_ui",
        "read",
        "tenders_dashboard",
    )

    tenders = get_tender_dashboard()

    return {
        "count": len(tenders),
        "tenders": tenders,
    }


@app.get("/tenders/review", summary="Закупки, требующие уточнения")
def get_tenders_review():
    from app.reports.review_dashboard import get_review_dashboard
    return get_review_dashboard()


# ── Задачи ───────────────────────────────────────────────────────────────────
@app.get("/tasks/{task_id}")
async def get_task_status(task_id: str):
    result = celery_app.AsyncResult(task_id)
    return {
        "task_id": task_id,
        "status": result.status,
        "ready": result.ready(),
        "result": result.result if result.ready() and result.successful() else None,
        "error": str(result.result) if result.ready() and result.failed() else None,
    }


@app.post("/tasks/mark-inactive")
async def trigger_mark_inactive():
    from app.workers.tasks_parsing import mark_inactive_tenders
    task = mark_inactive_tenders.delay()
    return {"status": "queued", "task_id": task.id}


# ── Отчёты ───────────────────────────────────────────────────────────────────
@app.post("/reports/generate", summary="Сгенерировать и разослать отчёт")
async def trigger_report():
    from app.workers.tasks_reports import generate_and_send_report
    task = generate_and_send_report.delay()
    return {"status": "queued", "task_id": task.id,
            "message": "Отчёт будет отправлен в Telegram и Битрикс24"}


@app.get("/reports/active.xlsx", summary="Скачать Excel-отчёт")
async def download_active_report():
    from app.reports.active_tenders import get_active_tenders as _get, generate_excel_report
    from app.security.fz152 import log_data_access
    log_data_access("web_ui", "export", "tenders")
    tenders = _get()
    excel = generate_excel_report(tenders)  # работает и с пустым списком
    return Response(
        content=excel,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=active_tenders.xlsx"},
    )


# ── Unified tender discovery ─────────────────────────────────

from pydantic import BaseModel as _DiscoveryBaseModel


class DiscoveryRunRequest(
    _DiscoveryBaseModel
):
    max_results_per_source: int = 100
    max_per_marketplace: int = 100


@app.post(
    "/discovery/run",
    summary=(
        "Запустить поиск тендеров "
        "по всем подключенным источникам"
    ),
)
async def run_discovery_http(
    payload: DiscoveryRunRequest,
):
    from app.workers.tasks_discovery_http import (
        run_full_tender_discovery,
    )

    task = run_full_tender_discovery.delay(
        max_results_per_source=(
            payload.max_results_per_source
        ),
        max_per_marketplace=(
            payload.max_per_marketplace
        ),
    )

    return {
        "status": "queued",
        "task_id": task.id,
        "sources": [
            "zakupki_gov_ru",
            "tender_pro",
        ],
        "dashboard_url":
            "/tenders/dashboard",
        "task_status_url":
            f"/tasks/{task.id}",
    }


from pydantic import BaseModel, Field
from fastapi import Request, HTTPException

class ReviewDismissalRequest(BaseModel):
    source: str = Field(min_length=1, max_length=100, pattern=r"^[a-z0-9_]+$")
    external_id: str = Field(min_length=1, max_length=200, pattern=r"^[A-Za-z0-9_-]+$")
    dismissed: bool = True

@app.post("/tenders/review/dismiss")
def dismiss_review_item(body: ReviewDismissalRequest, request: Request):
    # Browser mutations require an explicit same-origin header.
    if request.headers.get("x-review-action") != "manual":
        raise HTTPException(status_code=403, detail="Manual action required")
    from urllib.parse import urlsplit
    origin = request.headers.get("origin")
    if origin and urlsplit(origin).netloc != request.headers.get("host"):
        raise HTTPException(status_code=403, detail="Cross-origin action rejected")
    from app.reports.review_dismissals import set_dismissed
    set_dismissed(body.source, body.external_id, body.dismissed)
    return {"status": "dismissed" if body.dismissed else "restored"}


@app.get('/tenders/selection-policy')
def get_selection_policy():
    from app.scoring.selection_policy import policy
    return policy()
