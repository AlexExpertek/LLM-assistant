"""Shared STD procurement criteria. No database, network or credentials."""
import math
import re

VERSION = 'std-selection-20261005'
MIN_WEIGHT_KG = 500.0
OKPD2_PREFIXES = ('24.42.11', '24.42.22', '24.42.23', '24.42.24', '24.42.25', '24.42.26')
# Product words are a fallback only for sites without a structured classifier.
FALLBACK_QUERIES = ('алюминий', 'алюминиевый прокат', 'цветной металлопрокат',
    'алюминиевая лента', 'алюминиевый лист', 'алюминиевый профиль',
    'алюминиевая труба', 'алюминиевый пруток', 'алюминиевая шина',
    'алюминиевая плита', 'алюминиевая полоса', 'алюминиевая катанка', 'алюминиевая фольга')
PRODUCT = re.compile(r'\b(?:лист\w*|лент\w*|плит\w*|рулон\w*|фольг\w*|штрипс\w*|труб\w*|прут\w*|профил\w*|шин\w*|полос\w*|катанк\w*|уголок\w*|круг\w*|заготов\w*|слит\w*|чушк\w*|sheet|strip|plate|pipe|profile|bar|round|busbar|flat_bar|wire_rod|foil)\b',re.I)
NON_TARGET = re.compile(r'\b(?:стал\w*|сталь|медн\w*|латун\w*|бронз\w*|кабел\w*|провод\w*|сип[-\s]?\d|стремянк\w*|лестниц\w*|посуда)\b', re.I)
ALUMINIUM = re.compile(r'алюмини|alumin', re.I)
# Only distinctive Russian aluminium series; unknown labels alone do not prove metal.
ALLOY = re.compile(r'(?<!\w)(?:АД\s*\d+|АМ[ГЦ]\s*\d*|Д(?:1|16|19)|В95|ВД1|АК(?:4|6)|А[0567])(?:[А-Яа-я]\d*)*(?!\w)', re.I)


def number(value):
    if value is None or isinstance(value, bool): return None
    try:
        x = float(str(value).replace('\xa0','').replace(' ','').replace(',','.'))
        return x if math.isfinite(x) and x >= 0 else None
    except (TypeError,ValueError): return None


def mass_kg(position):
    mass = number(position.get('mass_kg'))
    if mass is None: mass = number(position.get('quantity_kg'))
    if mass is not None: return mass
    qty = number(position.get('quantity'))
    unit = str(position.get('unit') or '').strip().lower().rstrip('.')
    if qty is None: return None
    if unit in ('кг','kg','килограмм','килограммы','килограммов','166'): return qty
    if unit in ('т','тн','тонна','тонны','тонн','t','ton','tonne','168'): return qty * 1000
    return None


def material_status(position):
    name = str(position.get('name_product') or position.get('product_name') or position.get('name') or '')
    kind = str(position.get('product_type') or '')
    alloy = str(position.get('alloy') or position.get('alloy_normalized') or '')
    text = ' '.join((name, kind, alloy))
    if NON_TARGET.search(text): return False
    if not PRODUCT.search(name + ' ' + kind): return False if kind else None
    from app.marketplace_discovery.subject_classifier import classify_tender_subject
    if not classify_tender_subject('Поставка ' + name).allowed: return False
    if ALUMINIUM.search(text) or ALLOY.search(text): return True
    from app.scoring.alloy_normalizer import is_known_alloy
    return True if alloy and is_known_alloy(alloy) else None


def qualifies(position):
    mass = mass_kg(position)
    return material_status(position) is True and mass is not None and mass >= MIN_WEIGHT_KG


def processing_required(value):
    if isinstance(value, bool): return value
    s = str(value or '').strip().lower().replace('ё','е')
    if s in ('', 'нет', 'false', 'no', '0', 'null', 'none', 'не указано', 'не требуется', 'отсутствует', 'без покрытия', 'без обработки'): return False
    if re.match(r'^(?:не требуется|не предусмотрен|отсутствует|без покрытия|без обработки)\b', s): return False
    return bool(re.search(r'\b(?:да|true|yes|требуется|резк\w*|окраск\w*|покрыти\w*|анодирован\w*|гибк\w*|фрезер\w*|сверлен\w*)\b',s))


def price_priority(amount, currency='RUB'):
    value = number(amount)
    if str(currency or 'RUB').upper() not in ('RUB','RUR','РУБ','РУБ.','₽'): return 'currency_review'
    if value is None: return 'price_unknown'
    return 'high' if value >= 1_000_000 else ('normal' if value >= 500_000 else 'low')


def policy():
    return dict(version=VERSION, min_position_mass_kg=MIN_WEIGHT_KG, sum_positions=False,
        okpd2_prefixes=OKPD2_PREFIXES, geography='РФ и СНГ', all_customers=True,
        all_industries=True, all_aluminium_alloys=True, laws=['44-FZ','223-FZ','commercial'],
        price_priority_rub=1_000_000, price_secondary_rub=500_000,
        unknown_price_allowed=True, advance_restricted=False, security_restricted=False,
        kontur_enabled=False, tender_pro_min_request_interval_seconds=1.1)
