"""
Анализ многопозиционных тендеров.
Определяет по каждой позиции: можем ли мы её поставить.
Если не можем поставить все — проверяем допустимость частичной поставки.
"""
from dataclasses import dataclass
from typing import Optional
import re
import math
from app.models.database import TenderStatus

from app.scoring.alloy_normalizer import is_known_alloy, normalize_alloy_string
from app.scoring.selection_policy import material_status, mass_kg as position_mass, MIN_WEIGHT_KG
from app.core.logging import get_logger

logger = get_logger(__name__)

# Типы продукции которые мы поставляем
OUR_PRODUCT_TYPES = {
    "лента", "лента тисненная", "лист", "плита", "рулон",
    "фольга", "штрипсы", "лента алюминиевая", "лист алюминиевый",
    "плита алюминиевая", "рулон алюминиевый",
    "труба", "трубы", "пруток", "прутки", "профиль", "профили",
}


@dataclass
class PositionAnalysis:
    position_number: int
    name_product: str
    alloy: Optional[str]
    product_type: Optional[str]
    mass_kg: Optional[float]
    thickness_mm: Optional[float]
    width_mm: Optional[float]
    can_supply: Optional[bool]
    reason: str


@dataclass
class MultiPositionResult:
    total_positions: int
    can_supply_all: bool
    can_supply_count: int
    cannot_supply_count: int
    partial_delivery_possible: bool
    positions: list[PositionAnalysis]
    summary: str
    unknown_count: int = 0


def analyze_positions(positions: list[dict], partial_delivery_allowed: bool = None) -> MultiPositionResult:
    """
    Анализирует каждую позицию многопозиционного тендера.

    positions: список словарей с полями alloy, product_type, mass_kg и т.д.
    partial_delivery_allowed: из документов тендера (None = не указано)
    """
    analyzed = []

    for i, pos in enumerate(positions, 1):
        alloy_raw = pos.get("alloy") or pos.get("alloy_normalized")
        product_type = (pos.get("product_type") or "").lower().strip()
        mass_kg = position_mass(pos)
        material = material_status(pos)
        product_ok = material is True

        # Проверка сплава
        alloy_ok = False
        alloy_normalized = None
        if alloy_raw:
            alloy_normalized = normalize_alloy_string(alloy_raw)
            alloy_ok = is_known_alloy(alloy_raw)

        # Итоговое решение по позиции
        if not product_type:
            can_supply = None
            reason = "Тип продукции не указан — требует уточнения"
        elif material is False:
            can_supply = False
            reason = f"Тип '{product_type}' вне нашего ассортимента"
        elif material is None:
            can_supply = None
            reason = "Не подтверждено, что позиция относится к алюминиевой продукции"
        elif mass_kg is not None and mass_kg < MIN_WEIGHT_KG:
            can_supply = False
            reason = f"Объём {mass_kg} кг ниже минимальной партии (500 кг)"
        elif not alloy_raw or mass_kg is None or not any(pos.get(k) for k in ("thickness_mm", "width_mm", "diameter_mm")):
            can_supply = None
            reason = "Тип продукции в ассортименте; требуется уточнить сплав, массу и/или размеры"
        else:
            can_supply = True
            reason = "Алюминиевая продукция соответствует условиям отбора"
            if alloy_normalized:
                reason += f" ({alloy_normalized})"

        analyzed.append(PositionAnalysis(
            position_number=i,
            name_product=pos.get("name_product") or pos.get("product_name", f"Позиция {i}"),
            alloy=alloy_normalized or alloy_raw,
            product_type=product_type,
            mass_kg=mass_kg,
            thickness_mm=pos.get("thickness_mm"),
            width_mm=pos.get("width_mm"),
            can_supply=can_supply,
            reason=reason,
        ))

    can_count = sum(1 for p in analyzed if p.can_supply)
    cannot_count = sum(p.can_supply is False for p in analyzed)
    unknown_count = sum(p.can_supply is None for p in analyzed)
    can_all = bool(analyzed) and can_count == len(analyzed)

    # Частичная поставка возможна если:
    # 1. Явно разрешена в документах, или не запрещена (None)
    # 2. Хотя бы одну позицию можем поставить
    partial_ok = (partial_delivery_allowed is True) and can_count > 0

    if unknown_count:
        summary = f"Требуют уточнения: {unknown_count}; соответствуют: {can_count}; не соответствуют: {cannot_count}"
    elif can_all:
        summary = f"✅ Все {len(analyzed)} позиции в нашем ассортименте"
    elif can_count == 0:
        summary = f"❌ Ни одну из {len(analyzed)} позиций не можем поставить"
    else:
        summary = (
            f"⚠️ {can_count} из {len(analyzed)} позиций — наши. "
            f"{'Частичная поставка допустима.' if partial_ok else 'Частичная поставка НЕ допускается.'}"
        )

    return MultiPositionResult(
        total_positions=len(analyzed),
        can_supply_all=can_all,
        can_supply_count=can_count,
        cannot_supply_count=cannot_count,
        partial_delivery_possible=partial_ok,
        positions=analyzed,
        summary=summary,
        unknown_count=unknown_count,
    )


def position_status(scoring, mp):
    if any(s.name == "hard_stop_word" for s in scoring.signals):
        return TenderStatus.NOT_SUITABLE
    if mp is None or mp.unknown_count:
        return TenderStatus.MANUAL_REVIEW
    if mp.can_supply_count == 0:
        return TenderStatus.NOT_SUITABLE
    if not mp.can_supply_all:
        return TenderStatus.NEEDS_CLARIFICATION if mp.partial_delivery_possible else TenderStatus.MANUAL_REVIEW
    return scoring.suggested_status
