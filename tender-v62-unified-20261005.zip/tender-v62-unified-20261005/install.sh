#!/usr/bin/env bash
set -Eeuo pipefail
pkg_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
project_dir="${TENDER_PROJECT_DIR:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
cd "$project_dir"
test -f docker-compose.yml
python3 "$pkg_dir/apply.py" --project "$project_dir"
docker compose build app celery_worker celery_discovery celery_beat
docker compose run --rm --no-deps -T celery_worker python - < "$pkg_dir/verify.py"
# Check actual schedule flags in the new image before touching running services.
docker compose run --rm --no-deps -T celery_beat python - <<'PY'
from app.workers.celery_app import celery_app
schedule=celery_app.conf.beat_schedule
required={'monitor-eis-daily','marketplace-discovery-4h','marketplace-scout-daily'}
missing=required-set(schedule)
if missing:raise SystemExit('Enable EIS_MONITOR_ENABLED and MARKETPLACE_SCOUT_ENABLED in service environment: '+str(missing))
assert not any('kontur' in str(v) for v in schedule.values())
print('SCHEDULE_OK')
PY
docker compose stop celery_beat
docker compose up -d --no-deps --timeout 60 app celery_worker celery_discovery
docker compose exec -T celery_worker python - < "$pkg_dir/seed_dismissals.py"
docker compose exec -T celery_worker python - < "$pkg_dir/check_runtime.py"
docker compose up -d --no-deps --timeout 60 celery_beat
if [ "${1:-}" = "--start" ]; then
    docker compose exec -T celery_discovery python - < "$pkg_dir/start_sources.py"
fi
printf '\nUNIFIED_UPDATE_INSTALLED\n'
printf 'Automatic schedule is enabled. Use --start only for one immediate run.\n'
