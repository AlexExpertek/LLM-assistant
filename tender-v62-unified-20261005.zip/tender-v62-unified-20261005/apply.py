"""Guarded source-only update. Validate every file before writing any file."""
import argparse,hashlib,json,os,shutil,tempfile
from pathlib import Path

PACKAGE=Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--project',default=str(Path.cwd()));parser.add_argument('--check',action='store_true');args=parser.parse_args()
    root=Path(args.project).resolve();manifest=json.loads((PACKAGE/'manifest.json').read_text())
    changes=[]
    for name,info in manifest.items():
        rel=Path(name)
        if rel.is_absolute() or '..' in rel.parts:raise SystemExit('Unsafe manifest path')
        dest=root/rel;src=PACKAGE/'payload'/rel
        if dest.is_symlink() or root not in dest.resolve().parents:raise SystemExit('Symlink/path conflict: '+name)
        if digest(src)!=info['after']:raise SystemExit('Payload checksum mismatch: '+name)
        current=digest(dest)
        if current==info['after']:continue
        if current!=info['before']:raise SystemExit('SOURCE_VERSION_CONFLICT: '+name+'; files not changed')
        changes.append((name,dest,src,current))
    print('Source files to update:',len(changes))
    if args.check or not changes:return
    backup=Path(tempfile.mkdtemp(prefix='tender-unified-backup-',dir=root.parent))
    saved=[]
    for name,dest,src,current in changes:
        if current is not None:
            target=backup/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dest,target)
        saved.append({'path':name,'before':current,'after':digest(src)})
    (backup/'restore.json').write_text(json.dumps({'project':str(root),'files':saved},indent=2))
    print('BACKUP:',backup,flush=True)
    written=[]
    try:
        for name,dest,src,current in changes:
            dest.parent.mkdir(parents=True,exist_ok=True)
            fd,tmp=tempfile.mkstemp(dir=dest.parent);os.close(fd)
            try:
                shutil.copy2(src,tmp)
                if dest.exists():os.chmod(tmp,dest.stat().st_mode & 0o777)
                else:os.chmod(tmp,0o644)
                os.replace(tmp,dest);written.append((name,dest,current))
            finally:
                if os.path.exists(tmp):os.unlink(tmp)
    except Exception:
        for name,dest,current in reversed(written):
            if current is None:dest.unlink(missing_ok=True)
            else:shutil.copy2(backup/name,dest)
        raise
    print('SOURCES_APPLIED:',len(written))
if __name__=='__main__':main()
