import json,tempfile,unittest
from pathlib import Path
from datetime import datetime,timezone,timedelta
from unittest.mock import patch
import httpx
from app.sources.tektorg.adapter import TektorgAdapter,select_bundle,download
from app.sources.schemas import SourceDocument
from app.sources.eis_freshness import eligibility
URL='https://www.tektorg.ru/rosnefttkp/procedures/19839486'
def fixture(stage='Приём заявок',ident=19839486):
 row=dict(id=ident,title='Лента алюминиевая',statusName=stage,typeName='Запрос (Т)КП',sectionAlias='rosneft',subsectionAlias='rosnefttkp',dates={'dateEndRegistration':(datetime.now(timezone.utc)+timedelta(days=3)).isoformat()},lots=[],organizerName='Заказчик')
 return '<script id="__NEXT_DATA__">'+json.dumps({'props':{'pageProps':{'procedureItem':row}}})+'</script>'+''.join('<a href="/files-storage/'+str(i)+'/download?token=temporary">'+name+'</a>' for i,name in enumerate(['ТТ[1].docx docx','Форма_коммерческого_предложения.xls xls','Форма_технического_предложения.xls xls']))
class Tests(unittest.TestCase):
 def card(self,html=None):
  with patch('app.sources.tektorg.adapter.get_html',return_value=html or fixture()),patch('app.sources.tektorg.adapter.is_dismissed',return_value=False):
   return TektorgAdapter().fetch_by_id('19839486',source_url=URL)
 def test_bundle(self):
  card=self.card();selected=select_bundle(card.documents)
  self.assertEqual(len(selected),2)
  self.assertTrue(any('коммерческого' in d.name for d in selected))
  self.assertFalse(any('технического_предложения' in d.name for d in selected))
 def test_tokens_not_saved(self):
  self.assertNotIn('temporary',self.card().model_dump_json())
 def test_tkp(self):
  card=self.card();self.assertEqual(card.raw_payload['procedure_kind'],'tkp');self.assertTrue(card.title.startswith('[Запрос (Т)КП]'))
 def test_closed(self):self.assertIsNone(self.card(fixture(stage='Работа комиссии')))
 def test_identity(self):
  with self.assertRaises(ValueError):self.card(fixture(ident=1))
 def test_url(self):
  with self.assertRaises(ValueError):TektorgAdapter().fetch_by_id('19839486',source_url='https://evil.test/procedures/19839486')
 def test_freshness(self):
  future=datetime.now(timezone.utc)+timedelta(days=1)
  self.assertIsNone(eligibility('tektorg',future,{'procurement_status':'Приём заявок'}))
  self.assertEqual(eligibility('tektorg',None,{'procurement_status':'Приём заявок'}),'freshness_unknown')
  self.assertEqual(eligibility('tektorg',future-timedelta(days=2),{'procurement_status':'Приём заявок'}),'deadline_expired')
 def test_other_source_unchanged(self):
  self.assertIsNone(eligibility('roseltorg'))
 def test_download(self):
  def handler(request):
   return httpx.Response(302,headers={'location':'https://storage.tektorg.ru/file'}) if request.url.host=='www.tektorg.ru' else httpx.Response(200,content=b'PKfake')
  with tempfile.TemporaryDirectory() as d,httpx.Client(transport=httpx.MockTransport(handler)) as c:
   p=Path(d)/'x';download(c,'https://www.tektorg.ru/files-storage/a/download',p);self.assertEqual(p.read_bytes(),b'PKfake')
 def test_bad_redirect(self):
  with tempfile.TemporaryDirectory() as d,httpx.Client(transport=httpx.MockTransport(lambda r:httpx.Response(302,headers={'location':'https://evil.test'}))) as c:
   with self.assertRaises(ValueError):download(c,'https://www.tektorg.ru/files-storage/a/download',Path(d)/'x')
if __name__=='__main__':unittest.main()
