#!/usr/bin/env bash
set -Eeuo pipefail
pkg_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "${TENDER_PROJECT_DIR:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
# The last installed XLS handler and notification-suppression API must exist.
docker compose exec -T celery_worker python - <<'PY'
import inspect
from app.ocr.legacy_excel import extract_xls
from app.workers.tasks_scoring import analyze_tender
assert 'suppress_notifications' in inspect.signature(analyze_tender.run).parameters
print('TEKTORG_PREREQUISITES_OK')
PY
python3 "$pkg_dir/apply.py" --project "$PWD"
docker compose build app celery_worker celery_discovery
docker compose run --rm --no-deps -T -e PYTHONPATH=/app celery_worker python - < "$pkg_dir/test_pipeline.py"
docker compose run --rm --no-deps -T -e PYTHONPATH=/app celery_discovery python - < "$pkg_dir/test_tektorg.py"
docker compose run --rm --no-deps -T -e PYTHONPATH=/app celery_worker python - < "$pkg_dir/test_dispatch.py"
docker compose up -d --no-deps --timeout 60 app celery_worker celery_discovery
printf '\nTEKTORG_PIPELINE_UPDATE_INSTALLED\nExisting schedule retained. Scheduled runs now queue up to two new eligible Tektorg cards. No immediate run or notifications.\n'
