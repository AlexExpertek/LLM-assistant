import argparse,json
from app.sources.tektorg.adapter import TektorgAdapter,select_bundle
p=argparse.ArgumentParser();p.add_argument('--enqueue',action='store_true');args=p.parse_args()
url='https://www.tektorg.ru/rosnefttkp/procedures/19839486'
card=TektorgAdapter().fetch_by_id('19839486',source_url=url)
if card is None:raise SystemExit('NOT_ELIGIBLE: closed, expired, dismissed or non-target')
print(json.dumps({'number':card.external_id,'title':card.title,'deadline':str(card.submission_deadline),
 'type':card.procurement_method,'documents_found':len(card.documents),
 'selected':[d.name for d in select_bundle(card.documents)]},ensure_ascii=False,indent=2))
if args.enqueue:
 from app.sources.tektorg.dispatch import enqueue_candidates
 print(json.dumps(enqueue_candidates([{'external_id':card.external_id,'source_url':url}]),ensure_ascii=False,indent=2))
else:
 print('READ_ONLY: no DB writes, tasks, OCR, LLM or notifications. --enqueue submits once; completed results are reused.')
