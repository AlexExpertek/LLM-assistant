"""Document download, storage and extraction. One tender is analyzed only after all documents finish."""
from app.sources.eis_freshness import eligibility, gate_saved_tender
import hashlib
import io
import shutil
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlparse

from billiard.exceptions import SoftTimeLimitExceeded
from app.ocr.task_guard import OCRBusy, OCRGuard

import httpx
from sqlalchemy import delete, select, update

from app.core.config import settings
from app.core.logging import get_logger
from app.db.session import SyncSessionLocal
from app.models.database import Document, OCRStatus, ProcessingStatus, Tender, TenderStatus
from app.ocr.pipeline import extract_document
from app.sources.schemas import SourceDocument
from app.workers.completed_analysis import has_completed_analysis, cached_result
from app.workers.celery_app import celery_app

logger = get_logger(__name__)
SUPPORTED = {".pdf", ".doc", ".docx", ".xlsx", ".xls", ".txt", ".md", ".jpg", ".jpeg", ".png", ".tif", ".tiff"}


def compute_file_hash(file_path: str) -> str:
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


def _safe_name(name: str) -> str:
    name = Path(unquote(name or "document")).name
    return name or "document"


def _download_url(url: str, target: Path) -> Path:
    max_bytes = settings.max_download_size_mb * 1024 * 1024
    downloaded = 0
    with httpx.stream("GET", url, timeout=90.0, follow_redirects=True) as response:
        response.raise_for_status()
        with open(target, "wb") as fh:
            for chunk in response.iter_bytes():
                downloaded += len(chunk)
                if downloaded > max_bytes:
                    raise ValueError(f"Файл превышает {settings.max_download_size_mb} МБ")
                fh.write(chunk)
    return target


def _download_archive_member(archive_url: str, member: str, target: Path) -> Path:
    headers = {"usertoken": settings.eis_token} if settings.eis_token else {}
    with httpx.Client(timeout=120.0, follow_redirects=True) as client:
        response = client.get(archive_url, headers=headers)
        response.raise_for_status()
    with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
        info = archive.getinfo(member)
        if info.file_size > settings.max_download_size_mb * 1024 * 1024:
            raise ValueError("Файл в архиве превышает допустимый размер")
        target.write_bytes(archive.read(member))
    return target


def _materialize(doc: SourceDocument, storage_dir: Path) -> Path:
    target = storage_dir / _safe_name(doc.name)
    if doc.download_type == "local_file":
        if not doc.local_path:
            raise ValueError("local_path отсутствует")
        shutil.copy2(doc.local_path, target)
        return target
    if doc.download_type == "archive_member":
        if not doc.archive_url or not doc.archive_member:
            raise ValueError("archive_url/archive_member отсутствуют")
        return _download_archive_member(doc.archive_url, doc.archive_member, target)
    if not doc.url:
        raise ValueError("URL документа отсутствует")
    return _download_url(doc.url, target)


def _mark_incomplete(tender_id):
    with SyncSessionLocal() as session:
        if has_completed_analysis(session, session.get(Tender, tender_id)):
            return
        session.execute(update(Tender).where(Tender.id == tender_id).values(
            processing_status=ProcessingStatus.FAILED,
            status=TenderStatus.MANUAL_REVIEW,
            analysis_done=False,
        ))
        session.commit()


@celery_app.task(name="app.workers.tasks_ocr.process_tender_documents", bind=True,
                 max_retries=2, default_retry_delay=120,
                 soft_time_limit=840, time_limit=900)
def process_tender_documents(self, tender_id: str, documents: list[dict]):
    try:
        with OCRGuard(settings.storage_path, tender_id, self.request.id) as guard:
            previous = guard.previous()
            if previous is not None:
                logger.info("ocr_duplicate_completed", tender_id=tender_id, task_id=self.request.id)
                return previous
            try:
                result = _process_documents(tender_id, documents)
            except SoftTimeLimitExceeded:
                _mark_incomplete(tender_id)
                result = {"status": "manual_review", "tender_id": tender_id, "reason": "ocr_task_time_limit"}
                logger.warning("ocr_task_time_limit", tender_id=tender_id)
            guard.finish(result)
            return result
    except OCRBusy:
        logger.info("ocr_tender_busy", tender_id=tender_id)
        raise self.retry(countdown=60, max_retries=60)


def _process_documents(tender_id: str, documents: list[dict]):
    with SyncSessionLocal() as session:
        if has_completed_analysis(session, session.get(Tender, tender_id)):
            return cached_result(tender_id)
        blocked = gate_saved_tender(session, tender_id)
        if blocked:
            logger.info('eis_freshness_skipped', **blocked)
            return blocked
    storage_dir = Path(settings.storage_path) / "tenders" / tender_id
    storage_dir.mkdir(parents=True, exist_ok=True)
    texts = []
    document_ids = []
    incomplete = not documents

    with SyncSessionLocal() as session:
        session.execute(update(Tender).where(Tender.id == tender_id).values(processing_status=ProcessingStatus.DOCUMENTS_PENDING))
        # Reprocessing a changed tender replaces document snapshot and extracted facts.
        for old in session.execute(select(Document).where(Document.tender_id == tender_id)).scalars().all():
            session.delete(old)
        session.commit()

    for raw in documents:
        doc = SourceDocument.model_validate(raw)
        db_id = None
        try:
            local_path = _materialize(doc, storage_dir)
            if local_path.suffix.lower() not in SUPPORTED:
                raise ValueError("Unsupported document type: " + local_path.suffix.lower())
            result = extract_document(str(local_path))
            if result.status not in (OCRStatus.DONE, OCRStatus.NOT_REQUIRED) or not result.full_text.strip():
                incomplete = True
            file_hash = compute_file_hash(str(local_path))
            with SyncSessionLocal() as session:
                row = Document(
                    tender_id=tender_id,
                    external_id=doc.external_id,
                    filename=local_path.name,
                    file_hash=file_hash,
                    storage_uri=str(local_path),
                    source_url=doc.url or doc.archive_url,
                    ocr_status=OCRStatus(result.status.value),
                    pages_count=result.pages_count,
                    extracted_text=result.full_text,
                )
                session.add(row); session.commit(); session.refresh(row)
                db_id = str(row.id)
            if result.full_text and result.full_text.strip():
                texts.append(f"\n\n### DOCUMENT: {local_path.name}\n{result.full_text}")
                document_ids.append(db_id)
        except SoftTimeLimitExceeded:
            raise
        except Exception as exc:
            incomplete = True
            logger.error("document_processing_failed", tender_id=tender_id, document=doc.name, error=str(exc))
            with SyncSessionLocal() as session:
                row = Document(
                    tender_id=tender_id, filename=doc.name, source_url=doc.url or doc.archive_url,
                    ocr_status=OCRStatus.FAILED,
                )
                session.add(row); session.commit()

    if incomplete or not document_ids:
        _mark_incomplete(tender_id)
        logger.warning("ocr_documents_incomplete", tender_id=tender_id,
                       documents_total=len(documents), documents_ok=len(document_ids))
        return {"status": "manual_review", "tender_id": tender_id,
                "reason": "documents_incomplete_or_low_confidence", "documents_ok": len(document_ids)}

    with SyncSessionLocal() as session:
        session.execute(update(Tender).where(Tender.id == tender_id).values(processing_status=ProcessingStatus.DOCUMENTS_READY))
        session.commit()

    from app.workers.tasks_scoring import analyze_tender
    with SyncSessionLocal() as session:
        row = session.get(Tender, tender_id)
        tektorg = row is not None and row.source == 'tektorg'
    if tektorg:
        analyze_tender.delay(tender_id, "".join(texts), document_ids, suppress_notifications=True)
    else:
        analyze_tender.delay(tender_id, "".join(texts), document_ids)
    return {"status": "documents_ready", "tender_id": tender_id, "documents_ok": len(document_ids)}


# Compatibility alias for old callers. New code must use process_tender_documents.
@celery_app.task(name="app.workers.tasks_ocr.download_and_process_documents")
def download_and_process_documents(tender_external_id: str, document_urls: list[str]):
    return {"status": "deprecated", "reason": "use internal tender_id + SourceDocument contract"}
