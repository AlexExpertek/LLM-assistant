import hashlib
import json
import re
import time
from pathlib import Path
from urllib.parse import urljoin, urlsplit
import httpx
from bs4 import BeautifulSoup
from app.sources.public_http import get_html
from app.sources.schemas import SourceTender, SourceDocument
from app.marketplace_discovery.primary.tektorg_search import candidate
from app.reports.review_dismissals import is_dismissed
from datetime import datetime, timezone


def safe_url(url, document=False):
    try:
        p = urlsplit(url)
        hosts = {'www.tektorg.ru', 'storage.tektorg.ru'} if document else {'www.tektorg.ru'}
        return (p.scheme == 'https' and p.hostname in hosts and not p.username
                and not p.password and p.port in (None, 443))
    except ValueError:
        return False


def select_bundle(documents):
    def normalized(d):
        return re.sub(r'[_\s]+', ' ', d.name.lower())
    technical = [d for d in documents if re.search(r'\bтт\b|техническ\w* требован|техническ\w* задан|описание объекта|спецификац', normalized(d))]
    commercial = [d for d in documents if 'коммерческого предложения' in normalized(d) and Path(d.name).suffix.lower() in ('.xls', '.xlsx')]
    forms = [d for d in documents if 'технического предложения' in normalized(d) and Path(d.name).suffix.lower() in ('.xls', '.xlsx')]
    # The two observed forms repeat the same demanded positions. Prefer the commercial form.
    selected = technical + (commercial if commercial else forms)
    if not selected:
        from app.sources.document_relevance import select_documents
        selected = [x.document for x in select_documents(documents)]
    by_id = {d.external_id: d for d in selected}
    if len(by_id) > 6:
        raise ValueError('tektorg_document_limit_requires_review')
    return list(by_id.values())


class TektorgAdapter:
    def search(self):
        from app.marketplace_discovery.primary.tektorg_search import collect_tektorg
        report = collect_tektorg(persist=False)
        result = []
        for item in report['items'][:2]:
            card = self.fetch_by_id(item['external_id'], source_url=item['source_url'])
            if card:
                result.append(card)
        return result

    def fetch_by_id(self, external_id, source_url=None):
        external_id = str(external_id)
        if not source_url or not safe_url(source_url):
            raise ValueError('tektorg_observed_source_url_required')
        match = re.fullmatch(r'/(?:[a-z0-9_-]+/)?procedures/(\d+)/?', urlsplit(source_url).path)
        if not match or match[1] != external_id:
            raise ValueError('tektorg_card_identity_mismatch')
        soup = BeautifulSoup(get_html(source_url, timeout=25), 'html.parser')
        node = soup.find('script', id='__NEXT_DATA__')
        if node is None:
            raise ValueError('tektorg_detail_layout_unrecognized')
        data = json.loads(node.string or node.get_text())
        row = data['props']['pageProps']['procedureItem']
        if str(row.get('id')) != external_id:
            raise ValueError('tektorg_response_identity_mismatch')
        row = dict(row)
        row['okpd2'] = [code for lot in row.get('lots', []) for code in lot.get('okpd2', [])]
        admitted, reason = candidate(row, {external_id: source_url}, datetime.now(timezone.utc), is_dismissed)
        if not admitted:
            return None
        documents = {}
        for a in soup.select('a[href]'):
            href = urljoin(source_url, a['href'])
            p = urlsplit(href)
            if not safe_url(href) or not p.path.startswith('/files-storage/') or not p.path.endswith('/download'):
                continue
            label = a.get('title') or a.get_text(' ', strip=True)
            name_match = re.search(r'(.+?\.(?:docx?|xlsx?|pdf))(?:\s|$)', label, re.I)
            if not name_match:
                continue
            name = Path(name_match[1].replace('\\', '/')).name
            uid = hashlib.sha256(p.path.encode()).hexdigest()
            # Store a stable reference, never an expiring token. Materializer refreshes it.
            stable = p._replace(query='', fragment='').geturl()
            documents[uid] = SourceDocument(external_id=uid, name=name, url=stable)
        if not documents:
            raise ValueError('tektorg_no_supported_documents')
        method = str(row.get('typeName') or '')
        tkp = row.get('subsectionAlias') == 'rosnefttkp' or '(Т)КП' in method.upper()
        title = ('[Запрос (Т)КП] ' if tkp else '') + row['title']
        return SourceTender(source='tektorg', external_id=external_id, title=title,
            source_url=source_url, customer_name=row.get('organizerName'), customer_inn=row.get('inn'),
            law_type='44-FZ' if row.get('sectionAlias') == '44fz' else None,
            procurement_method=method, submission_deadline=admitted['submission_deadline'],
            documents=list(documents.values()),
            description='Запрос технико-коммерческих предложений; не подтверждает обязательство заключить договор.' if tkp else None,
            raw_payload={'stage':'detail', 'procurement_status':row.get('statusName'),
                         'procedure_kind':'tkp' if tkp else 'procurement',
                         'registry_number':row.get('registryNumber'), 'suppress_notifications':True})


def download(client, url, target):
    for _ in range(4):
        if not safe_url(url, document=True):
            raise ValueError('tektorg_unexpected_download_host')
        with client.stream('GET', url) as response:
            if response.is_redirect:
                location = response.headers.get('location')
                if not location:
                    raise ValueError('tektorg_redirect_without_location')
                url = urljoin(url, location)
                continue
            if response.status_code != 200:
                raise ValueError('tektorg_download_http_' + str(response.status_code))
            content = bytearray()
            for chunk in response.iter_bytes():
                content.extend(chunk)
                if len(content) > 20 * 1024 * 1024:
                    raise ValueError('tektorg_file_over_20MB')
            if not content or bytes(content).lstrip().lower().startswith((b'<!doctype html', b'<html')):
                raise ValueError('tektorg_html_instead_of_document')
            target.write_bytes(content)
            return
    raise ValueError('tektorg_redirect_limit')


def materialize(tender):
    from app.core.config import settings
    import tempfile
    import shutil
    # Revalidate deadline/status and refresh signed document links just before download.
    fresh = TektorgAdapter().fetch_by_id(tender.external_id, source_url=tender.source_url)
    if fresh is None:
        raise ValueError('tektorg_no_longer_open')
    selected = select_bundle(fresh.documents)
    if not selected:
        raise ValueError('tektorg_no_selected_documents')
    soup = BeautifulSoup(get_html(tender.source_url, timeout=25), 'html.parser')
    signed = {}
    for a in soup.select('a[href]'):
        href = urljoin(tender.source_url, a['href']); p = urlsplit(href)
        if safe_url(href) and p.path.startswith('/files-storage/') and p.path.endswith('/download'):
            signed[hashlib.sha256(p.path.encode()).hexdigest()] = href
    root = Path(settings.storage_path) / 'tektorg_prepared'
    root.mkdir(parents=True, exist_ok=True)
    directory = Path(tempfile.mkdtemp(prefix=str(tender.external_id)+'-', dir=root))
    result = []
    try:
        with httpx.Client(timeout=30, follow_redirects=False) as client:
            for index, doc in enumerate(selected):
                if doc.external_id not in signed:
                    raise ValueError('tektorg_document_disappeared')
                if index:
                    time.sleep(1.2)
                target = directory / (str(index + 1) + '_' + doc.name)
                download(client, signed[doc.external_id], target)
                result.append(doc.model_copy(update={'name':target.name, 'download_type':'local_file', 'local_path':str(target)}))
    except Exception:
        shutil.rmtree(directory, ignore_errors=True)
        raise ValueError('tektorg_materialization_failed') from None
    return result
