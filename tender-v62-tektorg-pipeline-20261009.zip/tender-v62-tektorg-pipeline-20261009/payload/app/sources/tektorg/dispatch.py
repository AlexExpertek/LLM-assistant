"""Bounded automatic queueing, no reanalysis of completed tenders."""
def enqueue_candidates(items):
    import redis
    from sqlalchemy import select
    from app.core.config import settings
    from app.db.session import SyncSessionLocal
    from app.models.database import Tender
    from app.workers.completed_analysis import has_completed_analysis
    from app.workers.tasks_parsing import process_new_tender
    from .adapter import TektorgAdapter
    client = redis.Redis.from_url(settings.redis_url)
    outcomes = []
    queued = 0
    for item in items:
        number = str(item['external_id'])
        with SyncSessionLocal() as session:
            tender = session.execute(select(Tender).where(Tender.source=='tektorg', Tender.external_id==number)).scalar_one_or_none()
            if tender and has_completed_analysis(session, tender):
                outcomes.append({'number':number,'status':'cached'})
                continue
        if queued >= 2:
            outcomes.append({'number':number,'status':'batch_limit'})
            continue
        # Prevent repeated attempts on each collection. Successful results have a permanent DB guard.
        key = 'tektorg:pipeline:v1:' + number
        if not client.set(key, 'reserved', nx=True, ex=86400):
            outcomes.append({'number':number,'status':'already_queued_or_attempted'})
            continue
        try:
            card = TektorgAdapter().fetch_by_id(number, source_url=item['source_url'])
            if card is None:
                outcomes.append({'number':number,'status':'no_longer_eligible'})
                continue
            task = process_new_tender.delay(card.model_dump(mode='json'))
            queued += 1
            outcomes.append({'number':number,'status':'queued','task_id':task.id})
        except Exception as exc:
            outcomes.append({'number':number,'status':'queue_error','error_type':type(exc).__name__})
    return outcomes
