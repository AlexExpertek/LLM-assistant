"""Public Tektorg procurement integration."""
