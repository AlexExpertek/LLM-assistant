"""Observed public NEXT_DATA search. Primary candidates, never supply decisions."""
import json
import re
import time
from datetime import datetime, timezone
from urllib.parse import urlencode, urljoin, urlsplit
from bs4 import BeautifulSoup
from app.sources.public_http import get_html
from app.scoring.selection_policy import FALLBACK_QUERIES, OKPD2_PREFIXES
from app.marketplace_discovery.product_screening import aluminium_evidence, subject_block_reason
from app.reports.review_dismissals import is_dismissed

BASE = 'https://www.tektorg.ru'
CARD = re.compile(r'^/(?:[a-z0-9_-]+/)?procedures/(\d+)/?$')

def search_url(query, page):
    return BASE + '/procedures?' + urlencode({'name': query, 'page': page})

def parse_search(html):
    soup = BeautifulSoup(html, 'html.parser')
    node = soup.find('script', id='__NEXT_DATA__')
    if node is None:
        raise ValueError('search_layout_unrecognized')
    data = json.loads(node.string or node.get_text())
    state = data['props']['pageProps']['initialReduxState']
    if isinstance(state, str):
        state = json.loads(state)
    listing = state['listingProcedures']
    if not isinstance(listing.get('data'), list):
        raise ValueError('search_rows_unrecognized')
    links = {}
    for a in soup.select('a[href]'):
        url = urljoin(BASE, a['href'])
        p = urlsplit(url)
        match = CARD.fullmatch(p.path)
        if (p.scheme == 'https' and p.hostname == 'www.tektorg.ru'
                and not p.username and not p.password and p.port in (None, 443) and match):
            links[match[1]] = p._replace(query='', fragment='').geturl()
    return listing, links

def candidate(row, links, now, dismissed):
    identifier = str(row.get('id') or '')
    title = str(row.get('title') or '').strip()
    if not identifier.isdigit() or not title:
        return None, 'invalid_row'
    if dismissed('tektorg', identifier) or (row.get('registryNumber') and dismissed('tektorg', str(row['registryNumber']))):
        return None, 'manually_dismissed'
    if str(row.get('statusName') or '').strip().lower().replace('ё', 'е') != 'прием заявок':
        return None, 'not_open'
    try:
        deadline = datetime.fromisoformat(row['dates']['dateEndRegistration'].replace('Z', '+00:00'))
        if deadline.tzinfo is None:
            raise ValueError('timezone_missing')
    except (ValueError, TypeError, KeyError, AttributeError):
        return None, 'deadline_unknown'
    if deadline <= now:
        return None, 'expired'
    if (row.get('sectionAlias') in ('sale', 'vitrina', 'tenders')
            or re.search(r'\b(?:реализация|реализации|продажа|продаже)\b', title, re.I)):
        return None, 'sale_not_purchase'
    if re.search(r'ценовой информации|мониторинг.*цен|анализ рынка', str(row.get('typeName') or ''), re.I):
        return None, 'price_monitoring'
    if subject_block_reason(title):
        return None, 'non_target_subject'
    codes = [str(x.get('code') or '') for x in row.get('okpd2', []) if isinstance(x, dict)]
    code_match = any(code == prefix or code.startswith(prefix + '.') for code in codes for prefix in OKPD2_PREFIXES)
    if not aluminium_evidence(title) and not code_match:
        return None, 'no_product_evidence'
    url = links.get(identifier)
    if not url:
        return None, 'card_url_unconfirmed'
    return dict(source='tektorg', external_id=identifier, registry_number=row.get('registryNumber'),
        title=title, source_url=url, customer=row.get('organizerName'),
        procurement_method=row.get('typeName'), amount_text=row.get('sumPrice'), okpd2=codes,
        submission_deadline=deadline.astimezone(timezone.utc).isoformat(),
        search_stage=row.get('statusName'), status='primary_information', analysis_done=False,
        documents=[], documents_status='not_checked', mass_kg=None, mass_status='not_verified',
        eligibility='not_confirmed_500kg', collected_at=now.isoformat()), None

def _collect(*, persist=True, fetch=None, now=None, pause=time.sleep, dismissed=None, cursors=None):
    from .collector import save_report
    fetch = fetch or get_html
    dismissed = dismissed or is_dismissed
    now = now or datetime.now(timezone.utc)
    rotated = [q for q in FALLBACK_QUERIES if q != 'алюминий']
    queries = ['алюминий', rotated[(now.toordinal() * 6 + now.hour // 4) % len(rotated)]]
    report = dict(source='tektorg', name='ТЭК-Торг', checked_at=now.isoformat(),
        status='partial', coverage='public_next_data_max_3_pages_per_query', requests=0,
        items=[], skipped={}, errors=[], searches=[], cards_checked=0,
        classifier_filter='local_okpd2_only; native_search_parameter_not_confirmed')
    cursors = dict(cursors or {})
    report['next_pages'] = cursors
    report['coverage'] = 'first_page_plus_2_cursor_pages_per_query'
    seen = set()
    for query in queries:
        run = dict(query=query, field='name', pages=0, complete=False)
        report['searches'].append(run)
        page_ids = set()
        start = max(2, int(cursors.get(query, 2)))
        run['requested_pages'] = []
        run['tail_start'] = start
        try:
            pages = [1, start, start + 1]
            for page in pages:
                if report['requests']:
                    pause(1.2)
                report['requests'] += 1
                listing, links = parse_search(fetch(search_url(query, page), timeout=25))
                run['pages'] += 1
                run['requested_pages'].append(page)
                rows = listing['data']
                signature = tuple(sorted(str(row.get('id')) for row in rows))
                if rows and signature in page_ids:
                    raise ValueError('repeated_page')
                page_ids.add(signature)
                total = int(listing['total'])
                total_pages = int(listing['totalPages'])
                if page == 1 and start > total_pages:
                    pages[1:] = [2, 3]
                    start = 2
                    run['tail_start'] = 2
                if not rows and total > 0:
                    raise ValueError('unexpected_empty_page')
                for row in rows:
                    identifier = str(row.get('id') or '')
                    if identifier in seen:
                        continue
                    seen.add(identifier)
                    item, reason = candidate(row, links, now, dismissed)
                    if item:
                        report['items'].append(item)
                    else:
                        report['skipped'][reason] = report['skipped'].get(reason, 0) + 1
                if page > 1:
                    cursors[query] = page + 1
                if total == 0 or page >= total_pages:
                    cursors[query] = 2
                    run['cycle_finished'] = True
                    run['complete'] = start == 2 or total_pages <= 1
                    break
            if not run['complete']:
                run['reason'] = 'cycle_tail_checked' if run.get('cycle_finished') else 'page_limit'
        except Exception as exc:
            run['reason'] = str(exc) if isinstance(exc, ValueError) else type(exc).__name__
        if run.get('reason'):
            report['errors'].append(dict(query=query, reason=run['reason']))
    if all(x['complete'] for x in report['searches']):
        report['status'] = 'completed_checked_filters' if report['items'] else 'no_matches_in_checked_filters'
    if persist:
        save_report('tektorg', report)
    return report


def collect_tektorg(*, persist=True, fetch=None, now=None, pause=time.sleep, dismissed=None):
    from .collector import folder
    import fcntl
    root = folder()
    def read_cursors():
        try:
            previous = json.loads((root / 'tektorg.json').read_text())
            return previous.get('next_pages') or {}
        except FileNotFoundError:
            return {}
    def run():
        return _collect(persist=persist, fetch=fetch, now=now, pause=pause,
                        dismissed=dismissed, cursors=read_cursors())
    if not persist:
        return run()
    root.mkdir(parents=True, exist_ok=True)
    with (root / 'tektorg.lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return {'source': 'tektorg', 'status': 'already_running', 'items': []}
        report = run()
        from app.sources.tektorg.dispatch import enqueue_candidates
        report['pipeline'] = enqueue_candidates(report.get('items', []))
        from .collector import save_report
        save_report('tektorg', report)
        return report
