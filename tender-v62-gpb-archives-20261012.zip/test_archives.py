import ctypes as C
import ctypes.util
import tempfile
import unittest
from pathlib import Path
from app.sources.gpb.archives import read_members, validate_bytes, unpack
from app.sources.schemas import SourceDocument

def seven_zip(name='folder/test.txt',content=b'hello'):
 lib=C.CDLL(C.util.find_library('archive'))
 sig={
 'archive_write_new':(C.c_void_p,[]),
 'archive_write_set_format_7zip':(C.c_int,[C.c_void_p]),
 'archive_write_open_memory':(C.c_int,[C.c_void_p,C.c_void_p,C.c_size_t,C.POINTER(C.c_size_t)]),
 'archive_entry_new':(C.c_void_p,[]),
 'archive_entry_set_pathname':(None,[C.c_void_p,C.c_char_p]),
 'archive_entry_set_filetype':(None,[C.c_void_p,C.c_uint]),
 'archive_entry_set_perm':(None,[C.c_void_p,C.c_int]),
 'archive_entry_set_size':(None,[C.c_void_p,C.c_longlong]),
 'archive_write_header':(C.c_int,[C.c_void_p,C.c_void_p]),
 'archive_write_data':(C.c_ssize_t,[C.c_void_p,C.c_void_p,C.c_size_t]),
 'archive_write_close':(C.c_int,[C.c_void_p]),
 'archive_write_free':(C.c_int,[C.c_void_p]),
 'archive_entry_free':(None,[C.c_void_p])}
 for n,(r,a) in sig.items():getattr(lib,n).restype=r;getattr(lib,n).argtypes=a
 w=lib.archive_write_new();e=lib.archive_entry_new();buf=C.create_string_buffer(65536);used=C.c_size_t()
 try:
  assert lib.archive_write_set_format_7zip(w)==0
  assert lib.archive_write_open_memory(w,buf,len(buf),C.byref(used))==0
  lib.archive_entry_set_pathname(e,name.encode());lib.archive_entry_set_filetype(e,0o100000);lib.archive_entry_set_perm(e,0o600);lib.archive_entry_set_size(e,len(content))
  assert lib.archive_write_header(w,e)==0
  assert lib.archive_write_data(w,content,len(content))==len(content)
  assert lib.archive_write_close(w)==0
  return buf.raw[:used.value]
 finally:lib.archive_entry_free(e);lib.archive_write_free(w)

class ArchiveTests(unittest.TestCase):
 def test_read_7z(self):self.assertEqual(read_members(seven_zip()),[('test.txt',b'hello')])
 def test_signature(self):
  with self.assertRaises(ValueError):validate_bytes(b'<html>', '.rar')
 def test_traversal(self):
  with self.assertRaisesRegex(ValueError,'unsafe_archive_path'):read_members(seven_zip('../outside.txt'))
 def test_nested(self):
  with self.assertRaisesRegex(ValueError,'format_requires_review'):read_members(seven_zip('nested.zip'))
 def test_unpack_process(self):
  with tempfile.TemporaryDirectory() as d:
   rows,count,total=unpack(seven_zip(),SourceDocument(name='a.7z'),Path(d),0,0)
   self.assertEqual(count,1);self.assertEqual(total,5)
   self.assertEqual(Path(rows[0].local_path).read_bytes(),b'hello')
if __name__=='__main__':unittest.main()
