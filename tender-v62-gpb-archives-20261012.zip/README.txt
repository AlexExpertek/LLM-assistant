GPB archives update 2026-10-12
Requires GPB pipeline + document cache patch. Transport RETRY_V2 is untouched.
Adds libarchive-tools to Dockerfile apt dependencies and support for 7z/RAR/RAR5.
Hashes and Dockerfile anchor checked before changes; backups printed.
Archive reading is delegated to a separate Python interpreter, limited to 35s
wall time, 25s CPU and 1GiB address space. Contents are streamed through
libarchive. No archive paths are extracted: only generated local filenames.
Reject traversal, links, special files, encryption, nested archives/unsupported
formats; limits 20 files, 20MiB per file, 80MiB bundle. Existing per-position
criteria, schedule, cache, notification suppression and handoff limits remain.
Unsafe/unreadable archives block automatic analysis; successful downloads stay
cached. No use of declared hashes as content checksums.
Five offline tests passed including actual generated 7z roundtrip and subprocess
unpack, traversal/nested format rejection. Live RAR and organizer files are not
yet confirmed: check_archives.py performs bounded downloads/unpack, no OCR/LLM
or DB writes. It deletes temporary files.
No enqueue reservation keys are cleared. Earlier card attempts may remain held
by the existing 24-hour reservation even after the format fix is installed.
