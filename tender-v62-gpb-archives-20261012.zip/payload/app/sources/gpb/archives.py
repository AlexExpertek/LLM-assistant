"""Streaming libarchive reader; never extract archive paths to filesystem."""
import ctypes as C
import ctypes.util
import io
import re
from pathlib import Path, PurePosixPath
from app.sources.metal_it.documents import validate_bytes as base_validate, unpack as base_unpack, EXTENSIONS, MAX_BYTES, MAX_TOTAL, MAX_FILES
from app.sources.schemas import SourceDocument

ARCHIVES = {'.7z', '.rar'}


def validate_bytes(data, suffix):
    if suffix not in ARCHIVES:
        return base_validate(data, suffix)
    signatures = {'.7z': (b'7z\xbc\xaf\x27\x1c',), '.rar': (b'Rar!\x1a\x07\x00', b'Rar!\x1a\x07\x01\x00')}
    if not data or len(data) > MAX_BYTES or not data.startswith(signatures[suffix]):
        raise ValueError('gpb_archive_signature_or_size_invalid')


def library():
    name = C.util.find_library('archive')
    if not name:
        raise ValueError('gpb_libarchive_missing')
    lib = C.CDLL(name)
    signatures = {
        'archive_read_new': (C.c_void_p, []),
        'archive_read_support_filter_all': (C.c_int, [C.c_void_p]),
        'archive_read_support_format_7zip': (C.c_int, [C.c_void_p]),
        'archive_read_support_format_rar': (C.c_int, [C.c_void_p]),
        'archive_read_support_format_rar5': (C.c_int, [C.c_void_p]),
        'archive_read_open_memory': (C.c_int, [C.c_void_p, C.c_void_p, C.c_size_t]),
        'archive_read_next_header': (C.c_int, [C.c_void_p, C.POINTER(C.c_void_p)]),
        'archive_read_data': (C.c_ssize_t, [C.c_void_p, C.c_void_p, C.c_size_t]),
        'archive_read_free': (C.c_int, [C.c_void_p]),
        'archive_entry_pathname': (C.c_char_p, [C.c_void_p]),
        'archive_entry_size': (C.c_longlong, [C.c_void_p]),
        'archive_entry_filetype': (C.c_uint, [C.c_void_p]),
        'archive_entry_symlink': (C.c_char_p, [C.c_void_p]),
        'archive_entry_hardlink': (C.c_char_p, [C.c_void_p]),
        'archive_entry_is_encrypted': (C.c_int, [C.c_void_p]),
    }
    for name, (ret, args) in signatures.items():
        function = getattr(lib, name)
        function.restype = ret; function.argtypes = args
    return lib


def read_members(data):
    lib = library(); reader = lib.archive_read_new()
    if not reader:
        raise ValueError('gpb_archive_reader_failed')
    raw = C.create_string_buffer(data)
    output = []; total = 0; count = 0
    try:
        for name in ('archive_read_support_filter_all','archive_read_support_format_7zip',
                     'archive_read_support_format_rar','archive_read_support_format_rar5'):
            if getattr(lib,name)(reader) != 0:
                raise ValueError('gpb_archive_support_unavailable')
        if lib.archive_read_open_memory(reader, raw, len(data)) != 0:
            raise ValueError('gpb_archive_open_failed')
        entry = C.c_void_p()
        while True:
            status = lib.archive_read_next_header(reader, C.byref(entry))
            if status == 1: break
            if status != 0: raise ValueError('gpb_archive_header_failed')
            count += 1
            if count > 2000: raise ValueError('gpb_archive_entry_limit')
            name = (lib.archive_entry_pathname(entry) or b'').decode('utf-8', errors='strict').replace('\\','/')
            path = PurePosixPath(name)
            if not name or path.is_absolute() or '..' in path.parts or ':' in name or any(ord(c)<32 for c in name):
                raise ValueError('gpb_unsafe_archive_path')
            if lib.archive_entry_is_encrypted(entry):
                raise ValueError('gpb_encrypted_archive_requires_review')
            if lib.archive_entry_symlink(entry) or lib.archive_entry_hardlink(entry):
                raise ValueError('gpb_archive_links_rejected')
            kind = lib.archive_entry_filetype(entry)
            if kind == 0o040000: continue
            if kind != 0o100000: raise ValueError('gpb_archive_nonregular_member')
            if len(output) >= MAX_FILES: raise ValueError('gpb_archive_file_limit')
            size = lib.archive_entry_size(entry)
            if size < 0 or size > MAX_BYTES or total+size > MAX_TOTAL:
                raise ValueError('gpb_archive_expanded_size_limit')
            if path.suffix.lower() not in EXTENSIONS:
                raise ValueError('gpb_archive_member_format_requires_review:' + path.suffix.lower())
            if len(path.name) > 180: raise ValueError('gpb_archive_filename_limit')
            buffer = C.create_string_buffer(65536); chunks = []; actual = 0
            while True:
                n = lib.archive_read_data(reader,buffer,len(buffer))
                if n < 0: raise ValueError('gpb_archive_decompression_failed')
                if n == 0: break
                actual += n; total += n
                if actual > MAX_BYTES or total > MAX_TOTAL:
                    raise ValueError('gpb_archive_expanded_size_limit')
                chunks.append(buffer.raw[:n])
            content = b''.join(chunks)
            if actual != size: raise ValueError('gpb_archive_member_size_mismatch')
            base_validate(content,path.suffix.lower())
            output.append((path.name,content))
        if not output: raise ValueError('gpb_archive_empty')
        return output
    finally:
        lib.archive_read_free(reader)


def _worker(data, directory, send):
    try:
        # Bound CPU and address space independently of HTTP and Celery limits.
        import resource
        resource.setrlimit(resource.RLIMIT_CPU, (25,25))
        resource.setrlimit(resource.RLIMIT_AS, (1024*1024*1024, 1024*1024*1024))
        # Do not fork: worker is launched via separate Python process below.
        members = read_members(data)
        for i,(name,content) in enumerate(members):
            (Path(directory)/str(i)).write_bytes(content)
        send([name for name,_ in members])
    except Exception as exc:
        raise ValueError('gpb_archive_unpack_failed:' + str(exc)) from None


def unpack(data, doc, directory, counter, total):
    suffix = Path(doc.name).suffix.lower()
    if suffix not in ARCHIVES:
        return base_unpack(data,doc,directory,counter,total)
    validate_bytes(data,suffix)
    # Separate interpreter also works inside Celery daemonic worker processes.
    import subprocess, sys, tempfile, json
    with tempfile.TemporaryDirectory(prefix='gpb-archive-') as scratch:
        command = [sys.executable,'-m','app.sources.gpb.archives',scratch]
        try:
            result = subprocess.run(command,input=data,capture_output=True,timeout=35)
        except subprocess.TimeoutExpired:
            raise ValueError('gpb_archive_unpack_timeout') from None
        if result.returncode:
            raise ValueError('gpb_archive_unpack_failed:' + result.stderr.decode('utf-8',errors='replace')[-700:])
        names = json.loads(result.stdout)
        if not isinstance(names,list) or len(names)>MAX_FILES or counter+len(names)>MAX_FILES:
            raise ValueError('gpb_bundle_file_limit')
        documents=[]
        for i,name in enumerate(names):
            content=(Path(scratch)/str(i)).read_bytes()
            total+=len(content)
            if total>MAX_TOTAL:raise ValueError('gpb_bundle_size_limit')
            counter+=1
            target=Path(directory)/(str(counter)+'_'+name)
            target.write_bytes(content)
            documents.append(SourceDocument(name=target.name,external_id=doc.external_id,
                download_type='local_file',local_path=str(target),url=doc.url))
        return documents,counter,total

if __name__=='__main__':
    import sys,json
    try:
        content=sys.stdin.buffer.read(MAX_BYTES+1)
        if len(content)>MAX_BYTES:raise ValueError('gpb_archive_input_limit')
        _worker(content,sys.argv[1],lambda names:print(json.dumps(names,ensure_ascii=True)))
    except Exception as exc:
        print(str(exc),file=sys.stderr);sys.exit(1)
