"""Cache complete, validated downloads within an exact document revision snapshot."""
import fcntl
import hashlib
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from .transport import fetch
from app.sources.metal_it.documents import MAX_TOTAL
from .archives import validate_bytes

class DocumentsIncomplete(ValueError):
    def __init__(self, report):
        self.report = report
        super().__init__('gpb_documents_incomplete: ' + str(len(report['errors'])) + ' unavailable; analysis not started')


def atomic(path, data):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_bytes(data)
    os.replace(temporary, path)


def cached_downloads(tender, root, download=None):
    download = download or fetch
    uid = str(tender.external_id)
    if not uid.isdigit():
        raise ValueError('gpb_cache_invalid_identity')
    # Include source dates/revision metadata; a declared hash is not a content checksum.
    public = tender.raw_payload['gpb']['public_card']
    parents = [public['procedure']] + public['lots']
    revisions = [p.get('relationships', {}).get('docs') for p in parents]
    identity = {'documents':[d.model_dump(mode='json') for d in tender.documents], 'revisions':revisions}
    key = hashlib.sha256(json.dumps(identity, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    directory = Path(root) / uid / key
    directory.mkdir(parents=True, exist_ok=True)
    with (directory/'cache.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        report = dict(external_id=uid, snapshot=key, checked_at=datetime.now(timezone.utc).isoformat(),
                      complete=False, documents=[], errors=[])
        output = []; total = 0
        for doc in tender.documents:
            token = hashlib.sha256(doc.url.encode()).hexdigest()
            file = directory/(token + '.bin'); metadata = directory/(token + '.json')
            data = None; cached = False
            try:
                if file.exists() and metadata.exists():
                    record = json.loads(metadata.read_text())
                    candidate = file.read_bytes()
                    if hashlib.sha256(candidate).hexdigest() == record.get('sha256'):
                        validate_bytes(candidate, Path(doc.name).suffix.lower())
                        data = candidate; cached = True
            except (ValueError, OSError):
                data = None
            try:
                if data is None:
                    data = download(doc.url, document=True)
                    validate_bytes(data, Path(doc.name).suffix.lower())
                    digest = hashlib.sha256(data).hexdigest()
                    atomic(file, data)
                    atomic(metadata, json.dumps({'sha256':digest,'name':doc.name}).encode())
                total += len(data)
                if total > MAX_TOTAL:
                    raise ValueError('gpb_document_bundle_size_limit')
                output.append((doc, file))
                report['documents'].append({'name':doc.name,'id':doc.external_id,
                    'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'cached':cached})
            except Exception as exc:
                reason = re.sub(r'https?://\S+', '[URL]', str(exc))[:700]
                report['errors'].append({'name':doc.name,'id':doc.external_id,
                                         'error_type':type(exc).__name__,'reason':reason})
        report['complete'] = not report['errors'] and len(output) == len(tender.documents)
        atomic(directory/'status.json', json.dumps(report,ensure_ascii=False,indent=2).encode())
        if not report['complete']:
            raise DocumentsIncomplete(report)
        return output
