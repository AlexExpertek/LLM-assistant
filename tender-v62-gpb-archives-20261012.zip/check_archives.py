import tempfile
from pathlib import Path
from app.sources.gpb.transport import fetch
from app.sources.gpb.archives import unpack
from app.sources.schemas import SourceDocument
files=[
('3._инструкции_для_поставщика.7z','https://etp.gpb.ru/file/get/t/LotDocuments/id/7037907/name/6abb9a50d4b460.90517190'),
('1._Проект_договора.7z','https://etp.gpb.ru/file/get/t/LotDocuments/id/7037908/name/6abb9a513829c0.39562884'),
('Документация.rar','https://etp.gpb.ru/file/get/t/PriceOrderDocument/id/1365589/m/nsi/name/6aba089e413513.11233175')]
for name,url in files:
 print('\nARCHIVE:',name,flush=True)
 try:
  data=fetch(url,document=True)
  with tempfile.TemporaryDirectory(prefix='gpb-archive-probe-') as directory:
   docs,count,total=unpack(data,SourceDocument(name=name,url=url),Path(directory),0,0)
   print('ARCHIVE_OK:',count,'EXPANDED_BYTES:',total,flush=True)
   for doc in docs:print('MEMBER:',doc.name,flush=True)
 except Exception as exc:print('ERROR:',type(exc).__name__,str(exc)[:1000],flush=True)
print('CHECK_FINISHED: temporary files deleted; no DB writes, queues, OCR, LLM or notifications')
