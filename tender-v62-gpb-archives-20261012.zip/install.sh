#!/usr/bin/env bash
set -Eeuo pipefail
pkg_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
python3 "$pkg_dir/dependency.py" --check
python3 "$pkg_dir/apply.py" --project "$PWD" --check
python3 "$pkg_dir/apply.py" --project "$PWD"
python3 "$pkg_dir/dependency.py"
docker compose build app celery_worker celery_discovery
docker compose run --rm --no-deps -T -e PYTHONPATH=/app -v "$pkg_dir:/gpb-archive-check:ro" celery_discovery python /gpb-archive-check/test_archives.py
docker compose up -d --no-deps --timeout 60 app celery_worker celery_discovery
printf '%s\n' 'GPB_ARCHIVES_INSTALLED' 'No immediate collection or analysis; existing schedule retained.'
