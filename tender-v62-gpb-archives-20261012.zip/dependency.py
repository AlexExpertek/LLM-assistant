from pathlib import Path
import sys,shutil,datetime
p=Path('Dockerfile');s=p.read_text()
if 'libarchive-tools' in s:
 print('LIBARCHIVE_DEPENDENCY_PRESENT');raise SystemExit(0)
anchor='    curl \\\n'
if s.count(anchor)!=1 or 'apt-get install' not in s:
 raise SystemExit('DOCKERFILE_VERSION_CONFLICT: no changes')
if '--check' in sys.argv:raise SystemExit(0)
backup=Path('/tmp')/('gpb-Dockerfile-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
shutil.copy2(p,backup)
p.write_text(s.replace(anchor,anchor+'    libarchive-tools \\\n'))
print('DOCKERFILE_BACKUP:',backup)
