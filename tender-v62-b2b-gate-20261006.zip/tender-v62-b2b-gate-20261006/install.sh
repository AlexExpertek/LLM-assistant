#!/usr/bin/env bash
set -Eeuo pipefail
pkg_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
project_dir="${TENDER_PROJECT_DIR:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
cd "$project_dir"
test -f docker-compose.yml
python3 "$pkg_dir/apply.py" --project "$project_dir"
docker compose build app celery_worker celery_discovery
for test_file in verify.py regression.py test_product.py; do
    docker compose run --rm --no-deps -T celery_worker python - < "$pkg_dir/$test_file"
done
docker compose run --rm --no-deps -T -v "$pkg_dir:/checks:ro" celery_worker python /checks/test_b2b.py
docker compose run --rm --no-deps -T celery_worker python - < "$pkg_dir/record_rejections.py"
docker compose up -d --no-deps --timeout 60 app celery_worker celery_discovery
printf '\nB2B_GATE_UPDATE_INSTALLED\nExisting schedule retained. No immediate collection or database cleanup requested.\n'
