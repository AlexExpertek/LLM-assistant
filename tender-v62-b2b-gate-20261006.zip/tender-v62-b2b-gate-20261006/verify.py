import os
# Offline verification never uses production connection settings.
for k,v in dict(DATABASE_URL='postgresql+asyncpg://test:test@127.0.0.1/test',DATABASE_URL_SYNC='postgresql://test:test@127.0.0.1/test',REDIS_URL='redis://127.0.0.1:6379/0',CELERY_BROKER_URL='memory://',CELERY_RESULT_BACKEND='cache+memory://',QDRANT_URL='http://127.0.0.1:6333').items():os.environ[k]=v
import unittest
from datetime import datetime, timezone
from unittest.mock import patch
import httpx
from app.sources.eis_freshness import eligibility
from app.sources.http_refusal import refusal_status
from app.reports.review_dashboard import assemble
from app.workers import tasks_parsing as tasks
from app.sources.schemas import SourceTender
NOW=datetime(2026,10,6,6,tzinfo=timezone.utc)
class Checks(unittest.TestCase):
    def test_dates_and_stages(self):
        cases=[
          ('2014-01-01',{'stage':'search','search_item':{'status':'Подача заявок'}},'deadline_expired'),
          (None,{'stage':'search'},'freshness_unknown'),
          (None,{'stage':'search','search_item':{'status':'Подача заявок'}},'needs_detail'),
          ('2026-10-06',{'stage':'search','search_item':{'status':'Подача заявок'}},'needs_detail'),
          ('2026-10-06T09:00:00+03:00',{},'deadline_expired'),
          ('2026-10-06T10:00:00+03:00',{},None),
          ('2026-10-06T05:59:59',{},'deadline_expired'),
          ('2026-12-01',{'procurement_status':'Работа комиссии'},'closed_stage'),
          (None,{'stage':'detail'},'freshness_unknown'),
          ('bad',{'stage':'detail'},'freshness_unknown')]
        for deadline,raw,want in cases:
            with self.subTest(deadline=deadline,raw=raw):
                self.assertEqual(eligibility('zakupki_gov_ru',deadline,raw,now=NOW),want)
    def test_other_sources_unknown(self):
        for source in ('b2b_center','tender_pro'):
            self.assertEqual(eligibility(source,None,{},now=NOW),'freshness_unknown')
    def test_review_hides_old_unknown(self):
        rows=[{'source':'zakupki_gov_ru','external_id':str(i),'submission_deadline':d} for i,d in enumerate((None,'bad','2014-01-01','2026-10-07T00:00:00+03:00'))]
        self.assertEqual([x['external_id'] for x in assemble(rows,[],now=NOW)],['3'])
    def test_refusal(self):
        for status in (401,403,429,500):
            request=httpx.Request('GET','https://example.test/')
            exc=httpx.HTTPStatusError('test',request=request,response=httpx.Response(status,request=request))
            self.assertEqual(refusal_status(exc),status if status!=500 else None)
    def card(self,raw):
        return SourceTender(source='zakupki_gov_ru',external_id='326test',title='Лист алюминиевый',documents=[],raw_payload=raw)
    def test_unknown_never_opens_db_or_fetches(self):
        for stage in ('search','detail'):
            card=self.card({'stage':stage})
            with patch('app.reports.review_dismissals.is_dismissed',return_value=False),patch.object(tasks,'SyncSessionLocal',side_effect=AssertionError('DB opened')),patch.object(tasks,'get_adapter',side_effect=AssertionError('HTTP attempted')):
                result=tasks.process_new_tender.run(card.model_dump(mode='json'))
            self.assertEqual(result['reason'],'freshness_unknown')
    def test_search_hydrates_before_db(self):
        card=self.card({'stage':'search','search_item':{'status':'Подача заявок'}})
        with patch('app.reports.review_dismissals.is_dismissed',return_value=False),patch.object(tasks,'get_adapter') as adapter,patch.object(tasks,'SyncSessionLocal',side_effect=AssertionError('DB opened')):
            adapter.return_value.fetch_by_id.return_value=self.card({'stage':'detail'})
            result=tasks.process_new_tender.run(card.model_dump(mode='json'))
            adapter.return_value.fetch_by_id.assert_called_once()
        self.assertEqual(result['reason'],'freshness_unknown')
    def test_403_no_retry(self):
        request=httpx.Request('GET','https://example.test/')
        exc=httpx.HTTPStatusError('test',request=request,response=httpx.Response(403,request=request))
        card=self.card({'stage':'search','search_item':{'status':'Подача заявок'}})
        with patch('app.reports.review_dismissals.is_dismissed',return_value=False),patch.object(tasks,'get_adapter') as adapter,patch.object(tasks.process_new_tender,'retry',side_effect=AssertionError('retry called')):
            adapter.return_value.fetch_by_id.side_effect=exc
            result=tasks.process_new_tender.run(card.model_dump(mode='json'))
        self.assertEqual(result,{'status':'blocked','reason':'http_refused','http_status':403})
if __name__=='__main__':unittest.main()
