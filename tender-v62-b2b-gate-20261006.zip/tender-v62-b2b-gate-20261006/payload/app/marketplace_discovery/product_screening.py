"""Conservative B2B product evidence; search hits and missing access are not evidence."""
import re
from app.scoring.selection_policy import ALUMINIUM, material_status
from app.marketplace_discovery.subject_classifier import classify_tender_subject

VERSION = 'b2b-gate-20261006'
OTHER = re.compile(r'\b(?:сталь|стальн\w*|кабел\w*|провод\w*|запасн\w*\s+част\w*|оснастк\w*|ветеринар\w*|сульфат\w*|оксид\w*|гидроксид\w*|хлорид\w*)\b', re.I)
CHEMICAL = re.compile(r'\b(?:сульфат\w*|оксид\w*|гидроксид\w*|хлорид\w*|ветеринар\w*)\b', re.I)


def aluminium_evidence(text):
    # Evaluate separate goods independently: steel elsewhere must not veto Al.
    # Do not use classifier codes or arbitrary search matches as product evidence.
    for part in re.split(r'[;\n,]|\s+и\s+', str(text or '')):
        if CHEMICAL.search(part):
            continue
        if material_status({'name': part}) is True:
            return True
        # Bare aluminium procurement can legitimately omit the form/alloy.
        if (ALUMINIUM.search(part) and not OTHER.search(part)
                and classify_tender_subject(part).allowed
                and re.search(r'\b(?:поставка|закупка|закупаем|приобретение)\s+алюмини[яй]\b', part, re.I)):
            return True
    return False


def title_excluded(title, description=''):
    if subject_block_reason(title):
        return True
    # A specific positive product in a search description preserves mixed tenders.
    if aluminium_evidence(title) or aluminium_evidence(description):
        return False
    return bool(OTHER.search(title or ''))


# Procurement subject takes precedence over materials mentioned in components.
FINISHED_HEAD = re.compile(r'^\s*(?:поставка|закупка|приобретение)\s+(?:сушил\w*|вешал\w*|контейнер\w*\s+для\s+кислород\w*\s+баллон\w*)\b', re.I)
WORK_SUBJECT = re.compile(r'\b(?:изготовлени\w*\s+и\s+установк\w*\s+светопрозрачн\w*\s+конструкц\w*|выполнить\s+строительств\w*|выполнение\s+работ\w*|подготовить\s+площадк\w*)\b', re.I)


def subject_block_reason(title):
    classification = classify_tender_subject(title or '')
    if not classification.allowed:
        return classification.subject_type
    if WORK_SUBJECT.search(title or ''):
        return 'works_service'
    if FINISHED_HEAD.search(title or ''):
        return 'finished_product'
    return None


REASONS = {
    'manually_dismissed': 'Отклонена после ручной проверки',
    'inactive': 'Закупка неактивна',
    'closed_stage': 'Приём заявок завершён или закупка отменена',
    'deadline_unknown': 'Нет подтверждённого срока подачи заявок',
    'expired': 'Срок подачи заявок истёк',
    'works_service': 'Предмет закупки — работы или монтаж',
    'finished_product': 'Предмет закупки — готовые изделия или кабельная продукция',
    'no_aluminium_evidence': 'Нет подтверждённых признаков целевой алюминиевой продукции',
    'no_target_positions': 'В полном списке нет целевых позиций',
    'below_500kg': 'Каждая целевая позиция меньше 500 кг; массы не суммируются',
    'incomplete_positions': 'Есть признаки алюминиевой продукции; полный список позиций не подтверждён',
    'mass_unknown': 'Есть признаки алюминиевой продукции; требуется подтвердить массу одной позиции от 500 кг',
    'ready_for_analysis': 'Есть алюминиевая позиция от 500 кг; требуется общий анализ условий',
}


def screen_candidate(candidate, *, now=None, dismissed=None, check_context=True):
    """Shared decision for collection, review display and read-only diagnostics.

    'analyze' is permission to analyze, never a final supply decision.
    Unknown mass stays review; complete specifications may still be analyzed to
    obtain dimensions/mass through the existing analysis pipeline.
    """
    from app.scoring.selection_policy import mass_kg, MIN_WEIGHT_KG
    raw = candidate.get('raw_payload') or {}
    positions = [p for p in (raw.get('positions') or []) if isinstance(p, dict)]
    matches = [p for p in positions if material_status(p) is True]
    evidence = [{'position_number': p.get('position_number'),
                 'name': p.get('name') or p.get('name_product') or p.get('product_name'),
                 'mass_kg': mass_kg(p)} for p in matches]
    def result(action, reason):
        return {'action': action, 'reason': reason, 'message': REASONS[reason], 'evidence': evidence}
    if check_context:
        if dismissed is None:
            from app.reports.review_dismissals import is_dismissed
            dismissed = is_dismissed(candidate.get('source'), str(candidate.get('external_id') or ''))
        if dismissed: return result('reject', 'manually_dismissed')
        from app.sources.eis_freshness import eligibility
        freshness = eligibility('b2b_center', candidate.get('submission_deadline'), raw,
                                candidate.get('is_active', True), now)
        if freshness:
            reason = {'freshness_unknown':'deadline_unknown', 'deadline_expired':'expired'}.get(freshness, freshness)
            return result('reject', reason)
    title = candidate.get('title') or ''
    blocked = subject_block_reason(title)
    if blocked: return result('reject', blocked)
    if not matches and not aluminium_evidence(title):
        return result('reject', 'no_aluminium_evidence')
    complete = (raw.get('b2b_public') or {}).get('complete') is True
    if not complete: return result('review', 'incomplete_positions')
    possible = [p for p in positions if material_status(p) is not False]
    if not possible: return result('reject', 'no_target_positions')
    # Even unconfirmed materials with known subthreshold mass cannot qualify.
    if all(mass_kg(p) is not None and mass_kg(p) < MIN_WEIGHT_KG for p in possible):
        return result('reject', 'below_500kg')
    if any(mass_kg(p) is not None and mass_kg(p) >= MIN_WEIGHT_KG for p in matches):
        return result('analyze', 'ready_for_analysis')
    return result('analyze', 'mass_unknown')


def candidate_relevant(candidate):
    """Compatibility product-only check; use screen_candidate for operational decisions."""
    return screen_candidate(candidate, check_context=False)['action'] != 'reject'
