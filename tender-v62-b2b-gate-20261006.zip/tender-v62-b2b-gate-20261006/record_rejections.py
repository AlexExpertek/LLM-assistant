"""Record only the three exclusions explicitly requested by the operator."""
from app.reports.review_dismissals import is_dismissed, set_dismissed
for source, number, reason in (
    ('b2b_center','4549069','Отклонено пользователем: две позиции Д16 по 10 кг; порог 500 кг'),
    ('b2b_center','4619387','Отклонено пользователем: кабельная продукция вне ассортимента'),
    ('zakupki_gov_ru','32616424753','Отклонено пользователем: алюминиевый лист около 60 кг; остальные позиции стальные'),
):
    if not is_dismissed(source, number): set_dismissed(source, number, reason=reason)
    print('MANUAL_REJECTION_RETAINED:',source,number)
