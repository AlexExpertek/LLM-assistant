"""Read-only operational gate diagnostics, including explicit matched positions."""
import json
from collections import Counter
from app.marketplace_discovery.review_store import list_review_candidates
from app.marketplace_discovery.product_screening import screen_candidate
counts=Counter()
for row in list_review_candidates(500):
    if row.get('source') != 'b2b_center': continue
    result=screen_candidate(row)
    counts[result['reason']]+=1
    print(json.dumps({'number':row.get('external_id'),'title':row.get('title'),
        'deadline':row.get('submission_deadline'), **result},ensure_ascii=False,default=str))
print(dict(counts))
print('READ_ONLY: no HTTP, tasks, DB writes, LLM or notifications')
