import os,json,unittest,copy,sys
sys.path.insert(0, os.getcwd())
from pathlib import Path
from unittest.mock import patch
for k,v in dict(DATABASE_URL='postgresql+asyncpg://test:test@127.0.0.1/test',DATABASE_URL_SYNC='postgresql://test:test@127.0.0.1/test',REDIS_URL='redis://127.0.0.1:6379/0',CELERY_BROKER_URL='memory://',CELERY_RESULT_BACKEND='cache+memory://',QDRANT_URL='http://127.0.0.1:6333').items():os.environ[k]=v
import httpx
from app.marketplace_discovery.b2b_center import B2BCenterDiscoveryClient,SEARCH_URL
ROOT=Path(__file__).resolve().parent
FIX=json.loads((ROOT/'fixtures/api-page1.json').read_text())
HTML=(ROOT/'fixtures/archive.html').read_text()
class Checks(unittest.TestCase):
 def setUp(self): self.c=B2BCenterDiscoveryClient()
 def test_real_api(self):
  rows=self.c._parse_api(FIX,query='алюминий');self.assertEqual(len(rows),20)
  self.assertEqual(rows[0].external_id,str(FIX['trades'][0]['trade_id']))
  self.assertTrue(all(r.deadline and r.deadline.utcoffset().total_seconds()==10800 for r in rows))
  self.assertEqual(rows[0].title.find('<mark>'),-1)
 def test_archive_response_rejected(self):
  data=copy.deepcopy(FIX);data['current_tab']='archive'
  with self.assertRaisesRegex(RuntimeError,'non-current'):self.c._parse_api(data,query='алюминий')
 def test_failure_not_empty_success(self):
  for data in ({'mode':'failure'},{'mode':'guest','current_tab':'actual'},[],None):
   with self.assertRaises(RuntimeError):self.c._parse_api(data,query='алюминий')
 def test_valid_empty(self):self.assertEqual(self.c._parse_api({'mode':'guest','current_tab':'actual','trades':[]},query='x'),[])
 def test_date_only_unknown(self):
  data=copy.deepcopy(FIX);data['trades']=data['trades'][:1];data['trades'][0]['date_actual']='12.10.2026'
  self.assertIsNone(self.c._parse_api(data,query='x')[0].deadline)
 def test_bad_url(self):
  for url in ('https://evil.test/tender-1/','http://www.b2b-center.ru/tender-1/','https://www.b2b-center.ru/tender-9999999/'):
   data=copy.deepcopy(FIX);data['trades'][0]['url']=url
   with self.assertRaises(RuntimeError):self.c._parse_api(data,query='x')
 def test_recommendations_not_included(self):
  data=copy.deepcopy(FIX)
  for row in data['trades']:row['is_recommended']=True
  self.assertEqual(self.c._parse_api(data,query='x'),[])
 def test_html_wrong_query(self):
  with self.assertRaisesRegex(RuntimeError,'query mismatch'):self.c._parse(HTML,query='алюминий')
 def test_html_archive(self):
  with self.assertRaisesRegex(RuntimeError,'current tab'):self.c._parse(HTML,query='ашинский метзавод феррохром')
 def test_public_request_and_repeated_page(self):
  req=httpx.Request('GET',SEARCH_URL);response=httpx.Response(200,json=FIX,request=req)
  with patch('app.marketplace_discovery.b2b_center.httpx.Client') as client:
   mock=client.return_value.__enter__.return_value;mock.get.return_value=response
   self.c.search('алюминий',page=1)
   params=mock.get.call_args.kwargs['params']
   self.assertEqual(params['tab'],'actual');self.assertEqual(params['macro_trade_type'],'buy');self.assertEqual(params['query'],'алюминий')
   with self.assertRaisesRegex(RuntimeError,'B2B_PAGINATION_REPEATED'):self.c.search('алюминий',page=2)
   self.assertEqual(mock.get.call_args.kwargs['params']['page'],2)
 def test_redirect_not_followed(self):
  with patch('app.marketplace_discovery.b2b_center.httpx.Client') as client:
   client.return_value.__enter__.return_value.get.return_value=httpx.Response(302,headers={'location':'/login'},request=httpx.Request('GET',SEARCH_URL))
   with self.assertRaises(httpx.HTTPStatusError):self.c.search('x')
   self.assertFalse(client.call_args.kwargs['follow_redirects'])
 def test_html_instead_of_json(self):
  with patch('app.marketplace_discovery.b2b_center.httpx.Client') as client:
   client.return_value.__enter__.return_value.get.return_value=httpx.Response(200,text='<html>Login</html>',request=httpx.Request('GET',SEARCH_URL))
   with self.assertRaisesRegex(RuntimeError,'non-JSON'):self.c.search('x')
 def test_schema_failure_stops_source_sweep(self):
  from app.marketplace_discovery import runner
  from types import SimpleNamespace
  from unittest.mock import Mock
  adapter=SimpleNamespace(platform_code='b2b_center',search=Mock(side_effect=RuntimeError('B2B public search unavailable')))
  with patch.object(runner,'get_marketplaces',return_value=[adapter]):
   result=runner.run_marketplace_discovery(max_per_platform=1)
  self.assertEqual(adapter.search.call_count,1)
  self.assertEqual(result['b2b_center']['status'],'error')
if __name__=='__main__':unittest.main()
