"""
Извлечение полей из текста тендерной документации.
Реализует требования раздела 5.4 (обязательные извлекаемые поля) и 6.4
(объяснимость и уверенность) ТЗ.

Принцип no-hallucination (раздел 1.3 ТЗ): модель никогда не выдумывает
значения. Если поле не найдено — null. Каждое поле сопровождается
confidence и цитатой-источником.
"""
from typing import Optional

from pydantic import BaseModel, Field

from app.llm.router import TaskType, llm_router

# ──────────────────────────────────────────────────────────
# Pydantic-схема для валидации ответа модели (= guardrails из ТЗ FR-EXP-001..003)
# ──────────────────────────────────────────────────────────


class ExtractedField(BaseModel):
    """Одно извлечённое поле с метаданными для объяснимости."""
    value: Optional[str] = None         # нормализованное значение, либо None
    raw_quote: Optional[str] = None      # точная цитата из документа
    confidence: float = Field(ge=0.0, le=1.0, default=0.0)


class TenderExtractionResult(BaseModel):
    """
    Полная схема извлекаемых полей по разделу 5.4 ТЗ.
    Каждое поле — объект ExtractedField, а не голое значение,
    чтобы сохранить confidence и источник для каждого факта отдельно.
    """
    # Идентификация
    customer_name: ExtractedField
    customer_inn: ExtractedField
    product_name: ExtractedField

    # Технические параметры
    alloy: ExtractedField                 # марка сплава
    temper: ExtractedField                 # состояние материала
    thickness_mm: ExtractedField
    width_mm: ExtractedField
    length_mm: ExtractedField
    diameter_mm: ExtractedField
    cross_section_shape: ExtractedField
    quantity: ExtractedField
    mass_kg: ExtractedField
    unit: ExtractedField
    tolerance: ExtractedField              # допустимые отклонения
    standard: ExtractedField               # ГОСТ/ОСТ/ТУ

    # Доп. обработка
    coating: ExtractedField
    machining: ExtractedField
    has_drawings: ExtractedField

    # Логистика и договор
    delivery_place: ExtractedField
    delivery_term: ExtractedField
    payment_terms: ExtractedField
    initial_max_price: ExtractedField      # НМЦК
    bid_security: ExtractedField           # обеспечение заявки
    contract_security: ExtractedField      # обеспечение исполнения
    experience_requirements: ExtractedField
    manufacturer_requirements: ExtractedField
    analog_allowed: ExtractedField         # допустимость аналога
    partial_delivery_allowed: ExtractedField
    advance_payment: ExtractedField
    penalties: ExtractedField

    # Результат и источник
    submission_deadline: ExtractedField


EXTRACTION_SYSTEM_PROMPT = """Ты — эксперт по анализу тендерной документации на поставку \
алюминиевого металлопроката (листы, рулоны, профили, трубы, прутки, шины, катанка, проволока) \
и услуг металлообработки (окраска, резка, профилирование).

Твоя задача — извлечь из текста тендерного документа структурированные данные.

ПРАВИЛА (строго обязательны):
1. Извлекай ТОЛЬКО то, что прямо написано в тексте. Никогда не выдумывай и не предполагай значения.
2. Если поле явно не упомянуто в документе — value: null, confidence: 0.0, raw_quote: null.
3. Для каждого найденного значения указывай raw_quote — точную цитату из текста (не более 200 символов),
   подтверждающую это значение.
4. confidence — твоя уверенность от 0.0 до 1.0:
   - 1.0 — значение прямо и однозначно указано
   - 0.5-0.7 — значение выводится косвенно или текст неоднозначен
   - ниже 0.5 — низкая уверенность, скан плохого качества, неполное предложение
5. Марки сплавов могут быть написаны кириллицей и латиницей, с пробелами и дефисами:
   АД31 / AD31 / АД 31 / Д16Т / AMg5M — нормализуй к стандартному виду без пробелов (АД31, Д16Т).
6. Единицы измерения нормализуй: массу к кг, длину к мм, если в документе другие единицы — \
   укажи нормализованное значение, а в raw_quote сохрани оригинальную формулировку.

Ответь СТРОГО в формате JSON, соответствующем описанной структуре, без каких-либо пояснений."""


def build_extraction_user_prompt(document_text: str, json_schema: dict) -> str:
    """Формирует промпт пользователя со схемой и текстом документа."""
    return f"""Извлеки данные из следующего тендерного документа.

JSON-схема ответа (каждое поле — объект {{value, raw_quote, confidence}}):
{json_schema}

Текст документа:
---
{document_text[:15000]}
---

Ответь только JSON-объектом, соответствующим схеме выше."""


async def extract_tender_fields(document_text: str) -> TenderExtractionResult:
    """
    Главная функция извлечения. Вызывает LLM, валидирует ответ через Pydantic
    (это и есть guardrails — невалидный ответ выбросит ValidationError,
    и задача уйдёт в статус "требует проверки" вместо того, чтобы пропустить
    мусорные данные дальше по пайплайну).
    """
    schema_hint = TenderExtractionResult.model_json_schema()

    user_prompt = build_extraction_user_prompt(document_text, schema_hint)

    response = await llm_router.complete(
        task=TaskType.EXTRACT_FIELDS,
        system_prompt=EXTRACTION_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        max_tokens=3000,
        temperature=0.0,
        json_mode=True,
    )

    raw_json = response.as_json()

    # Pydantic выбросит ValidationError если структура не соответствует схеме —
    # это и есть проверка "детерминированных правил и обязательных полей" из FR-EXP-003
    result = TenderExtractionResult.model_validate(raw_json)
    return result


def fields_requiring_review(result: TenderExtractionResult, threshold: float = 0.5) -> list[str]:
    """
    Возвращает список полей с confidence ниже порога —
    это и есть статус "требует проверки" из FR-DOC-004 ТЗ.
    """
    low_confidence_fields = []
    for field_name, field_value in result.model_dump().items():
        if field_value["value"] is not None and field_value["confidence"] < threshold:
            low_confidence_fields.append(field_name)
    return low_confidence_fields


# ───────────────── v6: многопозиционное извлечение ─────────────────
class TenderPositionExtraction(BaseModel):
    position_number: int = 1
    lot_number: Optional[str] = "1"
    product_name: ExtractedField = Field(default_factory=ExtractedField)
    product_type: ExtractedField = Field(default_factory=ExtractedField)
    alloy: ExtractedField = Field(default_factory=ExtractedField)
    temper: ExtractedField = Field(default_factory=ExtractedField)
    thickness_mm: ExtractedField = Field(default_factory=ExtractedField)
    width_mm: ExtractedField = Field(default_factory=ExtractedField)
    length_mm: ExtractedField = Field(default_factory=ExtractedField)
    diameter_mm: ExtractedField = Field(default_factory=ExtractedField)
    quantity: ExtractedField = Field(default_factory=ExtractedField)
    mass_kg: ExtractedField = Field(default_factory=ExtractedField)
    unit: ExtractedField = Field(default_factory=ExtractedField)
    standard: ExtractedField = Field(default_factory=ExtractedField)
    coating: ExtractedField = Field(default_factory=ExtractedField)
    machining: ExtractedField = Field(default_factory=ExtractedField)
    has_drawings: ExtractedField = Field(default_factory=ExtractedField)
    delivery_place: ExtractedField = Field(default_factory=ExtractedField)
    delivery_term: ExtractedField = Field(default_factory=ExtractedField)
    payment_terms: ExtractedField = Field(default_factory=ExtractedField)


class TenderMultiExtractionResult(BaseModel):
    partial_delivery_allowed: ExtractedField = Field(default_factory=ExtractedField)
    positions: list[TenderPositionExtraction] = Field(default_factory=list)


MULTI_EXTRACTION_SYSTEM_PROMPT = EXTRACTION_SYSTEM_PROMPT + """
7. Тендер может содержать несколько лотов и несколько товарных позиций. Не объединяй разные позиции.
8. Верни positions — отдельный объект для каждой фактической товарной позиции. lot_number сохрани как в документе.
9. Если в документе одна позиция — positions содержит ровно один элемент.
10. Изучай таблицы всех переданных документов, включая технические требования в конце текста.
11. Повтор одной и той же позиции в перечне продукции и таблице требований не является дополнительным объемом: не складывай повторенное количество. Разные позиции и лоты не объединяй.
12. Разделяй обозначение сплава и состояние материала, размеры и единицы. Для круглой трубы три размера означают наружный диаметр, толщину стенки и длину. Массу в тоннах переводи в кг, сохраняя исходные quantity и unit. Не рассчитывай массу из размеров без явного основания. Для каждого значения приводи цитату; отсутствующие сведения оставляй null.
"""


def _complete_document_text(document_text: str) -> str:
    """Never silently drop specification tables at the end of the input.

    Character limit is a local safety bound, not a provider token guarantee.
    Provider context-limit errors must remain visible to the caller.
    """
    if not document_text or not document_text.strip():
        raise ValueError("EMPTY_EXTRACTION_INPUT")
    if len(document_text) > 600000:
        raise ValueError(
            f"EXTRACTION_INPUT_TOO_LARGE: {len(document_text)} characters; "
            "limit 600000; no text was sent"
        )
    return document_text


async def _extract_positions_chunk(document_text: str) -> TenderMultiExtractionResult:
    document_text = _complete_document_text(document_text)
    schema_hint = TenderMultiExtractionResult.model_json_schema()
    user_prompt = f"""Извлеки фактические товарные позиции из этого фрагмента. Если есть только общие условия, название закупки, образец незаполненной формы или упоминание товара без конкретной спецификации, верни positions: []. Не придумывай позиции по заголовку. Номера лотов и позиций бери из спецификации.
JSON-схема:\n{schema_hint}\n\nДокументы:\n---\n{document_text}\n---\nОтветь только JSON."""
    response = await llm_router.complete(
        task=TaskType.EXTRACT_FIELDS,
        system_prompt=MULTI_EXTRACTION_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        max_tokens=6000,
        temperature=0.0,
        json_mode=True,
    )
    return TenderMultiExtractionResult.model_validate(response.as_json())


def _document_chunks(text: str, limit: int = 24000) -> list[str]:
    """Lossless split, preferring document boundaries and then whole lines."""
    _complete_document_text(text)
    import re
    sections = re.split(r"(?=\n\n### DOCUMENT:)", text)
    chunks = []
    for section in sections:
        while len(section) > limit:
            cut = section.rfind("\n", 0, limit + 1)
            if cut < limit // 2:
                cut = limit
            else:
                cut += 1
            chunks.append(section[:cut])
            section = section[cut:]
        if section:
            chunks.append(section)
    return chunks


def _merge_extractions(results):
    """Collapse exact value duplicates only; never sum quantities.

    Conflicting descriptions of a numbered position stop persistence rather
    than silently overwriting evidence or choosing one set of characteristics.
    """
    import json
    unique = {}
    numbered = {}
    partial = []
    for result in results:
        if result.partial_delivery_allowed.value is not None:
            partial.append(result.partial_delivery_allowed)
        for pos in result.positions:
            values = {k: (v.get('value') if isinstance(v, dict) else v)
                      for k, v in pos.model_dump().items()}
            key = json.dumps(values, sort_keys=True, ensure_ascii=False)
            if key in unique:
                continue
            identity = (pos.lot_number or '1', pos.position_number)
            if identity in numbered and numbered[identity] != key:
                raise ValueError('EXTRACTION_POSITION_CONFLICT: differing fragments for lot/position '
                                 + str(identity) + '; review required; no result saved')
            numbered[identity] = key
            unique[key] = pos
    partial_values = {f.value.strip().lower() for f in partial}
    if len(partial_values) > 1:
        raise ValueError('EXTRACTION_PARTIAL_DELIVERY_CONFLICT: review required')
    if not unique:
        raise ValueError('EXTRACTION_NO_SPECIFICATION_POSITIONS: no result saved')
    return TenderMultiExtractionResult(
        positions=list(unique.values()),
        partial_delivery_allowed=partial[0] if partial else ExtractedField(),
    )


async def extract_tender_positions(document_text: str) -> TenderMultiExtractionResult:
    results = []
    for chunk in _document_chunks(document_text):
        results.append(await _extract_positions_chunk(chunk))
    return _merge_extractions(results)
