import ast,asyncio,unittest
from pathlib import Path
from types import SimpleNamespace as NS
path=Path('app/llm/extraction.py')
if not path.exists():path=Path(__file__).parent/'payload/app/llm/extraction.py'
tree=ast.parse(path.read_text())
names={'_complete_document_text','_document_chunks','_merge_extractions','extract_tender_positions'}
ns={'TenderMultiExtractionResult':lambda **kw:NS(**kw),'ExtractedField':lambda:NS(value=None)}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names],type_ignores=[]),str(path),'exec'),ns)
class Pos:
 lot_number='1';position_number=1
 def __init__(self,mass='8000'):self.mass=mass
 def model_dump(self):return {'lot_number':'1','position_number':1,'mass_kg':{'value':self.mass,'confidence':1}}
def result(*positions):return NS(positions=list(positions),partial_delivery_allowed=NS(value=None))
class Checks(unittest.TestCase):
 def test_lossless(self):
  text='Общие условия. '*13000+'\n\n### DOCUMENT: ТТ.docx\nТруба АД1М 23х1,0х6000 | тн | 8'
  chunks=ns['_document_chunks'](text)
  self.assertEqual(''.join(chunks),text)
  self.assertTrue(all(len(x)<=24000 for x in chunks))
  self.assertIn('Труба АД1М',chunks[-1])
 def test_lines(self):
  line='x'*500+'\n';chunks=ns['_document_chunks'](line*100)
  self.assertTrue(all(c.endswith('\n') for c in chunks))
 def test_empty(self):
  with self.assertRaises(ValueError):ns['_document_chunks'](' ')
 def test_large(self):
  with self.assertRaises(ValueError):ns['_document_chunks']('x'*600001)
 def test_no_sum(self):
  r=ns['_merge_extractions']([result(Pos()),result(Pos())]);self.assertEqual(len(r.positions),1);self.assertEqual(r.positions[0].mass,'8000')
 def test_conflict(self):
  with self.assertRaisesRegex(ValueError,'POSITION_CONFLICT'):ns['_merge_extractions']([result(Pos()),result(Pos('16000'))])
 def test_all_chunks_sent(self):
  calls=[]
  async def fake(text):calls.append(text);return result(Pos()) if 'SPEC' in text else result()
  ns['_extract_positions_chunk']=fake
  text='a'*180000+'SPEC'
  r=asyncio.run(ns['extract_tender_positions'](text))
  self.assertEqual(''.join(calls),text);self.assertEqual(len(r.positions),1)
 def test_provider_failure_propagates(self):
  async def fake(text):raise RuntimeError('provider failed')
  ns['_extract_positions_chunk']=fake
  with self.assertRaises(RuntimeError):asyncio.run(ns['extract_tender_positions']('SPEC'))
 def test_no_positions(self):
  with self.assertRaisesRegex(ValueError,'NO_SPECIFICATION'):ns['_merge_extractions']([result()])
unittest.main()
