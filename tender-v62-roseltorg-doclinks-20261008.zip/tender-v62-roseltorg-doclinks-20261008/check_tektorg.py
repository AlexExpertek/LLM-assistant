"""One public HTML request; inspect observed forms and links without submitting them."""
import re
from urllib.parse import urljoin,urlsplit
from bs4 import BeautifulSoup
from app.sources.public_http import get_html
url='https://www.tektorg.ru/'
try:
 html=get_html(url,timeout=25);soup=BeautifulSoup(html,'html.parser')
 print('TITLE:',soup.title.get_text(' ',strip=True) if soup.title else None)
 print('HTML_CHARACTERS:',len(html))
 print('SEARCH_FORMS:')
 for form in soup.find_all('form')[:10]:
  fields=[{'name':n.get('name'),'type':n.get('type',n.name)} for n in form.select('input[name],select[name]')]
  print({'method':form.get('method','GET'),'action':form.get('action'),'fields':fields})
 print('PROCUREMENT_LINKS:')
 seen=set()
 for a in soup.select('a[href]'):
  label=a.get_text(' ',strip=True);target=urljoin(url,a['href'])
  if re.search(r'процедур|закуп|торги|procedur|tender',label+' '+target,re.I) and target not in seen:
   if urlsplit(target).scheme not in ('https','http'):continue
   seen.add(target);print(label[:160],'=>',target)
   if len(seen)>=35:break
 print('SCRIPTS:')
 for n in soup.select('script[src]')[:15]:print(urljoin(url,n['src']))
except Exception as exc:print('ERROR:',type(exc).__name__,str(exc)[:250])
print('READ_ONLY: no DB, tasks, OCR, LLM, notifications or report writes')
