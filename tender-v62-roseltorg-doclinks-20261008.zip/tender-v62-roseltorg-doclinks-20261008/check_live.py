import json
from app.marketplace_discovery.primary.collector import collect
print(json.dumps(collect('roseltorg',persist=False),ensure_ascii=False,indent=2,default=str))
print('READ_ONLY: no report writes, DB, tasks, OCR, LLM or notifications')
