import test_roseltorg as base
import unittest
from app.marketplace_discovery.primary.roseltorg_search import parse_detail
URL='https://business.roseltorg.ru/api/v1/documents/124901a3-5d5a-4df5-a2d8-d7c97af8cf0e'
class Checks(unittest.TestCase):
 def parse(self,content):return parse_detail(base.DETAIL+content,base.ITEM,base.NOW)[0]
 def test_uuid_document_and_dedup(self):
  a='<a href="'+URL+'" title="ТЗ.docx">ТЗ</a>'
  row=self.parse('<div id="documents">'+a+a+'</div>')
  self.assertEqual(len(row['documents']),1);self.assertEqual(row['documents'][0]['name'],'ТЗ.docx');self.assertEqual(row['documents_status'],'links_found_access_unverified')
 def test_empty_published(self):self.assertEqual(self.parse('<div id="documents">Документов пока нет, они появятся позднее</div>')['documents_status'],'not_published')
 def test_missing_section(self):self.assertEqual(self.parse('')['documents_status'],'section_not_found')
 def test_archive_external_and_credentials_excluded(self):
  for url in (URL.replace('business.roseltorg.ru','evil.test'),URL.replace('business.','user:pass@business.'),URL.replace('business.roseltorg.ru','business.roseltorg.ru:444'),URL+'?token=secret','https://business.roseltorg.ru/api/v1/documents/archive?procedure=123'):
   self.assertEqual(self.parse('<div id="documents"><a href="'+url+'">file</a></div>')['documents'],[])
if __name__=='__main__':unittest.main()
