Roseltorg document links — 2026-10-08
Requires installed ROSELTORG_SEARCH_UPDATE_INSTALLED.
Changes only roseltorg_search.py. Hash validation and source backup before writes.
Extracts links in #documents, including the observed business.roseltorg.ru
/api/v1/documents/<UUID> endpoint. Does not follow these links or download files.
Archive endpoint and unexpected hosts/credentials/ports are excluded.

Document statuses:
links_found_access_unverified — links found, download access not checked;
not_published — page explicitly says documents are not published yet;
links_not_recognized — block exists but parser found no accepted links;
section_not_found — block absent.
No claim of restricted access is inferred from a connection timeout.
Known server TCP timeout to business.roseltorg.ru is not bypassed.

Install: bash install.sh. 15 offline tests before container recreation.
Existing schedule, no-repeat analysis guard and manual dashboard are unchanged.
check_live.py: read-only Roseltorg search including updated document metadata.
check_tektorg.py: one public homepage request, prints observed form fields,
procedure links and script paths. No form submission or authentication attempted.
Tektorg search adapter is not installed by this update.
