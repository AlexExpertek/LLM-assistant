import os
for k,v in dict(DATABASE_URL='postgresql+asyncpg://test:test@127.0.0.1/test',DATABASE_URL_SYNC='postgresql://test:test@127.0.0.1/test',REDIS_URL='redis://127.0.0.1:6379/0',CELERY_BROKER_URL='memory://',CELERY_RESULT_BACKEND='cache+memory://',QDRANT_URL='http://127.0.0.1:6333').items():os.environ[k]=v
import unittest
from unittest.mock import patch
from datetime import datetime,timezone
from urllib.parse import parse_qs,urlsplit
from app.marketplace_discovery.primary import roseltorg_search as r
NOW=datetime(2026,10,8,6,tzinfo=timezone.utc)
ITEM=dict(external_id='B2109261047095',lot_number='1',source_url=r.BASE+'/procedure/B2109261047095/1',title='Профиль ЛВТ100.051 (алюминиевый по чертежу)')
DETAIL='<h1>Профиль</h1>Прием заявок до 09.10.26 14:35 (МСК) Работа комиссии Завершен Прием заявок до 09.10.26 14:35 (МСК)'
HTML='''<div class="search-results__item"><a class="search-results__link--description" href="/procedure/B2109261047095/1">Профиль ЛВТ100.051 (алюминиевый по чертежу)</a><div class="search-results__status">Прием заявок 2 дн.</div></div>'''
class Checks(unittest.TestCase):
 def test_date_timezone_and_timeline(self):
  item,why=r.parse_detail(DETAIL,ITEM,NOW);self.assertIsNone(why);self.assertEqual(item['submission_deadline'],'2026-10-09T11:35:00+00:00');self.assertFalse(item['analysis_done'])
 def test_four_digit_year(self):self.assertIsNone(r.parse_detail(DETAIL.replace('09.10.26','09.10.2026'),ITEM,NOW)[1])
 def test_unknown_zone_rejected(self):self.assertEqual(r.parse_detail(DETAIL.replace('(МСК)',''),ITEM,NOW)[1],'deadline_unconfirmed')
 def test_conflicting_dates(self):self.assertEqual(r.parse_detail(DETAIL+' Прием заявок до 10.10.26 14:35 (МСК)',ITEM,NOW)[1],'deadline_unconfirmed')
 def test_expired(self):self.assertEqual(r.parse_detail(DETAIL.replace('09.10.26','07.10.26'),ITEM,NOW)[1],'expired')
 def test_explicit_closed(self):self.assertEqual(r.parse_detail(DETAIL+'<div class="procedure-status">Закупка отменена</div>',ITEM,NOW)[1],'closed')
 def test_form_and_safe_urls(self):
  p=parse_qs(urlsplit(r.search_url('алюминий')).query);self.assertEqual(p['status[]'],['0']);self.assertEqual(p['query_field'],['алюминий'])
  for u in ('http://www.roseltorg.ru/','https://evil.test/','https://u:p@www.roseltorg.ru/','https://www.roseltorg.ru:88/') :self.assertFalse(r.safe(u))
 def test_repeated_pages_bounded(self):
  def fetch(url,**kwargs):return HTML+'<a href="/procedures/search?page=2">2</a>' if 'search_ajax' in url else DETAIL
  with patch.object(r.time,'sleep'),patch.object(r,'is_dismissed',return_value=False):report=r.collect_roseltorg(persist=False,fetch=fetch,now=NOW)
  self.assertEqual(len(report['items']),1);self.assertEqual(report['status'],'partial');self.assertTrue(any(e['reason']=='repeated_page' for e in report['errors']))
 def test_layout_error_not_zero(self):
  with patch.object(r.time,'sleep'):report=r.collect_roseltorg(persist=False,fetch=lambda *a,**k:'<html>Пустая оболочка</html>',now=NOW)
  self.assertEqual(report['status'],'partial');self.assertTrue(report['errors'])
 def test_dismissed_eis(self):
  html=HTML.replace('B2109261047095','32616424753')
  with patch.object(r.time,'sleep'),patch.object(r,'is_dismissed',side_effect=lambda src,num:src=='zakupki_gov_ru'):
   report=r.collect_roseltorg(persist=False,fetch=lambda *a,**k:html,now=NOW)
  self.assertEqual(report['items'],[]);self.assertGreater(report['skipped']['manually_dismissed'],0)
 def test_empty_confirmed(self):
  with patch.object(r.time,'sleep'):report=r.collect_roseltorg(persist=False,fetch=lambda *a,**k:'По вашему запросу ничего не найдено',now=NOW)
  self.assertEqual(report['status'],'no_matches_in_checked_filters')
if __name__=='__main__':unittest.main()
