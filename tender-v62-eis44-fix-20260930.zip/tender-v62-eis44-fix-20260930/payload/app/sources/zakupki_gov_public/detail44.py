"""44-FZ card transport. Validated EIS URLs only; no OCR/LLM or database writes."""
import re
from datetime import datetime
from urllib.parse import urljoin, urlsplit, parse_qs
import httpx
from bs4 import BeautifulSoup
from app.sources.schemas import SourceTender, SourceDocument
from app.sources.zakupki_gov_public.public_client import DEFAULT_HEADERS
from app.sources.zakupki_gov_public.detail_client import _extract_card_dates


def validate_card_url(url, number, page='common-info.html'):
    p = urlsplit(url)
    if (p.scheme != 'https' or p.netloc != 'zakupki.gov.ru'
            or not re.fullmatch(r'/epz/order/notice/[a-z0-9]+/view/' + re.escape(page), p.path)
            or parse_qs(p.query).get('regNumber') != [str(number)]):
        raise ValueError('Invalid EIS 44-FZ card URL or identity')
    return url


def document_page_url(html, source_url, number):
    validate_card_url(source_url, number)
    for a in BeautifulSoup(html, 'html.parser').find_all('a', href=True):
        url = urljoin(source_url, a['href'])
        if urlsplit(url).path.endswith('/documents.html'):
            try:
                return validate_card_url(url, number, 'documents.html')
            except ValueError:
                continue
    raise ValueError('EIS 44-FZ documents tab not found')


def parse_documents(html, base_url):
    result, seen = [], set()
    for a in BeautifulSoup(html, 'html.parser').find_all('a', href=True):
        url = urljoin(base_url, a['href']); p = urlsplit(url)
        if (p.scheme != 'https' or p.netloc != 'zakupki.gov.ru'
                or p.path != '/44fz/filestore/public/1.0/download/priz/file.html'):
            continue
        uid = parse_qs(p.query).get('uid', [''])[0]
        if not re.fullmatch(r'[0-9A-Fa-f]{32}', uid) or uid in seen:
            continue
        filename = (a.get('title') or '').strip()
        if not filename or not re.search(r'\.[a-zA-Z0-9]{2,5}$', filename):
            raise ValueError('EIS document filename missing')
        label = a.get_text(' ', strip=True)
        # Keep extension and original filename, include category for technical selection.
        name = (label + ' — ' + filename) if label and label != filename else filename
        result.append(SourceDocument(external_id=uid, name=name, url=url))
        seen.add(uid)
    if not result:
        raise ValueError('No supported EIS 44-FZ document links found')
    return result


def parse_card(html, number, url, documents):
    validate_card_url(url, number)
    soup = BeautifulSoup(html, 'html.parser')
    for node in soup(['script','style']): node.decompose()
    text = re.sub(r'\s+', ' ', soup.get_text(' ', strip=True))
    if not re.search(r'(?<!\d)' + re.escape(str(number)) + r'(?!\d)', text) or '44-ФЗ' not in text:
        raise ValueError('EIS 44-FZ page identity not confirmed')
    header = text.split('Объект закупки', 1)[0]
    statuses = ['Подача заявок','Работа комиссии','Определение поставщика завершено','Закупка отменена','Закупка завершена']
    status = next((s for s in statuses if s in header), None)
    match = re.search(r'Объект закупки\s+(.+?)\s+(?:Организация, осуществляющая размещение|Заказчик|Начальная цена)', text)
    if not match: raise ValueError('EIS 44-FZ procurement title not found')
    published, deadline = _extract_card_dates(text)
    return SourceTender(source='zakupki_gov_ru', external_id=str(number), title=match.group(1),
        law_type='44-FZ', source_url=url,
        publish_date=datetime.strptime(published, '%d.%m.%Y') if published else None,
        submission_deadline=datetime.fromisoformat(deadline) if deadline else None,
        documents=documents, raw_payload={'stage':'detail','procurement_status':status,
            'publish_date_raw':published,'submission_deadline_raw':deadline,
            'documents':{'total':len(documents),'items':[d.model_dump(mode='json') for d in documents]}})


def fetch_44(number, url, verify=False):
    validate_card_url(url, number)
    with httpx.Client(timeout=30, verify=verify, headers=DEFAULT_HEADERS, follow_redirects=False) as client:
        common = client.get(url); common.raise_for_status()
        docs_url = document_page_url(common.text, url, number)
        docs = client.get(docs_url, headers={'Referer':url}); docs.raise_for_status()
        return parse_card(common.text, number, url, parse_documents(docs.text, docs_url))
