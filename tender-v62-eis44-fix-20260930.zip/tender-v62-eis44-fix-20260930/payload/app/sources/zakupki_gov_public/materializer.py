"""Materialize selected public EIS documents using one HTTP session."""

from __future__ import annotations

import re
from pathlib import Path

import httpx

from app.core.config import settings
from app.sources.schemas import SourceDocument
from app.sources.zakupki_gov_public.detail_client import (
    BASE_URL,
    DEFAULT_HEADERS,
    EisDocumentRef,
)


class EisMaterializationError(RuntimeError):
    pass


def _safe_filename(name: str) -> str:
    value = Path(name or "document").name.strip()

    value = value.replace("/", "_")
    value = value.replace("\\", "_")

    return value or "document"


def materialize_selected_documents(
    *,
    external_id: str,
    source_url: str,
    documents: list[EisDocumentRef],
    verify: bool | str = False,
    timeout: float = 90.0,
) -> list[SourceDocument]:
    """
    Download only selected EIS documents.

    EIS filestore requires the same HTTP session as:
        common-info -> documents page -> file download.

    Files are stored under STORAGE_PATH/source_cache so
    Celery can consume them later as local_file documents.
    """

    if not documents:
        return []

    target_dir = (
        Path(settings.storage_path)
        / "source_cache"
        / "zakupki_gov_ru"
        / str(external_id)
    )

    target_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    with httpx.Client(
        verify=verify,
        follow_redirects=True,
        timeout=timeout,
        headers=DEFAULT_HEADERS,
    ) as client:

        # 1. Establish EIS session.
        common = client.get(source_url)
        common.raise_for_status()

        if '/view/common-info.html' in source_url:
            from app.sources.zakupki_gov_public.detail44 import document_page_url
            documents_url = document_page_url(common.text, source_url, external_id)
        else:
            guid_match = re.search(
                r"(?:noticeGuid|purchaseNoticeGuid)="
                r"([0-9a-fA-F-]{36})",
                common.text,
            )

            if not guid_match:
                raise EisMaterializationError(
                    "EIS noticeGuid not found"
                )

            notice_guid = guid_match.group(1)

            # 2. Open documents page in the SAME session.
            documents_url = (
                BASE_URL
                + "/epz/order/notice/notice223/"
                "documents.html"
                f"?purchaseNoticeNumber={external_id}"
                f"&noticeGuid={notice_guid}"
            )

        documents_page = client.get(
            documents_url,
            headers={
                "Referer": str(common.url),
            },
        )

        documents_page.raise_for_status()

        result: list[SourceDocument] = []

        for document in documents:
            if not document.url:
                continue

            if (
                document.uid
                and document.uid not in documents_page.text
            ):
                raise EisMaterializationError(
                    "Selected document UID "
                    f"{document.uid} is not present "
                    "on current EIS documents page"
                )

            filename = _safe_filename(
                document.name
            )

            target = target_dir / filename

            response = client.get(
                document.url,
                headers={
                    "Referer": str(
                        documents_page.url
                    ),
                    "Accept": "*/*",
                },
            )

            response.raise_for_status()

            max_bytes = (
                settings.max_download_size_mb
                * 1024
                * 1024
            )

            if len(response.content) > max_bytes:
                raise EisMaterializationError(
                    f"{filename}: file exceeds "
                    f"{settings.max_download_size_mb} MB"
                )

            if not response.content or response.content.lstrip().lower().startswith((b'<!doctype html', b'<html')):
                raise EisMaterializationError(f'{filename}: empty or HTML download')
            target.write_bytes(
                response.content
            )

            result.append(
                SourceDocument(
                    external_id=document.uid,
                    name=filename,
                    url=document.url,
                    download_type="local_file",
                    local_path=str(target),
                )
            )

    return result
