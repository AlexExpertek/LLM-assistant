"""Read current card and download selected documents. No DB writes or task enqueue."""
from pathlib import Path
from zipfile import ZipFile
from sqlalchemy import select
from app.db.session import SyncSessionLocal
from app.models.database import Tender
from app.sources.registry import get_adapter
from app.sources.document_preparer import prepare_tender_documents
from app.sources.eis_freshness import eligibility
number='0119200000126016262'
with SyncSessionLocal() as s:
    row=s.execute(select(Tender).where(Tender.source=='zakupki_gov_ru',Tender.external_id==number)).scalar_one()
    url=row.source_url
card=get_adapter('zakupki_gov_ru').fetch_by_id(number,source_url=url)
if card is None:raise SystemExit('Card unavailable')
print('NUMBER:',card.external_id)
print('TITLE:',card.title)
print('DEADLINE_UTC:',card.submission_deadline)
print('STAGE:',card.raw_payload.get('procurement_status'))
print('DOCUMENT_LINKS:',len(card.documents))
reason=eligibility(card.source,card.submission_deadline,card.raw_payload)
if reason:raise SystemExit('NOT_DOWNLOADED: '+reason)
prepared=prepare_tender_documents(card)
if not prepared:raise SystemExit('No documents selected')
for d in prepared:
    path=Path(d.local_path)
    if path.suffix.lower()=='.docx':
        with ZipFile(path) as z:
            if 'word/document.xml' not in z.namelist():raise ValueError('Invalid DOCX: '+d.name)
            if z.testzip():raise ValueError('Corrupt DOCX: '+d.name)
    print('DOWNLOADED:',d.name,'BYTES:',path.stat().st_size)
print('EIS44_DOWNLOAD_OK: no DB writes, OCR, LLM or notifications')
