import unittest
from unittest.mock import patch
from app.sources.zakupki_gov_public.detail44 import parse_documents, parse_card, document_page_url, validate_card_url, fetch_44
from app.sources.document_preparer import _select_documents
import httpx
N='0119200000126016262'
U='https://zakupki.gov.ru/epz/order/notice/ea20/view/common-info.html?regNumber='+N
D=U.replace('common-info','documents')
UID='01A0D73B67D479BABF5A9C4417202A72'
F='https://zakupki.gov.ru/44fz/filestore/public/1.0/download/priz/file.html?uid='+UID
CARD=f'''44-ФЗ Электронный аукцион № {N} Подача заявок Объект закупки Поставка профиля Организация, осуществляющая размещение АГЕНТСТВО Начальная цена 283 626,40 ₽ Размещено 25.09.2026 Дата и время окончания срока подачи заявок 06.10.2026 08:00 (МСК+4)<a href="{D}">Документы</a>'''
DOC=f'<a href="{F}" title="ООЗ (Приложение 1).docx">Описание объекта закупки</a>'
class Checks(unittest.TestCase):
 def test_filename_category(self):
  d=parse_documents(DOC,D)[0];self.assertTrue(d.name.endswith('ООЗ (Приложение 1).docx'));self.assertIn('Описание объекта закупки',d.name)
 def test_selection(self):self.assertEqual(len(_select_documents(parse_documents(DOC,D))),1)
 def test_uid_dedup(self):self.assertEqual(len(parse_documents(DOC+DOC,D)),1)
 def test_bad_uid(self):
  with self.assertRaises(ValueError):parse_documents(DOC.replace(UID,'null'),D)
 def test_foreign_url(self):
  with self.assertRaises(ValueError):parse_documents(DOC.replace('zakupki.gov.ru','evil.example'),D)
 def test_card(self):
  c=parse_card(CARD,N,U,parse_documents(DOC,D));self.assertEqual(str(c.submission_deadline),'2026-10-06 01:00:00');self.assertEqual(c.law_type,'44-FZ');self.assertEqual(c.raw_payload['procurement_status'],'Подача заявок')
 def test_no_time(self):self.assertIsNone(parse_card(CARD.replace('08:00 (МСК+4)',''),N,U,[]).submission_deadline)
 def test_wrong_identity(self):
  with self.assertRaises(ValueError):parse_card(CARD.replace(N,'0000000000000000000'),N,U,[])
 def test_url_identity(self):
  with self.assertRaises(ValueError):validate_card_url(U,'wrong')
 def test_document_tab(self):self.assertEqual(document_page_url(CARD,U,N),D)
 def test_missing_tab(self):
  with self.assertRaises(ValueError):document_page_url('no links',U,N)
 def test_closed_status(self):self.assertEqual(parse_card(CARD.replace('Подача заявок','Работа комиссии'),N,U,[]).raw_payload['procurement_status'],'Работа комиссии')
 def test_http_transport(self):
  calls=[]
  def handler(req):
   calls.append(str(req.url));return httpx.Response(200,text=CARD if str(req.url)==U else DOC)
  real=httpx.Client
  with patch('app.sources.zakupki_gov_public.detail44.httpx.Client',side_effect=lambda **kw: real(transport=httpx.MockTransport(handler),trust_env=False,**kw)):
   self.assertEqual(len(fetch_44(N,U).documents),1)
  self.assertEqual(calls,[U,D])
 def test_materializer_both_laws(self):
  import tempfile
  from types import SimpleNamespace
  from pathlib import Path
  from app.sources.zakupki_gov_public import materializer as m
  from app.sources.zakupki_gov_public.detail_client import EisDocumentRef
  for number, url, common, docs_url in [
   (N,U,CARD,D),
   ('32616417112','https://zakupki.gov.ru/epz/order/notice/notice223/common-info.html?regNumber=32616417112',
    'noticeGuid=3fc640d5-b43c-43f9-bbbf-fb5c56c64fe9',
    'https://zakupki.gov.ru/epz/order/notice/notice223/documents.html?purchaseNoticeNumber=32616417112&noticeGuid=3fc640d5-b43c-43f9-bbbf-fb5c56c64fe9')]:
   calls=[]
   def handler(req):
    calls.append(str(req.url))
    if str(req.url)==url:return httpx.Response(200,text=common)
    if str(req.url)==docs_url:return httpx.Response(200,text=DOC)
    return httpx.Response(200,content=b'PK-test-document')
   real=httpx.Client
   with tempfile.TemporaryDirectory() as directory:
    with patch.object(m,'settings',SimpleNamespace(storage_path=directory,max_download_size_mb=1)), patch.object(m.httpx,'Client',side_effect=lambda **kw:real(transport=httpx.MockTransport(handler),trust_env=False,**kw)):
     docs=m.materialize_selected_documents(external_id=number,source_url=url,documents=[EisDocumentRef(name='test.docx',url=F,uid=UID)])
     self.assertEqual(Path(docs[0].local_path).read_bytes(),b'PK-test-document')
   self.assertEqual(calls,[url,docs_url,F])
unittest.main()
