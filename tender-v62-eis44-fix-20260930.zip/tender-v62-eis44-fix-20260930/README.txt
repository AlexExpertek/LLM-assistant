EIS44 2026-09-30
4 files: new detail44.py, adapter.py, tasks_parsing.py, materializer.py.
Prerequisite: freshness 20260930 and existing deadline client. Hash guard prevents replacing unknown versions.
44-FZ uses source_url from search (required, never guessed). 223-FZ dispatch remains unchanged.
44-FZ title and identity checked. Stage read from header; deadline from exact time and MSK offset. Missing precise deadline remains unknown.
Documents: title attribute preserves filename/extension; anchor category prepended to name for existing technical selection. 32-hex UID required, EIS host/path restricted; duplicates removed.
Download uses common-info -> actual documents tab -> file within same session. Empty/HTML responses rejected. Existing TLS verify=False inherited, not fixed by this package.
No automatic historical bulk retry. Normal scheduled processing will use new 44-FZ path after deployment. No changes to Kontur, TenderPro, notifications configuration, classification or LLM merge.
check_one.py: reads source URL from DB, fetches fresh control card, checks eligibility, downloads selected files, validates DOCX. Does NOT save updated dates/documents to DB, enqueue tasks, run OCR/LLM or send notifications.
Scope: observed ea20 layout and strict compatible /notice/<type>/view/ layouts. Unrecognized markup fails explicitly. All 44-FZ layouts are not claimed supported.
14 fixture/mock tests, including 44 and 223 transport. Fixtures reconstructed from supplied snippets, no claim of local live EIS test. On-server import and same tests run before recreation.
Installer backup printed. Repeated installation idempotent. Installation does restart app/main/discovery; beat unaffected.
