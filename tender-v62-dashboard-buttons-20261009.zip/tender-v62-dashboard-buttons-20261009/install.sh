#!/usr/bin/env bash
set -Eeuo pipefail
pkg_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "${TENDER_PROJECT_DIR:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
python3 "$pkg_dir/apply.py" --project "$PWD"
docker compose build app
docker compose up -d --no-deps --timeout 60 app
printf '\nDASHBOARD_BUTTONS_UPDATE_INSTALLED\nOnly dashboard presentation updated. No tasks or database changes.\n'
