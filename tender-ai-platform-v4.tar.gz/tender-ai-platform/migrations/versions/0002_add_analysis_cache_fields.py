"""Add analysis_done, is_active, score, notified fields to tenders

Revision ID: 0002
Revises: 0001
"""
from alembic import op
import sqlalchemy as sa

revision = '0002'
down_revision = '0001'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column('tenders', sa.Column('analysis_done', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('tenders', sa.Column('is_active', sa.Boolean(), nullable=False, server_default='true'))
    op.add_column('tenders', sa.Column('score', sa.Integer(), nullable=True))
    op.add_column('tenders', sa.Column('notified_bitrix', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('tenders', sa.Column('notified_telegram', sa.Boolean(), nullable=False, server_default='false'))
    op.create_index('ix_tenders_not_analyzed', 'tenders', ['analysis_done', 'is_active'])


def downgrade() -> None:
    op.drop_index('ix_tenders_not_analyzed', 'tenders')
    op.drop_column('tenders', 'notified_telegram')
    op.drop_column('tenders', 'notified_bitrix')
    op.drop_column('tenders', 'score')
    op.drop_column('tenders', 'is_active')
    op.drop_column('tenders', 'analysis_done')
