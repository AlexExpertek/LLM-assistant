"""
Эндпоинты загрузки файлов и анализа по URL.
Обновлено: сжатие >50МБ, анализ по URL, многопозиционные тендеры.
"""
import hashlib
import uuid
from pathlib import Path

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from app.core.config import settings
from app.core.logging import get_logger
from app.security.fz152 import log_data_access, sanitize_for_rag

logger = get_logger(__name__)

router = APIRouter(tags=["Загрузка и анализ"])

MAX_SIZE_MB = 50
COMPRESS_THRESHOLD_MB = 50
HARD_LIMIT_MB = 200

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".xlsx", ".zip", ".jpg", ".jpeg", ".png", ".tiff"}


def _compress_pdf(content: bytes, filename: str) -> bytes:
    """Сжимает PDF через ghostscript если доступен, иначе возвращает как есть."""
    import subprocess, tempfile, os

    with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as tmp_in:
        tmp_in.write(content)
        tmp_in_path = tmp_in.name

    tmp_out_path = tmp_in_path.replace('.pdf', '_compressed.pdf')

    try:
        result = subprocess.run([
            'gs', '-sDEVICE=pdfwrite', '-dCompatibilityLevel=1.4',
            '-dPDFSETTINGS=/ebook',  # 150 dpi — хорошее качество/размер
            '-dNOPAUSE', '-dQUIET', '-dBATCH',
            f'-sOutputFile={tmp_out_path}', tmp_in_path
        ], capture_output=True, timeout=120)

        if result.returncode == 0 and Path(tmp_out_path).exists():
            compressed = Path(tmp_out_path).read_bytes()
            ratio = len(content) / max(len(compressed), 1)
            logger.info("pdf_compressed", original_mb=len(content)//1024//1024,
                       compressed_mb=len(compressed)//1024//1024, ratio=f"{ratio:.1f}x")
            return compressed
    except (FileNotFoundError, subprocess.TimeoutExpired):
        logger.warning("ghostscript_not_available", filename=filename)
    finally:
        for p in [tmp_in_path, tmp_out_path]:
            try: os.unlink(p)
            except: pass

    return content  # возвращаем оригинал если сжатие недоступно


def _optimize_file(content: bytes, filename: str) -> tuple[bytes, str]:
    """Оптимизирует файл если он больше порога. Возвращает (bytes, примечание)."""
    size_mb = len(content) / 1024 / 1024
    suffix = Path(filename).suffix.lower()

    if size_mb <= COMPRESS_THRESHOLD_MB:
        return content, ""

    logger.info("file_compression_started", filename=filename, size_mb=f"{size_mb:.1f}")

    if suffix == '.pdf':
        compressed = _compress_pdf(content, filename)
        new_mb = len(compressed) / 1024 / 1024
        note = f"Сжато: {size_mb:.1f} МБ → {new_mb:.1f} МБ"
        return compressed, note

    # Для остальных форматов — возвращаем как есть с предупреждением
    return content, f"Файл {size_mb:.1f} МБ принят без сжатия (поддерживается только PDF)"


@router.post("/upload/tender", summary="Загрузить документ тендера")
async def upload_tender(
    file: UploadFile = File(...),
    tender_name: str = Form(default=""),
    source: str = Form(default="manual_upload"),
    external_id: str = Form(default=""),
):
    filename = file.filename or "document"
    suffix = Path(filename).suffix.lower()

    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=400,
            detail=f"Неподдерживаемый тип: {suffix}. Допустимые: {', '.join(ALLOWED_EXTENSIONS)}")

    content = await file.read()
    size_mb = len(content) / 1024 / 1024

    if size_mb > HARD_LIMIT_MB:
        raise HTTPException(status_code=413,
            detail=f"Файл слишком большой: {size_mb:.1f} МБ. Максимум: {HARD_LIMIT_MB} МБ")

    # Оптимизация если нужно
    content, compress_note = _optimize_file(content, filename)
    final_size_mb = len(content) / 1024 / 1024

    upload_id = str(uuid.uuid4())[:8]
    file_hash = hashlib.sha256(content).hexdigest()[:16]

    # Сохраняем файл
    storage_dir = Path(settings.storage_path) / "uploads" / upload_id
    storage_dir.mkdir(parents=True, exist_ok=True)
    file_path = storage_dir / filename
    file_path.write_bytes(content)

    log_data_access("web_ui", "write", "document", upload_id)
    logger.info("tender_uploaded", upload_id=upload_id, filename=filename,
                original_mb=size_mb, final_mb=final_size_mb)

    tender_data = {
        "source": source,
        "external_id": external_id or f"manual_{upload_id}",
        "title": tender_name or Path(filename).stem,
        "customer_name": None,
        "upload_id": upload_id,
        "file_path": str(file_path),
        "file_hash": file_hash,
        "document_urls": [],
    }

    from app.workers.tasks_upload import process_uploaded_tender
    task = process_uploaded_tender.delay(tender_data, str(file_path))

    return JSONResponse(status_code=202, content={
        "status": "queued",
        "message": "Файл принят. Результат придёт в Telegram и Битрикс24.",
        "task_id": task.id,
        "upload_id": upload_id,
        "filename": filename,
        "size_kb": int(final_size_mb * 1024),
        "compress_note": compress_note,
        "check_status_url": f"/tasks/{task.id}",
    })


class AnalyzeUrlRequest(BaseModel):
    url: str
    external_id: str = ""
    source: str = "zakupki_gov_ru"


@router.post("/tenders/analyze-url", summary="Запустить анализ тендера по URL")
async def analyze_by_url(payload: AnalyzeUrlRequest):
    """
    Принимает ссылку на тендер, скачивает документацию и запускает анализ.
    Поддерживает zakupki.gov.ru и другие источники.
    """
    url = payload.url.strip()
    if not url.startswith(('http://', 'https://')):
        raise HTTPException(status_code=400, detail="Некорректный URL")

    # Извлекаем номер закупки из URL если не указан
    import re
    ext_id = payload.external_id
    if not ext_id:
        match = re.search(r'regNumber=(\d+)', url)
        if match:
            ext_id = match.group(1)
        else:
            match = re.search(r'[/=](\d{19,})', url)
            if match:
                ext_id = match.group(1)

    if not ext_id:
        ext_id = f"url_{str(uuid.uuid4())[:8]}"

    log_data_access("web_ui", "read", "tender_url", ext_id)
    logger.info("analyze_url_requested", url=url[:100], external_id=ext_id)

    # Запускаем задачу скачивания и анализа
    from app.workers.tasks_parsing import process_new_tender
    tender_data = {
        "source": payload.source,
        "external_id": ext_id,
        "title": f"Тендер {ext_id}",
        "source_url": url,
        "document_urls": [],  # парсер сам извлечёт из страницы тендера
        "url_for_scraping": url,  # передаём URL для скачивания страницы
    }

    task = process_new_tender.delay(tender_data)

    return {
        "status": "queued",
        "task_id": task.id,
        "external_id": ext_id,
        "message": "Анализ запущен. Скачиваем документацию...",
        "check_status_url": f"/tasks/{task.id}",
    }


@router.get("/upload/status/{task_id}", summary="Статус обработки")
async def get_upload_status(task_id: str):
    from app.workers.celery_app import celery_app
    result = celery_app.AsyncResult(task_id)
    return {
        "task_id": task_id,
        "status": result.status,
        "ready": result.ready(),
        "result": result.result if result.ready() and result.successful() else None,
        "error": str(result.result) if result.ready() and result.failed() else None,
    }
