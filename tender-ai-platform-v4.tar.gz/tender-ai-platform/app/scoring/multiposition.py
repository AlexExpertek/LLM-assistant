"""
Анализ многопозиционных тендеров.
Определяет по каждой позиции: можем ли мы её поставить.
Если не можем поставить все — проверяем допустимость частичной поставки.
"""
from dataclasses import dataclass
from typing import Optional

from app.scoring.alloy_normalizer import is_known_alloy, normalize_alloy_string
from app.core.logging import get_logger

logger = get_logger(__name__)

# Типы продукции которые мы поставляем
OUR_PRODUCT_TYPES = {
    "лента", "лента тисненная", "лист", "плита", "рулон",
    "фольга", "штрипсы", "лента алюминиевая", "лист алюминиевый",
    "плита алюминиевая", "рулон алюминиевый",
}


@dataclass
class PositionAnalysis:
    position_number: int
    name_product: str
    alloy: Optional[str]
    product_type: Optional[str]
    mass_kg: Optional[float]
    thickness_mm: Optional[float]
    width_mm: Optional[float]
    can_supply: bool
    reason: str


@dataclass
class MultiPositionResult:
    total_positions: int
    can_supply_all: bool
    can_supply_count: int
    cannot_supply_count: int
    partial_delivery_possible: bool
    positions: list[PositionAnalysis]
    summary: str


def analyze_positions(positions: list[dict], partial_delivery_allowed: bool = None) -> MultiPositionResult:
    """
    Анализирует каждую позицию многопозиционного тендера.

    positions: список словарей с полями alloy, product_type, mass_kg и т.д.
    partial_delivery_allowed: из документов тендера (None = не указано)
    """
    analyzed = []

    for i, pos in enumerate(positions, 1):
        alloy_raw = pos.get("alloy") or pos.get("alloy_normalized")
        product_type = (pos.get("product_type") or "").lower().strip()
        mass_kg = pos.get("mass_kg") or pos.get("quantity_kg")

        # Проверка типа продукции
        product_ok = any(pt in product_type for pt in OUR_PRODUCT_TYPES) if product_type else False

        # Проверка сплава
        alloy_ok = False
        alloy_normalized = None
        if alloy_raw:
            alloy_normalized = normalize_alloy_string(alloy_raw)
            alloy_ok = is_known_alloy(alloy_raw)

        # Итоговое решение по позиции
        if not product_type:
            can_supply = False
            reason = "Тип продукции не указан — требует уточнения"
        elif not product_ok:
            can_supply = False
            reason = f"Тип '{product_type}' вне нашего ассортимента"
        elif alloy_raw and not alloy_ok:
            can_supply = False
            reason = f"Сплав {alloy_raw} не в нашем справочнике"
        elif mass_kg and mass_kg < 500:
            can_supply = False
            reason = f"Объём {mass_kg} кг ниже минимальной партии (500 кг)"
        else:
            can_supply = True
            reason = "Продукция и сплав соответствуют нашему ассортименту"
            if alloy_normalized:
                reason += f" ({alloy_normalized})"

        analyzed.append(PositionAnalysis(
            position_number=i,
            name_product=pos.get("name_product") or pos.get("product_name", f"Позиция {i}"),
            alloy=alloy_normalized or alloy_raw,
            product_type=product_type,
            mass_kg=mass_kg,
            thickness_mm=pos.get("thickness_mm"),
            width_mm=pos.get("width_mm"),
            can_supply=can_supply,
            reason=reason,
        ))

    can_count = sum(1 for p in analyzed if p.can_supply)
    cannot_count = len(analyzed) - can_count
    can_all = can_count == len(analyzed)

    # Частичная поставка возможна если:
    # 1. Явно разрешена в документах, или не запрещена (None)
    # 2. Хотя бы одну позицию можем поставить
    partial_ok = (partial_delivery_allowed is not False) and can_count > 0

    if can_all:
        summary = f"✅ Все {len(analyzed)} позиции в нашем ассортименте"
    elif can_count == 0:
        summary = f"❌ Ни одну из {len(analyzed)} позиций не можем поставить"
    else:
        summary = (
            f"⚠️ {can_count} из {len(analyzed)} позиций — наши. "
            f"{'Частичная поставка допустима.' if partial_ok else 'Частичная поставка НЕ допускается.'}"
        )

    return MultiPositionResult(
        total_positions=len(analyzed),
        can_supply_all=can_all,
        can_supply_count=can_count,
        cannot_supply_count=cannot_count,
        partial_delivery_possible=partial_ok,
        positions=analyzed,
        summary=summary,
    )
