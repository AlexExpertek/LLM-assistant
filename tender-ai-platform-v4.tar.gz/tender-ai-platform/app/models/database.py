"""
Модель данных — обновлённая версия.
Добавлено:
- поле analysis_done в Tender (флаг "был ли уже проверен")
- поле is_active (тендер ещё действующий, дедлайн не прошёл)
- индексы для быстрого поиска непроверенных и активных тендеров
"""
import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    JSON, Boolean, Column, DateTime, Enum, Float,
    ForeignKey, Integer, Numeric, String, Text, UniqueConstraint, Index,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


def gen_uuid() -> str:
    return str(uuid.uuid4())


class LawType(str, enum.Enum):
    FZ_44 = "44-FZ"
    FZ_223 = "223-FZ"
    COMMERCIAL = "commercial"
    OTHER = "other"


class TenderStatus(str, enum.Enum):
    NEW = "new"
    PROCESSING = "processing"
    CAN_APPLY = "can_apply"
    NEEDS_CLARIFICATION = "needs_clarification"
    NOT_SUITABLE = "not_suitable"
    MANUAL_REVIEW = "manual_review"


class DocumentType(str, enum.Enum):
    TENDER_DOC = "tender_doc"
    CONTRACT = "contract"
    SPECIFICATION = "specification"
    DRAWING = "drawing"
    PROTOCOL = "protocol"
    OTHER = "other"


class OCRStatus(str, enum.Enum):
    NOT_REQUIRED = "not_required"
    PENDING = "pending"
    DONE = "done"
    LOW_CONFIDENCE = "low_confidence"
    FAILED = "failed"


class Tender(Base):
    __tablename__ = "tenders"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    source = Column(String(100), nullable=False)
    external_id = Column(String(255), nullable=False)
    title = Column(Text, nullable=False)
    customer_name = Column(String(500))
    customer_inn = Column(String(20))
    law_type = Column(Enum(LawType), default=LawType.OTHER)
    procurement_method = Column(String(100))

    amount = Column(Numeric(18, 2))
    currency = Column(String(10), default="RUB")
    region = Column(String(255))

    publish_date = Column(DateTime)
    submission_deadline = Column(DateTime)

    status = Column(Enum(TenderStatus), default=TenderStatus.NEW, index=True)
    source_url = Column(Text)
    raw_hash = Column(String(64), index=True)

    # ── НОВЫЕ ПОЛЯ ──────────────────────────────────────────
    # analysis_done: True если тендер уже прошёл полный цикл OCR+LLM+скоринг.
    # При повторном обнаружении — берём данные из БД, не гоняем LLM заново.
    analysis_done = Column(Boolean, default=False, nullable=False)

    # is_active: False когда дедлайн подачи заявки прошёл.
    # Обновляется планировщиком раз в час.
    is_active = Column(Boolean, default=True, nullable=False, index=True)

    # score: кэшированный балл скоринга для быстрых запросов отчёта
    score = Column(Integer, default=None)

    # notified_bitrix: флаг что уведомление в Битрикс24 уже отправлено
    notified_bitrix = Column(Boolean, default=False)

    # notified_telegram: флаг что уведомление в Telegram уже отправлено
    notified_telegram = Column(Boolean, default=False)
    # ────────────────────────────────────────────────────────

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    lots = relationship("Lot", back_populates="tender", cascade="all, delete-orphan")
    documents = relationship("Document", back_populates="tender", cascade="all, delete-orphan")
    decisions = relationship("Decision", back_populates="tender", cascade="all, delete-orphan")

    __table_args__ = (
        UniqueConstraint("source", "external_id", name="uq_tender_source_external_id"),
        # Индекс для быстрой выборки непроверенных тендеров
        Index("ix_tenders_not_analyzed", "analysis_done", "is_active"),
    )


class Lot(Base):
    __tablename__ = "lots"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    tender_id = Column(UUID(as_uuid=False), ForeignKey("tenders.id"), nullable=False)

    lot_number = Column(String(50))
    product_type = Column(String(255))
    alloy = Column(String(100))
    temper = Column(String(50))
    thickness_mm = Column(Float)
    width_mm = Column(Float)
    length_mm = Column(Float)
    diameter_mm = Column(Float)
    cross_section_shape = Column(String(100))
    quantity = Column(Float)
    mass_kg = Column(Float)
    unit = Column(String(50))
    standard = Column(String(255))
    coating_required = Column(Boolean, default=False)
    coating_type = Column(String(255))
    machining_required = Column(Boolean, default=False)
    has_drawings = Column(Boolean, default=False)
    delivery_place = Column(Text)
    delivery_term = Column(String(255))
    payment_terms = Column(Text)
    raw_text = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    tender = relationship("Tender", back_populates="lots")


class Document(Base):
    __tablename__ = "documents"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    tender_id = Column(UUID(as_uuid=False), ForeignKey("tenders.id"), nullable=False)
    doc_type = Column(Enum(DocumentType), default=DocumentType.OTHER)
    filename = Column(String(500))
    version = Column(Integer, default=1)
    file_hash = Column(String(64), index=True)
    storage_uri = Column(Text)
    source_url = Column(Text)
    ocr_status = Column(Enum(OCRStatus), default=OCRStatus.PENDING)
    pages_count = Column(Integer)
    extracted_text = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    tender = relationship("Tender", back_populates="documents")
    facts = relationship("ExtractedFact", back_populates="document", cascade="all, delete-orphan")


class ExtractedFact(Base):
    __tablename__ = "extracted_facts"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    document_id = Column(UUID(as_uuid=False), ForeignKey("documents.id"), nullable=False)
    field_name = Column(String(255), nullable=False)
    raw_value = Column(Text)
    normalized_value = Column(Text)
    confidence = Column(Float, default=0.0)
    page_or_cell = Column(String(100))
    quote = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    document = relationship("Document", back_populates="facts")


class Decision(Base):
    __tablename__ = "decisions"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    tender_id = Column(UUID(as_uuid=False), ForeignKey("tenders.id"), nullable=False)
    score = Column(Integer)
    status = Column(Enum(TenderStatus))
    reasons = Column(JSON)
    risks = Column(JSON)
    model_version = Column(String(100))
    reviewer = Column(String(255))
    final_feedback = Column(Text)
    is_manual_override = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    tender = relationship("Tender", back_populates="decisions")


class Company(Base):
    __tablename__ = "companies"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    inn = Column(String(20), unique=True, index=True)
    ogrn = Column(String(20))
    name = Column(String(500))
    okved = Column(String(20))
    site = Column(Text)
    region = Column(String(255))
    segment = Column(String(255))
    signals = Column(JSON)
    consent_status = Column(String(50), default="unknown")
    created_at = Column(DateTime, default=datetime.utcnow)

    contacts = relationship("Contact", back_populates="company", cascade="all, delete-orphan")


class Contact(Base):
    __tablename__ = "contacts"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    company_id = Column(UUID(as_uuid=False), ForeignKey("companies.id"))
    contact_type = Column(String(50))
    value = Column(String(500))
    person_name = Column(String(255))
    role = Column(String(255))
    source = Column(String(255))
    discovered_at = Column(DateTime, default=datetime.utcnow)
    is_opted_out = Column(Boolean, default=False)

    company = relationship("Company", back_populates="contacts")


class KnowledgeItem(Base):
    __tablename__ = "knowledge_items"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    item_type = Column(String(100))
    title = Column(String(500))
    content = Column(Text)
    metadata_json = Column(JSON)
    qdrant_point_id = Column(String(100))
    version = Column(Integer, default=1)
    access_scope = Column(String(50), default="internal")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
