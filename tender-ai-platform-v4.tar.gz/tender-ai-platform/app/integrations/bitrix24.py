"""
Интеграция с Битрикс24 — отправка сообщений в чат через REST API.

Поддерживает коробочную версию (on-premise) по адресу bitrix.tdsm.ru.
Использует метод imbot.message.add или im.message.add через webhook.

Настройка описана в docs/bitrix24_setup.md
"""
import httpx
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


def _get_status_emoji(status: str) -> str:
    return {
        "can_apply": "✅",
        "needs_clarification": "⚠️",
        "manual_review": "🔍",
        "not_suitable": "❌",
    }.get(status, "📄")


def format_bitrix_message(tender_id: str, scoring_data: dict) -> str:
    """
    Форматирует сообщение для чата Битрикс24.
    Битрикс поддерживает BB-коды: [B]жирный[/B], [URL=...]ссылка[/URL].
    """
    score = scoring_data.get("total_score", scoring_data.get("score", 0))
    status = scoring_data.get("suggested_status", scoring_data.get("status", ""))
    status_val = status.value if hasattr(status, "value") else str(status)
    category = scoring_data.get("category", "")
    category_val = category.value if hasattr(category, "value") else str(category)
    signals = scoring_data.get("signals", [])
    unknowns = scoring_data.get("critical_unknowns", [])

    emoji = _get_status_emoji(status_val)

    # Причины (3-7 пунктов)
    reasons_lines = []
    for s in signals[:7]:
        reason = s.get("reason", "") if isinstance(s, dict) else getattr(s, "reason", "")
        points = s.get("points", "") if isinstance(s, dict) else getattr(s, "points", "")
        sign = "+" if str(points).lstrip("-").isdigit() and int(str(points)) >= 0 else ""
        reasons_lines.append(f"• {sign}{points}: {reason}")
    reasons_text = "\n".join(reasons_lines) if reasons_lines else "• нет данных"

    # Риски
    risks_text = "\n".join(f"• ⚠ {u}" for u in unknowns) if unknowns else "• нет критических рисков"

    msg = (
        f"{emoji} [B]Новый тендер #{tender_id}[/B]\n\n"
        f"[B]Рейтинг:[/B] {score}/100 ({category_val})\n"
        f"[B]Статус:[/B] {status_val}\n\n"
        f"[B]Причины оценки:[/B]\n{reasons_text}\n\n"
        f"[B]Требует внимания:[/B]\n{risks_text}\n\n"
        f"[I]Подробности — в веб-кабинете тендерного ассистента[/I]"
    )
    return msg


def send_to_bitrix_chat(message: str) -> dict:
    """
    Отправляет сообщение в чат Битрикс24 через webhook.

    Использует im.message.add — универсальный метод для групповых чатов.
    BITRIX24_WEBHOOK_URL должен иметь права im.message.add.
    BITRIX24_CHAT_ID — ID чата (смотреть в настройках чата → ID).
    """
    webhook_url = settings.bitrix24_webhook_url
    chat_id = settings.bitrix24_chat_id

    if not webhook_url or not chat_id:
        logger.warning("bitrix24_not_configured",
                       has_webhook=bool(webhook_url), has_chat=bool(chat_id))
        return {"status": "skipped", "reason": "not_configured"}

    # Формируем URL метода
    # Для коробки: https://bitrix.tdsm.ru/rest/1/ТОКЕН/im.message.add
    url = webhook_url.rstrip("/") + "/im.message.add"

    payload = {
        "DIALOG_ID": f"chat{chat_id}",
        "MESSAGE": message,
    }

    try:
        response = httpx.post(url, json=payload, timeout=15.0)
        response.raise_for_status()
        data = response.json()

        if data.get("error"):
            logger.error("bitrix24_api_error", error=data.get("error"),
                         description=data.get("error_description"))
            return {"status": "failed", "error": data.get("error")}

        logger.info("bitrix24_message_sent", message_id=data.get("result"))
        return {"status": "sent", "message_id": data.get("result")}

    except httpx.HTTPError as e:
        logger.error("bitrix24_http_error", error=str(e))
        return {"status": "failed", "error": str(e)}


def send_to_bitrix_user(user_id: str, message: str) -> dict:
    """
    Отправляет личное сообщение конкретному пользователю Битрикс24.
    BITRIX24_USER_ID — ID пользователя (напр. "1" для администратора).
    """
    webhook_url = settings.bitrix24_webhook_url
    if not webhook_url:
        return {"status": "skipped", "reason": "not_configured"}

    url = webhook_url.rstrip("/") + "/im.message.add"
    payload = {"DIALOG_ID": user_id, "MESSAGE": message}

    try:
        response = httpx.post(url, json=payload, timeout=15.0)
        data = response.json()
        if data.get("error"):
            return {"status": "failed", "error": data.get("error")}
        return {"status": "sent"}
    except httpx.HTTPError as e:
        return {"status": "failed", "error": str(e)}
