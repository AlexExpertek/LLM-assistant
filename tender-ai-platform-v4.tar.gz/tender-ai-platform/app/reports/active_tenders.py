"""
Генерация отчёта по активным тендерам.

Активные = is_active=True (дедлайн не прошёл) + analysis_done=True.
Отчёт: Excel-файл с полными данными + краткая карточка для Telegram/Битрикс24.
"""
from datetime import datetime
from io import BytesIO

from sqlalchemy import select
from sqlalchemy.orm import joinedload

from app.core.logging import get_logger
from app.db.session import SyncSessionLocal
from app.models.database import Decision, Lot, Tender, TenderStatus

logger = get_logger(__name__)

# Статусы которые включаем в отчёт
REPORT_STATUSES = {
    TenderStatus.CAN_APPLY,
    TenderStatus.NEEDS_CLARIFICATION,
    TenderStatus.MANUAL_REVIEW,
}


def get_active_tenders() -> list[dict]:
    """Возвращает список активных проанализированных тендеров из БД."""
    with SyncSessionLocal() as session:
        stmt = (
            select(Tender)
            .where(
                Tender.is_active == True,
                Tender.analysis_done == True,
                Tender.status.in_(REPORT_STATUSES),
            )
            .options(
                joinedload(Tender.lots),
                joinedload(Tender.decisions),
            )
            .order_by(Tender.score.desc())
        )
        tenders = session.execute(stmt).unique().scalars().all()

        result = []
        for t in tenders:
            last_decision = (
                sorted(t.decisions, key=lambda d: d.created_at, reverse=True)[0]
                if t.decisions else None
            )
            lot = t.lots[0] if t.lots else None

            result.append({
                "id": t.id,
                "external_id": t.external_id,
                "source": t.source,
                "title": t.title,
                "customer_name": t.customer_name or "",
                "customer_inn": t.customer_inn or "",
                "status": t.status.value if t.status else "",
                "score": t.score or 0,
                "amount": float(t.amount) if t.amount else None,
                "region": t.region or "",
                "submission_deadline": t.submission_deadline.strftime("%d.%m.%Y %H:%M") if t.submission_deadline else "",
                "source_url": t.source_url or "",
                "notified_bitrix": t.notified_bitrix,
                "notified_telegram": t.notified_telegram,
                # Данные из лота
                "product_type": lot.product_type if lot else "",
                "alloy": lot.alloy if lot else "",
                "thickness_mm": lot.thickness_mm if lot else None,
                "width_mm": lot.width_mm if lot else None,
                "mass_kg": lot.mass_kg if lot else None,
                "standard": lot.standard if lot else "",
                "delivery_place": lot.delivery_place if lot else "",
                "delivery_term": lot.delivery_term if lot else "",
                "payment_terms": lot.payment_terms if lot else "",
                # Данные из решения
                "reasons": last_decision.reasons if last_decision else [],
                "risks": last_decision.risks if last_decision else [],
                "model_version": last_decision.model_version if last_decision else "",
            })
        return result


def generate_excel_report(tenders: list[dict]) -> bytes:
    """Генерирует Excel-файл с полными данными по активным тендерам."""
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter
    except ImportError:
        logger.error("openpyxl_not_installed")
        raise

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Активные тендеры"

    # Заголовки — соответствуют Приложению Б ТЗ
    headers = [
        "№", "Внешний ID", "Источник", "Заказчик", "ИНН заказчика",
        "Предмет закупки", "Продукт", "Сплав", "Толщина, мм", "Ширина, мм",
        "Масса, кг", "ГОСТ/ТУ", "НМЦК, руб", "Место поставки",
        "Срок поставки", "Условия оплаты", "Регион",
        "Статус ИИ", "Балл", "Срок подачи", "Ссылка",
        "Причины", "Риски",
    ]

    # Стиль заголовков
    header_fill = PatternFill("solid", fgColor="1F4E79")
    header_font = Font(color="FFFFFF", bold=True)

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", wrap_text=True)

    # Стили строк по статусу
    status_fills = {
        "can_apply": PatternFill("solid", fgColor="C6EFCE"),       # зелёный
        "manual_review": PatternFill("solid", fgColor="FFEB9C"),    # жёлтый
        "needs_clarification": PatternFill("solid", fgColor="FFEB9C"),
    }

    for row_num, t in enumerate(tenders, 2):
        fill = status_fills.get(t["status"])
        row_data = [
            row_num - 1,
            t["external_id"],
            t["source"],
            t["customer_name"],
            t["customer_inn"],
            t["title"],
            t["product_type"],
            t["alloy"],
            t["thickness_mm"],
            t["width_mm"],
            t["mass_kg"],
            t["standard"],
            t["amount"],
            t["delivery_place"],
            t["delivery_term"],
            t["payment_terms"],
            t["region"],
            t["status"],
            t["score"],
            t["submission_deadline"],
            t["source_url"],
            "; ".join(t["reasons"]) if t["reasons"] else "",
            "; ".join(t["risks"]) if t["risks"] else "",
        ]
        for col, value in enumerate(row_data, 1):
            cell = ws.cell(row=row_num, column=col, value=value)
            if fill:
                cell.fill = fill
            cell.alignment = Alignment(wrap_text=True)

    # Ширина столбцов
    column_widths = [4, 18, 15, 25, 14, 45, 12, 10, 10, 10,
                     10, 15, 15, 25, 15, 25, 15, 18, 8, 18, 35, 40, 40]
    for i, width in enumerate(column_widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = width

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}1"

    # Итоговая строка
    last_row = len(tenders) + 2
    ws.cell(row=last_row, column=1, value=f"Итого: {len(tenders)} тендеров")
    ws.cell(row=last_row, column=1).font = Font(bold=True)

    buffer = BytesIO()
    wb.save(buffer)
    return buffer.getvalue()


def format_report_summary(tenders: list[dict]) -> str:
    """Краткая сводка для Telegram/Битрикс24."""
    can_apply = [t for t in tenders if t["status"] == "can_apply"]
    manual = [t for t in tenders if t["status"] in ("manual_review", "needs_clarification")]

    lines = [
        f"📊 *Отчёт по активным тендерам* — {datetime.now().strftime('%d.%m.%Y %H:%M')}",
        "",
        f"Всего активных: *{len(tenders)}*",
        f"✅ Можем участвовать: *{len(can_apply)}*",
        f"🔍 На проверку специалиста: *{len(manual)}*",
        "",
    ]

    if can_apply:
        lines.append("*Топ-5 по баллу:*")
        for t in can_apply[:5]:
            deadline = t["submission_deadline"] or "не указан"
            lines.append(
                f"  • {t['score']}б | {t['customer_name'] or t['external_id']} | "
                f"до {deadline}"
            )

    return "\n".join(lines)
