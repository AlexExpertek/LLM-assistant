"""
Модуль безопасности — соответствие ФЗ-152 «О персональных данных».

Что делает:
1. Логирует все обращения к персональным данным (ИНН, ФИО, контакты)
2. Маскирует ПДн в логах
3. Middleware для заголовков безопасности
4. Утилиты для анонимизации перед сохранением в Qdrant/RAG
5. Политика хранения: документы удаляются через N дней (настраивается)
"""
import hashlib
import re
from datetime import datetime, timedelta
from typing import Optional

from fastapi import Request, Response
from fastapi.middleware.base import BaseHTTPMiddleware
from starlette.middleware.base import RequestResponseEndpoint

from app.core.logging import get_logger

logger = get_logger(__name__)

# Срок хранения документов тендеров (дней) — по умолчанию 90
DOCUMENT_RETENTION_DAYS = 90

# Паттерны ПДн для маскирования в логах
_PII_PATTERNS = [
    (re.compile(r'\b\d{10}\b'), 'ИНН:****'),           # ИНН физлица (10 цифр)
    (re.compile(r'\b\d{12}\b'), 'ИНН:****'),           # ИНН юрлица (12 цифр)
    (re.compile(r'\+7[\s\-]?\d{3}[\s\-]?\d{3}[\s\-]?\d{2}[\s\-]?\d{2}'), 'ТЕЛ:****'),
    (re.compile(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}'), 'EMAIL:****'),
]


def mask_pii(text: str) -> str:
    """Маскирует персональные данные перед записью в лог."""
    result = text
    for pattern, replacement in _PII_PATTERNS:
        result = pattern.sub(replacement, result)
    return result


def pseudonymize(value: str) -> str:
    """
    Псевдонимизация значения через SHA-256.
    Используется для хранения идентификаторов в аналитике без раскрытия ПДн.
    """
    return hashlib.sha256(value.encode('utf-8')).hexdigest()[:16]


def document_expiry_date() -> datetime:
    """Дата истечения срока хранения документа."""
    return datetime.utcnow() + timedelta(days=DOCUMENT_RETENTION_DAYS)


def should_delete_document(created_at: datetime) -> bool:
    """True если документ устарел и подлежит удалению."""
    return datetime.utcnow() > created_at + timedelta(days=DOCUMENT_RETENTION_DAYS)


def sanitize_for_rag(text: str) -> str:
    """
    Очищает текст перед помещением в RAG/Qdrant.
    Удаляет явные ПДн (телефоны, email, паспортные данные),
    оставляет технические параметры продукции.
    """
    result = text
    # Телефоны
    result = re.sub(r'\+7[\s\-]?\d[\s\-]?\d{3}[\s\-]?\d{3}[\s\-]?\d{2}[\s\-]?\d{2}',
                    '[ТЕЛЕФОН СКРЫТ]', result)
    # Email
    result = re.sub(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}',
                    '[EMAIL СКРЫТ]', result)
    # Паспортные данные (серия номер)
    result = re.sub(r'\b\d{4}\s\d{6}\b', '[ПАСПОРТ СКРЫТ]', result)
    # СНИЛС
    result = re.sub(r'\b\d{3}-\d{3}-\d{3}\s\d{2}\b', '[СНИЛС СКРЫТ]', result)
    return result


def log_data_access(
    user_id: str,
    action: str,
    data_type: str,
    record_id: Optional[str] = None,
    reason: Optional[str] = None,
):
    """
    Журнал доступа к данным — требование ст. 22 ФЗ-152.
    Все операции с данными должны быть задокументированы.
    """
    logger.info(
        "pdn_access",
        user=pseudonymize(user_id) if user_id else "system",
        action=action,           # read | write | delete | export
        data_type=data_type,     # tender | document | contact | company
        record_id=record_id,
        reason=reason or "tender_analysis",
        timestamp=datetime.utcnow().isoformat(),
    )


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """
    Middleware добавляет заголовки безопасности к каждому ответу.
    Соответствует требованиям ФЗ-152 о технических мерах защиты ПДн.
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        response = await call_next(request)

        # Запрет кэширования страниц с данными
        if request.url.path.startswith(('/tenders', '/reports', '/upload')):
            response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
            response.headers['Pragma'] = 'no-cache'

        # Заголовки безопасности
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
        response.headers['Content-Security-Policy'] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; "
            "connect-src 'self';"
        )

        return response


class PDNAccessLogger:
    """
    Контекстный менеджер для журналирования доступа к ПДн.
    Использование:
        async with PDNAccessLogger("user_1", "read", "tender"):
            # операции с данными
    """

    def __init__(self, user_id: str, action: str, data_type: str, record_id: str = None):
        self.user_id = user_id
        self.action = action
        self.data_type = data_type
        self.record_id = record_id
        self.start = None

    def __enter__(self):
        self.start = datetime.utcnow()
        log_data_access(self.user_id, self.action + '_start', self.data_type, self.record_id)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        duration_ms = int((datetime.utcnow() - self.start).total_seconds() * 1000)
        log_data_access(
            self.user_id,
            self.action + ('_error' if exc_type else '_done'),
            self.data_type,
            self.record_id,
            f"duration={duration_ms}ms",
        )


def check_retention_policy(session, storage_path: str):
    """
    Проверяет и удаляет устаревшие документы согласно политике хранения.
    Вызывается планировщиком раз в неделю.
    """
    from pathlib import Path
    from app.models.database import Document

    cutoff = datetime.utcnow() - timedelta(days=DOCUMENT_RETENTION_DAYS)

    # Находим устаревшие документы
    from sqlalchemy import select
    old_docs = session.execute(
        select(Document).where(Document.created_at < cutoff)
    ).scalars().all()

    deleted_count = 0
    for doc in old_docs:
        # Удаляем файл с диска
        if doc.storage_uri:
            p = Path(doc.storage_uri)
            if p.exists():
                p.unlink()
                deleted_count += 1
        # Очищаем extracted_text (содержит возможные ПДн)
        doc.extracted_text = None
        session.add(doc)

    if old_docs:
        session.commit()
        logger.info("retention_policy_applied",
                    deleted_files=deleted_count, cleared_records=len(old_docs))

    return {"deleted_files": deleted_count, "cleared_records": len(old_docs)}
