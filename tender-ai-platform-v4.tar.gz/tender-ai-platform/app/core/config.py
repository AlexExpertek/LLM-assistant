"""
Конфигурация приложения — обновлено: добавлены параметры Битрикс24.
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # БД
    database_url: str
    database_url_sync: str

    # Redis / Celery
    redis_url: str
    celery_broker_url: str
    celery_result_backend: str

    # Qdrant
    qdrant_url: str

    # LLM
    anthropic_api_key: str = ""
    anthropic_model_default: str = "claude-sonnet-4-6"
    anthropic_model_cheap: str = "claude-haiku-4-5-20251001"
    yandex_api_key: str = ""
    yandex_folder_id: str = ""
    yandex_model_uri: str = ""
    default_llm_provider: str = "anthropic"

    # Telegram
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""

    # Битрикс24 — коробочная версия
    bitrix24_webhook_url: str = ""   # напр: https://bitrix.tdsm.ru/rest/1/ТОКЕН
    bitrix24_chat_id: str = ""       # ID группового чата (только цифры)
    bitrix24_user_id: str = ""       # ID пользователя для личных сообщений

    # Прочее
    environment: str = "development"
    log_level: str = "INFO"
    storage_path: str = "/app/storage"


settings = Settings()
