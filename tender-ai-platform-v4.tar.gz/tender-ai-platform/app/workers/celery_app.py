"""
Celery конфигурация — обновлено: добавлено расписание mark_inactive_tenders
и generate_daily_report.
"""
from celery import Celery
from celery.schedules import crontab

from app.core.config import settings

celery_app = Celery(
    "tender_platform",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
    include=[
        "app.workers.tasks_parsing",
        "app.workers.tasks_ocr",
        "app.workers.tasks_scoring",
        "app.workers.tasks_notify",
        "app.workers.tasks_reports",
    ],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Europe/Moscow",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_default_retry_delay=60,
    task_max_retries=3,
)

celery_app.conf.beat_schedule = {
    # Мониторинг ЕИС — каждый день в 03:00
    "monitor-eis-daily": {
        "task": "app.workers.tasks_parsing.monitor_source",
        "schedule": crontab(hour=3, minute=0),
        "args": ("zakupki_gov_ru",),
    },
    # Помечаем просроченные тендеры неактивными — каждый час
    "mark-inactive-tenders-hourly": {
        "task": "app.workers.tasks_parsing.mark_inactive_tenders",
        "schedule": crontab(minute=0),
    },
    # Ежедневный отчёт по активным тендерам — в 09:00
    "daily-active-report": {
        "task": "app.workers.tasks_reports.generate_and_send_report",
        "schedule": crontab(hour=9, minute=0),
    },
}
