"""
Уведомления: Telegram + Битрикс24.
Обновлено: добавлены send_bitrix_notification и notify_bitrix_from_db.
"""
import asyncio
from sqlalchemy import select, update

from telegram import Bot

from app.core.config import settings
from app.core.logging import get_logger
from app.db.session import SyncSessionLocal
from app.integrations.bitrix24 import format_bitrix_message, send_to_bitrix_chat
from app.models.database import Tender
from app.workers.celery_app import celery_app

logger = get_logger(__name__)


def _get_status_emoji(status: str) -> str:
    return {
        "can_apply": "✅",
        "needs_clarification": "⚠️",
        "manual_review": "🔍",
        "not_suitable": "❌",
    }.get(status, "📄")


def format_telegram_card(tender_id: str, scoring_data: dict) -> str:
    score = scoring_data.get("total_score", scoring_data.get("score", 0))
    status = scoring_data.get("suggested_status", "")
    status_val = status.value if hasattr(status, "value") else str(status)
    category = scoring_data.get("category", "")
    category_val = category.value if hasattr(category, "value") else str(category)
    signals = scoring_data.get("signals", [])
    unknowns = scoring_data.get("critical_unknowns", [])

    emoji = _get_status_emoji(status_val)

    reasons = []
    for s in signals[:7]:
        reason = s.get("reason", "") if isinstance(s, dict) else getattr(s, "reason", "")
        reasons.append(f"  • {reason}")
    reasons_text = "\n".join(reasons) or "  нет данных"
    risks_text = "\n".join(f"  ⚠ {u}" for u in unknowns) or "  нет критических рисков"

    return (
        f"{emoji} *Тендер #{tender_id}*\n\n"
        f"*Рейтинг:* {score}/100 ({category_val})\n"
        f"*Статус:* {status_val}\n\n"
        f"*Причины:*\n{reasons_text}\n\n"
        f"*Критические неизвестные:*\n{risks_text}\n\n"
        f"_Результат сохранён в БД. Проверьте веб-кабинет._"
    )


@celery_app.task(name="app.workers.tasks_notify.send_telegram_notification")
def send_telegram_notification(tender_external_id: str, scoring_data: dict):
    if not settings.telegram_bot_token or not settings.telegram_chat_id:
        return {"status": "skipped"}

    text = format_telegram_card(tender_external_id, scoring_data)

    async def _send():
        bot = Bot(token=settings.telegram_bot_token)
        await bot.send_message(
            chat_id=settings.telegram_chat_id,
            text=text,
            parse_mode="Markdown",
        )

    try:
        asyncio.run(_send())
        logger.info("telegram_sent", tender_id=tender_external_id)
        return {"status": "sent"}
    except Exception as exc:
        logger.error("telegram_failed", error=str(exc))
        return {"status": "failed", "error": str(exc)}


@celery_app.task(name="app.workers.tasks_notify.send_bitrix_notification")
def send_bitrix_notification(tender_db_id: str, scoring_data: dict):
    """Отправляет уведомление в чат Битрикс24 и помечает тендер как уведомлённый."""
    message = format_bitrix_message(tender_db_id, scoring_data)
    result = send_to_bitrix_chat(message)

    if result.get("status") == "sent":
        # Проставляем флаг что уведомление отправлено
        with SyncSessionLocal() as session:
            session.execute(
                update(Tender)
                .where(Tender.id == tender_db_id)
                .values(notified_bitrix=True)
            )
            session.commit()
        logger.info("bitrix_notification_sent", tender_id=tender_db_id)
    else:
        logger.warning("bitrix_notification_failed", tender_id=tender_db_id, result=result)

    return result


@celery_app.task(name="app.workers.tasks_notify.notify_bitrix_from_db")
def notify_bitrix_from_db(tender_db_id: str):
    """
    Отправляет уведомление в Битрикс24 по уже сохранённым данным из БД.
    Используется для кэшированных тендеров (analysis_done=True).
    """
    with SyncSessionLocal() as session:
        tender = session.execute(
            select(Tender).where(Tender.id == tender_db_id)
        ).scalar_one_or_none()

        if not tender or tender.notified_bitrix:
            return {"status": "skipped"}

        scoring_data = {
            "score": tender.score,
            "suggested_status": tender.status.value if tender.status else "",
            "category": "",
            "signals": [],
            "critical_unknowns": [],
        }

    message = format_bitrix_message(tender.external_id, scoring_data)
    result = send_to_bitrix_chat(message)

    if result.get("status") == "sent":
        with SyncSessionLocal() as session:
            session.execute(
                update(Tender)
                .where(Tender.id == tender_db_id)
                .values(notified_bitrix=True)
            )
            session.commit()

    return result
