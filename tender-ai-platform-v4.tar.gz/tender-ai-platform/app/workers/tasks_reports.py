"""
Задачи формирования и рассылки отчётов по активным тендерам.
Запускается по расписанию ежедневно в 09:00 (см. celery_app.py).
Также доступен через API: POST /reports/generate
"""
import asyncio
from pathlib import Path
from datetime import datetime

from telegram import Bot

from app.core.config import settings
from app.core.logging import get_logger
from app.integrations.bitrix24 import send_to_bitrix_chat
from app.reports.active_tenders import (
    get_active_tenders,
    generate_excel_report,
    format_report_summary,
)
from app.workers.celery_app import celery_app

logger = get_logger(__name__)


@celery_app.task(name="app.workers.tasks_reports.generate_and_send_report")
def generate_and_send_report():
    """
    Формирует отчёт по активным тендерам и рассылает:
    1. Краткую сводку в Telegram
    2. Краткую сводку в чат Битрикс24
    3. Excel-файл сохраняется на диск (путь в логах)
    """
    logger.info("generating_active_tenders_report")

    tenders = get_active_tenders()
    if not tenders:
        logger.info("no_active_tenders_for_report")
        _send_telegram_text("📊 *Отчёт по тендерам*\n\nАктивных тендеров для отчёта нет.")
        return {"status": "no_tenders"}

    # Краткая сводка
    summary = format_report_summary(tenders)

    # Excel файл
    excel_bytes = generate_excel_report(tenders)
    report_path = _save_excel(excel_bytes)

    # Отправляем сводку в Telegram
    _send_telegram_text(summary)

    # Отправляем сводку в Битрикс24
    bitrix_msg = summary.replace("*", "[B]").replace("*", "[/B]")
    send_to_bitrix_chat(summary)

    # Telegram: отправляем Excel-файл
    _send_telegram_file(report_path, f"tenders_report_{datetime.now().strftime('%Y%m%d')}.xlsx")

    logger.info("report_sent", tenders_count=len(tenders), report_path=str(report_path))
    return {"status": "sent", "tenders_count": len(tenders), "report_path": str(report_path)}


def _save_excel(excel_bytes: bytes) -> Path:
    """Сохраняет Excel отчёт на диск."""
    reports_dir = Path(settings.storage_path) / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    filename = f"active_tenders_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    path = reports_dir / filename
    path.write_bytes(excel_bytes)
    return path


def _send_telegram_text(text: str):
    if not settings.telegram_bot_token or not settings.telegram_chat_id:
        return

    async def _send():
        bot = Bot(token=settings.telegram_bot_token)
        # Разбиваем длинные сообщения
        for chunk in _split_message(text, 4000):
            await bot.send_message(
                chat_id=settings.telegram_chat_id,
                text=chunk,
                parse_mode="Markdown",
            )

    try:
        asyncio.run(_send())
    except Exception as exc:
        logger.error("telegram_report_failed", error=str(exc))


def _send_telegram_file(path: Path, filename: str):
    """Отправляет Excel-файл в Telegram."""
    if not settings.telegram_bot_token or not settings.telegram_chat_id:
        return

    async def _send():
        bot = Bot(token=settings.telegram_bot_token)
        with open(path, "rb") as f:
            await bot.send_document(
                chat_id=settings.telegram_chat_id,
                document=f,
                filename=filename,
                caption=f"📎 Полный отчёт по активным тендерам ({filename})",
            )

    try:
        asyncio.run(_send())
    except Exception as exc:
        logger.error("telegram_file_send_failed", error=str(exc))


def _split_message(text: str, max_len: int) -> list[str]:
    """Разбивает длинное сообщение на части."""
    if len(text) <= max_len:
        return [text]
    chunks = []
    while text:
        chunks.append(text[:max_len])
        text = text[max_len:]
    return chunks
