"""
Извлечение полей через LLM и скоринг.
Обновлено: сохраняем результаты в БД, проставляем analysis_done=True.
"""
import asyncio
from dataclasses import asdict
from datetime import datetime

from sqlalchemy import update, select

from app.core.logging import get_logger
from app.db.session import SyncSessionLocal
from app.llm.extraction import extract_tender_fields, fields_requiring_review
from app.models.database import (
    Decision, Document, ExtractedFact, Lot, Tender, TenderStatus
)
from app.scoring.alloy_normalizer import is_known_alloy
from app.scoring.rules import score_tender
from app.workers.celery_app import celery_app

logger = get_logger(__name__)

# Версия промпта/модели — фиксируется в каждом решении для воспроизводимости
MODEL_VERSION = "scoring-v1.0"


@celery_app.task(
    name="app.workers.tasks_scoring.extract_fields_and_score",
    bind=True,
    max_retries=2,
)
def extract_fields_and_score(
    self,
    tender_external_id: str,
    document_text: str,
    tender_db_id: str = None,
    document_db_id: str = None,
):
    try:
        # ── LLM-извлечение ───────────────────────────────────────────
        extraction_result = asyncio.run(extract_tender_fields(document_text))
        low_confidence_fields = fields_requiring_review(extraction_result, threshold=0.5)

        if low_confidence_fields:
            logger.warning("low_confidence_fields", tender_id=tender_external_id,
                           fields=low_confidence_fields)

        # ── Скоринг ──────────────────────────────────────────────────
        alloy_value = extraction_result.alloy.value
        scoring_result = score_tender(
            text=document_text,
            has_alloy_match=bool(alloy_value and is_known_alloy(alloy_value)),
            has_dimensions=any([
                extraction_result.thickness_mm.value,
                extraction_result.width_mm.value,
                extraction_result.diameter_mm.value,
            ]),
            has_volume=bool(extraction_result.mass_kg.value or extraction_result.quantity.value),
            has_standard_ref=bool(extraction_result.standard.value),
            has_drawings=bool(extraction_result.has_drawings.value),
            has_processing_services=bool(
                extraction_result.coating.value or extraction_result.machining.value
            ),
        )

        score = scoring_result.total_score
        status = scoring_result.suggested_status
        category = scoring_result.category

        logger.info("tender_scored", tender_id=tender_external_id,
                    score=score, status=status.value)

        # ── Сохраняем в БД ───────────────────────────────────────────
        if tender_db_id:
            _save_results_to_db(
                tender_db_id=tender_db_id,
                document_db_id=document_db_id,
                extraction_result=extraction_result,
                scoring_result=scoring_result,
                low_confidence_fields=low_confidence_fields,
            )

        # ── Уведомления ──────────────────────────────────────────────
        if category.value in ("high_probability", "manual_review"):
            payload = asdict(scoring_result)
            payload["category"] = scoring_result.category.value
            payload["suggested_status"] = scoring_result.suggested_status.value

            from app.workers.tasks_notify import (
                send_telegram_notification,
                send_bitrix_notification,
            )
            send_telegram_notification.delay(tender_external_id, payload)
            if tender_db_id:
                send_bitrix_notification.delay(tender_db_id, payload)

        return {
            "status": "scored",
            "score": score,
            "category": category.value,
            "low_confidence_fields": low_confidence_fields,
        }

    except Exception as exc:
        logger.error("scoring_failed", tender_id=tender_external_id, error=str(exc))
        raise self.retry(exc=exc)


def _save_results_to_db(
    tender_db_id: str,
    document_db_id: str,
    extraction_result,
    scoring_result,
    low_confidence_fields: list,
):
    """Сохраняет extraction + scoring в БД, проставляет analysis_done=True."""
    with SyncSessionLocal() as session:
        # Сохраняем Decision
        decision = Decision(
            tender_id=tender_db_id,
            score=scoring_result.total_score,
            status=scoring_result.suggested_status,
            reasons=[s.reason for s in scoring_result.signals],
            risks=scoring_result.critical_unknowns,
            model_version=MODEL_VERSION,
        )
        session.add(decision)

        # Сохраняем Lot из извлечённых данных
        ext = extraction_result
        lot = Lot(
            tender_id=tender_db_id,
            product_type=getattr(ext, "product_type", None) and ext.product_type.value,
            alloy=ext.alloy.value,
            thickness_mm=_num(ext.thickness_mm.value),
            width_mm=_num(ext.width_mm.value),
            diameter_mm=_num(ext.diameter_mm.value),
            mass_kg=_num(ext.mass_kg.value),
            standard=ext.standard.value,
            coating_required=bool(ext.coating.value),
            has_drawings=bool(ext.has_drawings.value),
            delivery_place=ext.delivery_place.value,
            delivery_term=ext.delivery_term.value,
            payment_terms=ext.payment_terms.value,
        )
        session.add(lot)

        # Сохраняем ExtractedFacts если есть document_db_id
        if document_db_id:
            for field_name, field_obj in extraction_result.__dict__.items():
                if hasattr(field_obj, "value") and hasattr(field_obj, "confidence"):
                    fact = ExtractedFact(
                        document_id=document_db_id,
                        field_name=field_name,
                        raw_value=str(field_obj.value) if field_obj.value is not None else None,
                        normalized_value=str(field_obj.value) if field_obj.value is not None else None,
                        confidence=field_obj.confidence or 0.0,
                        quote=getattr(field_obj, "raw_quote", None),
                    )
                    session.add(fact)

        # Обновляем Tender: проставляем analysis_done + кэшируем score + статус
        session.execute(
            update(Tender)
            .where(Tender.id == tender_db_id)
            .values(
                analysis_done=True,
                score=scoring_result.total_score,
                status=scoring_result.suggested_status,
                updated_at=datetime.utcnow(),
            )
        )

        session.commit()
        logger.info("results_saved_to_db", tender_id=tender_db_id,
                    score=scoring_result.total_score)


def _num(val):
    """Безопасно конвертирует строку в float."""
    try:
        return float(val) if val is not None else None
    except (ValueError, TypeError):
        return None
