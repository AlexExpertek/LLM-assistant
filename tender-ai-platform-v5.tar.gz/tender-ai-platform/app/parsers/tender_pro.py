"""
Адаптер для получения тендеров с площадки Tender.Pro через REST API.

API документация: https://help.tender.pro/vigruzka_lenti_procedur.html
Методы: https://www.tender.pro/api/docs/smd

Ключевые методы:
  _info.tenderlist_by_set — список тендеров
  _tender.info           — детали тендера
  _tender.files          — файлы тендера

Ключ API: _key=1732ede4de680a0c93d81f01d7bac7d1
"""
from datetime import datetime, timezone
from typing import Optional

import httpx

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

TENDER_PRO_BASE = "https://www.tender.pro/api"
TENDER_PRO_KEY = "1732ede4de680a0c93d81f01d7bac7d1"
TENDER_PRO_SOURCE = "tender_pro"

# Ключевые слова для фильтрации — только алюминиевая продукция
KEYWORDS = [
    "алюминиев", "алюминий", "aluminium", "aluminum",
    "лента алюм", "лист алюм", "профиль алюм",
    "труба алюм", "пруток алюм", "прокат цветн",
    "цветной металл", "металлопрокат",
]


def _api_get(method: str, params: dict) -> Optional[dict]:
    """Выполняет GET запрос к API Tender.Pro."""
    url = f"{TENDER_PRO_BASE}/{method}.json"
    params["_key"] = TENDER_PRO_KEY

    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.get(url, params=params)
            resp.raise_for_status()
            data = resp.json()
            return data
    except httpx.HTTPError as e:
        logger.error("tender_pro_api_error", method=method, error=str(e))
        return None
    except Exception as e:
        logger.error("tender_pro_parse_error", method=method, error=str(e))
        return None


def _matches_keywords(text: str) -> bool:
    """Проверяет наличие ключевых слов алюминиевой продукции."""
    text_lower = text.lower()
    return any(kw in text_lower for kw in KEYWORDS)


def _parse_tender_item(item: dict) -> Optional[dict]:
    """
    Преобразует запись из API Tender.Pro в стандартный формат tender_data.
    """
    title = item.get("name", "") or item.get("subject", "") or ""
    description = item.get("description", "") or ""

    # Фильтрация по ключевым словам
    if not _matches_keywords(title + " " + description):
        return None

    tender_id = str(item.get("id", ""))
    company_id = str(item.get("company_id", ""))

    # Дата окончания приёма заявок
    deadline = None
    for date_field in ["date_close", "close_date", "end_date", "date_end"]:
        if item.get(date_field):
            deadline = item[date_field]
            break

    # НМЦК / стартовая цена
    amount = None
    for price_field in ["start_price", "price", "amount", "sum"]:
        val = item.get(price_field)
        if val:
            try:
                amount = float(str(val).replace(",", ".").replace(" ", ""))
                break
            except (ValueError, TypeError):
                pass

    return {
        "source": TENDER_PRO_SOURCE,
        "external_id": tender_id,
        "title": title,
        "customer_name": item.get("company_name") or item.get("organizer"),
        "customer_inn": item.get("inn"),
        "amount": amount,
        "region": item.get("region") or item.get("delivery_address"),
        "source_url": f"https://www.tender.pro/procedure/{tender_id}",
        "submission_deadline": deadline,
        "law_type": "commercial",
        "document_urls": [],
        "company_id": company_id,
        "_raw": item,
    }


def fetch_tender_details(tender_id: str, company_id: str) -> Optional[dict]:
    """Получает детальную информацию по тендеру."""
    data = _api_get("_tender.info", {
        "id": tender_id,
        "company_id": company_id,
    })
    if not data:
        return None
    # API возвращает либо объект напрямую, либо в поле result/data
    if isinstance(data, dict):
        return data.get("result") or data.get("data") or data
    return None


def fetch_tender_files(tender_id: str, company_id: str) -> list[str]:
    """
    Получает список URL файлов тендера.
    Возвращает ссылки для последующего скачивания.
    """
    data = _api_get("_tender.files", {
        "id": tender_id,
        "company_id": company_id,
    })
    if not data:
        return []

    files = []
    items = data if isinstance(data, list) else data.get("result", []) or data.get("files", [])
    for f in items:
        if isinstance(f, dict):
            url = f.get("url") or f.get("file_url") or f.get("href")
            if url:
                files.append(url)
        elif isinstance(f, str) and f.startswith("http"):
            files.append(f)
    return files


def fetch_new_tenders(max_rows: int = 100) -> list[dict]:
    """
    Главная функция — получает активные тендеры с Tender.Pro.
    Вызывается Celery-задачей monitor_source каждую ночь.

    set_type_id=2 — все торговые процедуры (не только одной компании)
    open_only=t   — только в стадии приёма предложений
    """
    logger.info("tender_pro_fetch_started", max_rows=max_rows)

    data = _api_get("_info.tenderlist_by_set", {
        "set_type_id": 2,
        "set_id": 7964,
        "max_rows": max_rows,
        "open_only": "t",
    })

    if not data:
        logger.error("tender_pro_no_data")
        return []

    # API возвращает список или объект с полем result
    items = data if isinstance(data, list) else \
            data.get("result", []) or data.get("tenders", []) or data.get("data", [])

    if not isinstance(items, list):
        logger.warning("tender_pro_unexpected_format", type=type(items).__name__)
        return []

    results = []
    skipped = 0

    for item in items:
        if not isinstance(item, dict):
            continue

        tender = _parse_tender_item(item)
        if not tender:
            skipped += 1
            continue

        # Получаем файлы документации
        company_id = tender.pop("company_id", "")
        files = fetch_tender_files(tender["external_id"], company_id)
        tender["document_urls"] = files

        results.append(tender)
        logger.info("tender_pro_accepted",
                    external_id=tender["external_id"],
                    title=tender["title"][:60],
                    files=len(files))

    logger.info("tender_pro_fetch_done",
                found=len(results),
                skipped=skipped,
                total=len(items))
    return results
