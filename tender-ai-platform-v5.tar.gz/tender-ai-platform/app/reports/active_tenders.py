"""
Генерация отчёта по активным тендерам.
Исправлено: Excel генерируется даже при пустом списке тендеров.
"""
from datetime import datetime
from io import BytesIO

from sqlalchemy import select
from sqlalchemy.orm import joinedload

from app.core.logging import get_logger
from app.db.session import SyncSessionLocal
from app.models.database import Decision, Lot, Tender, TenderStatus

logger = get_logger(__name__)

REPORT_STATUSES = {
    TenderStatus.CAN_APPLY,
    TenderStatus.NEEDS_CLARIFICATION,
    TenderStatus.MANUAL_REVIEW,
}


def get_active_tenders() -> list[dict]:
    """Возвращает список активных проанализированных тендеров из БД."""
    try:
        with SyncSessionLocal() as session:
            stmt = (
                select(Tender)
                .where(
                    Tender.is_active == True,
                    Tender.analysis_done == True,
                    Tender.status.in_(REPORT_STATUSES),
                )
                .options(
                    joinedload(Tender.lots),
                    joinedload(Tender.decisions),
                )
                .order_by(Tender.score.desc())
            )
            tenders = session.execute(stmt).unique().scalars().all()

            result = []
            for t in tenders:
                last_decision = (
                    sorted(t.decisions, key=lambda d: d.created_at, reverse=True)[0]
                    if t.decisions else None
                )
                lot = t.lots[0] if t.lots else None

                result.append({
                    "id": str(t.id),
                    "external_id": t.external_id,
                    "source": t.source,
                    "title": t.title,
                    "customer_name": t.customer_name or "",
                    "customer_inn": t.customer_inn or "",
                    "status": t.status.value if t.status else "",
                    "score": t.score or 0,
                    "amount": float(t.amount) if t.amount else None,
                    "region": t.region or "",
                    "submission_deadline": (
                        t.submission_deadline.strftime("%d.%m.%Y %H:%M")
                        if t.submission_deadline else ""
                    ),
                    "source_url": t.source_url or "",
                    "notified_bitrix": t.notified_bitrix,
                    "notified_telegram": t.notified_telegram,
                    "product_type": lot.product_type if lot else "",
                    "alloy": lot.alloy if lot else "",
                    "thickness_mm": lot.thickness_mm if lot else None,
                    "width_mm": lot.width_mm if lot else None,
                    "mass_kg": lot.mass_kg if lot else None,
                    "standard": lot.standard if lot else "",
                    "delivery_place": lot.delivery_place if lot else "",
                    "delivery_term": lot.delivery_term if lot else "",
                    "payment_terms": lot.payment_terms if lot else "",
                    "reasons": last_decision.reasons if last_decision else [],
                    "risks": last_decision.risks if last_decision else [],
                    "model_version": last_decision.model_version if last_decision else "",
                    # Заглушки для совместимости с интерфейсом
                    "positions": [],
                    "can_supply_partial": False,
                })
            return result

    except Exception as e:
        logger.error("get_active_tenders_failed", error=str(e))
        return []


def get_all_tenders_stats() -> dict:
    """Статистика по всем тендерам в БД — для дашборда."""
    try:
        with SyncSessionLocal() as session:
            all_tenders = session.execute(select(Tender)).scalars().all()
            return {
                "total": len(all_tenders),
                "active": sum(1 for t in all_tenders if t.is_active),
                "analyzed": sum(1 for t in all_tenders if t.analysis_done),
                "can_apply": sum(1 for t in all_tenders if t.status == TenderStatus.CAN_APPLY),
                "manual_review": sum(1 for t in all_tenders
                                     if t.status in (TenderStatus.MANUAL_REVIEW, TenderStatus.NEEDS_CLARIFICATION)),
                "not_analyzed_yet": sum(1 for t in all_tenders if not t.analysis_done),
            }
    except Exception as e:
        logger.error("get_stats_failed", error=str(e))
        return {}


def generate_excel_report(tenders: list[dict]) -> bytes:
    """
    Генерирует Excel-файл.
    Работает даже при пустом списке тендеров — возвращает файл с заголовками.
    """
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Активные тендеры"

    headers = [
        "№", "Внешний ID", "Источник", "Заказчик", "ИНН заказчика",
        "Предмет закупки", "Продукт", "Сплав", "Толщина, мм", "Ширина, мм",
        "Масса, кг", "ГОСТ/ТУ", "НМЦК, руб", "Место поставки",
        "Срок поставки", "Условия оплаты", "Регион",
        "Статус ИИ", "Балл", "Срок подачи", "Ссылка",
        "Причины", "Риски",
    ]

    header_fill = PatternFill("solid", fgColor="1F4E79")
    header_font = Font(color="FFFFFF", bold=True)

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", wrap_text=True)

    if not tenders:
        # Если тендеров нет — добавляем пояснение
        msg_cell = ws.cell(row=2, column=1,
                           value="Активных тендеров нет. Запустите мониторинг ЕИС или загрузите тендер вручную.")
        msg_cell.font = Font(italic=True, color="666666")
        ws.merge_cells("A2:W2")
    else:
        status_fills = {
            "can_apply": PatternFill("solid", fgColor="C6EFCE"),
            "manual_review": PatternFill("solid", fgColor="FFEB9C"),
            "needs_clarification": PatternFill("solid", fgColor="FFEB9C"),
        }

        for row_num, t in enumerate(tenders, 2):
            fill = status_fills.get(t.get("status", ""))
            row_data = [
                row_num - 1,
                t.get("external_id", ""),
                t.get("source", ""),
                t.get("customer_name", ""),
                t.get("customer_inn", ""),
                t.get("title", ""),
                t.get("product_type", ""),
                t.get("alloy", ""),
                t.get("thickness_mm"),
                t.get("width_mm"),
                t.get("mass_kg"),
                t.get("standard", ""),
                t.get("amount"),
                t.get("delivery_place", ""),
                t.get("delivery_term", ""),
                t.get("payment_terms", ""),
                t.get("region", ""),
                t.get("status", ""),
                t.get("score", 0),
                t.get("submission_deadline", ""),
                t.get("source_url", ""),
                "; ".join(t.get("reasons", []) or []),
                "; ".join(t.get("risks", []) or []),
            ]
            for col, value in enumerate(row_data, 1):
                cell = ws.cell(row=row_num, column=col, value=value)
                if fill:
                    cell.fill = fill
                cell.alignment = Alignment(wrap_text=True)

        # Итоговая строка
        last_row = len(tenders) + 2
        ws.cell(row=last_row, column=1,
                value=f"Итого: {len(tenders)} тендеров | Сформировано: {datetime.now().strftime('%d.%m.%Y %H:%M')}"
                ).font = Font(bold=True)

    # Ширина столбцов
    widths = [4, 20, 15, 28, 14, 45, 12, 10, 10, 10,
              10, 15, 15, 25, 15, 25, 15, 18, 8, 18, 35, 40, 40]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    ws.freeze_panes = "A2"
    if tenders:
        ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}1"

    buffer = BytesIO()
    wb.save(buffer)
    return buffer.getvalue()


def format_report_summary(tenders: list[dict]) -> str:
    """Краткая сводка для Telegram/Битрикс24."""
    can_apply = [t for t in tenders if t.get("status") == "can_apply"]
    manual = [t for t in tenders if t.get("status") in ("manual_review", "needs_clarification")]

    lines = [
        f"📊 *Отчёт по активным тендерам* — {datetime.now().strftime('%d.%m.%Y %H:%M')}",
        "",
        f"Всего активных: *{len(tenders)}*",
        f"✅ Можем участвовать: *{len(can_apply)}*",
        f"🔍 На проверку специалиста: *{len(manual)}*",
        "",
    ]

    if can_apply:
        lines.append("*Топ-5 по баллу:*")
        for t in sorted(can_apply, key=lambda x: x.get("score", 0), reverse=True)[:5]:
            deadline = t.get("submission_deadline") or "не указан"
            lines.append(
                f"  • {t.get('score', 0)}б | "
                f"{t.get('customer_name') or t.get('external_id', '')} | "
                f"до {deadline}"
            )
    elif not tenders:
        lines.append("_Активных тендеров нет. Система ожидает данных от ЕИС._")

    return "\n".join(lines)
