"""
FastAPI приложение — v0.4.0
Новое: веб-интерфейс на русском, ФЗ-152, загрузка файлов, анализ по URL,
многопозиционные тендеры, сжатие файлов.
"""
from fastapi import FastAPI, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from app.core.config import settings
from app.core.logging import configure_logging, get_logger
from app.db.health import check_postgres, check_redis
from app.security.fz152 import SecurityHeadersMiddleware
from app.workers.celery_app import celery_app
from app.workers.tasks_parsing import SOURCE_REGISTRY, monitor_source
from app.api.upload import router as upload_router

configure_logging()
logger = get_logger(__name__)

app = FastAPI(
    title="Тендерный ассистент ТДСМ",
    description="Блок I MVP — мониторинг, анализ, отчёты, Битрикс24",
    version="0.4.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

# Middleware
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])

# Роутеры
app.include_router(upload_router)

# Статические файлы (интерфейс)
from pathlib import Path
static_dir = Path(__file__).parent / "static"
if static_dir.exists():
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


# ── Главная страница ─────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def root():
    index_path = Path(__file__).parent / "static" / "index.html"
    if index_path.exists():
        return HTMLResponse(content=index_path.read_text(encoding='utf-8'))
    return HTMLResponse(content="<h1>Тендерный ассистент ТДСМ</h1><p><a href='/api/docs'>API документация</a></p>")


# ── Health ───────────────────────────────────────────────────────────────────
@app.get("/health/live")
async def liveness():
    return {"status": "ok"}


@app.get("/health/ready")
@app.get("/health")
async def readiness():
    services = {"postgres": await check_postgres(), "redis": await check_redis()}
    if not all(services.values()):
        raise HTTPException(503, detail={"status": "not_ready", "services": services})
    return {"status": "ready", "services": services,
            "environment": settings.environment,
            "llm_provider_default": settings.default_llm_provider}


# ── Источники ────────────────────────────────────────────────────────────────
@app.get("/sources")
async def list_sources():
    return {"sources": [
        {"key": k, "name": v["name"], "law_types": v["law_types"]}
        for k, v in SOURCE_REGISTRY.items()
    ]}


class TriggerRequest(BaseModel):
    source_key: str


@app.post("/sources/trigger")
async def trigger_monitoring(payload: TriggerRequest):
    if payload.source_key not in SOURCE_REGISTRY:
        raise HTTPException(404, "Источник не найден")
    task = monitor_source.delay(payload.source_key)
    return {"status": "queued", "task_id": task.id}


# ── Тендеры ──────────────────────────────────────────────────────────────────

@app.get("/tenders/stats", summary="Статистика по тендерам")
async def get_tenders_stats():
    from app.reports.active_tenders import get_all_tenders_stats
    return get_all_tenders_stats()

@app.get("/tenders/active", summary="Активные тендеры")
async def get_active_tenders():
    from app.reports.active_tenders import get_active_tenders as _get
    from app.security.fz152 import log_data_access
    log_data_access("web_ui", "read", "tenders")
    tenders = _get()
    return {"count": len(tenders), "tenders": tenders}


# ── Задачи ───────────────────────────────────────────────────────────────────
@app.get("/tasks/{task_id}")
async def get_task_status(task_id: str):
    result = celery_app.AsyncResult(task_id)
    return {
        "task_id": task_id,
        "status": result.status,
        "ready": result.ready(),
        "result": result.result if result.ready() and result.successful() else None,
        "error": str(result.result) if result.ready() and result.failed() else None,
    }


@app.post("/tasks/mark-inactive")
async def trigger_mark_inactive():
    from app.workers.tasks_parsing import mark_inactive_tenders
    task = mark_inactive_tenders.delay()
    return {"status": "queued", "task_id": task.id}


# ── Отчёты ───────────────────────────────────────────────────────────────────
@app.post("/reports/generate", summary="Сгенерировать и разослать отчёт")
async def trigger_report():
    from app.workers.tasks_reports import generate_and_send_report
    task = generate_and_send_report.delay()
    return {"status": "queued", "task_id": task.id,
            "message": "Отчёт будет отправлен в Telegram и Битрикс24"}


@app.get("/reports/active.xlsx", summary="Скачать Excel-отчёт")
async def download_active_report():
    from app.reports.active_tenders import get_active_tenders as _get, generate_excel_report
    from app.security.fz152 import log_data_access
    log_data_access("web_ui", "export", "tenders")
    tenders = _get()
    excel = generate_excel_report(tenders)  # работает и с пустым списком
    return Response(
        content=excel,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=active_tenders.xlsx"},
    )
