"""Celery-задача обработки вручную загруженного тендера."""
import asyncio
from app.core.logging import get_logger
from app.ocr.pipeline import extract_document
from app.models.database import OCRStatus
from app.workers.celery_app import celery_app
logger = get_logger(__name__)

@celery_app.task(name="app.workers.tasks_upload.process_uploaded_tender", bind=True, max_retries=2)
def process_uploaded_tender(self, tender_data: dict, file_path: str):
    upload_id = tender_data.get("upload_id", "unknown")
    logger.info("processing_uploaded_tender", upload_id=upload_id)
    try:
        extraction = extract_document(file_path)
    except Exception as exc:
        logger.error("ocr_failed", error=str(exc))
        raise self.retry(exc=exc)
    if not extraction.full_text.strip():
        return {"status": "failed", "reason": "empty_text"}
    try:
        from app.llm.extraction import extract_tender_fields, fields_requiring_review
        extracted = asyncio.run(extract_tender_fields(extraction.full_text))
    except Exception as exc:
        logger.error("llm_failed", error=str(exc))
        raise self.retry(exc=exc)
    try:
        from app.scoring.alloy_normalizer import is_known_alloy
        from app.scoring.rules import score_tender
        alloy_val = extracted.alloy.value
        scoring = score_tender(
            text=extraction.full_text,
            has_alloy_match=bool(alloy_val and is_known_alloy(alloy_val)),
            has_dimensions=any([extracted.thickness_mm.value, extracted.width_mm.value]),
            has_volume=bool(extracted.mass_kg.value or extracted.quantity.value),
            has_standard_ref=bool(extracted.standard.value),
            has_drawings=bool(extracted.has_drawings.value),
            has_processing_services=bool(extracted.coating.value or extracted.machining.value),
        )
    except Exception as exc:
        logger.error("scoring_failed", error=str(exc))
        raise self.retry(exc=exc)
    try:
        from app.workers.tasks_notify import send_upload_result_notification
        send_upload_result_notification.delay(tender_data, {
            "upload_id": upload_id, "filename": tender_data.get("title", ""),
            "extracted": extracted, "scoring": scoring, "ocr_warnings": [],
        })
    except Exception as e:
        logger.error("notify_failed", error=str(e))
    return {"status": "completed", "score": scoring.total_score,
            "decision": scoring.suggested_status.value}
