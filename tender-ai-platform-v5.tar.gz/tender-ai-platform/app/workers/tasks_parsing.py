"""
Мониторинг источников тендеров.
Источники: ЕИС zakupki.gov.ru, Tender.Pro, ручная загрузка.
"""
import hashlib
from datetime import datetime, timezone

from sqlalchemy import select, update

from app.core.logging import get_logger
from app.db.session import SyncSessionLocal
from app.models.database import Tender, TenderStatus
from app.workers.celery_app import celery_app

logger = get_logger(__name__)

SOURCE_REGISTRY = {
    "zakupki_gov_ru": {
        "name": "ЕИС zakupki.gov.ru (44-ФЗ / 223-ФЗ)",
        "base_url": "https://zakupki.gov.ru",
        "law_types": ["44-FZ", "223-FZ"],
        "parser": "app.parsers.zakupki_gov.fetch_new_tenders",
    },
    "tender_pro": {
        "name": "Tender.Pro — коммерческая площадка",
        "base_url": "https://www.tender.pro",
        "law_types": ["commercial"],
        "parser": "app.parsers.tender_pro.fetch_new_tenders",
    },
    "commercial_etp": {
        "name": "Другие коммерческие ЭТП",
        "base_url": None,
        "law_types": ["commercial"],
        "parser": None,
    },
}


def compute_tender_hash(source: str, external_id: str, customer_name: str, title: str) -> str:
    raw = f"{source}|{external_id}|{customer_name}|{title}".lower().strip()
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def find_existing_tender(session, source: str, external_id: str):
    stmt = select(Tender).where(
        Tender.source == source,
        Tender.external_id == external_id,
    )
    return session.execute(stmt).scalar_one_or_none()


@celery_app.task(
    name="app.workers.tasks_parsing.monitor_source",
    bind=True,
    max_retries=3,
    default_retry_delay=300,
)
def monitor_source(self, source_key: str):
    source_config = SOURCE_REGISTRY.get(source_key)
    if not source_config:
        logger.error("unknown_source", source=source_key)
        return {"status": "error", "reason": "unknown_source"}

    logger.info("monitor_source_started", source=source_key)

    try:
        if not source_config["parser"]:
            logger.warning("parser_not_implemented", source=source_key)
            return {"status": "skipped", "reason": "parser_not_implemented"}

        new_tenders = _dispatch_parser(source_config["parser"], source_key)
        logger.info("monitor_source_completed", source=source_key,
                    new_tenders_count=len(new_tenders))

        for tender_data in new_tenders:
            process_new_tender.delay(tender_data)

        return {"status": "success", "new_tenders": len(new_tenders)}

    except Exception as exc:
        logger.error("monitor_source_failed", source=source_key, error=str(exc))
        raise self.retry(exc=exc)


def _dispatch_parser(parser_path: str, source_key: str) -> list[dict]:
    module_path, func_name = parser_path.rsplit(".", 1)
    import importlib
    module = importlib.import_module(module_path)
    return getattr(module, func_name)()


@celery_app.task(
    name="app.workers.tasks_parsing.process_new_tender",
    bind=True,
    max_retries=3,
)
def process_new_tender(self, tender_data: dict):
    """
    Обработка тендера с проверкой кэша:
    - analysis_done=True → берём из БД, не гоняем LLM повторно
    - Новый → сохраняем и запускаем цепочку
    """
    source = tender_data["source"]
    external_id = tender_data["external_id"]
    tender_hash = compute_tender_hash(
        source=source,
        external_id=external_id,
        customer_name=tender_data.get("customer_name", ""),
        title=tender_data.get("title", ""),
    )

    with SyncSessionLocal() as session:
        existing = find_existing_tender(session, source, external_id)

        if existing:
            if existing.analysis_done:
                logger.info("tender_cached_skip_llm",
                            external_id=external_id,
                            status=existing.status.value,
                            score=existing.score)
                if not existing.notified_bitrix and existing.is_active:
                    from app.workers.tasks_notify import notify_bitrix_from_db
                    notify_bitrix_from_db.delay(str(existing.id))
                return {
                    "status": "cached",
                    "external_id": external_id,
                    "score": existing.score,
                    "decision": existing.status.value,
                }
            else:
                logger.info("tender_exists_not_analyzed", external_id=external_id)
        else:
            new_tender = Tender(
                source=source,
                external_id=external_id,
                title=tender_data.get("title", ""),
                customer_name=tender_data.get("customer_name"),
                customer_inn=tender_data.get("customer_inn"),
                amount=tender_data.get("amount"),
                region=tender_data.get("region"),
                source_url=tender_data.get("source_url"),
                raw_hash=tender_hash,
                status=TenderStatus.NEW,
                analysis_done=False,
                is_active=True,
            )
            deadline_str = tender_data.get("submission_deadline")
            if deadline_str:
                try:
                    new_tender.submission_deadline = datetime.fromisoformat(
                        str(deadline_str).replace("Z", "+00:00")
                    )
                except (ValueError, TypeError):
                    pass

            session.add(new_tender)
            session.commit()
            session.refresh(new_tender)
            logger.info("tender_saved_to_db",
                        external_id=external_id, id=str(new_tender.id))

    from app.workers.tasks_ocr import download_and_process_documents
    download_and_process_documents.delay(
        external_id,
        tender_data.get("document_urls", []),
    )

    return {"status": "queued_for_processing", "hash": tender_hash}


@celery_app.task(name="app.workers.tasks_parsing.mark_inactive_tenders")
def mark_inactive_tenders():
    """Помечает тендеры с истёкшим дедлайном как неактивные."""
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    with SyncSessionLocal() as session:
        stmt = (
            update(Tender)
            .where(
                Tender.is_active == True,
                Tender.submission_deadline != None,
                Tender.submission_deadline < now,
            )
            .values(is_active=False)
        )
        result = session.execute(stmt)
        session.commit()
        count = result.rowcount
        if count:
            logger.info("tenders_marked_inactive", count=count)
    return {"marked_inactive": count}
