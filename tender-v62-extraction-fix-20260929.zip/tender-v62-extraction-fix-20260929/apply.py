import sys,json,hashlib,shutil,tempfile
from pathlib import Path
package=Path(__file__).resolve().parent
root=Path(sys.argv[1]).resolve()
manifest=json.loads((package/'manifest.json').read_text())
updates=[]
for rel,h in manifest.items():
 target=root/rel; payload=package/'payload'/rel
 digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
 if digest(payload)!=h['after']:raise SystemExit('Payload mismatch: '+rel)
 if digest(target)==h['after']:continue
 if digest(target)!=h['before']:raise SystemExit('Unexpected installed version: '+rel)
 updates.append(rel)
if updates:
 backup=Path(tempfile.mkdtemp(prefix='tender-extraction-backup-',dir=root.parent))
 for rel in updates:
  dst=backup/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/rel,dst)
 for rel in updates:shutil.copy2(package/'payload'/rel,root/rel)
 print('Backup:',backup)
print('Applied:',len(updates))
