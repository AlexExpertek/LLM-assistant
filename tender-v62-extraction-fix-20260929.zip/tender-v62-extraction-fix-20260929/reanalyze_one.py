"""Read saved documents; optionally queue one fresh analysis, without re-downloading."""
import argparse
from sqlalchemy import select
from app.core.config import settings
from app.db.session import SyncSessionLocal
from app.models.database import Tender,Document,OCRStatus
from app.llm.extraction import _complete_document_text
from app.workers.tasks_scoring import analyze_tender
p=argparse.ArgumentParser();p.add_argument('--enqueue',action='store_true');args=p.parse_args()
with SyncSessionLocal() as s:
 t=s.execute(select(Tender).where(Tender.source=='zakupki_gov_ru',Tender.external_id=='32616417112')).scalar_one()
 docs=s.execute(select(Document).where(Document.tender_id==t.id).order_by(Document.created_at,Document.id)).scalars().all()
 if not docs or any(d.ocr_status not in (OCRStatus.DONE,OCRStatus.NOT_REQUIRED) or not (d.extracted_text or '').strip() for d in docs):raise SystemExit('Incomplete document snapshot; stopped')
 parts=[]
 for d in docs:
  print(d.filename,'characters=',len(d.extracted_text or ''))
  parts.append('\n\n### DOCUMENT: '+d.filename+'\n'+d.extracted_text)
 text=''.join(parts)
 print('DOCUMENT_TEXT_CHARACTERS:',len(text))
 print('SPEC_MARKER_OFFSET:',text.find('23х1'))
 # Use a margin for metadata inserted by the task.
 _complete_document_text((t.title or '')+'\n'+(t.description or '')+'\n'+(t.delivery_place or '')+'\n'+text+' '*1024)
 tid=str(t.id);ids=[str(d.id) for d in docs]
if args.enqueue:
 if settings.notifications_enabled:raise SystemExit('NOTIFICATIONS_ENABLED: stopped')
 print('TASK_ID:',analyze_tender.delay(tid,text,ids).id)
else:print('PREVIEW_ONLY: add --enqueue to run one LLM analysis')
