"""Exercise actual extraction function with a mocked provider, without external calls."""
import ast,asyncio,unittest
from pathlib import Path
from types import SimpleNamespace
path=Path('app/llm/extraction.py')
if not path.exists():path=Path(__file__).parent/'payload/app/llm/extraction.py'
tree=ast.parse(path.read_text())
selected=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in ('_complete_document_text','extract_tender_positions')]
class Result:
 @classmethod
 def model_json_schema(cls):return {}
 @classmethod
 def model_validate(cls,data):return data
class Router:
 def __init__(self):self.calls=[]
 async def complete(self,**kw):
  self.calls.append(kw)
  return SimpleNamespace(as_json=lambda:{'positions':[]})
router=Router()
ns={'TenderMultiExtractionResult':Result,'llm_router':router,'TaskType':SimpleNamespace(EXTRACT_FIELDS='extract_fields'),'MULTI_EXTRACTION_SYSTEM_PROMPT':'test'}
exec(compile(ast.Module(body=selected,type_ignores=[]),str(path),'exec'),ns)
class Checks(unittest.TestCase):
 def setUp(self):router.calls.clear()
 def test_late_spec_reaches_provider(self):
  spec='Труба АД1М 23х1,0х6000 ГОСТ 18475-82 | тн | 8'
  text='Общие условия. '*3000+'\n### DOCUMENT: Технические требования.docx\n'+spec
  asyncio.run(ns['extract_tender_positions'](text))
  self.assertIn(text,router.calls[0]['user_prompt'])
  self.assertIn(spec,router.calls[0]['user_prompt'])
 def test_short_unchanged(self):self.assertEqual(ns['_complete_document_text']('ABC'),'ABC')
 def test_boundary(self):self.assertEqual(len(ns['_complete_document_text']('x'*120000)),120000)
 def test_oversize_no_request(self):
  with self.assertRaisesRegex(ValueError,'TOO_LARGE'):asyncio.run(ns['extract_tender_positions']('x'*120001))
  self.assertEqual(router.calls,[])
 def test_empty_no_request(self):
  with self.assertRaisesRegex(ValueError,'EMPTY'):asyncio.run(ns['extract_tender_positions']('  '))
  self.assertEqual(router.calls,[])
 def test_no_syntax_error(self):compile(tree,str(path),'exec')
unittest.main()
