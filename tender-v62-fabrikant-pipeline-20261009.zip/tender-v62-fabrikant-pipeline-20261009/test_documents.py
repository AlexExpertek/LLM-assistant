import unittest,tempfile
from pathlib import Path
import httpx
from app.sources.fabrikant.documents import *
PAGE=documentation_url('https://fabrikant.ru/v2/trades/procedure/view/abc')
HTML='<p>Общее количество загруженных документов: 4</p>'+''.join('<tr><td class="procedure-document-file"><span>'+name+'</span></td><td><a href="/v2/trades/procedure/documentation/download/single/abc/'+str(i)+'?tab=proc">Скачать</a></td></tr>' for i,name in enumerate(['Анкета.docx','Договор.docx','Заявка.xls','Форма ответа.xls']))
class Tests(unittest.TestCase):
 def test_metadata(self):
  docs,total=parse_documents(HTML,PAGE);self.assertEqual(total,4);self.assertEqual([x.name for x in select_bundle(docs)],['Заявка.xls'])
 def test_no_fallback_to_contract(self):
  with self.assertRaises(ValueError):select_bundle([SourceDocument(name='Договор.docx')])
 def test_identity(self):
  with self.assertRaises(ValueError):parse_documents(HTML.replace('/single/abc/','/single/other/'),PAGE)
 def test_path(self):
  with self.assertRaises(ValueError):parse_documents(HTML.replace('Заявка.xls','../Заявка.xls'),PAGE)
 def test_host(self):self.assertFalse(safe('https://fabrikant.ru.evil.org/'))
 def test_redirect_chain(self):
  def handler(r):
   if r.url.host=='fabrikant.ru':return httpx.Response(301,headers={'location':'https://www.fabrikant.ru/file'})
   if r.url.host=='www.fabrikant.ru':return httpx.Response(302,headers={'location':'https://storage.fabrikant.ru/file.xls'})
   return httpx.Response(200,content=bytes.fromhex('D0CF11E0A1B11AE1')+b'example')
  with tempfile.TemporaryDirectory() as d,httpx.Client(transport=httpx.MockTransport(handler)) as c:
   self.assertGreater(download(c,'https://fabrikant.ru/file',Path(d)/'a.xls',validate=lambda u:u),8)
 def test_html_not_saved(self):
  with tempfile.TemporaryDirectory() as d,httpx.Client(transport=httpx.MockTransport(lambda r:httpx.Response(200,text='<html>Login</html>'))) as c:
   path=Path(d)/'a.xls'
   with self.assertRaises(ValueError):download(c,'https://www.fabrikant.ru/file',path,validate=lambda u:u)
   self.assertFalse(path.exists())
 def test_external_redirect(self):
  with tempfile.TemporaryDirectory() as d,httpx.Client(transport=httpx.MockTransport(lambda r:httpx.Response(302,headers={'location':'https://evil.test/file'}))) as c:
   with self.assertRaises(ValueError):download(c,'https://www.fabrikant.ru/file',Path(d)/'a.xls',validate=lambda u:u)
unittest.main()
