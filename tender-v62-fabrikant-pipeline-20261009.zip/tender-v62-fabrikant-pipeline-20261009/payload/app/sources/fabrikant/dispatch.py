"""Canonical-source deduplication before HTTP and bounded automatic handoff."""
from datetime import datetime,timezone
from .adapter import identity,resolve
from app.sources.tektorg.backlog import deadline,process_backlog
from app.reports.review_dismissals import is_dismissed


def enqueue_candidates(items):
    import redis
    from sqlalchemy import select
    from app.core.config import settings
    from app.db.session import SyncSessionLocal
    from app.models.database import Tender
    from app.workers.completed_analysis import has_completed_analysis
    from app.workers.tasks_parsing import process_new_tender
    client=redis.Redis.from_url(settings.redis_url)
    results=[];attempts=0
    for item in items:
        number=str(item.get('external_id',''))
        row={'number':number}
        try:
            end=deadline(item)
            if end is None or end<=datetime.now(timezone.utc):
                results.append(dict(row,status='no_longer_eligible'));continue
            source,canonical=identity(item)
            row.update(canonical_source=source,canonical_number=canonical)
            if is_dismissed('fabrikant',number) or is_dismissed(source,canonical):
                results.append(dict(row,status='no_longer_eligible'));continue
            with SyncSessionLocal() as session:
                tender=session.execute(select(Tender).where(Tender.source==source,Tender.external_id==canonical)).scalar_one_or_none()
                if tender and has_completed_analysis(session,tender):
                    results.append(dict(row,status='cached'));continue
                if tender and not tender.is_active:
                    results.append(dict(row,status='no_longer_eligible'));continue
                if tender and getattr(tender.processing_status,'value',tender.processing_status) in ('analyzing','documents_pending'):
                    results.append(dict(row,status='in_progress'));continue
            if attempts>=2:
                results.append(dict(row,status='batch_limit'));continue
            key='fabrikant:pipeline:v1:'+source+':'+canonical
            if not client.set(key,'reserved',nx=True,ex=86400):
                results.append(dict(row,status='already_queued_or_attempted'));continue
            attempts+=1
            card=resolve(item)
            if card is None:
                results.append(dict(row,status='no_longer_eligible'));continue
            if card.source!=source or str(card.external_id)!=canonical:
                raise ValueError('fabrikant_resolved_identity_mismatch')
            task=process_new_tender.delay(card.model_dump(mode='json'))
            results.append(dict(row,status='queued',task_id=task.id))
        except Exception as exc:
            results.append(dict(row,status='queue_error',error_type=type(exc).__name__,
                                reason=str(exc) if isinstance(exc,ValueError) else 'processing_unavailable'))
    return results


def drain(items):
    from pathlib import Path
    from app.core.config import settings
    return process_backlog(items,path=Path(settings.storage_path)/'fabrikant_backlog.sqlite3',enqueue=enqueue_candidates)
