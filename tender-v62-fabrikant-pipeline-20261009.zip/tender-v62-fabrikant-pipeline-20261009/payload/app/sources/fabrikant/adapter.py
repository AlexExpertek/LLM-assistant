"""Fresh public listing validation and single-lot commercial documents."""
import re
import shutil
import tempfile
import time
from pathlib import Path
from datetime import datetime,timezone
from urllib.parse import urlsplit,urljoin,parse_qs
from bs4 import BeautifulSoup
import httpx
from app.sources.public_http import get_html
from app.sources.schemas import SourceTender
from app.sources.eis_freshness import eligibility
from app.marketplace_discovery.primary.fabrikant_search import parse_listing,candidate,search_url,normalized
from app.marketplace_discovery.product_screening import aluminium_evidence,subject_block_reason
from app.reports.review_dismissals import is_dismissed
from .documents import safe,CARD,documentation_url,parse_documents,select_bundle,download


def identity(item):
    url=item.get('source_url') or ''
    p=urlsplit(url)
    if (p.scheme!='https' or p.hostname not in {'fabrikant.ru','www.fabrikant.ru','44.fabrikant.ru'}
            or p.username or p.password or p.port not in (None,443)):
        raise ValueError('fabrikant_invalid_card_url')
    path=urlsplit(url).path
    match=re.fullmatch(r'/44/procedure/[a-z0-9]+/(\d{19})/?',path)
    if match:
        if item.get('registry_number') and str(item['registry_number'])!=match[1]:
            raise ValueError('fabrikant_registry_mismatch')
        return 'zakupki_gov_ru',match[1]
    if CARD.fullmatch(path) and str(item.get('external_id','')).isdigit():
        return 'fabrikant',str(item['external_id'])
    raise ValueError('fabrikant_section_adapter_required')


def fresh_listing(external_id,url,html,fetch=get_html):
    # The "Прием заявок" tab on a detail page is not proof of an open stage.
    # Re-query the observed public search with status=1 and exact procedure ID.
    p=urlsplit(url)
    if p.path.startswith('/44/procedure/'):
        query=p.path.rstrip('/').rsplit('/',1)[-1]
    else:
        text=BeautifulSoup(html,'html.parser').get_text(' ',strip=True)
        match=re.search(r'Процедурная часть\s*\(№\s*(\d+)\)',text)
        if not match:raise ValueError('fabrikant_procedure_number_missing')
        query=match[1]
    cards,total=parse_listing(fetch(search_url((),1,query),timeout=25))
    for node in cards:
        if str(node.get('data-id'))!=str(external_id):continue
        item,reason=candidate(node,now=datetime.now(timezone.utc),dismissed=is_dismissed)
        if item is None:return None
        if urlsplit(item['source_url']).path!=p.path:
            raise ValueError('fabrikant_listing_identity_mismatch')
        return item
    if total>len(cards):raise ValueError('fabrikant_identity_not_on_first_search_page')
    return None


def eis_url(html,number,base):
    soup=BeautifulSoup(html,'html.parser')
    found=set()
    for a in soup.select('a[href]'):
        url=urljoin(base,a['href']);p=urlsplit(url)
        if (p.scheme=='https' and p.hostname=='zakupki.gov.ru' and not p.username
                and not p.password and p.port in (None,443)
                and re.fullmatch(r'/epz/order/notice/[a-zA-Z0-9_-]+/view/common-info\.html',p.path)
                and parse_qs(p.query).get('regNumber')==[number]):
            found.add(url)
    if len(found)!=1:raise ValueError('fabrikant_eis_notice_url_unconfirmed')
    return found.pop()


class FabrikantAdapter:
    def fetch_by_id(self,external_id,source_url=None):
        item={'external_id':str(external_id),'source_url':source_url}
        source,number=identity(item)
        if source!='fabrikant':raise ValueError('use_eis_route_for_44')
        html=get_html(source_url,timeout=25)
        fresh=fresh_listing(external_id,source_url,html)
        if fresh is None:return None
        soup=BeautifulSoup(html,'html.parser')
        links={urlsplit(urljoin(source_url,a['href'])).path for a in soup.select('a[href]')
               if '/trades/positions/lot/view/' in a['href']}
        proc=CARD.fullmatch(urlsplit(source_url).path)[1]
        if len(links)!=1 or not next(iter(links)).startswith('/v2/trades/positions/lot/view/'+proc+'/'):
            raise ValueError('fabrikant_single_lot_not_confirmed')
        page=documentation_url(source_url)
        docs,total=parse_documents(get_html(page,timeout=25),page)
        if total is None or total!=len(docs):
            raise ValueError('fabrikant_document_list_incomplete')
        selected=select_bundle(docs)
        return SourceTender(source='fabrikant',external_id=str(external_id),title=fresh['title'],
            source_url=source_url,submission_deadline=fresh['submission_deadline'],
            customer_name=fresh.get('customer'),documents=selected,
            raw_payload={'stage':'detail','procurement_status':'Прием заявок',
                'discovered_by':'fabrikant','suppress_notifications':True,
                'procedure_id':proc,'documents_total':total,'positions_page':next(iter(links))})


def resolve(item):
    source,number=identity(item)
    if is_dismissed('fabrikant',str(item['external_id'])) or is_dismissed(source,number):return None
    if source=='fabrikant':
        return FabrikantAdapter().fetch_by_id(number,source_url=item['source_url'])
    html=get_html(item['source_url'],timeout=25)
    if fresh_listing(item['external_id'],item['source_url'],html) is None:return None
    from app.sources.registry import get_adapter
    card=get_adapter('zakupki_gov_ru').fetch_by_id(number,source_url=eis_url(html,number,item['source_url']))
    if card is None:return None
    if card.source!=source or str(card.external_id)!=number:raise ValueError('fabrikant_eis_identity_mismatch')
    if eligibility(card.source,card.submission_deadline,card.raw_payload) is not None:return None
    if subject_block_reason(card.title) or not aluminium_evidence(card.title):return None
    card.raw_payload=dict(card.raw_payload or {},discovered_by='fabrikant',
                          fabrikant_external_id=str(item['external_id']),suppress_notifications=True)
    return card


def materialize(tender):
    from app.core.config import settings
    fresh=FabrikantAdapter().fetch_by_id(tender.external_id,source_url=tender.source_url)
    if fresh is None:raise ValueError('fabrikant_no_longer_eligible')
    root=Path(settings.storage_path)/'fabrikant_prepared';root.mkdir(parents=True,exist_ok=True)
    directory=Path(tempfile.mkdtemp(prefix=str(tender.external_id)+'-',dir=root))
    result=[]
    try:
        with httpx.Client(timeout=30,follow_redirects=False,trust_env=False) as client:
            for i,doc in enumerate(fresh.documents):
                if i:time.sleep(1.2)
                target=directory/(str(i+1)+'_'+doc.name)
                download(client,doc.url,target)
                result.append(doc.model_copy(update={'name':target.name,'download_type':'local_file','local_path':str(target)}))
    except Exception:
        shutil.rmtree(directory,ignore_errors=True)
        raise
    return result
