from app.sources.zakupki_gov_public.adapter import ZakupkiGovPublicAdapter
from app.sources.tender_pro.adapter import TenderProAdapter
from app.sources.kontur_zakupki.adapter import KonturZakupkiAdapter

from app.sources.tektorg.adapter import TektorgAdapter

from app.sources.fabrikant.adapter import FabrikantAdapter

SOURCE_REGISTRY = {
    "fabrikant": FabrikantAdapter(),
    "tektorg": TektorgAdapter(),
    "zakupki_gov_ru": ZakupkiGovPublicAdapter(),
    "tender_pro": TenderProAdapter(),
    "kontur_zakupki": KonturZakupkiAdapter(),
}


def get_adapter(source_key: str):
    return SOURCE_REGISTRY.get(source_key)
