import json,sqlite3
from pathlib import Path
from app.core.config import settings
from app.workers.celery_app import celery_app
from app.marketplace_discovery.primary.collector import folder
for name, entry in celery_app.conf.beat_schedule.items():
    if 'fabrikant' in str(entry.get('args',())):
        print('SCHEDULE:',name,str(entry.get('schedule')),'TASK:',entry.get('task'),'ARGS:',entry.get('args'))
report=folder()/'fabrikant.json'
if report.exists():
    data=json.loads(report.read_text())
    print(json.dumps({k:data.get(k) for k in ('checked_at','status','pipeline_status','pipeline','backlog_pending','errors')},ensure_ascii=False,indent=2))
else:print('REPORT: no scheduled report yet')
path=Path(settings.storage_path)/'fabrikant_backlog.sqlite3'
if path.exists():
    with sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True) as db:
        print('PENDING:',db.execute('SELECT count(*) FROM pending').fetchone()[0])
else:print('PENDING: created on first scheduled run')
print('READ_ONLY: no HTTP, tasks, DB changes, OCR, LLM or notifications')
