#!/usr/bin/env bash
set -Eeuo pipefail
pkg_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "${TENDER_PROJECT_DIR:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
docker compose exec -T celery_worker python - <<'CHECK'
from app.ocr.legacy_excel import extract_xls
from app.sources.tektorg.backlog import process_backlog
from app.workers.tasks_scoring import analyze_tender
import inspect
assert 'suppress_notifications' in inspect.signature(analyze_tender.run).parameters
print('PIPELINE_DEPENDENCIES_OK')
CHECK
python3 "$pkg_dir/apply.py" --project "$PWD"
docker compose build app celery_worker celery_discovery
for test in test_search.py test_documents.py test_pipeline.py; do
  docker compose run --rm --no-deps -T -e PYTHONPATH=/app celery_discovery python - < "$pkg_dir/$test"
done
docker compose run --rm --no-deps -T -e PYTHONPATH=/app celery_discovery python - <<'CHECK'
from app.sources.registry import get_adapter
from app.sources.document_preparer import prepare_tender_documents
from app.workers.tasks_ocr import process_tender_documents
from app.workers.tasks_primary_discovery import collect_primary
assert get_adapter('fabrikant') is not None
assert get_adapter('tektorg') is not None
assert get_adapter('zakupki_gov_ru') is not None
print('PIPELINE_IMPORTS_OK')
CHECK
docker compose up -d --no-deps --timeout 60 app celery_worker celery_discovery
printf '\nFABRIKANT_PIPELINE_UPDATE_INSTALLED\nExisting schedule retained. Up to two new cards per run. No immediate collection or notifications.\n'
