import unittest,tempfile,sys,types
# Isolate tests from real engines, brokers and worker imports.
from unittest.mock import MagicMock
for name,attrs in {
 "app.db.session": ["SyncSessionLocal"],
 "app.workers.completed_analysis": ["has_completed_analysis"],
 "app.workers.tasks_parsing": ["process_new_tender"],
 "app.sources.registry": ["get_adapter"],
}.items():
 module=types.ModuleType(name)
 for attr in attrs:setattr(module,attr,MagicMock())
 sys.modules[name]=module
from pathlib import Path
from datetime import datetime,timedelta,timezone
from unittest.mock import patch,MagicMock
from app.sources.fabrikant import adapter as a
from app.sources.fabrikant import dispatch as d
from app.sources.eis_freshness import eligibility
from app.sources.schemas import SourceTender
from app.marketplace_discovery.primary.fabrikant_search import collect_fabrikant

NUMBER='0816500000626015213'
ITEM={'external_id':'679708758','registry_number':NUMBER,'source_url':'https://44.fabrikant.ru/44/procedure/ea21/'+NUMBER,'submission_deadline':(datetime.now(timezone.utc)+timedelta(days=3)).isoformat(),'title':'Лист алюминиевый'}
COMM=dict(ITEM,external_id='100',registry_number=None,source_url='https://fabrikant.ru/v2/trades/procedure/view/abc')
class Tests(unittest.TestCase):
 def test_eis_identity(self):self.assertEqual(a.identity(ITEM),('zakupki_gov_ru',NUMBER))
 def test_identity_mismatch(self):
  with self.assertRaises(ValueError):a.identity(dict(ITEM,registry_number='0'))
 def test_commercial_identity(self):self.assertEqual(a.identity(COMM),('fabrikant','100'))
 def test_eis_link(self):
  url='https://zakupki.gov.ru/epz/order/notice/ea20/view/common-info.html?regNumber='+NUMBER
  self.assertEqual(a.eis_url('<a href="'+url+'">ЕИС</a>',NUMBER,ITEM['source_url']),url)
 def test_wrong_eis_number(self):
  with self.assertRaises(ValueError):a.eis_url('<a href="https://zakupki.gov.ru/epz/order/notice/ea20/view/common-info.html?regNumber=0">ЕИС</a>',NUMBER,ITEM['source_url'])
 def test_freshness(self):
  self.assertEqual(eligibility('fabrikant',COMM['submission_deadline'],{}),'closed_stage')
  self.assertIsNone(eligibility('fabrikant',COMM['submission_deadline'],{'procurement_status':'Прием заявок'}))
  self.assertEqual(eligibility('fabrikant','2000-01-01',{'procurement_status':'Прием заявок'}),'deadline_expired')
 def test_completed_before_http(self):
  with patch('app.db.session.SyncSessionLocal') as session,patch('app.workers.completed_analysis.has_completed_analysis',return_value=True),patch.object(d,'resolve') as resolve,patch.object(d,'is_dismissed',return_value=False),patch('redis.Redis.from_url'):
   result=d.enqueue_candidates([ITEM]);self.assertEqual(result[0]['status'],'cached');resolve.assert_not_called()
 def test_dismissed_before_http(self):
  with patch.object(d,'is_dismissed',return_value=True),patch.object(d,'resolve') as resolve,patch('redis.Redis.from_url'):
   self.assertEqual(d.enqueue_candidates([COMM])[0]['status'],'no_longer_eligible');resolve.assert_not_called()
 def test_batch_limit(self):
  card=SourceTender(source='fabrikant',external_id='100',title='Лист алюминиевый')
  with patch('app.db.session.SyncSessionLocal') as s,patch.object(d,'is_dismissed',return_value=False),patch('redis.Redis.from_url') as redis,patch.object(d,'resolve',side_effect=lambda item: SourceTender(source='fabrikant',external_id=item['external_id'],title='Лист алюминиевый')) as resolve,patch('app.workers.tasks_parsing.process_new_tender.delay') as queue:
   s.return_value.__enter__.return_value.execute.return_value.scalar_one_or_none.return_value=None
   redis.return_value.set.return_value=True
   result=d.enqueue_candidates([dict(COMM,external_id=str(i)) for i in range(3)])
   self.assertEqual([r['status'] for r in result],['queued','queued','batch_limit']);self.assertEqual(queue.call_count,2)
 def test_non_target_control_not_admitted(self):
  html='<div>Процедурная часть (№5584497)</div>'
  node=MagicMock();node.get.return_value='100'
  with patch.object(a,'parse_listing',return_value=([node],1)),patch.object(a,'candidate',return_value=(None,'product_unconfirmed_in_listing')):
   self.assertIsNone(a.fresh_listing('100',COMM['source_url'],html,fetch=lambda *args,**kw:''))
 def test_multi_lot_stops_before_documents(self):
  html='<a href="/v2/trades/positions/lot/view/abc/1">1</a><a href="/v2/trades/positions/lot/view/abc/2">2</a>'
  with patch.object(a,'get_html',return_value=html),patch.object(a,'fresh_listing',return_value=COMM):
   with self.assertRaisesRegex(ValueError,'single_lot'):a.FabrikantAdapter().fetch_by_id('100',COMM['source_url'])
 def test_44_route_marks_notification_suppression(self):
  card=SourceTender(source='zakupki_gov_ru',external_id=NUMBER,title='Лист алюминиевый',submission_deadline=COMM['submission_deadline'],raw_payload={'stage':'detail','procurement_status':'Подача заявок'})
  with patch.object(a,'get_html',return_value='html'),patch.object(a,'fresh_listing',return_value=ITEM),patch.object(a,'eis_url',return_value='https://zakupki.gov.ru/notice'),patch.object(a,'is_dismissed',return_value=False),patch('app.sources.registry.get_adapter') as adapter:
   adapter.return_value.fetch_by_id.return_value=card
   result=a.resolve(ITEM);self.assertEqual(result.source,'zakupki_gov_ru');self.assertTrue(result.raw_payload['suppress_notifications'])
 def test_schedule_persists_drained_queue(self):
  with tempfile.TemporaryDirectory() as tmp,patch('app.marketplace_discovery.primary.collector.folder',return_value=Path(tmp)),patch('app.sources.fabrikant.dispatch.drain',return_value={'outcomes':[],'pending':0}) as drain:
   report=collect_fabrikant(persist=True,fetch=lambda *args,**kw:'<p>Всего: 0</p>',pause=lambda n:None)
   drain.assert_called_once();self.assertTrue((Path(tmp)/'fabrikant.json').exists());self.assertEqual(report['pipeline_status'],'automatic_bounded_handoff')
 def test_commercial_document_bundle(self):
  from app.sources.schemas import SourceDocument
  doc=SourceDocument(name='Заявка.xls',url='https://www.fabrikant.ru/file')
  html='<a href="/v2/trades/positions/lot/view/abc/lot1">Позиции</a>'
  with patch.object(a,'get_html',return_value=html),patch.object(a,'fresh_listing',return_value=COMM),patch.object(a,'parse_documents',return_value=([doc],1)):
   card=a.FabrikantAdapter().fetch_by_id('100',COMM['source_url'])
   self.assertEqual(card.documents,[doc]);self.assertTrue(card.raw_payload['suppress_notifications'])
   self.assertEqual(card.raw_payload['positions_page'],'/v2/trades/positions/lot/view/abc/lot1')
 def test_download_failure_removes_temporary_files(self):
  from app.core.config import settings
  from app.sources.schemas import SourceDocument
  card=SourceTender(source='fabrikant',external_id='100',title='Лист алюминиевый',documents=[SourceDocument(name='Заявка.xls',url='https://www.fabrikant.ru/file')])
  with tempfile.TemporaryDirectory() as tmp,patch.object(settings,'storage_path',tmp),patch.object(a.FabrikantAdapter,'fetch_by_id',return_value=card),patch.object(a,'download',side_effect=ValueError('download_failed')):
   with self.assertRaisesRegex(ValueError,'download_failed'):a.materialize(card)
   self.assertEqual(list((Path(tmp)/'fabrikant_prepared').iterdir()),[])
 def test_reject_foreign_host(self):
  with self.assertRaises(ValueError):a.identity(dict(COMM,source_url='https://evil.example/v2/trades/procedure/view/abc'))
unittest.main()
