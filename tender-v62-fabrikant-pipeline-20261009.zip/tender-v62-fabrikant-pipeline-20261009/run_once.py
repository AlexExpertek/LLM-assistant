import json
from app.marketplace_discovery.primary.fabrikant_search import collect_fabrikant
report=collect_fabrikant(persist=True)
print(json.dumps({k:report.get(k) for k in ('source','checked_at','status','pipeline_status','pipeline','backlog_pending','errors')},ensure_ascii=False,indent=2,default=str))
