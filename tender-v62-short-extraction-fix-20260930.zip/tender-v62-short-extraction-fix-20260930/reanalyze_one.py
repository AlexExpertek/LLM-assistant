from sqlalchemy import select
from app.core.config import settings
from app.db.session import SyncSessionLocal
from app.models.database import Tender, Document, ProcessingStatus, OCRStatus
from app.sources.eis_freshness import eligibility
from app.workers.tasks_scoring import analyze_tender
from app.llm.extraction import _document_chunks
if settings.notifications_enabled:raise SystemExit('Notifications enabled; stopped')
tid='062a51eb-89ee-4063-8e7f-fc2948cf8737'
with SyncSessionLocal() as s:
 t=s.execute(select(Tender).where(Tender.id==tid).with_for_update()).scalar_one()
 if t.processing_status!=ProcessingStatus.FAILED:raise SystemExit('Expected failed; no changes')
 reason=eligibility(t.source,t.submission_deadline,t.raw_payload,t.is_active)
 if reason:raise SystemExit(reason)
 docs=s.execute(select(Document).where(Document.tender_id==t.id).order_by(Document.id)).scalars().all()
 if not docs or any(d.ocr_status not in (OCRStatus.DONE,OCRStatus.NOT_REQUIRED) or not (d.extracted_text or '').strip() for d in docs):raise SystemExit('Documents incomplete')
 text='\n\n'.join('### DOCUMENT: '+d.filename+'\n'+d.extracted_text for d in docs)
 ids=[str(d.id) for d in docs]
 print('DOCUMENT_CHARACTERS:',len(text))
 t.processing_status=ProcessingStatus.DOCUMENTS_READY;s.commit()
print('ANALYSIS_TASK_ID:',analyze_tender.delay(tid,text,ids).id)
