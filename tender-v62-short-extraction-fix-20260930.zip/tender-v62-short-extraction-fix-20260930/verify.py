import asyncio,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch,AsyncMock
from app.llm import extraction as m
from app.core import config
TEXT='Поставка профиля\n\n### DOCUMENT: ООЗ.docx\n1 | Профиль алюминиевый с противоскользящей вставкой | 80.0000 | пог. м'
def result(q='80'):
 return m.TenderMultiExtractionResult.model_validate({'positions':[{'product_name':{'value':'Профиль алюминиевый с противоскользящей вставкой'},'quantity':{'value':q},'unit':{'value':'пог. м'}}]})
class Checks(unittest.TestCase):
 def test_short_one(self):self.assertEqual(m._document_chunks(TEXT),[TEXT])
 def test_long_lossless(self):
  t=TEXT+'\n'+('А'*50000);c=m._document_chunks(t);self.assertEqual(''.join(c),t);self.assertTrue(all(len(x)<=24000 for x in c))
 def test_scalar(self):self.assertEqual(m.ExtractedField(value=3000).value,'3000')
 def test_conflict_preserved(self):
  with self.assertRaisesRegex(ValueError,'POSITION_CONFLICT'):m._merge_extractions([result(),result('90')])
 def test_no_sum(self):self.assertEqual(len(m._merge_extractions([result(),result()]).positions),1)
 def test_one_call_and_snapshot(self):
  with tempfile.TemporaryDirectory() as d, patch.object(config,'settings',SimpleNamespace(storage_path=d)),patch.object(m,'_extract_positions_chunk',new_callable=AsyncMock,return_value=result()) as call:
   r=asyncio.run(m.extract_tender_positions(TEXT));self.assertEqual(call.await_count,1)
   self.assertEqual(r.positions[0].quantity.value,'80');self.assertIsNone(r.positions[0].alloy.value)
   data=json.loads(next(Path(d).rglob('responses.json')).read_text());self.assertEqual(data['state'],'completed');self.assertEqual(len(data['responses']),1)
 def test_conflict_snapshot(self):
  with tempfile.TemporaryDirectory() as d,patch.object(config,'settings',SimpleNamespace(storage_path=d)),patch.object(m,'_extract_positions_chunk',new_callable=AsyncMock,side_effect=[result(),result('90')]),patch.object(m,'_document_chunks',return_value=[TEXT,TEXT]):
   with self.assertRaisesRegex(ValueError,'POSITION_CONFLICT'):asyncio.run(m.extract_tender_positions(TEXT))
   data=json.loads(next(Path(d).rglob('responses.json')).read_text());self.assertEqual(data['state'],'failed');self.assertEqual(len(data['responses']),2)
unittest.main()
