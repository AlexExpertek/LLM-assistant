Short extraction fix 20260930
Requires exact extraction.py SHA 10c1a6d3d334cde3570cb78f60b4ff06e7a84e08365751b40d86533097f3cf0b.
Short entire input <=24000 chars uses one request. Longer input remains lossless and document-aware.
Each validated LLM response is saved before normalization/merge under storage/extraction_snapshots/<input hash>-<unique run>/responses.json, including failure state and chunk hashes. Atomic file replacement. Does not store API credentials. No automatic cache reuse or retention cleanup in this release.
Strict merge unchanged; no implicit quantity summation or enrichment across ambiguous position identities. Previous paid responses were not saved and cannot be recovered by this patch.
7 local tests using actual extraction module, fake router/config, mocked LLM responses. No live LLM calls during tests. Server repeats tests before restart. Does not guarantee live model output.
Installer backups code, checks hashes and rebuilds/restarts app/main/discovery. No data migration.
reanalyze_one.py runs ONE known failed 44-FZ tender, requires notifications disabled and complete saved documents, changes state to documents_ready then queues paid analysis. If enqueue fails after commit, do not blindly rerun; inspect queue/status.
Expected source facts: one profile with anti-slip insert; 80 linear metres. Alloy/dimensions/mass not specified. Do not infer them from quantity.
