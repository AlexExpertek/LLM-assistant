"""Preview or enqueue one failed DOC tender using already saved local files."""
import argparse
import json
from pathlib import Path
import sys
from uuid import UUID
sys.path.insert(0,'/app')
from sqlalchemy import select
from app.core.config import settings
from app.db.session import SyncSessionLocal
from app.models.database import Tender, Document, TenderStatus, ProcessingStatus
from app.workers.tasks_ocr import process_tender_documents, SUPPORTED

parser=argparse.ArgumentParser()
parser.add_argument('tender_id',type=UUID)
parser.add_argument('--enqueue',action='store_true')
args=parser.parse_args()
root=Path(settings.storage_path).resolve()
with SyncSessionLocal() as session:
    tender=session.get(Tender,args.tender_id)
    if tender is None:raise SystemExit('Tender not found')
    if tender.status != TenderStatus.MANUAL_REVIEW or tender.processing_status != ProcessingStatus.FAILED:
        raise SystemExit('Tender is not in manual_review/failed; no task sent')
    rows=session.execute(select(Document).where(Document.tender_id==args.tender_id)).scalars().all()
    documents=[];names=set();has_doc=False
    for row in rows:
        filename=Path(row.filename).name
        if filename in names:raise SystemExit('Duplicate document filenames; manual inspection required')
        names.add(filename)
        path=(Path(row.storage_uri) if row.storage_uri else root/'tenders'/str(args.tender_id)/filename).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise SystemExit('Saved local document unavailable: '+filename)
        if path.suffix.lower() not in SUPPORTED:
            raise SystemExit('Another unsupported document remains: '+filename)
        has_doc |= path.suffix.lower()=='.doc'
        documents.append({'name':filename,'external_id':row.external_id,'url':row.source_url,
                          'download_type':'local_file','local_path':str(path)})
    if not has_doc:raise SystemExit('No DOC files found; no task sent')
    print(json.dumps({'tender_id':str(args.tender_id),'title':tender.title,
                      'documents':[d['name'] for d in documents]},ensure_ascii=False,indent=2))
if args.enqueue:
    # The source files already live in storage/tenders/<id>, so stage separate copies.
    # _materialize copies files into that folder and must not copy a file to itself.
    import shutil
    import tempfile
    staging_root=root/'doc_reprocess'
    staging_root.mkdir(parents=True,exist_ok=True)
    staging=Path(tempfile.mkdtemp(prefix=str(args.tender_id)+'-',dir=staging_root))
    for doc in documents:
        destination=staging/doc['name']
        shutil.copy2(doc['local_path'],destination)
        doc['local_path']=str(destination)
    job=process_tender_documents.apply_async(args=[str(args.tender_id),documents],queue='celery')
    print('DOC_REPROCESS_TASK:',job.id)
else:
    print('PREVIEW_ONLY: no task sent. Add --enqueue to process this tender.')
