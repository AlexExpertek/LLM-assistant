"""DOC checks. --real additionally requires the installed LibreOffice binary."""
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock
import subprocess

sys.path.insert(0,os.environ.get('OCR_PROJECT','/app'))
for key,value in {
 'DATABASE_URL':'postgresql+asyncpg://test:test@127.0.0.1:1/test',
 'DATABASE_URL_SYNC':'postgresql+psycopg2://test:test@127.0.0.1:1/test',
 'REDIS_URL':'redis://127.0.0.1:1/0','QDRANT_URL':'http://127.0.0.1:1',
 'CELERY_BROKER_URL':'memory://','CELERY_RESULT_BACKEND':'cache+memory://',
}.items():os.environ[key]=value
from app.ocr import legacy_word as converter
from app.ocr.pipeline import extract_document
from app.workers.tasks_ocr import SUPPORTED
from docx import Document

REAL='--real' in sys.argv
if REAL:sys.argv.remove('--real')

def make_fixture(path):
    doc=Document();doc.add_paragraph('Поставка прутка Д16Т')
    table=doc.add_table(rows=2,cols=3)
    for row,values in zip(table.rows,[['Продукция','Количество','Единица'],['Пруток Д16Т','600','кг']]):
        for cell,value in zip(row.cells,values):cell.text=value
    doc.save(path)

class Checks(unittest.TestCase):
    def test_original_preserved_and_cyrillic_name(self):
        with tempfile.TemporaryDirectory() as d:
            source=Path(d)/'Извещение Д16Т.DOC';source.write_bytes(b'original')
            def fake(src,out,profile,fmt):
                self.assertEqual(src.read_bytes(),b'original')
                out.mkdir();make_fixture(out/'source.docx')
            with patch.object(converter,'run_office',side_effect=fake):
                result=extract_document(str(source))
            self.assertIn('Д16Т',result.full_text);self.assertIn('600 | кг',result.full_text)
            self.assertEqual(source.read_bytes(),b'original')
            self.assertIn('.doc',SUPPORTED)

    def test_missing_output_is_failure(self):
        with tempfile.TemporaryDirectory() as d:
            source=Path(d)/'x.doc';source.write_bytes(b'x')
            with patch.object(converter,'run_office'):
                with self.assertRaises(ValueError):
                    with converter.converted_docx(source):pass

    def test_invalid_docx_is_failure(self):
        with tempfile.TemporaryDirectory() as d:
            source=Path(d)/'x.doc';source.write_bytes(b'x')
            def fake(src,out,profile,fmt):out.mkdir();(out/'source.docx').write_bytes(b'not a zip')
            with patch.object(converter,'run_office',side_effect=fake):
                with self.assertRaises(ValueError):
                    with converter.converted_docx(source):pass

    def test_missing_converter_is_failure(self):
        with patch.object(converter.shutil,'which',return_value=None):
            with self.assertRaises(RuntimeError):converter.run_office(Path('x'),Path('out'),Path('profile'),'docx')

    def test_timeout_kills_process_group(self):
        process=MagicMock();process.pid=12345
        process.wait.side_effect=[subprocess.TimeoutExpired('office',90),-9]
        with tempfile.TemporaryDirectory() as d, patch.object(converter.shutil,'which',return_value='/usr/bin/libreoffice'), patch.object(converter.subprocess,'Popen',return_value=process) as spawn, patch.object(converter.os,'killpg') as kill:
            root=Path(d)
            with self.assertRaises(RuntimeError):converter.run_office(root/'x.doc',root/'out',root/'profile','docx')
            kill.assert_called_once();self.assertTrue(spawn.call_args.kwargs['start_new_session'])
            self.assertEqual(process.wait.call_args_list[0].kwargs,{'timeout':90})

    @unittest.skipUnless(REAL,'real conversion runs in the server image before restart')
    def test_real_binary_doc_text_and_table(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);source=root/'fixture.docx';make_fixture(source)
            converter.run_office(source,root/'binary',root/'export-profile','doc:MS Word 97')
            binary=root/'binary/fixture.doc'
            self.assertEqual(binary.read_bytes()[:8],bytes.fromhex('D0CF11E0A1B11AE1'))
            before=binary.read_bytes()
            result=extract_document(str(binary))
            self.assertIn('Д16Т',result.full_text)
            self.assertIn('600 | кг',result.full_text)
            self.assertEqual(binary.read_bytes(),before)
            print('REAL_DOC_CONVERSION_OK: binary DOC, Cyrillic text and table preserved')

if __name__=='__main__':unittest.main(verbosity=1)
