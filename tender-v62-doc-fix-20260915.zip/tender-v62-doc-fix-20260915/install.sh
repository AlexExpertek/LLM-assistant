#!/usr/bin/env bash
set -Eeuo pipefail
PACKAGE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="${1:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
cd "$PROJECT_DIR"
python3 "$PACKAGE_DIR/apply.py" "$PROJECT_DIR"
docker compose config --quiet
docker compose build app celery_worker
docker compose run --rm --no-deps -T celery_worker python - < "$PACKAGE_DIR/verify_ocr.py"
docker compose run --rm --no-deps -T celery_worker python - --real < "$PACKAGE_DIR/verify_doc.py"
echo 'Real DOC conversion verified. Updating main worker and app.'
docker compose up -d --no-deps --timeout 60 celery_worker app
docker compose exec -T celery_worker python - <<'PY'
import socket
import time
import shutil
from app.workers.celery_app import celery_app
from app.workers.tasks_ocr import SUPPORTED
assert '.doc' in SUPPORTED
assert shutil.which('libreoffice') or shutil.which('soffice')
node='celery@'+socket.gethostname()
for attempt in range(10):
    if any(reply.get(node,{}).get('ok')=='pong' for reply in celery_app.control.ping(destination=[node],timeout=5)):
        print('DOC_WORKER_READY:',node)
        break
    time.sleep(2)
else:raise SystemExit('Main worker did not reply; inspect logs')
PY
docker compose ps -a
echo 'DOC_UPDATE_INSTALLED. Existing review items were not automatically resubmitted.'
