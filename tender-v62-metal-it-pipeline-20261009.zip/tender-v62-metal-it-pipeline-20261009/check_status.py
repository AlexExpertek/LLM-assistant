from pathlib import Path
import json
from app.workers.celery_app import celery_app
from app.marketplace_discovery.primary.collector import folder
for name, spec in celery_app.conf.beat_schedule.items():
    if 'metal' in name or 'metal_it' in str(spec.get('args',())):
        print('SCHEDULE:', name, str(spec.get('schedule')), 'TASK:', spec.get('task'), 'ARGS:', spec.get('args'))
p=folder()/'metal_it.json'
if p.exists():
    d=json.loads(p.read_text())
    print(json.dumps({k:v for k,v in d.items() if k!='items'},ensure_ascii=False,indent=2))
    print('ITEMS:',len(d.get('items') or []))
else: print('REPORT: not created yet')
print('READ_ONLY: no HTTP, tasks, DB changes or LLM')

import sqlite3
from app.core.config import settings
path=Path(settings.storage_path)/'metal_it_backlog.sqlite3'
if path.exists():
    with sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True) as db:
        print('BACKLOG_PENDING:',db.execute('SELECT count(*) FROM pending').fetchone()[0])
else: print('BACKLOG: created on first scheduled run')
