"""Read-only transport and document probe. Never enqueue this non-target card."""
import argparse,json,tempfile
from pathlib import Path
import httpx
from app.marketplace_discovery.primary.metal_it_search import collect_metal_it
from app.sources.metal_it.adapter import request,DETAIL
from app.sources.metal_it.documents import references,download,unpack
from app.ocr.pipeline import extract_document
from app.models.database import OCRStatus
parser=argparse.ArgumentParser();parser.add_argument('--documents',action='store_true');args=parser.parse_args()
r=collect_metal_it(persist=False)
print(json.dumps({k:v for k,v in r.items() if k!='items'},ensure_ascii=False,indent=2))
if r.get('errors'):raise SystemExit('SEARCH_ERRORS: pipeline transport requires correction')
# Known public card for verifying the expanded query, not a candidate for admission.
t=request('getTradeInfo',DETAIL,{'id':627888177}).get('trade')
if not t or str(t.get('id'))!='627888177':raise SystemExit('PROBE_CARD_UNAVAILABLE')
docs=references(t)
print('DETAIL_QUERY_OK; PUBLIC_DOCUMENTS:',len(docs))
if args.documents:
 with tempfile.TemporaryDirectory(prefix='metal-it-check-') as tmp:
  counter=total=0
  with httpx.Client(timeout=30,follow_redirects=False,trust_env=False) as client:
   for doc in docs:
    local,counter,total=unpack(download(client,doc.url),doc,Path(tmp),counter,total)
    for f in local:
     result=extract_document(f.local_path)
     print(json.dumps({'file':f.name,'text_characters':len(result.full_text or ''),'status':str(result.status)},ensure_ascii=False))
     if result.status not in (OCRStatus.DONE,OCRStatus.NOT_REQUIRED) or not (result.full_text or '').strip():
      raise SystemExit('DOCUMENT_EXTRACTION_INCOMPLETE')
 print('Temporary probe files deleted.')
print('CHECK_OK: no DB writes, queues, LLM or notifications; report not saved')
