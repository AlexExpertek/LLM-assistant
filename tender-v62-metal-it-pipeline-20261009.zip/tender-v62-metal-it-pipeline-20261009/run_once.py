# Explicit collection: persists backlog/report and queues up to two eligible cards.
import json
from app.marketplace_discovery.primary.metal_it_search import collect_metal_it
r=collect_metal_it(persist=True)
print(json.dumps({k:v for k,v in r.items() if k!='items'},ensure_ascii=False,indent=2,default=str))
print('ITEMS:',len(r.get('items') or []))
