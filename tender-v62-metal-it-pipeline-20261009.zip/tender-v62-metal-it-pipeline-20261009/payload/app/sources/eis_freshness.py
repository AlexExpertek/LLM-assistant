"""Conservative eligibility gate for automatic EIS processing, no network calls."""
from datetime import datetime, timezone

CLOSED = {'работа комиссии', 'закупка завершена', 'закупка отменена',
          'определение поставщика завершено'}

def eligibility(source, deadline=None, raw=None, active=True, now=None):
    if source in ('tektorg', 'fabrikant', 'metal_it'):
        stage = str((raw or {}).get('procurement_status') or '').strip().lower().replace('ё', 'е')
        if stage != 'прием заявок':
            return 'closed_stage'
    if source not in ('zakupki_gov_ru', 'b2b_center', 'tender_pro', 'tektorg', 'fabrikant', 'metal_it'):
        return None
    if active is False:
        return 'inactive'
    raw = raw if isinstance(raw, dict) else {}
    search = raw.get('search_item') or {}
    status = str(raw.get('procurement_status') or search.get('status') or '').strip().lower()
    if status in CLOSED:
        return 'closed_stage'
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    dt = None
    try:
        if deadline is not None:
            dt = deadline if isinstance(deadline, datetime) else datetime.fromisoformat(str(deadline).replace('Z', '+00:00'))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        pass
    if source == 'zakupki_gov_ru' and raw.get('stage') == 'search':
        # Search has a calendar date, not a reliable time. RF+CIS may be
        # ahead of Moscow: only reject a date once it is past even at UTC-12.
        from datetime import timedelta
        if dt and dt.date() < now.astimezone(timezone(timedelta(hours=-12))).date():
            return 'deadline_expired'
        if status != 'подача заявок':
            return 'freshness_unknown'
        return 'needs_detail'
    if dt is None:
        return 'freshness_unknown'
    if dt <= now:
        return 'deadline_expired'
    return None

def gate_saved_tender(session, tender_id):
    from app.models.database import Tender, TenderStatus
    tender = session.get(Tender, tender_id)
    if tender is None:
        return {'status': 'skipped', 'reason': 'tender_not_found', 'tender_id': str(tender_id)}
    from app.reports.review_dismissals import is_dismissed
    if is_dismissed(tender.source, tender.external_id):
        return {'status':'skipped','reason':'manually_dismissed','tender_id':str(tender_id)}
    if tender.source == 'b2b_center':
        deadline = tender.submission_deadline
        if not tender.is_active:
            return {'status':'skipped','reason':'inactive','tender_id':str(tender_id)}
        if deadline is None or (deadline.replace(tzinfo=timezone.utc) if deadline.tzinfo is None else deadline) <= datetime.now(timezone.utc):
            return {'status':'skipped','reason':'deadline_unknown_or_expired','tender_id':str(tender_id)}
    reason = eligibility(tender.source, tender.submission_deadline, tender.raw_payload, tender.is_active)
    if reason is None:
        return None
    if reason in ('inactive', 'closed_stage', 'deadline_expired'):
        tender.is_active = False
    session.commit()
    return {'status': 'skipped', 'reason': reason, 'tender_id': str(tender_id)}
