"""Fresh GraphQL card -> shared document/LLM pipeline."""
import json
import re
import shutil
import tempfile
import time
from datetime import datetime,timezone
from pathlib import Path
from urllib.parse import urlsplit
import httpx
from app.sources.schemas import SourceTender,SourceDocument
from app.marketplace_discovery.primary.metal_it_search import request,parse_trade
from app.reports.review_dismissals import is_dismissed
from .documents import references,download,unpack,TRADE_FIELDS,LOT_FIELDS

DETAIL = 'query getTradeInfo($id: Long) { trade(id:$id) {\n id title registeredNumber published request processStatus bidSubmissionEndDate\n status {code} organizer {title} customer {title} procurementMethod {title}\n deliveryDate deliveryPeriod participationNotes bidValidityRules qualificationRequirements\n participationConditionsString notes requireRnpAbsence signatureRequired\n commonLotData {textPaymentTerms multipleWinnersAllowed}\n lots { id number title processStatus goodsDescription goodsRequirements executionPeriod\n allowPartialBids allowAnalogueInBid initialContractPrice\n purchaseItems {id number title productTitle quantity unit {code title} characteristics canceled}\ntechnicalSpecificationAttachments {id name href}\ncontractDraftAttachments {id name href}\notherAttachments {id name href}\nimageAttachments {id name href}\nmainMaterialsAttachments {id name href}\nworkScheduleAttachments {id name href}\ncashFlowTimeLineAttachments {id name href}\nprojectDocumentationAttachments {id name href}\n}\ntechnicalSpecificationAttachments {id name href}\ncontractDraftAttachments {id name href}\notherAttachments {id name href}\npurchaseDocumentationAttachments {id name href}\npurchaseDocumentationTemplateAttachments {id name href}\ncontractRequirementsAttachments {id name href}\ntenderOfferFormAttachments {id name href}\nprojectDocumentationAttachments {id name href}\nqualificationDocumentationAttachments {id name href}\nspecificationDetailingAttachments {id name href}\nextraAttachments {id name href}\n}}'

def identity(item):
    p=urlsplit(item.get('source_url') or '')
    m=re.fullmatch(r'/trades/(\d+)/info/?',p.path)
    if (p.scheme!='https' or p.hostname!='etp.metal-it.ru' or p.username or p.password
            or p.port not in (None,443) or not m or m[1]!=str(item.get('external_id'))):
        raise ValueError('metal_it_card_identity_mismatch')
    return 'metal_it',m[1]

def build_card(trade,external_id,source_url,now=None):
    identity(dict(external_id=external_id,source_url=source_url))
    if not isinstance(trade,dict) or str(trade.get('id'))!=str(external_id):
        raise ValueError('metal_it_response_identity_mismatch')
    item,reason=parse_trade(trade,now or datetime.now(timezone.utc))
    if item is None:return None
    # Do not silently treat separate lots as one supply obligation.
    if len(trade.get('lots') or [])!=1:raise ValueError('metal_it_multi_lot_requires_review')
    docs=references(trade)
    return SourceTender(source='metal_it',external_id=str(external_id),title=item['title'],
        source_url=source_url,submission_deadline=item['submission_deadline'],
        customer_name=(trade.get('customer') or {}).get('title') or item.get('customer'),procurement_method=item.get('procurement_method'),
        documents=docs,raw_payload={'stage':'detail','procurement_status':'Прием заявок',
            'registry_number':item.get('number'),'positions':item['positions'],
            'suppress_notifications':True,'metal_it':{'public_card':trade,
                'all_positions_required':trade['lots'][0].get('allowPartialBids') is False}})

class MetalItAdapter:
    def fetch_by_id(self,external_id,source_url=None):
        identity(dict(external_id=external_id,source_url=source_url))
        if is_dismissed('metal_it',str(external_id)):return None
        trade=request('getTradeInfo',DETAIL,{'id':int(external_id)}).get('trade')
        return build_card(trade,external_id,source_url)
    def fetch_by_url(self,url):
        m=re.fullmatch(r'/trades/(\d+)/info/?',urlsplit(url).path)
        if not m:raise ValueError('metal_it_unsupported_card_url')
        return self.fetch_by_id(m[1],source_url=url)

def resolve(item):
    source,number=identity(item)
    return MetalItAdapter().fetch_by_id(number,source_url=item['source_url'])

def materialize(tender):
    from app.core.config import settings
    fresh=MetalItAdapter().fetch_by_id(tender.external_id,source_url=tender.source_url)
    if fresh is None:raise ValueError('metal_it_no_longer_eligible')
    # Reject a changed source snapshot: never mix old database metadata and new files.
    if fresh.model_dump(mode='json')!=tender.model_dump(mode='json'):
        raise ValueError('metal_it_card_changed_retry_required')
    root=Path(settings.storage_path)/'metal_it_prepared';root.mkdir(parents=True,exist_ok=True)
    directory=Path(tempfile.mkdtemp(prefix=str(tender.external_id)+'-',dir=root))
    result=[];counter=0;total=0
    try:
        with httpx.Client(timeout=30,follow_redirects=False,trust_env=False) as client:
            for i,doc in enumerate(fresh.documents):
                if i:time.sleep(0.5)
                data=download(client,doc.url)
                files,counter,total=unpack(data,doc,directory,counter,total)
                result.extend(files)
        snapshot=directory/'00_Публичные_позиции_METAL_IT.txt'
        snapshot.write_text('Публичные данные METAL-IT. Позиции ниже совпадают с позициями карточки; не суммировать повторения из приложений.\n'
            +json.dumps(fresh.raw_payload['metal_it']['public_card'],ensure_ascii=False,indent=2),encoding='utf-8')
        result.insert(0,SourceDocument(name=snapshot.name,download_type='local_file',local_path=str(snapshot)))
        return result
    except Exception:
        shutil.rmtree(directory,ignore_errors=True)
        raise
