"""Bounded public attachments; ZIP members are copied without path extraction."""
import io
import re
import zipfile
from pathlib import Path
from urllib.parse import urlsplit,urljoin
from app.sources.schemas import SourceDocument
from app.sources.public_http import validate_url

EXTENSIONS={'.pdf','.doc','.docx','.xls','.xlsx','.txt','.png','.jpg','.jpeg'}
MAX_BYTES=20*1024*1024
MAX_TOTAL=80*1024*1024
MAX_FILES=20
TRADE_FIELDS=('technicalSpecificationAttachments', 'contractDraftAttachments', 'otherAttachments', 'purchaseDocumentationAttachments', 'purchaseDocumentationTemplateAttachments', 'contractRequirementsAttachments', 'tenderOfferFormAttachments', 'projectDocumentationAttachments', 'qualificationDocumentationAttachments', 'specificationDetailingAttachments', 'extraAttachments')
LOT_FIELDS=('technicalSpecificationAttachments', 'contractDraftAttachments', 'otherAttachments', 'imageAttachments', 'mainMaterialsAttachments', 'workScheduleAttachments', 'cashFlowTimeLineAttachments', 'projectDocumentationAttachments')

def safe_url(url):
    try:
        p=urlsplit(url)
        return (p.scheme=='https' and p.hostname=='etp.metal-it.ru' and not p.username
                and not p.password and p.port in (None,443) and p.path.startswith('/files/get/'))
    except ValueError:return False

def filename(name):
    name=str(name or '')
    if not name or len(name)>180 or '/' in name or '\\' in name or any(ord(c)<32 for c in name):
        raise ValueError('metal_it_invalid_filename')
    return name

def references(trade):
    docs={}
    groups=[(trade,TRADE_FIELDS)]+[(lot,LOT_FIELDS) for lot in trade.get('lots',[])]
    for parent,fields in groups:
      for field in fields:
          rows=parent.get(field)
          if not isinstance(rows,list):raise ValueError('metal_it_document_list_missing')
          for d in rows:
              name=filename(d.get('name'));url=urljoin('https://etp.metal-it.ru',d.get('href') or '')
              if not safe_url(url):raise ValueError('metal_it_invalid_document_url')
              if Path(name).suffix.lower() not in EXTENSIONS|{'.zip'}:
                  raise ValueError('metal_it_unsupported_document_format')
              uid=str(d.get('id') or '')
              if not uid.isdigit():raise ValueError('metal_it_invalid_document_id')
              doc=SourceDocument(external_id=uid,name=name,url=url)
              if uid in docs and docs[uid]!=doc:raise ValueError('metal_it_duplicate_document_id')
              docs[uid]=doc
    if not docs:raise ValueError('metal_it_no_public_documents')
    if len(docs)>8:raise ValueError('metal_it_document_limit')
    return list(docs.values())

def validate_bytes(data,suffix):
    if not data:raise ValueError('metal_it_empty_document')
    if data.lstrip().lower().startswith((b'<html',b'<!doctype html')):raise ValueError('metal_it_html_document')
    if suffix in ('.docx','.xlsx','.zip'):
        valid=zipfile.is_zipfile(io.BytesIO(data))
        if valid:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                valid=(sum(x.file_size for x in z.infolist())<=MAX_TOTAL and len(z.infolist())<=2000)
                if suffix!='.zip':valid=valid and '[Content_Types].xml' in z.namelist() and any(n.startswith('word/' if suffix=='.docx' else 'xl/') for n in z.namelist())
    elif suffix=='.pdf':valid=data.startswith(b'%PDF-')
    elif suffix in ('.doc','.xls'):valid=data.startswith(bytes.fromhex('D0CF11E0A1B11AE1'))
    elif suffix=='.png':valid=data.startswith(b'\x89PNG\r\n\x1a\n')
    elif suffix in ('.jpg','.jpeg'):valid=data.startswith(b'\xff\xd8\xff')
    elif suffix=='.txt':
        try:data.decode('utf-8-sig');valid=b'\x00' not in data
        except UnicodeError:valid=False
    else:valid=False
    if not valid:raise ValueError('metal_it_document_signature_mismatch')

def download(client,url,validate=validate_url):
    for _ in range(4):
        if not safe_url(url):raise ValueError('metal_it_unexpected_download_host_or_path')
        validate(url)
        with client.stream('GET',url) as r:
            if r.is_redirect:
                location=r.headers.get('location')
                if not location:raise ValueError('metal_it_redirect_without_location')
                url=urljoin(url,location);continue
            if r.status_code!=200:raise ValueError('metal_it_download_http_'+str(r.status_code))
            data=bytearray()
            for chunk in r.iter_bytes():
                data.extend(chunk)
                if len(data)>MAX_BYTES:raise ValueError('metal_it_file_over_20MB')
            return bytes(data)
    raise ValueError('metal_it_redirect_limit')

def unpack(data,doc,directory,counter,total):
    suffix=Path(doc.name).suffix.lower();validate_bytes(data,suffix)
    entries=[]
    if suffix=='.zip':
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            files=[x for x in z.infolist() if not x.is_dir()]
            if not files or len(files)>MAX_FILES:raise ValueError('metal_it_archive_file_limit')
            for info in files:
                p=Path(info.filename.replace('\\','/'))
                if p.is_absolute() or '..' in p.parts or info.flag_bits&1 or (info.external_attr>>16)&0o170000==0o120000:
                    raise ValueError('metal_it_unsafe_archive_member')
                ext=p.suffix.lower()
                if ext not in EXTENSIONS:raise ValueError('metal_it_unsupported_archive_member')
                if info.file_size>MAX_BYTES:raise ValueError('metal_it_archive_member_over_20MB')
                total+=info.file_size
                if total>MAX_TOTAL:raise ValueError('metal_it_bundle_over_80MB')
                content=z.read(info);validate_bytes(content,ext)
                entries.append((filename(p.name),content))
    else:
        total+=len(data)
        if total>MAX_TOTAL:raise ValueError('metal_it_bundle_over_80MB')
        entries=[(doc.name,data)]
    result=[]
    for name,content in entries:
        counter+=1
        if counter>MAX_FILES:raise ValueError('metal_it_bundle_file_limit')
        target=directory/(str(counter)+'_'+name);target.write_bytes(content)
        result.append(SourceDocument(name=target.name,external_id=doc.external_id,
            download_type='local_file',local_path=str(target),url=doc.url))
    return result,counter,total
