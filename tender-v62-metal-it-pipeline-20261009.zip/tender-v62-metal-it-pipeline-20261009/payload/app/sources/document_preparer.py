"""Prepare source documents for the common tender processing pipeline."""

from __future__ import annotations

from app.core.logging import get_logger
from app.sources.document_relevance import (
    rank_documents,
)
from app.sources.schemas import (
    SourceDocument,
    SourceTender,
)

logger = get_logger(__name__)


SELECTED_TIERS = {
    "must_download",
    "high_priority",
    "secondary",
}


def _select_documents(
    documents: list[SourceDocument],
) -> list[SourceDocument]:
    """
    Select technically relevant documents using metadata scoring.

    Preserve original source order after selection.
    """
    if not documents:
        return []

    ranked = rank_documents(documents)

    selected_ids = {
        id(item.document)
        for item in ranked
        if item.tier in SELECTED_TIERS
    }

    selected = [
        document
        for document in documents
        if id(document) in selected_ids
    ]

    # Safety fallback:
    # never silently discard every attachment.
    if not selected and documents:
        best = ranked[0] if ranked else None

        if best is not None:
            selected = [best.document]

    return selected


def prepare_tender_documents(
    tender: SourceTender,
) -> list[SourceDocument]:
    """
    Convert source-specific attachments into documents consumable
    by the common OCR/extraction pipeline.

    EIS:
        metadata selection
        -> cookie-aware materialization
        -> local_file SourceDocument

    Other sources:
        metadata selection
        -> keep existing SourceDocument contract
    """
    if tender.source == 'metal_it':
        from app.sources.metal_it.adapter import materialize
        return materialize(tender)
    if tender.source == 'fabrikant':
        from app.sources.fabrikant.adapter import materialize
        return materialize(tender)
    if tender.source == 'tektorg':
        from app.sources.tektorg.adapter import materialize
        return materialize(tender)
    if tender.source == 'b2b_center':
        from app.marketplace_discovery.b2b_public import prepare_public_snapshot
        return prepare_public_snapshot(tender)
    documents = list(tender.documents or [])

    if not documents:
        logger.info(
            "no_source_documents",
            source=tender.source,
            external_id=tender.external_id,
        )
        return []

    # Existing sources keep their current document behaviour.
    # Do not change Tender.Pro / Kontur processing while
    # introducing the new EIS transport.
    if tender.source != "zakupki_gov_ru":
        return documents

    selected = _select_documents(documents)

    logger.info(
        "documents_selected",
        source=tender.source,
        external_id=tender.external_id,
        total=len(documents),
        selected=len(selected),
        names=[
            document.name
            for document in selected
        ],
    )

    if not tender.source_url:
        raise ValueError(
            "EIS tender source_url is required "
            "for document materialization"
        )

    from app.sources.zakupki_gov_public.detail_client import (
        EisDocumentRef,
    )
    from app.sources.zakupki_gov_public.materializer import (
        materialize_selected_documents,
    )

    eis_documents = [
        EisDocumentRef(
            name=document.name,
            url=document.url,
            uid=document.external_id,
        )
        for document in selected
        if document.url
    ]

    if not eis_documents:
        return []

    materialized = materialize_selected_documents(
        external_id=str(tender.external_id),
        source_url=tender.source_url,
        documents=eis_documents,
    )

    logger.info(
        "eis_documents_materialized",
        external_id=tender.external_id,
        count=len(materialized),
        names=[
            document.name
            for document in materialized
        ],
    )

    return materialized
