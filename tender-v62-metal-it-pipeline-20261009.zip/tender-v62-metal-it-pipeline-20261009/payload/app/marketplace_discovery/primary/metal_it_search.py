"""METAL-IT public GraphQL search, verified against the site's own client.
Primary information only: no Tender/Decision changes, LLM, or notifications.
"""
import json
import math
import time
from datetime import datetime, timezone
from urllib.parse import urljoin, urlsplit
import httpx
from app.sources.public_http import validate_url
from app.scoring.selection_policy import material_status, mass_kg, MIN_WEIGHT_KG, FALLBACK_QUERIES
from app.marketplace_discovery.product_screening import subject_block_reason

BASE = 'https://etp.metal-it.ru'
ENDPOINT = BASE + '/graphql'
SEARCH = '''query trades($tradeQueryDto: TradeQueryDtoInput, $limit: Int, $skip: Int) {
 trades(tradeQueryDto: $tradeQueryDto, limit: $limit, skip: $skip) {
 items { id title registeredNumber request } total } }'''
DETAIL = '''query getTradeInfo($id: Long) { trade(id: $id) {
 id title registeredNumber published request processStatus bidSubmissionEndDate
 status {code} organizer {title} procurementMethod {title}
 lots { id number title processStatus purchaseItems {
 id number title productTitle quantity unit {code title} characteristics canceled } }
 technicalSpecificationAttachments {id name href} otherAttachments {id name href}
} }'''
LIMIT = 5
MAX_REQUESTS = 36


def request(operation, query, variables):
    validate_url(ENDPOINT)
    body = bytearray()
    with httpx.Client(timeout=25, follow_redirects=False, trust_env=False) as client:
        with client.stream('POST', ENDPOINT, json=dict(operationName=operation,
                query=query, variables=variables), headers={'Accept':'application/json'}) as r:
            if r.status_code != 200:
                raise ValueError('http_' + str(r.status_code))
            for chunk in r.iter_bytes():
                body.extend(chunk)
                if len(body) > 4 * 1024 * 1024: raise ValueError('response_too_large')
    if not body: raise ValueError('empty_response')
    try: payload = json.loads(body)
    except (ValueError, UnicodeError): raise ValueError('invalid_json') from None
    if not isinstance(payload, dict) or payload.get('errors'):
        raise ValueError('graphql_error')
    if not isinstance(payload.get('data'), dict): raise ValueError('invalid_data')
    return payload['data']


def deadline(value):
    # The public API sends epoch milliseconds, verified against +03:00 UI.
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    if not math.isfinite(value) or not 946684800000 <= value <= 4102444800000:
        return None
    return datetime.fromtimestamp(value / 1000, timezone.utc)


def parse_trade(t, now, dismissed=False):
    if dismissed: return None, 'manually_dismissed'
    if not isinstance(t, dict) or not str(t.get('id','')).isdigit():
        return None, 'invalid_card'
    if t.get('published') is not True or t.get('request') is not False:
        return None, 'not_published_trade'
    if (t.get('status') or {}).get('code') != 'active' or t.get('processStatus') != 'BID_SUBMISSION':
        return None, 'not_open'
    dt = deadline(t.get('bidSubmissionEndDate'))
    if dt is None: return None, 'deadline_unconfirmed'
    if dt <= now: return None, 'expired'
    title = str(t.get('title') or '')
    if subject_block_reason(title): return None, 'non_target_subject'
    lots = t.get('lots')
    if not isinstance(lots, list) or not lots: return None, 'positions_unavailable'
    positions = []
    for lot in lots:
        if not isinstance(lot, dict): return None, 'invalid_lot'
        if lot.get('processStatus') != 'BID_SUBMISSION': continue
        rows = lot.get('purchaseItems')
        if not isinstance(rows, list): return None, 'positions_unavailable'
        for p in rows:
            if not isinstance(p, dict): return None, 'invalid_position'
            if p.get('canceled') is not False: continue
            unit = p.get('unit') or {}
            item = dict(position_id=str(p.get('id') or ''), lot_id=str(lot.get('id') or ''),
                position_number=p.get('number'), name=p.get('productTitle') or p.get('title') or '',
                quantity=p.get('quantity'), unit=unit.get('title') or unit.get('code'),
                characteristics=p.get('characteristics') or '')
            item['mass_kg'] = mass_kg(item)
            positions.append(item)
    targets = [p for p in positions if material_status(p) is True]
    if not targets: return None, 'no_target_positions'
    qualified = [p for p in targets if p['mass_kg'] is not None and p['mass_kg'] >= MIN_WEIGHT_KG]
    if not qualified:
        return None, ('mass_unconfirmed' if any(p['mass_kg'] is None for p in targets) else 'below_500kg')
    docs = []
    for key in ('technicalSpecificationAttachments', 'otherAttachments'):
        for doc in t.get(key) or []:
            href = urljoin(BASE, str(doc.get('href') or ''))
            parsed = urlsplit(href)
            if (parsed.scheme == 'https' and parsed.hostname == 'etp.metal-it.ru'
                and not parsed.username and not parsed.password and parsed.port in (None,443)
                and parsed.path.startswith('/files/get/')):
                docs.append(dict(name=doc.get('name'), url=href))
    return dict(source='metal_it', external_id=str(t['id']), number=t.get('registeredNumber'),
        title=title, source_url=BASE+'/trades/'+str(t['id'])+'/info',
        submission_deadline=dt.isoformat(), customer=(t.get('organizer') or {}).get('title'),
        procurement_method=(t.get('procurementMethod') or {}).get('title'),
        positions=positions, qualifying_positions=qualified, documents=docs,
        mass_kg=max(p['mass_kg'] for p in qualified), mass_status='position_mass_confirmed',
        eligibility='requires_conditions_analysis', status='primary_information',
        analysis_done=False, collected_at=now.isoformat()), None


def _collect_metal_it(*, persist=True, fetch=None, now=None, previous=None, dismissed=None):
    from .collector import folder, save_report
    from app.reports.review_dismissals import is_dismissed
    now = now or datetime.now(timezone.utc)
    fetch = fetch or request
    dismissed = dismissed or is_dismissed
    if previous is None:
        try: previous = json.loads((folder()/'metal_it.json').read_text())
        except (OSError, ValueError): previous = {}
    offsets = dict(previous.get('next_offsets') or {})
    rotation = FALLBACK_QUERIES[(now.toordinal()*6+now.hour//4) % len(FALLBACK_QUERIES)]
    queries = list(dict.fromkeys(['алюм', rotation]))
    report = dict(source='metal_it', name='METAL-IT', checked_at=now.isoformat(),
        status='partial', coverage='first_page_plus_two_cursor_pages_per_query',
        classifier_filter='native_okpd2_not_verified', requests=0, items=[], skipped={},
        errors=[], searches=[], cards_checked=0, next_offsets=offsets,
        pipeline_status='primary_only_no_automatic_analysis')
    seen = set()
    def call(op, query, variables):
        if report['requests'] >= MAX_REQUESTS: raise ValueError('request_budget')
        if report['requests']: time.sleep(0.3)
        report['requests'] += 1
        return fetch(op, query, variables)
    for query in queries:
        start = offsets.get(query, LIMIT)
        if not isinstance(start, int) or start < LIMIT or start % LIMIT: start = LIMIT
        search = dict(query=query, offsets=[], total=None, complete=False)
        report['searches'].append(search)
        page_signatures = set()
        try:
            for skip in (0, start, start+LIMIT):
                result = call('trades', SEARCH, {'tradeQueryDto':{
                    'fullTextString':query, 'sitemapPage':'purchases.search', 'request':False},
                    'limit':LIMIT, 'skip':skip}).get('trades')
                if not isinstance(result, dict) or not isinstance(result.get('items'), list):
                    raise ValueError('invalid_listing')
                total, rows = result.get('total'), result['items']
                if isinstance(total,bool) or not isinstance(total,int) or total<0:
                    raise ValueError('invalid_total')
                if len(rows)>LIMIT: raise ValueError('page_size_not_respected')
                search['total']=total; search['offsets'].append(skip)
                ids = tuple(str(x.get('id','')) for x in rows)
                if any(not x.isdigit() for x in ids): raise ValueError('invalid_id')
                if ids and ids in page_signatures: raise ValueError('repeated_page')
                page_signatures.add(ids)
                if not rows and skip < total: raise ValueError('incomplete_page')
                for row in rows:
                    key=str(row['id'])
                    if key in seen: continue
                    if report['requests']>=MAX_REQUESTS: raise ValueError('request_budget')
                    seen.add(key)
                    if dismissed('metal_it',key):
                        reason='manually_dismissed'; item=None
                    else:
                        t=call('getTradeInfo',DETAIL,{'id':int(key)}).get('trade')
                        report['cards_checked']+=1
                        item,reason=parse_trade(t,now)
                    if item:report['items'].append(item)
                    else:report['skipped'][reason]=report['skipped'].get(reason,0)+1
                if skip+len(rows)>=total:
                    offsets[query]=LIMIT
                    search['complete']=(skip==0 or start==LIMIT)
                    search['cycle_finished']=True
                    break
                if len(rows)<LIMIT: raise ValueError('incomplete_page')
                if skip:offsets[query]=skip+LIMIT
            else: search['reason']='page_limit'
        except Exception as exc:
            reason = str(exc) if isinstance(exc,ValueError) else type(exc).__name__
            search['reason']=reason
            report['errors'].append(dict(query=query,reason=reason))
    all_complete=all(s['complete'] for s in report['searches'])
    if not report['errors'] and all_complete:
        report['status']='ok' if report['items'] else 'no_matches_in_checked_filters'
    if persist:save_report('metal_it',report)
    return report


def collect_metal_it(*, persist=True, **kwargs):
    if not persist:
        return _collect_metal_it(persist=False, **kwargs)
    import fcntl
    from .collector import folder, save_report
    from app.sources.metal_it.dispatch import drain
    root=folder(); root.mkdir(parents=True,exist_ok=True)
    with (root/'metal_it.lock').open('a') as lock:
        try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            return {'source':'metal_it','status':'already_running','items':[]}
        try: previous=json.loads((root/'metal_it.json').read_text()).get('items',[])
        except FileNotFoundError: previous=[]
        report=_collect_metal_it(persist=False,**kwargs)
        backlog=drain(previous+report['items'])
        report.update(pipeline=backlog['outcomes'],backlog_pending=backlog['pending'],
                      pipeline_status='automatic_bounded_handoff')
        save_report('metal_it',report)
        return report
