import copy,io,json,tempfile,unittest,zipfile
from pathlib import Path
from datetime import datetime,timezone,timedelta
from unittest.mock import patch,MagicMock
from app.sources.metal_it import adapter as a,documents as d,dispatch as dispatch
from app.sources.schemas import SourceDocument
from app.sources.eis_freshness import eligibility
from app.reports.dashboard_eligibility import evaluate_dashboard_tender
from app.marketplace_discovery.primary import metal_it_search as m
from app.sources.tektorg.backlog import process_backlog
NOW=datetime.now(timezone.utc)

def trade():
 t=dict(id=123,title='Лист алюминиевый АМг2',registeredNumber='123-ТТ',published=True,request=False,
  processStatus='BID_SUBMISSION',status={'code':'active'},bidSubmissionEndDate=int((NOW+timedelta(days=2)).timestamp()*1000),
  customer={'title':'Покупатель'},organizer={'title':'Организатор'},procurementMethod={'title':'Запрос предложений'},
  lots=[dict(id=5,title='Лист',number='1',processStatus='BID_SUBMISSION',allowPartialBids=False,
    purchaseItems=[dict(id=6,title='Лист алюминиевый АМг2',quantity=600,unit={'code':'166','title':'кг'},canceled=False)])])
 for f in d.TRADE_FIELDS:t[f]=[]
 for f in d.LOT_FIELDS:t['lots'][0][f]=[]
 t['technicalSpecificationAttachments']=[dict(id=7,name='ТЗ.txt',href='/files/get/7/tz.txt')]
 return t

def card():return a.build_card(trade(),'123','https://etp.metal-it.ru/trades/123/info',NOW)

class Pipeline(unittest.TestCase):
 def test_card_complete(self):
  c=card();self.assertEqual(c.customer_name,'Покупатель');self.assertEqual(c.raw_payload['positions'][0]['mass_kg'],600)
  self.assertTrue(c.raw_payload['metal_it']['all_positions_required']);self.assertTrue(c.raw_payload['suppress_notifications'])
 def test_wrong_identity(self):
  with self.assertRaises(ValueError):a.build_card(trade(),'999','https://etp.metal-it.ru/trades/999/info',NOW)
 def test_wrong_host(self):
  with self.assertRaises(ValueError):a.identity(dict(external_id='123',source_url='https://evil.test/trades/123/info'))
 def test_expired(self):
  t=trade();t['bidSubmissionEndDate']=0;self.assertIsNone(a.build_card(t,'123','https://etp.metal-it.ru/trades/123/info',NOW))
 def test_no_summing(self):
  t=trade();p=t['lots'][0]['purchaseItems'][0];p['quantity']=350;t['lots'][0]['purchaseItems'].append(copy.deepcopy(p))
  self.assertIsNone(a.build_card(t,'123','https://etp.metal-it.ru/trades/123/info',NOW))
 def test_all_document_groups(self):
  t=trade();t['lots'][0]['contractDraftAttachments']=[dict(id=8,name='Договор.pdf',href='/files/get/8/c.pdf')]
  self.assertEqual(len(d.references(t)),2)
 def test_missing_document_group(self):
  t=trade();del t['contractDraftAttachments']
  with self.assertRaises(ValueError):d.references(t)
 def test_no_documents(self):
  t=trade();t['technicalSpecificationAttachments']=[]
  with self.assertRaises(ValueError):d.references(t)
 def test_unsupported(self):
  t=trade();t['technicalSpecificationAttachments'][0]['name']='ТЗ.rar'
  with self.assertRaises(ValueError):d.references(t)
 def test_html_pdf_rejected(self):
  with self.assertRaises(ValueError):d.validate_bytes(b'<html>login</html>','.pdf')
 def test_redirect_blocked(self):
  client=MagicMock();r=client.stream.return_value.__enter__.return_value;r.is_redirect=True;r.headers={'location':'https://evil.test/x'}
  with self.assertRaises(ValueError):d.download(client,'https://etp.metal-it.ru/files/get/1/test.pdf',validate=lambda x:x)
  self.assertEqual(client.stream.call_count,1)
 def zipdata(self,name):
  b=io.BytesIO()
  with zipfile.ZipFile(b,'w') as z:z.writestr(name,'Тестовый договор'.encode())
  return b.getvalue()
 def test_zip(self):
  with tempfile.TemporaryDirectory() as tmp:
   files,count,size=d.unpack(self.zipdata('folder/Договор.txt'),SourceDocument(name='a.zip'),Path(tmp),0,0)
   self.assertEqual(count,1);self.assertTrue(Path(files[0].local_path).exists())
 def test_zip_traversal(self):
  with tempfile.TemporaryDirectory() as tmp:
   with self.assertRaises(ValueError):d.unpack(self.zipdata('../x.txt'),SourceDocument(name='a.zip'),Path(tmp),0,0)
 def test_materialize_snapshot_and_attachment(self):
  c=card()
  with tempfile.TemporaryDirectory() as tmp,patch('app.core.config.settings.storage_path',tmp),patch.object(a.MetalItAdapter,'fetch_by_id',return_value=c),patch.object(a,'download',return_value='Лист АМг2 600 кг'.encode()):
   docs=a.materialize(c);self.assertEqual(len(docs),2)
   self.assertIn('600',Path(docs[0].local_path).read_text())
 def test_changed_snapshot_blocked(self):
  c=card();changed=c.model_copy(deep=True);changed.title+=' изменено'
  with patch.object(a.MetalItAdapter,'fetch_by_id',return_value=changed):
   with self.assertRaises(ValueError):a.materialize(c)
 def test_stage_deadline_gate(self):
  self.assertEqual(eligibility('metal_it',NOW+timedelta(days=1),{}),'closed_stage')
  self.assertEqual(eligibility('metal_it',NOW-timedelta(days=1),{'procurement_status':'Прием заявок'}),'deadline_expired')
 def test_dashboard_after_analysis_only(self):
  row={'analysis_done':False,'status':'can_apply','positions':[{'name':'Лист алюминиевый АМг2','mass_kg':600,'can_supply':True}]}
  self.assertFalse(evaluate_dashboard_tender(row).eligible)
  row['analysis_done']=True;self.assertTrue(evaluate_dashboard_tender(row).eligible)
  row['status']='needs_clarification';self.assertFalse(evaluate_dashboard_tender(row).eligible)
 def test_backlog_deferred_and_cached(self):
  item=dict(external_id='123',source_url=card().source_url,submission_deadline=card().submission_deadline.isoformat())
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'q.db'
   r=process_backlog([item],path=path,enqueue=lambda rows:[{'number':'123','status':'batch_limit'}]);self.assertEqual(r['pending'],1)
   r=process_backlog([],path=path,enqueue=lambda rows:[{'number':'123','status':'cached'}]);self.assertEqual(r['pending'],0)
 def test_dispatch_bound_and_dedup(self):
  items=[dict(external_id=str(i),source_url=f'https://etp.metal-it.ru/trades/{i}/info',submission_deadline=card().submission_deadline.isoformat()) for i in range(1,4)]
  def resolve(item):return card().model_copy(update={'external_id':item['external_id'],'source_url':item['source_url']})
  with patch('redis.Redis.from_url') as redis,patch('app.db.session.SyncSessionLocal') as session,patch.object(dispatch,'is_dismissed',return_value=False),patch.object(dispatch,'resolve',side_effect=resolve),patch('app.workers.tasks_parsing.process_new_tender.delay') as queue:
   session.return_value.__enter__.return_value.execute.return_value.scalar_one_or_none.return_value=None
   redis.return_value.set.return_value=True;queue.return_value.id='test'
   out=dispatch.enqueue_candidates(items);self.assertEqual(queue.call_count,2);self.assertEqual(out[-1]['status'],'batch_limit')
 def test_cached_does_not_fetch_or_queue(self):
  item=dict(external_id='123',source_url=card().source_url,submission_deadline=card().submission_deadline.isoformat())
  with patch('redis.Redis.from_url'),patch('app.db.session.SyncSessionLocal'),patch('app.workers.completed_analysis.has_completed_analysis',return_value=True),patch.object(dispatch,'is_dismissed',return_value=False),patch.object(dispatch,'resolve') as resolve,patch('app.workers.tasks_parsing.process_new_tender.delay') as queue:
   out=dispatch.enqueue_candidates([item]);self.assertEqual(out[0]['status'],'cached');resolve.assert_not_called();queue.assert_not_called()
 def test_readonly_never_dispatches(self):
  with patch('app.sources.metal_it.dispatch.drain') as drain,patch.object(m,'_collect_metal_it',return_value={'items':[]}):
   m.collect_metal_it(persist=False);drain.assert_not_called()

if __name__=='__main__':unittest.main()
