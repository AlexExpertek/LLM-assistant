from __future__ import annotations

from typing import Any

from app.parsers.registry import get_parser_for_url, normalize_tender_url


async def parse_tender_url(url: str) -> dict[str, Any]:
    normalized_url = normalize_tender_url(url)
    parser = get_parser_for_url(normalized_url)
    tender = await parser.parse(normalized_url)

    return {
        "tender": tender.to_dict(),
        "document_urls": [
            {
                "name": attachment.name,
                "url": attachment.url,
                "mime_type": attachment.mime_type,
                "size_bytes": attachment.size_bytes,
            }
            for attachment in tender.attachments
        ],
    }
