from __future__ import annotations

import asyncio
import logging
from typing import Any

from app.services.tender_url_service import parse_tender_url
from app.workers.celery_app import celery_app

logger = logging.getLogger(__name__)


@celery_app.task(
    bind=True,
    autoretry_for=(Exception,),
    retry_backoff=True,
    retry_backoff_max=300,
    retry_jitter=True,
    retry_kwargs={"max_retries": 3},
    name="app.workers.tasks_url_pipeline.process_tender_url_task",
)
def process_tender_url_task(self, url: str) -> dict[str, Any]:
    """
    Parse a tender URL and return normalized tender data.

    IMPORTANT:
    This starter task intentionally does not call project-specific DB,
    downloader, OCR or LLM functions because their actual signatures
    must be verified in the source archive.
    """
    logger.info("tender_url_processing_started", extra={"url": url})
    parsed = asyncio.run(parse_tender_url(url))

    logger.info(
        "tender_url_processing_parsed",
        extra={
            "url": url,
            "source": parsed["tender"].get("source"),
            "external_id": parsed["tender"].get("external_id"),
            "document_count": len(parsed["document_urls"]),
        },
    )

    return {
        "status": "parsed",
        **parsed,
        "next_step": (
            "Connect this result to the existing DB save and "
            "download_and_process_documents task."
        ),
    }
