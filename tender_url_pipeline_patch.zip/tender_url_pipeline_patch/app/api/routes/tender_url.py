from __future__ import annotations

from pydantic import BaseModel, HttpUrl

from app.workers.tasks_url_pipeline import process_tender_url_task

try:
    from fastapi import APIRouter, status
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("FastAPI is required") from exc


router = APIRouter(prefix="/tenders", tags=["tenders"])


class ProcessTenderURLRequest(BaseModel):
    url: HttpUrl


class ProcessTenderURLResponse(BaseModel):
    task_id: str
    status: str


@router.post(
    "/process-url",
    response_model=ProcessTenderURLResponse,
    status_code=status.HTTP_202_ACCEPTED,
)
def process_tender_url(payload: ProcessTenderURLRequest) -> ProcessTenderURLResponse:
    task = process_tender_url_task.delay(str(payload.url))
    return ProcessTenderURLResponse(task_id=task.id, status="queued")
