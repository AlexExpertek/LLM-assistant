class TenderParserError(RuntimeError):
    """Base parser error."""


class UnsupportedTenderSourceError(TenderParserError):
    """Raised when no parser adapter supports the URL."""


class TenderPageFetchError(TenderParserError):
    """Raised when the tender page cannot be downloaded."""


class TenderPageParseError(TenderParserError):
    """Raised when mandatory tender data cannot be extracted."""


class AuthenticationRequiredError(TenderParserError):
    """Raised when a platform requires an authenticated session."""
