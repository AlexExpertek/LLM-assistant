from __future__ import annotations

import asyncio
import os

import httpx

from .exceptions import TenderPageFetchError


DEFAULT_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
    "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.7",
    "User-Agent": os.getenv(
        "TENDER_PARSER_USER_AGENT",
        "TenderAssistant/1.0 (+contact: admin@example.local)",
    ),
}


async def fetch_html(url: str) -> str:
    timeout = float(os.getenv("TENDER_PARSER_TIMEOUT_SECONDS", "30"))
    retries = int(os.getenv("TENDER_PARSER_MAX_RETRIES", "3"))
    last_error: Exception | None = None

    async with httpx.AsyncClient(
        timeout=timeout,
        follow_redirects=True,
        headers=DEFAULT_HEADERS,
    ) as client:
        for attempt in range(1, retries + 1):
            try:
                response = await client.get(url)
                response.raise_for_status()

                content_type = response.headers.get("content-type", "")
                if "text/html" not in content_type and "application/xhtml" not in content_type:
                    raise TenderPageFetchError(
                        f"Expected HTML page, received {content_type!r}"
                    )

                return response.text

            except (httpx.HTTPError, TenderPageFetchError) as exc:
                last_error = exc
                if attempt < retries:
                    await asyncio.sleep(min(2 ** (attempt - 1), 8))

    raise TenderPageFetchError(
        f"Failed to fetch tender page after {retries} attempts: {last_error}"
    )
