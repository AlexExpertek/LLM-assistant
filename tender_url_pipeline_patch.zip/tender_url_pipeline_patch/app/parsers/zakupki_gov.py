from __future__ import annotations

import re
from urllib.parse import parse_qs, urlparse

from .base import ParsedTender, TenderAttachment, TenderParser
from .exceptions import TenderPageParseError
from .html_utils import attachment_links, first_text, meta_content, soup
from .http import fetch_html


class ZakupkiGovParser(TenderParser):
    source_name = "zakupki_gov_ru"
    domains = ("zakupki.gov.ru",)

    async def parse(self, url: str) -> ParsedTender:
        html = await fetch_html(url)
        doc = soup(html)

        title = first_text(
            doc,
            [
                "h1",
                ".cardMainInfo__title",
                ".registry-entry__header-mid__number",
            ],
        ) or meta_content(doc, ["og:title", "description"])

        query = parse_qs(urlparse(url).query)
        external_id = (
            (query.get("regNumber") or query.get("noticeInfoId") or [""])[0]
        )

        if not external_id:
            match = re.search(r"\b\d{10,23}\b", url)
            external_id = match.group(0) if match else ""

        if not title or not external_id:
            raise TenderPageParseError(
                "EIS page structure was not recognized. "
                "Prefer official structured feeds/API where available."
            )

        attachments = [
            TenderAttachment(name=name, url=file_url)
            for name, file_url in attachment_links(doc, url)
        ]

        return ParsedTender(
            source=self.source_name,
            source_url=url,
            external_id=external_id,
            title=title,
            customer_name=first_text(
                doc,
                [
                    ".cardMainInfo__section",
                    ".registry-entry__body-href",
                ],
            ),
            description=meta_content(doc, ["description", "og:description"]),
            attachments=attachments,
            raw={"parser_version": 1},
        )
