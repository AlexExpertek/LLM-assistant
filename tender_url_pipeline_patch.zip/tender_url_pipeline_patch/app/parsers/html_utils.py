from __future__ import annotations

import json
import re
from urllib.parse import urljoin

from bs4 import BeautifulSoup


def soup(html: str) -> BeautifulSoup:
    return BeautifulSoup(html, "html.parser")


def clean_text(value: str | None) -> str | None:
    if value is None:
        return None
    result = re.sub(r"\s+", " ", value).strip()
    return result or None


def first_text(doc: BeautifulSoup, selectors: list[str]) -> str | None:
    for selector in selectors:
        node = doc.select_one(selector)
        if node:
            value = clean_text(node.get_text(" ", strip=True))
            if value:
                return value
    return None


def meta_content(doc: BeautifulSoup, names: list[str]) -> str | None:
    for name in names:
        node = doc.select_one(
            f'meta[name="{name}"], meta[property="{name}"]'
        )
        if node and node.get("content"):
            return clean_text(str(node["content"]))
    return None


def extract_json_ld(doc: BeautifulSoup) -> list[dict]:
    results: list[dict] = []
    for node in doc.select('script[type="application/ld+json"]'):
        raw = node.string or node.get_text()
        try:
            value = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            continue

        if isinstance(value, dict):
            results.append(value)
        elif isinstance(value, list):
            results.extend(x for x in value if isinstance(x, dict))
    return results


def attachment_links(
    doc: BeautifulSoup,
    base_url: str,
    extensions: tuple[str, ...] = (
        ".pdf", ".doc", ".docx", ".xls", ".xlsx",
        ".zip", ".rar", ".7z", ".jpg", ".jpeg", ".png", ".tif", ".tiff",
    ),
) -> list[tuple[str, str]]:
    found: list[tuple[str, str]] = []
    seen: set[str] = set()

    for link in doc.select("a[href]"):
        href = str(link.get("href") or "").strip()
        if not href:
            continue

        absolute = urljoin(base_url, href)
        lower_path = absolute.lower().split("?", 1)[0]
        text = clean_text(link.get_text(" ", strip=True)) or "Документ"

        looks_like_file = lower_path.endswith(extensions)
        looks_like_download = any(
            token in absolute.lower()
            for token in ("download", "attachment", "document", "file")
        )

        if not (looks_like_file or looks_like_download):
            continue
        if absolute in seen:
            continue

        seen.add(absolute)
        found.append((text, absolute))

    return found
