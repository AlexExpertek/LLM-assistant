from __future__ import annotations

from urllib.parse import urlparse

from .base import TenderParser
from .exceptions import UnsupportedTenderSourceError
from .zakupki_gov import ZakupkiGovParser
from .roseltorg import RoseltorgParser
from .b2b_center import B2BCenterParser


PARSER_CLASSES: tuple[type[TenderParser], ...] = (
    ZakupkiGovParser,
    RoseltorgParser,
    B2BCenterParser,
)


def normalize_tender_url(url: str) -> str:
    url = (url or "").strip()
    parsed = urlparse(url)

    if parsed.scheme not in {"http", "https"}:
        raise ValueError("URL must start with http:// or https://")
    if not parsed.hostname:
        raise ValueError("URL does not contain a hostname")

    return parsed.geturl()


def get_parser_for_url(url: str) -> TenderParser:
    normalized = normalize_tender_url(url)
    hostname = urlparse(normalized).hostname or ""

    for parser_class in PARSER_CLASSES:
        if parser_class.supports(hostname):
            return parser_class()

    raise UnsupportedTenderSourceError(
        f"No tender parser registered for hostname {hostname!r}"
    )
