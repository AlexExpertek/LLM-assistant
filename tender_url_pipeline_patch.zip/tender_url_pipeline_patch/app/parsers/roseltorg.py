from __future__ import annotations

import re
from urllib.parse import urlparse

from .base import ParsedTender, TenderAttachment, TenderParser
from .exceptions import TenderPageParseError
from .html_utils import attachment_links, first_text, meta_content, soup
from .http import fetch_html


class RoseltorgParser(TenderParser):
    source_name = "roseltorg"
    domains = ("roseltorg.ru",)

    async def parse(self, url: str) -> ParsedTender:
        html = await fetch_html(url)
        doc = soup(html)

        title = (
            first_text(doc, ["h1", ".procedure__title", "[data-testid='title']"])
            or meta_content(doc, ["og:title", "twitter:title"])
        )

        path = urlparse(url).path
        match = re.search(r"/procedure/([^/?#]+)", path)
        external_id = match.group(1) if match else ""

        if not title or not external_id:
            raise TenderPageParseError(
                "Roseltorg page structure was not recognized. "
                "The adapter selectors must be updated from a real saved page."
            )

        attachments = [
            TenderAttachment(name=name, url=file_url)
            for name, file_url in attachment_links(doc, url)
        ]

        return ParsedTender(
            source=self.source_name,
            source_url=url,
            external_id=external_id,
            title=title,
            customer_name=first_text(
                doc,
                [
                    ".customer-name",
                    "[data-field='customer']",
                    ".procedure__customer",
                ],
            ),
            description=meta_content(doc, ["description", "og:description"]),
            attachments=attachments,
            raw={"parser_version": 1},
        )
