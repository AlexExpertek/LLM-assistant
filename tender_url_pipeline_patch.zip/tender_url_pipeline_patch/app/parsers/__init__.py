"""Tender platform parser adapters."""
