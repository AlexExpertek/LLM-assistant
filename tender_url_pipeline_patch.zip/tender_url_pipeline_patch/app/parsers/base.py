from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any


@dataclass(slots=True)
class TenderAttachment:
    name: str
    url: str
    mime_type: str | None = None
    size_bytes: int | None = None


@dataclass(slots=True)
class ParsedTender:
    source: str
    source_url: str
    external_id: str
    title: str
    customer_name: str | None = None
    customer_inn: str | None = None
    amount: float | None = None
    currency: str = "RUB"
    region: str | None = None
    law_type: str | None = None
    published_at: datetime | None = None
    submission_deadline: datetime | None = None
    description: str | None = None
    attachments: list[TenderAttachment] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        for key in ("published_at", "submission_deadline"):
            value = result.get(key)
            if isinstance(value, datetime):
                result[key] = value.isoformat()
        return result


class TenderParser(ABC):
    source_name: str
    domains: tuple[str, ...]

    @classmethod
    def supports(cls, hostname: str) -> bool:
        hostname = hostname.lower().strip(".")
        return any(
            hostname == domain or hostname.endswith(f".{domain}")
            for domain in cls.domains
        )

    @abstractmethod
    async def parse(self, url: str) -> ParsedTender:
        """Parse one tender page and return a normalized tender."""
        raise NotImplementedError
