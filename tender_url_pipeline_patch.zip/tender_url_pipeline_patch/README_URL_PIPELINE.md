# Патч универсальной обработки URL тендера

Патч добавляет первый реальный слой конвейера:

```text
URL
→ проверка URL
→ определение площадки
→ выбор адаптера
→ нормализованная карточка
→ список найденных вложений
→ Celery task
→ REST endpoint
```

## Важно

Это стартовый инфраструктурный слой. CSS-селекторы площадок нельзя считать
окончательно подтверждёнными без реальных сохранённых HTML-страниц и проверки
условий доступа каждой ЭТП.

Патч намеренно не вызывает существующие функции БД, OCR и LLM, потому что
сигнатуры этих функций необходимо брать из актуального архива проекта.

## 1. Поддерживаемые домены

- `zakupki.gov.ru`;
- `roseltorg.ru`;
- `b2b-center.ru`.

Для неизвестного домена будет возвращена ошибка
`UnsupportedTenderSourceError`.

## 2. Копирование файлов

```bash
cd ~/LLM-assistant/tender-ai-platform

cp -R /ПУТЬ_К_ПАТЧУ/app/parsers app/
cp -R /ПУТЬ_К_ПАТЧУ/app/services/tender_url_service.py app/services/
cp /ПУТЬ_К_ПАТЧУ/app/workers/tasks_url_pipeline.py app/workers/
cp /ПУТЬ_К_ПАТЧУ/app/api/routes/tender_url.py app/api/routes/
cp /ПУТЬ_К_ПАТЧУ/scripts/test_tender_url.py scripts/
```

Перед копированием сделайте резервную копию:

```bash
cp -a app "app.backup.$(date +%Y%m%d_%H%M%S)"
```

## 3. Зависимости

Добавить в основной файл зависимостей:

```text
beautifulsoup4>=4.12,<5
httpx>=0.27,<1
```

Затем пересобрать образы:

```bash
docker compose build app celery_worker
```

## 4. Подключение Celery

В `app/workers/celery_app.py` добавить:

```python
"app.workers.tasks_url_pipeline",
```

Пример:

```python
include=[
    "app.workers.tasks_parsing",
    "app.workers.tasks_ocr",
    "app.workers.tasks_scoring",
    "app.workers.tasks_notify",
    "app.workers.tasks_bitrix24",
    "app.workers.tasks_url_pipeline",
]
```

## 5. Подключение API-router

В `app/main.py` или в общем API-router добавить:

```python
from app.api.routes.tender_url import router as tender_url_router

app.include_router(tender_url_router)
```

Если проект использует префикс `/api`, подключить через существующий общий
router, а не напрямую.

## 6. Перезапуск

```bash
docker compose up -d --build --force-recreate app celery_worker
```

Проверить:

```bash
docker compose ps
docker compose logs --tail=100 app
docker compose logs --tail=100 celery_worker
```

## 7. Проверка OpenAPI

```bash
curl -s http://127.0.0.1:8000/openapi.json \
  | grep -o '"/tenders/process-url"'
```

Ожидается:

```text
"/tenders/process-url"
```

## 8. Ручной тест без Celery

```bash
docker compose run --rm app \
  python scripts/test_tender_url.py \
  'https://www.roseltorg.ru/procedure/REAL_ID'
```

Результат должен содержать:

```json
{
  "tender": {
    "source": "roseltorg",
    "source_url": "...",
    "external_id": "...",
    "title": "..."
  },
  "document_urls": []
}
```

Пустой `document_urls` означает, что текущие HTML-селекторы не нашли
вложения. Это не означает, что у закупки нет документов.

## 9. Тест API

```bash
curl -X POST 'http://127.0.0.1:8000/tenders/process-url' \
  -H 'Content-Type: application/json' \
  -d '{"url":"https://www.roseltorg.ru/procedure/REAL_ID"}'
```

Ожидается HTTP 202:

```json
{
  "task_id": "...",
  "status": "queued"
}
```

## 10. Проверка задачи

Использовать существующий endpoint:

```bash
curl \
  'http://127.0.0.1:8000/tasks/TASK_ID'
```

Или смотреть логи:

```bash
docker compose logs -f celery_worker
```

## 11. Следующее подключение к текущему проекту

После успешного парсинга результат:

```python
{
    "tender": {...},
    "document_urls": [...]
}
```

нужно передать в уже существующие функции:

```text
save tender to PostgreSQL
→ check duplicate
→ save document records
→ download_and_process_documents
→ OCR
→ LLM
→ aluminium matching
→ scoring
→ report
→ Bitrix24
```

Псевдокод будущего соединения:

```python
parsed = asyncio.run(parse_tender_url(url))

tender_id = save_or_update_tender(parsed["tender"])

download_and_process_documents.delay(
    tender_id=tender_id,
    document_urls=parsed["document_urls"],
)
```

Точные имена аргументов нельзя подставлять без проверки актуальных моделей и
Celery-задач проекта.

## 12. Ограничения площадок

Некоторые ЭТП:

- требуют авторизации;
- загружают данные через JavaScript;
- используют CAPTCHA или антибот-защиту;
- отдают вложения через временные ссылки;
- запрещают автоматизированный сбор условиями использования.

В таких случаях нужен официальный API, экспорт, RSS/XML, авторизованная
сессия или согласованный интеграционный способ. Обход защит в патч не входит.
