from __future__ import annotations

import argparse
import asyncio
import json

from app.services.tender_url_service import parse_tender_url


async def main(url: str) -> None:
    result = await parse_tender_url(url)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("url")
    args = parser.parse_args()
    asyncio.run(main(args.url))
