"""
Unit-тесты для нормализации марок сплавов.
Раздел 14.1 ТЗ: Unit-тесты — нормализация сплавов, единиц, дат, сумм...
"""
import pytest

from app.scoring.alloy_normalizer import (
    extract_alloy_and_temper,
    is_known_alloy,
    normalize_alloy_string,
    normalize_text_typos,
)


class TestNormalizeAlloyString:
    def test_removes_spaces(self):
        assert normalize_alloy_string("АД 31") == "АД31"

    def test_uppercase(self):
        assert normalize_alloy_string("амг5м") == "АМГ5М"

    def test_already_normalized(self):
        assert normalize_alloy_string("Д16Т") == "Д16Т"

    def test_latin_ad_to_cyrillic(self):
        result = normalize_alloy_string("AD31")
        assert result == "АД31"

    def test_latin_amg_to_cyrillic(self):
        result = normalize_alloy_string("AMG5")
        assert result == "АМГ5"

    def test_empty_string_returns_none(self):
        assert normalize_alloy_string("") is None

    def test_none_input_returns_none(self):
        assert normalize_alloy_string(None) is None

    def test_numeric_designation_unchanged(self):
        assert normalize_alloy_string("5083") == "5083"
        assert normalize_alloy_string("6061") == "6061"


class TestExtractAlloyAndTemper:
    def test_splits_alloy_and_temper(self):
        alloy, temper = extract_alloy_and_temper("Д16Т")
        assert alloy == "Д16"
        assert temper == "Т"

    def test_alloy_without_temper(self):
        alloy, temper = extract_alloy_and_temper("Д16")
        assert alloy == "Д16"
        assert temper is None

    def test_amg5m_splits_correctly(self):
        alloy, temper = extract_alloy_and_temper("АМг5М")
        assert alloy == "АМГ5"
        assert temper == "М"

    def test_long_temper_suffix_t651(self):
        alloy, temper = extract_alloy_and_temper("6061Т651")
        assert temper == "Т651"

    def test_empty_input(self):
        alloy, temper = extract_alloy_and_temper("")
        assert alloy is None
        assert temper is None


class TestIsKnownAlloy:
    def test_known_alloy_cyrillic(self):
        assert is_known_alloy("АД31") is True

    def test_known_alloy_with_spaces(self):
        assert is_known_alloy("АД 31") is True

    def test_known_numeric_designation(self):
        assert is_known_alloy("6061") is True

    def test_unknown_alloy(self):
        assert is_known_alloy("НЕИЗВЕСТНЫЙСПЛАВ999") is False

    def test_empty_string(self):
        assert is_known_alloy("") is False


class TestNormalizeTextTypos:
    def test_fixes_alluminium_typo(self):
        result = normalize_text_typos("аллюминий")
        assert result == "алюминий"

    def test_fixes_aluminievyy_typo(self):
        result = normalize_text_typos("алюминевый профиль")
        assert "алюминиевый" in result

    def test_correct_text_unchanged(self):
        result = normalize_text_typos("алюминиевый прокат")
        assert result == "алюминиевый прокат"

    def test_case_insensitive(self):
        result = normalize_text_typos("Аллюминий")
        assert result.lower() == "алюминий"
