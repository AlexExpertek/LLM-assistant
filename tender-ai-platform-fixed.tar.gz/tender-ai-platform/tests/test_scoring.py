"""
Unit-тесты для скоринга тендеров (раздел 6.2 ТЗ).
"""
from app.scoring.rules import (
    ScoreCategory,
    categorize_score,
    has_explicit_aluminum_product,
    score_tender,
)
from app.models.database import TenderStatus


class TestCategorizeScore:
    def test_high_probability_at_60(self):
        category, status = categorize_score(60)
        assert category == ScoreCategory.HIGH_PROBABILITY
        assert status == TenderStatus.CAN_APPLY

    def test_manual_review_at_40(self):
        category, status = categorize_score(40)
        assert category == ScoreCategory.MANUAL_REVIEW

    def test_reserve_at_20(self):
        category, status = categorize_score(20)
        assert category == ScoreCategory.RESERVE

    def test_low_relevance_below_20(self):
        category, status = categorize_score(19)
        assert category == ScoreCategory.LOW_RELEVANCE
        assert status == TenderStatus.NOT_SUITABLE

    def test_boundary_59_is_manual_review(self):
        category, _ = categorize_score(59)
        assert category == ScoreCategory.MANUAL_REVIEW


class TestHasExplicitAluminumProduct:
    def test_detects_explicit_rolled_product(self):
        text = "Закупка лома алюминия, а также поставка алюминиевого проката"
        assert has_explicit_aluminum_product(text) is True

    def test_pure_scrap_collection_no_explicit_product(self):
        text = "Сбор и утилизация алюминиевого лома на территории завода"
        assert has_explicit_aluminum_product(text) is False


class TestScoreTender:
    def test_relevant_tender_with_full_data_scores_high(self):
        text = (
            "Поставка алюминиевого листа марки АД31 по ГОСТ 21631, "
            "толщина 5мм, объём 2000 кг, с чертежами, требуется покрытие"
        )
        result = score_tender(
            text=text,
            has_alloy_match=True,
            has_dimensions=True,
            has_volume=True,
            has_standard_ref=True,
            has_drawings=True,
            has_processing_services=True,
        )
        assert result.total_score >= 60
        assert result.category == ScoreCategory.HIGH_PROBABILITY

    def test_irrelevant_kitchenware_scores_low(self):
        text = "Закупка алюминиевой посуды: кастрюли, сковороды для столовой"
        result = score_tender(
            text=text,
            has_alloy_match=False,
            has_dimensions=False,
            has_volume=False,
            has_standard_ref=False,
            has_drawings=False,
            has_processing_services=False,
        )
        # Бытовая посуда не должна попадать в категорию высокой вероятности —
        # это и есть значимая граница, а не конкретное число баллов
        assert result.category != ScoreCategory.HIGH_PROBABILITY
        assert result.total_score < 40

    def test_hard_stop_word_without_explicit_product_excluded(self):
        text = "Демонтаж алюминиевых конструкций фасада здания"
        result = score_tender(
            text=text,
            has_alloy_match=False,
            has_dimensions=False,
            has_volume=False,
            has_standard_ref=False,
            has_drawings=False,
            has_processing_services=False,
        )
        # demontazh -30 балл должен серьёзно просадить итоговый счёт
        assert result.total_score <= 0

    def test_hard_stop_word_with_explicit_product_not_excluded(self):
        text = (
            "Демонтаж старых алюминиевых конструкций с последующей поставкой "
            "алюминиевого профиля для новых конструкций"
        )
        result = score_tender(
            text=text,
            has_alloy_match=False,
            has_dimensions=False,
            has_volume=False,
            has_standard_ref=False,
            has_drawings=False,
            has_processing_services=False,
        )
        # стоп-слово не должно вычитать баллы, должен появиться critical_unknown
        assert len(result.critical_unknowns) > 0

    def test_target_industry_marker_adds_points(self):
        text = "Поставка алюминиевых шин для кабельной промышленности предприятия"
        result = score_tender(
            text=text,
            has_alloy_match=False,
            has_dimensions=False,
            has_volume=False,
            has_standard_ref=False,
            has_drawings=False,
            has_processing_services=False,
        )
        signal_names = [s.name for s in result.signals]
        assert "target_industry" in signal_names
