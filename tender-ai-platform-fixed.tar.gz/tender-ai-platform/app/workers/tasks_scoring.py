"""
Задачи извлечения полей через LLM и финального скоринга.
Связывает app/llm/extraction.py и app/scoring/rules.py с пайплайном Celery.
"""
import asyncio
from dataclasses import asdict

from app.core.logging import get_logger
from app.llm.extraction import extract_tender_fields, fields_requiring_review
from app.scoring.alloy_normalizer import is_known_alloy
from app.scoring.rules import score_tender
from app.workers.celery_app import celery_app

logger = get_logger(__name__)


@celery_app.task(
    name="app.workers.tasks_scoring.extract_fields_and_score",
    bind=True,
    max_retries=2,
)
def extract_fields_and_score(self, tender_external_id: str, document_text: str):
    """
    Главная задача: извлекает структурированные поля через LLM,
    затем считает финальный скоринг по детерминированным правилам.

    Celery-таски синхронные, а наш LLM router асинхронный — поэтому
    запускаем через asyncio.run(). Для высокой нагрузки лучше перейти
    на celery с async-пулом или использовать httpx синхронно — это
    оптимизация для следующих этапов, не для MVP.
    """
    try:
        extraction_result = asyncio.run(extract_tender_fields(document_text))

        low_confidence_fields = fields_requiring_review(extraction_result, threshold=0.5)
        if low_confidence_fields:
            logger.warning(
                "low_confidence_fields_detected",
                tender_id=tender_external_id,
                fields=low_confidence_fields,
            )

        # Готовим флаги для скоринга на основе извлечённых данных
        alloy_value = extraction_result.alloy.value
        has_alloy_match = bool(alloy_value and is_known_alloy(alloy_value))
        has_dimensions = any([
            extraction_result.thickness_mm.value,
            extraction_result.width_mm.value,
            extraction_result.diameter_mm.value,
        ])
        has_volume = bool(extraction_result.mass_kg.value or extraction_result.quantity.value)
        has_standard_ref = bool(extraction_result.standard.value)
        has_drawings = bool(extraction_result.has_drawings.value)
        has_processing = bool(
            extraction_result.coating.value or extraction_result.machining.value
        )

        scoring_result = score_tender(
            text=document_text,
            has_alloy_match=has_alloy_match,
            has_dimensions=has_dimensions,
            has_volume=has_volume,
            has_standard_ref=has_standard_ref,
            has_drawings=has_drawings,
            has_processing_services=has_processing,
        )

        logger.info(
            "tender_scored",
            tender_id=tender_external_id,
            score=scoring_result.total_score,
            category=scoring_result.category.value,
            status=scoring_result.suggested_status.value,
        )

        # TODO: сохранить extraction_result -> ExtractedFact records
        # TODO: сохранить scoring_result -> Decision record
        # TODO: если статус high_probability или manual_review -> отправить в Telegram

        from app.workers.tasks_notify import send_telegram_notification
        if scoring_result.category.value in ("high_probability", "manual_review"):
            payload = asdict(scoring_result)
            payload["category"] = scoring_result.category.value
            payload["suggested_status"] = scoring_result.suggested_status.value
            send_telegram_notification.delay(tender_external_id, payload)

        return {
            "status": "scored",
            "score": scoring_result.total_score,
            "category": scoring_result.category.value,
            "low_confidence_fields": low_confidence_fields,
        }

    except Exception as exc:
        logger.error("extraction_and_scoring_failed", tender_id=tender_external_id, error=str(exc))
        raise self.retry(exc=exc)
