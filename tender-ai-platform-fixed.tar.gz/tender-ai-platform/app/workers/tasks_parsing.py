"""
Задачи мониторинга источников и парсинга карточек тендеров.
Реализует раздел 4.1 ТЗ: мониторинг -> дедупликация -> скачивание -> ...

ВАЖНО: парсер для конкретного источника (zakupki.gov.ru и т.д.) —
это адаптер, который нужно реализовать отдельно под структуру каждой
площадки (FR-SRC-002: администратор должен добавлять новый источник
без изменения основной бизнес-логики). Здесь — каркас и пример для ЕИС.
"""
import hashlib
from datetime import datetime

from app.core.logging import get_logger
from app.workers.celery_app import celery_app

logger = get_logger(__name__)


# Реестр источников — FR-SRC-002. В продакшене это таблица в БД с полями
# url, auth_type, schedule, limits, extraction_rules, чтобы администратор
# мог добавлять источники без релиза кода.
SOURCE_REGISTRY = {
    "zakupki_gov_ru": {
        "name": "ЕИС (zakupki.gov.ru)",
        "base_url": "https://zakupki.gov.ru",
        "law_types": ["44-FZ", "223-FZ"],
        "parser": "app.parsers.zakupki_gov.fetch_new_tenders",
    },
    "commercial_etp": {
        "name": "Коммерческие ЭТП (заглушка)",
        "base_url": None,
        "law_types": ["commercial"],
        "parser": None,  # TODO: реализовать адаптер под конкретную площадку
    },
}


def compute_tender_hash(source: str, external_id: str, customer_name: str, title: str) -> str:
    """
    Хэш для дедупликации (FR-SRC-005): по номеру закупки, заказчику,
    предмету и площадке.
    """
    raw = f"{source}|{external_id}|{customer_name}|{title}".lower().strip()
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@celery_app.task(
    name="app.workers.tasks_parsing.monitor_source",
    bind=True,
    max_retries=3,
    default_retry_delay=300,
)
def monitor_source(self, source_key: str):
    """
    Главная задача мониторинга. Вызывается планировщиком (см. celery_app.py
    beat_schedule) или вручную через API для конкретного источника.

    Логирует журнал доступности источника (FR-SRC-004): успех/ошибка/время.
    """
    source_config = SOURCE_REGISTRY.get(source_key)
    if not source_config:
        logger.error("unknown_source", source=source_key)
        return {"status": "error", "reason": "unknown_source"}

    logger.info("monitor_source_started", source=source_key)

    try:
        if not source_config["parser"]:
            logger.warning("parser_not_implemented", source=source_key)
            return {"status": "skipped", "reason": "parser_not_implemented"}

        # Здесь вызывается конкретный парсер источника.
        # Пример для ЕИС — см. app/parsers/zakupki_gov.py
        new_tenders = _dispatch_parser(source_config["parser"], source_key)

        logger.info(
            "monitor_source_completed",
            source=source_key,
            new_tenders_count=len(new_tenders),
            timestamp=datetime.utcnow().isoformat(),
        )

        # Для каждого нового тендера запускаем цепочку обработки
        for tender_data in new_tenders:
            process_new_tender.delay(tender_data)

        return {"status": "success", "new_tenders": len(new_tenders)}

    except Exception as exc:
        logger.error("monitor_source_failed", source=source_key, error=str(exc))
        raise self.retry(exc=exc)


def _dispatch_parser(parser_path: str, source_key: str) -> list[dict]:
    """Динамически импортирует и вызывает функцию-парсер по пути из реестра."""
    module_path, func_name = parser_path.rsplit(".", 1)
    import importlib

    module = importlib.import_module(module_path)
    parser_func = getattr(module, func_name)
    return parser_func()


@celery_app.task(
    name="app.workers.tasks_parsing.process_new_tender",
    bind=True,
    max_retries=3,
)
def process_new_tender(self, tender_data: dict):
    """
    Обработка одной новой карточки тендера: дедупликация -> сохранение в БД
    -> запуск скачивания документов -> запуск OCR -> запуск извлечения -> скоринг.

    Это последовательность из раздела 4.1 ТЗ, реализованная как цепочка задач.
    """
    tender_hash = compute_tender_hash(
        source=tender_data["source"],
        external_id=tender_data["external_id"],
        customer_name=tender_data.get("customer_name", ""),
        title=tender_data.get("title", ""),
    )

    # TODO: проверка дубликата по hash в БД перед сохранением (FR-SRC-005)
    logger.info("processing_new_tender", external_id=tender_data["external_id"], hash=tender_hash)

    # Следующий шаг цепочки — скачивание документов
    from app.workers.tasks_ocr import download_and_process_documents
    download_and_process_documents.delay(tender_data["external_id"], tender_data.get("document_urls", []))

    return {"status": "queued_for_documents", "hash": tender_hash}
