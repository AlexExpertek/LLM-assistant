"""
Модель данных по разделу 10.2 ТЗ.
Сущности: Tender, Lot/Position, Document, ExtractedFact, Decision,
Company, Contact, Offer, Interaction, KnowledgeItem.

Для MVP (Блок I) активно используются: Tender, Lot, Document, ExtractedFact, Decision.
Остальные сущности (Company, Contact, Offer, Interaction) — заготовки для Блока III.
"""
import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


def gen_uuid() -> str:
    return str(uuid.uuid4())


# ──────────────────────────────────────────────────────────
# Справочные enum-ы
# ──────────────────────────────────────────────────────────

class LawType(str, enum.Enum):
    FZ_44 = "44-FZ"
    FZ_223 = "223-FZ"
    COMMERCIAL = "commercial"
    OTHER = "other"


class TenderStatus(str, enum.Enum):
    NEW = "new"                      # только обнаружен, не обработан
    PROCESSING = "processing"        # идёт OCR/извлечение
    CAN_APPLY = "can_apply"          # можем подать заявку
    NEEDS_CLARIFICATION = "needs_clarification"  # нужно уточнение
    NOT_SUITABLE = "not_suitable"    # не подходим
    MANUAL_REVIEW = "manual_review"  # передано специалисту


class DocumentType(str, enum.Enum):
    TENDER_DOC = "tender_doc"        # основная документация тендера
    CONTRACT = "contract"
    SPECIFICATION = "specification"
    DRAWING = "drawing"
    PROTOCOL = "protocol"
    OTHER = "other"


class OCRStatus(str, enum.Enum):
    NOT_REQUIRED = "not_required"    # текстовый PDF/DOCX, OCR не нужен
    PENDING = "pending"
    DONE = "done"
    LOW_CONFIDENCE = "low_confidence"
    FAILED = "failed"


# ──────────────────────────────────────────────────────────
# Tender — карточка закупки
# ──────────────────────────────────────────────────────────

class Tender(Base):
    __tablename__ = "tenders"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    source = Column(String(100), nullable=False)          # zakupki_gov_ru, b2b_basis, ...
    external_id = Column(String(255), nullable=False)     # номер закупки на источнике
    title = Column(Text, nullable=False)
    customer_name = Column(String(500))
    customer_inn = Column(String(20))
    law_type = Column(Enum(LawType), default=LawType.OTHER)
    procurement_method = Column(String(100))               # аукцион, запрос котировок ...

    amount = Column(Numeric(18, 2))
    currency = Column(String(10), default="RUB")
    region = Column(String(255))

    publish_date = Column(DateTime)
    submission_deadline = Column(DateTime)

    status = Column(Enum(TenderStatus), default=TenderStatus.NEW, index=True)
    source_url = Column(Text)

    raw_hash = Column(String(64), index=True)  # хэш для дедупликации

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    lots = relationship("Lot", back_populates="tender", cascade="all, delete-orphan")
    documents = relationship("Document", back_populates="tender", cascade="all, delete-orphan")
    decisions = relationship("Decision", back_populates="tender", cascade="all, delete-orphan")

    __table_args__ = (
        UniqueConstraint("source", "external_id", name="uq_tender_source_external_id"),
    )


# ──────────────────────────────────────────────────────────
# Lot / Position — позиция внутри тендера (может быть несколько на тендер)
# ──────────────────────────────────────────────────────────

class Lot(Base):
    __tablename__ = "lots"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    tender_id = Column(UUID(as_uuid=False), ForeignKey("tenders.id"), nullable=False)

    lot_number = Column(String(50))
    product_type = Column(String(255))      # лист, профиль, труба, шина...
    alloy = Column(String(100))             # марка сплава: АД31, АМг5...
    temper = Column(String(50))             # состояние: Т, Т1, М, Н...

    thickness_mm = Column(Float)
    width_mm = Column(Float)
    length_mm = Column(Float)
    diameter_mm = Column(Float)
    cross_section_shape = Column(String(100))

    quantity = Column(Float)
    mass_kg = Column(Float)
    unit = Column(String(50))

    standard = Column(String(255))          # ГОСТ/ОСТ/ТУ
    coating_required = Column(Boolean, default=False)
    coating_type = Column(String(255))
    machining_required = Column(Boolean, default=False)
    has_drawings = Column(Boolean, default=False)

    delivery_place = Column(Text)
    delivery_term = Column(String(255))
    payment_terms = Column(Text)

    raw_text = Column(Text)  # исходная строка из документа, для аудита

    created_at = Column(DateTime, default=datetime.utcnow)

    tender = relationship("Tender", back_populates="lots")


# ──────────────────────────────────────────────────────────
# Document — файл, прикреплённый к тендеру
# ──────────────────────────────────────────────────────────

class Document(Base):
    __tablename__ = "documents"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    tender_id = Column(UUID(as_uuid=False), ForeignKey("tenders.id"), nullable=False)

    doc_type = Column(Enum(DocumentType), default=DocumentType.OTHER)
    filename = Column(String(500))
    version = Column(Integer, default=1)
    file_hash = Column(String(64), index=True)
    storage_uri = Column(Text)              # путь в object storage / локальном volume
    source_url = Column(Text)

    ocr_status = Column(Enum(OCRStatus), default=OCRStatus.PENDING)
    pages_count = Column(Integer)
    extracted_text = Column(Text)           # полный извлечённый текст (для RAG/поиска)

    created_at = Column(DateTime, default=datetime.utcnow)

    tender = relationship("Tender", back_populates="documents")
    facts = relationship("ExtractedFact", back_populates="document", cascade="all, delete-orphan")


# ──────────────────────────────────────────────────────────
# ExtractedFact — конкретное извлечённое значение с привязкой к источнику
# ──────────────────────────────────────────────────────────

class ExtractedFact(Base):
    __tablename__ = "extracted_facts"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    document_id = Column(UUID(as_uuid=False), ForeignKey("documents.id"), nullable=False)

    field_name = Column(String(255), nullable=False)   # напр. "alloy", "thickness_mm"
    raw_value = Column(Text)                             # как написано в документе
    normalized_value = Column(Text)                      # нормализованное значение
    confidence = Column(Float, default=0.0)               # 0.0 - 1.0

    page_or_cell = Column(String(100))   # "стр. 3" или "лист2!B14"
    quote = Column(Text)                  # точная цитата-источник факта

    created_at = Column(DateTime, default=datetime.utcnow)

    document = relationship("Document", back_populates="facts")


# ──────────────────────────────────────────────────────────
# Decision — итоговое решение по тендеру (с историей)
# ──────────────────────────────────────────────────────────

class Decision(Base):
    __tablename__ = "decisions"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    tender_id = Column(UUID(as_uuid=False), ForeignKey("tenders.id"), nullable=False)

    score = Column(Integer)                     # итоговый балл скоринга
    status = Column(Enum(TenderStatus))
    reasons = Column(JSON)                       # список причин (3-7 пунктов)
    risks = Column(JSON)                         # критические риски

    model_version = Column(String(100))          # какая модель/промпт использовались
    reviewer = Column(String(255))                # кто проверил (специалист)
    final_feedback = Column(Text)                 # комментарий специалиста при корректировке

    is_manual_override = Column(Boolean, default=False)

    created_at = Column(DateTime, default=datetime.utcnow)

    tender = relationship("Tender", back_populates="decisions")


# ──────────────────────────────────────────────────────────
# Company — заготовка для Блока III (CRM/лидогенерация)
# ──────────────────────────────────────────────────────────

class Company(Base):
    __tablename__ = "companies"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    inn = Column(String(20), unique=True, index=True)
    ogrn = Column(String(20))
    name = Column(String(500))
    okved = Column(String(20))
    site = Column(Text)
    region = Column(String(255))
    segment = Column(String(255))         # кабельная промышленность, машиностроение...
    signals = Column(JSON)                 # доказательства потребности
    consent_status = Column(String(50), default="unknown")

    created_at = Column(DateTime, default=datetime.utcnow)

    contacts = relationship("Contact", back_populates="company", cascade="all, delete-orphan")


class Contact(Base):
    __tablename__ = "contacts"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    company_id = Column(UUID(as_uuid=False), ForeignKey("companies.id"))

    contact_type = Column(String(50))      # email, phone, telegram...
    value = Column(String(500))
    person_name = Column(String(255))
    role = Column(String(255))
    source = Column(String(255))
    discovered_at = Column(DateTime, default=datetime.utcnow)
    is_opted_out = Column(Boolean, default=False)

    company = relationship("Company", back_populates="contacts")


# ──────────────────────────────────────────────────────────
# KnowledgeItem — заготовка для Блока II (RAG база знаний)
# ──────────────────────────────────────────────────────────

class KnowledgeItem(Base):
    __tablename__ = "knowledge_items"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    item_type = Column(String(100))    # catalog_product, gost_standard, past_case...
    title = Column(String(500))
    content = Column(Text)
    metadata_json = Column(JSON)
    qdrant_point_id = Column(String(100))   # ссылка на вектор в Qdrant
    version = Column(Integer, default=1)
    access_scope = Column(String(50), default="internal")

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
