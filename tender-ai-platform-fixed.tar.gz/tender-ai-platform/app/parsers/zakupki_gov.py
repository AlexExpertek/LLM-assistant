"""
Адаптер для мониторинга ЕИС (zakupki.gov.ru). Реализует FR-SRC-001, FR-SRC-002.

ВАЖНО ДЛЯ РАЗРАБОТЧИКА:
У ЕИС нет полностью открытого публичного REST API для произвольного поиска закупок
по ключевым словам — основной способ интеграции:

1. Открытый набор данных ФЗ-44/223 через portal.budgetplanning или ftp выгрузки
   zakupki.gov.ru/epz/main/public/home.html (XML-выгрузки доступны, но требуют
   договора на доступ к "Открытым данным" — см. zakupki.gov.ru/epz/opendata).

2. Альтернатива — коммерческие агрегаторы с готовым API (Тендерплан, Контур.Закупки,
   Synergy, RusTender и т.п.) — они уже агрегируют 44-ФЗ/223-ФЗ и дают чистый JSON/XML
   API за подписку. Это быстрее в реализации и снимает риск изменения вёрстки ЕИС
   (см. риск "Изменение верстки и блокировки ЭТП" в разделе 18 ТЗ).

3. Если бюджет ограничен — парсинг HTML-страниц поиска ЕИС напрямую (Playwright/Selenium,
   так как часть контента подгружается JS). Это наименее устойчивый вариант:
   ломается при любом обновлении вёрстки площадки, требует ротации User-Agent
   и может потребовать капчу — что НАПРЯМУЮ запрещено разделом 13 ТЗ
   ("запрещено обходить технические ограничения площадок, CAPTCHA").

РЕКОМЕНДАЦИЯ: начать с варианта 2 (коммерческий агрегатор с API) для быстрого MVP,
параллельно подавать заявку на доступ к "Открытым данным" ЕИС (вариант 1) для
снижения зависимости от платной подписки в перспективе.

Ниже — структура адаптера на примере открытых данных ЕИС (XML), чтобы показать
ожидаемый контракт функции. Реальный URL и параметры запроса нужно уточнить
после получения доступа к open data ЕИС.
"""
from datetime import datetime, timedelta

import httpx

from app.core.logging import get_logger

logger = get_logger(__name__)

# Ключевые слова для первичной фильтрации — из Приложения А, раздел 1 ТЗ
PRIORITY_KEYWORDS = [
    "алюминий", "алюминиевый прокат", "прокат алюминиевый", "алюминиевые сплавы",
    "алюминиевый лист", "алюминиевый профиль", "алюминиевая труба",
    "алюминиевый пруток", "алюминиевая шина", "алюминиевая катанка",
    "алюминиевая проволока", "алюминиевая фольга",
]

# ОКПД2-коды из FR-FLT-001
TARGET_OKPD2_CODES = ["24.42.22", "24.42.23", "24.42.24", "24.42.25", "24.42.26", "24.42.11"]


def fetch_new_tenders() -> list[dict]:
    """
    Контракт функции, которую вызывает Celery-задача monitor_source
    (см. app/workers/tasks_parsing.py).

    Должна вернуть список словарей вида:
    {
        "source": "zakupki_gov_ru",
        "external_id": "0123456789012345",
        "title": "Поставка алюминиевого профиля...",
        "customer_name": "ООО Заказчик",
        "customer_inn": "7700000000",
        "law_type": "44-FZ",
        "amount": 1500000.00,
        "region": "Москва",
        "submission_deadline": "2026-07-15T00:00:00",
        "source_url": "https://zakupki.gov.ru/...",
        "document_urls": ["https://zakupki.gov.ru/.../doc1.pdf", ...],
    }

    ЗАГЛУШКА: возвращает пустой список. Реализация зависит от выбранного
    способа доступа к данным ЕИС (см. docstring модуля выше).
    """
    logger.warning(
        "zakupki_parser_not_implemented",
        note="Требуется выбрать способ доступа: открытые данные ЕИС или коммерческий агрегатор"
    )
    return []


def _filter_by_keywords(title: str, description: str = "") -> bool:
    """Первичная фильтрация по ключевым словам (FR-FLT-007) — дешёвая проверка до LLM."""
    text = f"{title} {description}".lower()
    return any(kw in text for kw in PRIORITY_KEYWORDS)


def _filter_by_okpd2(okpd2_code: str) -> bool:
    """Фильтрация по ОКПД2 (FR-FLT-001)."""
    return any(okpd2_code.startswith(code) for code in TARGET_OKPD2_CODES)


def _filter_by_amount(amount: float | None) -> bool:
    """
    Фильтрация по сумме (FR-FLT-004): высокий приоритет от 1 млн руб.,
    диапазон 500 тыс - 1 млн сохраняется как дополнительный пул (не отбрасывается).
    """
    if amount is None:
        return True  # сумма не указана -> не исключаем, проверит специалист
    return amount >= 500_000  # порог входа в любой пул


# ──────────────────────────────────────────────────────────
# Пример адаптера через коммерческого агрегатора (структура запроса)
# Раскомментировать и адаптировать после выбора конкретного провайдера API
# ──────────────────────────────────────────────────────────

def fetch_from_aggregator_api(api_url: str, api_key: str) -> list[dict]:
    """
    Пример обращения к гипотетическому агрегатору с REST API.
    Конкретные параметры запроса (поля фильтра, формат ответа) нужно
    адаптировать под документацию выбранного провайдера.
    """
    headers = {"Authorization": f"Bearer {api_key}"}
    params = {
        "keywords": ",".join(PRIORITY_KEYWORDS[:5]),
        "okpd2": ",".join(TARGET_OKPD2_CODES),
        "date_from": (datetime.utcnow() - timedelta(days=1)).strftime("%Y-%m-%d"),
        "law_types": "44-fz,223-fz",
    }

    try:
        response = httpx.get(api_url, headers=headers, params=params, timeout=30.0)
        response.raise_for_status()
        raw_items = response.json().get("items", [])
    except httpx.HTTPError as e:
        logger.error("aggregator_api_error", error=str(e))
        return []

    results = []
    for item in raw_items:
        if not _filter_by_keywords(item.get("title", "")):
            continue
        if not _filter_by_amount(item.get("amount")):
            continue

        results.append({
            "source": "zakupki_gov_ru",
            "external_id": item.get("registry_number"),
            "title": item.get("title"),
            "customer_name": item.get("customer", {}).get("name"),
            "customer_inn": item.get("customer", {}).get("inn"),
            "law_type": item.get("law_type"),
            "amount": item.get("amount"),
            "region": item.get("region"),
            "submission_deadline": item.get("deadline"),
            "source_url": item.get("url"),
            "document_urls": item.get("document_urls", []),
        })

    return results
