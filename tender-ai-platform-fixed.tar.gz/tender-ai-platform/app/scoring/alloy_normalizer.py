"""
Нормализация марок алюминиевых сплавов.
Реализует раздел 6.1 ТЗ: марки распознаются в кириллице и латинице,
с пробелами, дефисами и состоянием материала.

Справочник марок взят из Приложения А, раздел 11 ТЗ.
"""
import re

# Справочник марок — сокращённый, но покрывающий основные группы из ТЗ.
# В продакшене этот список должен быть выгружен в отдельную таблицу БД (MDM-справочник),
# чтобы администратор мог редактировать его без релиза кода (требование раздела 12 ТЗ).
KNOWN_ALLOYS = {
    # Технический и первичный алюминий
    "А0", "А5", "А5Е", "А6", "А7", "А7Е", "А8", "АД", "АД0", "АД00", "АД000", "АД1",
    "1050", "1050A", "1070", "1070A", "1100", "1200", "1235",
    # Al-Mg
    "АМГ1", "АМГ2", "АМГ2М", "АМГ2Н", "АМГ3", "АМГ4", "АМГ5", "АМГ5М", "АМГ6",
    "5005", "5052", "5083", "5086", "5154", "5251", "5754",
    # Al-Mg-Si
    "АД31", "АД31Е", "АД31Т", "АД31Т1", "АД33", "АД35", "АВ",
    "6060", "6061", "6063", "6005", "6005A", "6082", "6101", "6101B",
    # Конструкционные
    "Д1", "Д16", "Д16Т", "Д16АТ", "Д16АМ", "В95", "В95Т", "АК4", "АК4-1", "АК6", "АК8",
    "2017", "2024", "2618", "7075",
    # Специальные
    "1561", "1561Б", "1915", "1925", "1933", "01420", "1420", "1441",
    "1163", "1161", "1580", "8011", "8111",
}

# Состояния поставки — раздел 12 Приложения А
KNOWN_TEMPERS = {
    "М", "Н", "Н1", "Н2", "Н3", "Т", "Т1", "Т4", "Т5", "Т6", "Т66",
    "Т8", "Т851", "Т651", "Т6511",
}

# Опечатки -> правильное написание (раздел 18 ТЗ)
TYPO_CORRECTIONS = {
    "аллюминий": "алюминий",
    "алюминний": "алюминий",
    "алюминевый": "алюминиевый",
    "алюминивый": "алюминиевый",
    "алюминевая": "алюминиевая",
    "аллюминиевый": "алюминиевый",
}


def normalize_text_typos(text: str) -> str:
    """Исправляет частые опечатки в слове 'алюминий' и его формах."""
    result = text
    for typo, correct in TYPO_CORRECTIONS.items():
        result = re.sub(typo, correct, result, flags=re.IGNORECASE)
    return result


def normalize_alloy_string(raw: str) -> str | None:
    """
    Нормализует написание марки сплава к стандартному виду.

    Примеры:
        "АД 31"    -> "АД31"
        "AD31"     -> "АД31"  (латиница -> кириллица для известных марок)
        "Д16Т"     -> "Д16Т"
        "амг5м"    -> "АМГ5М"
    """
    if not raw:
        return None

    # Убираем пробелы, приводим к верхнему регистру
    cleaned = raw.upper().replace(" ", "").strip()

    # Транслитерация латиницы в кириллицу для распознанных латинских вариантов
    # (упрощённая карта для самых частых случаев из ТЗ: AD31, AMg5, D16T)
    latin_to_cyrillic_map = {
        "AD": "АД", "AM": "АМ", "AK": "АК", "AB": "АВ", "D": "Д", "V": "В",
        "MG": "Г",  # внутри AMg -> АМГ
    }
    transliterated = cleaned
    transliterated = transliterated.replace("AMG", "АМГ")
    transliterated = transliterated.replace("AD", "АД")
    transliterated = transliterated.replace("AK", "АК")
    transliterated = transliterated.replace("AB", "АВ")
    if transliterated.startswith("D") and transliterated[1:2].isdigit():
        transliterated = "Д" + transliterated[1:]

    candidate = transliterated if transliterated in KNOWN_ALLOYS else cleaned

    # Проверка по справочнику числовых обозначений (международная номенклатура: 5083, 6061...)
    if cleaned in KNOWN_ALLOYS:
        return cleaned
    if candidate in KNOWN_ALLOYS:
        return candidate

    # Если марка похожа на известную, но не найдена точно — возвращаем
    # очищенную строку с пометкой низкой уверенности (обрабатывается выше, в extraction.py)
    return cleaned if cleaned else None


def extract_alloy_and_temper(raw: str) -> tuple[str | None, str | None]:
    """
    Разделяет строку вида "Д16Т" или "АМг5М" на марку и состояние.
    Состояние — это буквенно-цифровой суффикс из KNOWN_TEMPERS.
    """
    if not raw:
        return None, None

    normalized = normalize_alloy_string(raw)
    if not normalized:
        return None, None

    # Пробуем найти суффикс состояния (от самого длинного к самому короткому)
    sorted_tempers = sorted(KNOWN_TEMPERS, key=len, reverse=True)
    for temper in sorted_tempers:
        if normalized.endswith(temper):
            alloy_part = normalized[: -len(temper)]
            if alloy_part:  # не позволяем марке стать пустой строкой
                return alloy_part, temper

    return normalized, None


def is_known_alloy(alloy: str) -> bool:
    """Проверяет, есть ли марка в справочнике — используется в скоринге (alloy_match)."""
    normalized = normalize_alloy_string(alloy)
    return normalized in KNOWN_ALLOYS if normalized else False
