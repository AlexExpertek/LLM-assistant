"""
Детерминированный скоринг тендеров по разделу 6.2 ТЗ.

Принцип из FR-EXP-003: LLM не принимает финальный статус без проверки
детерминированных правил. Эта логика — тот самый "фундамент" скоринга,
LLM подключается только для генерации объяснения и анализа нюансов
(см. app/llm/extraction.py).
"""
from dataclasses import dataclass, field
from enum import Enum

from app.models.database import TenderStatus


class ScoreCategory(str, Enum):
    HIGH_PROBABILITY = "high_probability"   # 60+
    MANUAL_REVIEW = "manual_review"          # 40-59
    RESERVE = "reserve"                       # 20-39
    LOW_RELEVANCE = "low_relevance"           # <20


# Баллы по признакам — таблица 6.2 ТЗ
SCORE_RULES = {
    "exact_product_match": 20,
    "alloy_match": 15,
    "has_dimensions": 10,
    "has_volume": 10,
    "has_standard": 7,
    "has_drawings": 10,
    "has_processing_services": 8,
    "supply_wording": 5,
    "target_industry": 5,
    "irrelevant_word": -10,
    "hard_stop_word": -30,
}


@dataclass
class ScoringSignal:
    """Один признак, повлиявший на скоринг — для объяснимости (FR-EXP-002)."""
    name: str
    points: int
    reason: str


@dataclass
class ScoringResult:
    total_score: int
    category: ScoreCategory
    suggested_status: TenderStatus
    signals: list[ScoringSignal] = field(default_factory=list)
    critical_unknowns: list[str] = field(default_factory=list)


def categorize_score(score: int) -> tuple[ScoreCategory, TenderStatus]:
    """Маппинг балла -> категория -> рекомендуемый статус (таблица 6.2 + 6.3 ТЗ)."""
    if score >= 60:
        return ScoreCategory.HIGH_PROBABILITY, TenderStatus.CAN_APPLY
    elif score >= 40:
        return ScoreCategory.MANUAL_REVIEW, TenderStatus.NEEDS_CLARIFICATION
    elif score >= 20:
        return ScoreCategory.RESERVE, TenderStatus.MANUAL_REVIEW
    else:
        return ScoreCategory.LOW_RELEVANCE, TenderStatus.NOT_SUITABLE


# Жёсткие стоп-слова — раздел 20 Приложения А ТЗ.
# Исключение НЕ применяется, если в составе закупки отдельно присутствуют
# алюминиевый прокат/профиль/лист/рулон/труба/шина (см. примечание в ТЗ).
#
# Каждый стоп-маркер задан как пара ключевых слов (глагол/действие + объект),
# а не точная фраза — это устойчивее к реальным формулировкам тендеров
# ("демонтаж старых алюминиевых конструкций" должен матчиться так же,
# как "демонтаж алюминиевых конструкций").
HARD_STOP_PATTERNS: list[tuple[str, str]] = [
    ("демонтаж", "конструкци"),
    ("демонтаж", "алюмини"),
    ("сбор", "лом"),
    ("прием", "лом"),
    ("продажа", "лом"),
    ("реализация", "лом"),
    ("утилизация", "отход"),
    ("утилизация", "лом"),
    ("бытов", "посуд"),
    ("ремонт", "окон"),
    ("установка", "окон"),
    ("ремонт", "радиатор"),
    ("регистрационн", "знак"),
    ("изготовление", "табличк"),
    ("изготовление", "вывес"),
    ("кухонн", "фольг"),
]

# Сохраняем также человекочитаемый список фраз — для логов и отображения причины
HARD_STOP_WORDS = [
    "сбор алюминиевого лома",
    "прием алюминиевого лома",
    "продажа алюминиевого лома",
    "реализация алюминиевого лома",
    "утилизация отходов алюминия",
    "демонтаж алюминиевых конструкций",
    "бытовая алюминиевая посуда",
    "готовые алюминиевые окна",
    "ремонт алюминиевых окон",
    "установка алюминиевых окон",
    "алюминиевые радиаторы отопления",
    "ремонт радиаторов",
    "государственные регистрационные знаки",
    "изготовление табличек",
    "изготовление вывесок",
    "алюминиевая кухонная фольга",
]

# Слова, снижающие рейтинг, но не исключающие тендер — раздел 19 Приложения А
SOFT_IRRELEVANT_WORDS = [
    "алюминиевый радиатор отопления",
    "бытовой радиатор",
    "алюминиевая посуда",
    "кастрюля",
    "сковорода",
    "алюминиевая банка",
    "пищевая фольга бытовая",
    "алюминиевое окно",
    "оконный блок",
    "готовое окно",
    "москитная сетка",
    "жалюзи",
    "лом алюминия",
    "отходы алюминия",
]

# Признаки целевой отрасли (раздел 15 Приложения А, сокращённый список ключевых маркеров).
# Используются основы слов без окончаний, чтобы матчиться независимо от падежа
# ("кабельной промышленности", "кабельная промышленность" и т.д.)
TARGET_INDUSTRY_MARKERS = [
    "кабельн", "электротехническ", "машиностроен", "судостроен",
    "авиастроен", "оборонн", "гоз", "фасад", "приборостроен", "вагоностроен",
]


def has_explicit_aluminum_product(text: str) -> bool:
    """
    Проверка исключения для стоп-слов: если в тексте отдельно упомянут
    алюминиевый прокат/профиль/лист/рулон/труба/шина — стоп-слово не блокирует тендер.

    Паттерны заданы как пары основ слов (действие + изделие), устойчивые
    к падежным окончаниям ("поставкой алюминиевого профиля",
    "поставка алюминиевого проката" и т.п. должны матчиться одинаково).
    """
    action_stems = ["поставк", "изготовлен", "закупк", "продаж"]
    product_stems = [
        "алюминиевый прокат", "алюминиевого проката", "алюминиевый профил",
        "алюминиевого профил", "алюминиевый лист", "алюминиевого лист",
        "алюминиевый рулон", "алюминиевого рулон", "алюминиевая труба",
        "алюминиевой труб", "алюминиевая шина", "алюминиевой шин",
        "алюминиевых изделий",
    ]
    text_lower = text.lower()

    has_action = any(stem in text_lower for stem in action_stems)
    has_product = any(stem in text_lower for stem in product_stems)
    return has_action and has_product


def score_tender(
    text: str,
    has_alloy_match: bool,
    has_dimensions: bool,
    has_volume: bool,
    has_standard_ref: bool,
    has_drawings: bool,
    has_processing_services: bool,
) -> ScoringResult:
    """
    Считает балл тендера по правилам раздела 6.2 ТЗ.

    Текстовые признаки (стоп-слова, отрасль) проверяются по тексту тендера.
    Структурные признаки (alloy_match, dimensions и т.д.) передаются как
    булевы флаги — они вычисляются заранее на основе извлечённых полей
    (см. app/llm/extraction.py), чтобы не дублировать LLM-логику здесь.
    """
    signals: list[ScoringSignal] = []
    total = 0
    text_lower = text.lower()

    # Точное совпадение продукции — наличие любого ключевого товара.
    # ВАЖНО: не засчитываем этот балл, если упоминание алюминия идёт исключительно
    # в нерелевантном контексте (посуда, окна, лом и т.п.) — иначе бытовая закупка
    # кастрюль получает +20 только за слово "алюминиевый".
    product_keywords = ["алюмини", "aluminium", "aluminum"]
    soft_hits_preview = [w for w in SOFT_IRRELEVANT_WORDS if w in text_lower]
    mentions_aluminum = any(kw in text_lower for kw in product_keywords)
    if mentions_aluminum and not soft_hits_preview:
        total += SCORE_RULES["exact_product_match"]
        signals.append(ScoringSignal(
            "exact_product_match", SCORE_RULES["exact_product_match"],
            "В тексте упоминается алюминиевая продукция"
        ))

    if has_alloy_match:
        total += SCORE_RULES["alloy_match"]
        signals.append(ScoringSignal(
            "alloy_match", SCORE_RULES["alloy_match"], "Указана марка сплава из справочника"
        ))

    if has_dimensions:
        total += SCORE_RULES["has_dimensions"]
        signals.append(ScoringSignal(
            "has_dimensions", SCORE_RULES["has_dimensions"], "Указаны размеры продукции"
        ))

    if has_volume:
        total += SCORE_RULES["has_volume"]
        signals.append(ScoringSignal(
            "has_volume", SCORE_RULES["has_volume"], "Указан объём в кг/т"
        ))

    if has_standard_ref:
        total += SCORE_RULES["has_standard"]
        signals.append(ScoringSignal(
            "has_standard", SCORE_RULES["has_standard"], "Указана ссылка на ГОСТ/ОСТ/ТУ"
        ))

    if has_drawings:
        total += SCORE_RULES["has_drawings"]
        signals.append(ScoringSignal(
            "has_drawings", SCORE_RULES["has_drawings"], "Приложены чертежи/спецификация"
        ))

    if has_processing_services:
        total += SCORE_RULES["has_processing_services"]
        signals.append(ScoringSignal(
            "has_processing_services", SCORE_RULES["has_processing_services"],
            "Требуются услуги обработки (резка/окраска/профилирование)"
        ))

    supply_words = ["поставка", "изготовление", "закупка"]
    if any(w in text_lower for w in supply_words):
        total += SCORE_RULES["supply_wording"]
        signals.append(ScoringSignal(
            "supply_wording", SCORE_RULES["supply_wording"],
            "Формулировка соответствует поставке/изготовлению/закупке"
        ))

    if any(marker in text_lower for marker in TARGET_INDUSTRY_MARKERS):
        total += SCORE_RULES["target_industry"]
        signals.append(ScoringSignal(
            "target_industry", SCORE_RULES["target_industry"],
            "Заказчик относится к целевой отрасли"
        ))

    soft_hits = soft_hits_preview
    if soft_hits:
        total += SCORE_RULES["irrelevant_word"]
        signals.append(ScoringSignal(
            "irrelevant_word", SCORE_RULES["irrelevant_word"],
            f"Найдены нерелевантные формулировки: {', '.join(soft_hits[:3])}"
        ))

    hard_hits = [pattern for pattern in HARD_STOP_PATTERNS
                 if pattern[0] in text_lower and pattern[1] in text_lower]
    critical_unknowns = []
    if hard_hits and not has_explicit_aluminum_product(text):
        total += SCORE_RULES["hard_stop_word"]
        signals.append(ScoringSignal(
            "hard_stop_word", SCORE_RULES["hard_stop_word"],
            f"Жёсткое стоп-сочетание без явного упоминания алюминиевого проката: "
            f"'{hard_hits[0][0]}' + '{hard_hits[0][1]}'"
        ))
    elif hard_hits:
        critical_unknowns.append(
            f"Найдено стоп-сочетание '{hard_hits[0][0]} + {hard_hits[0][1]}', но также "
            f"упомянут алюминиевый прокат — требуется проверка специалиста"
        )

    category, suggested_status = categorize_score(total)

    return ScoringResult(
        total_score=total,
        category=category,
        suggested_status=suggested_status,
        signals=signals,
        critical_unknowns=critical_unknowns,
    )
