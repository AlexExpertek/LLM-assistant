"""
OCR и извлечение текста из документов. Реализует раздел 5.3 ТЗ.

Поддерживаемые типы (FR-DOC-002): PDF (текстовый и скан), DOCX, XLSX,
изображения JPG/PNG/TIFF.

Принцип FR-DOC-004: при низкой уверенности OCR поле помечается
"требует проверки", значение не подменяется.
"""
import io
from dataclasses import dataclass
from pathlib import Path

import fitz  # pymupdf
import pytesseract
from docx import Document as DocxDocument
from openpyxl import load_workbook
from PIL import Image

from app.core.logging import get_logger
from app.models.database import OCRStatus

logger = get_logger(__name__)

# Порог уверенности Tesseract (0-100), ниже которого страница помечается
# как low_confidence — используется для FR-DOC-004
TESSERACT_CONFIDENCE_THRESHOLD = 60


@dataclass
class PageExtraction:
    page_number: int
    text: str
    confidence: float  # 0-100, для текстовых PDF всегда 100
    is_scanned: bool


@dataclass
class ExtractionResult:
    full_text: str
    pages: list[PageExtraction]
    status: OCRStatus
    pages_count: int


def _extract_pdf_text_layer(pdf_path: str) -> list[PageExtraction]:
    """Пытается извлечь текст из PDF напрямую (без OCR) — для текстовых PDF."""
    pages = []
    doc = fitz.open(pdf_path)
    for i, page in enumerate(doc):
        text = page.get_text().strip()
        pages.append(PageExtraction(
            page_number=i + 1,
            text=text,
            confidence=100.0 if text else 0.0,
            is_scanned=(len(text) < 20),  # почти нет текста -> вероятно скан
        ))
    doc.close()
    return pages


def _ocr_pdf_page(pdf_path: str, page_number: int) -> PageExtraction:
    """OCR одной страницы PDF через рендер в изображение + Tesseract."""
    doc = fitz.open(pdf_path)
    page = doc[page_number - 1]

    # Рендерим страницу в изображение с увеличенным DPI для лучшего качества OCR
    pix = page.get_pixmap(dpi=300)
    img_data = pix.tobytes("png")
    image = Image.open(io.BytesIO(img_data))
    doc.close()

    return _ocr_image(image, page_number)


def _ocr_image(image: Image.Image, page_number: int = 1) -> PageExtraction:
    """OCR изображения через Tesseract с русским языком, с оценкой уверенности."""
    ocr_data = pytesseract.image_to_data(
        image, lang="rus+eng", output_type=pytesseract.Output.DICT
    )

    words = []
    confidences = []
    for i, word in enumerate(ocr_data["text"]):
        if word.strip():
            words.append(word)
            conf = int(ocr_data["conf"][i])
            if conf >= 0:  # tesseract возвращает -1 для строк без текста
                confidences.append(conf)

    text = " ".join(words)
    avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0

    return PageExtraction(
        page_number=page_number,
        text=text,
        confidence=avg_confidence,
        is_scanned=True,
    )


def extract_pdf(pdf_path: str) -> ExtractionResult:
    """
    Главная функция обработки PDF.
    Сначала пробует текстовый слой, для страниц без текста — запускает OCR.
    """
    text_pages = _extract_pdf_text_layer(pdf_path)

    final_pages: list[PageExtraction] = []
    has_low_confidence = False

    for tp in text_pages:
        if tp.is_scanned:
            logger.info("ocr_fallback_triggered", page=tp.page_number, pdf=pdf_path)
            ocr_page = _ocr_pdf_page(pdf_path, tp.page_number)
            if ocr_page.confidence < TESSERACT_CONFIDENCE_THRESHOLD:
                has_low_confidence = True
                logger.warning(
                    "ocr_low_confidence",
                    page=tp.page_number,
                    confidence=ocr_page.confidence,
                )
            final_pages.append(ocr_page)
        else:
            final_pages.append(tp)

    full_text = "\n\n".join(p.text for p in final_pages)
    status = OCRStatus.LOW_CONFIDENCE if has_low_confidence else OCRStatus.DONE

    return ExtractionResult(
        full_text=full_text,
        pages=final_pages,
        status=status,
        pages_count=len(final_pages),
    )


def extract_docx(docx_path: str) -> ExtractionResult:
    """Извлечение текста из Word-документа, включая таблицы."""
    doc = DocxDocument(docx_path)

    parts = []
    for para in doc.paragraphs:
        if para.text.strip():
            parts.append(para.text)

    for table in doc.tables:
        for row in table.rows:
            row_text = " | ".join(cell.text.strip() for cell in row.cells)
            if row_text.strip(" |"):
                parts.append(row_text)

    full_text = "\n".join(parts)

    return ExtractionResult(
        full_text=full_text,
        pages=[PageExtraction(page_number=1, text=full_text, confidence=100.0, is_scanned=False)],
        status=OCRStatus.NOT_REQUIRED,
        pages_count=1,
    )


def extract_xlsx(xlsx_path: str) -> ExtractionResult:
    """
    Извлечение данных из Excel с сохранением привязки "значение -> ячейка"
    (требование FR-DOC-003: связь "поле -> документ -> страница/лист -> фрагмент").
    """
    wb = load_workbook(xlsx_path, data_only=True)

    parts = []
    for sheet_name in wb.sheetnames:
        sheet = wb[sheet_name]
        parts.append(f"=== Лист: {sheet_name} ===")
        for row in sheet.iter_rows():
            row_values = []
            for cell in row:
                if cell.value is not None:
                    # сохраняем привязку к ячейке прямо в тексте для последующего извлечения
                    row_values.append(f"{cell.coordinate}={cell.value}")
            if row_values:
                parts.append(" | ".join(row_values))

    full_text = "\n".join(parts)

    return ExtractionResult(
        full_text=full_text,
        pages=[PageExtraction(page_number=1, text=full_text, confidence=100.0, is_scanned=False)],
        status=OCRStatus.NOT_REQUIRED,
        pages_count=len(wb.sheetnames),
    )


def extract_image(image_path: str) -> ExtractionResult:
    """OCR отдельного изображения (JPG/PNG/TIFF)."""
    image = Image.open(image_path)
    page = _ocr_image(image)

    status = (
        OCRStatus.LOW_CONFIDENCE
        if page.confidence < TESSERACT_CONFIDENCE_THRESHOLD
        else OCRStatus.DONE
    )

    return ExtractionResult(
        full_text=page.text,
        pages=[page],
        status=status,
        pages_count=1,
    )


def extract_document(file_path: str) -> ExtractionResult:
    """
    Универсальная точка входа — определяет тип файла по расширению
    и вызывает соответствующий обработчик.
    """
    suffix = Path(file_path).suffix.lower()

    handlers = {
        ".pdf": extract_pdf,
        ".docx": extract_docx,
        ".xlsx": extract_xlsx,
        ".jpg": extract_image,
        ".jpeg": extract_image,
        ".png": extract_image,
        ".tiff": extract_image,
        ".tif": extract_image,
    }

    handler = handlers.get(suffix)
    if not handler:
        raise ValueError(f"Неподдерживаемый тип файла: {suffix}")

    logger.info("extracting_document", path=file_path, type=suffix)
    return handler(file_path)
