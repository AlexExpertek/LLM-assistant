#!/usr/bin/env bash
set -Eeuo pipefail

if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sudo sh
  sudo usermod -aG docker "$USER"
  echo "Docker установлен. Переподключитесь по SSH или выполните: newgrp docker"
  exit 0
fi

docker --version
docker compose version

if [[ ! -f .env ]]; then
  cp .env.example .env
  chmod 600 .env
  echo "Создан .env. Заполните CHANGE_ME значения и повторите запуск."
  exit 0
fi

if grep -q 'CHANGE_ME' .env; then
  echo "Ошибка: в .env остались значения CHANGE_ME"
  exit 1
fi

mkdir -p storage
docker compose config >/dev/null
docker compose up --build -d
docker compose exec app alembic upgrade head
docker compose ps
curl --fail http://localhost:8000/health/ready
