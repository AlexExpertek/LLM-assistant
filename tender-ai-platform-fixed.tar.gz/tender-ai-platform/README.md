# Tender AI Platform

MVP автоматизированного LLM-ассистента для мониторинга и первичной оценки тендеров.

## Быстрый запуск на Ubuntu 22.04

```bash
git clone <URL_РЕПОЗИТОРИЯ> tender-ai-platform
cd tender-ai-platform
chmod +x scripts/install.sh
./scripts/install.sh
```

При первом запуске скрипт установит Docker и попросит переподключиться по SSH. При втором — создаст `.env`. Заполните все значения `CHANGE_ME`, затем снова выполните:

```bash
./scripts/install.sh
```

Скрипт проверит конфигурацию, соберёт контейнеры, применит готовые миграции и вызовет readiness-проверку.

## Ручной запуск

```bash
cp .env.example .env
chmod 600 .env
nano .env
mkdir -p storage
docker compose config
docker compose up --build -d
docker compose exec app alembic upgrade head
curl --fail http://localhost:8000/health/ready
```

## Доступ к API и Flower

По умолчанию порты доступны только на сервере через `127.0.0.1`. Используйте SSH-туннель:

```bash
ssh -L 8000:localhost:8000 -L 5555:localhost:5555 user@SERVER_IP
```

После этого локально доступны:

- `http://localhost:8000/docs`
- `http://localhost:5555`

## Проверки

```bash
docker compose ps
docker compose logs --tail=200 app
docker compose logs --tail=200 celery_worker
docker compose exec app pytest tests/ -v
curl http://localhost:8000/health/live
curl http://localhost:8000/health/ready
```

## Важно

Адаптер `app/parsers/zakupki_gov.py` по-прежнему содержит безопасную заглушку для ЕИС. Для получения реальных тендеров требуется легальный API агрегатора либо официальный доступ к открытым данным ЕИС. Проект не обходит CAPTCHA или технические ограничения площадок.
