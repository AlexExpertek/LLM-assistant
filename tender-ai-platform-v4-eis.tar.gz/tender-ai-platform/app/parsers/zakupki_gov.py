"""
Адаптер для получения тендеров из ЕИС zakupki.gov.ru через SOAP API.

Использует токен физического лица (individualPerson_token).
Эндпоинт: https://int44.zakupki.gov.ru/eis-integration/services/getDocsIP

Как добавить токен в .env:
    EIS_TOKEN=11265c3a-3f69-4ce9-8eb4-6225e02944dd
"""
import io
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional
from xml.etree import ElementTree as ET

import httpx

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

EIS_SOAP_URL = "https://int44.zakupki.gov.ru/eis-integration/services/getDocsIP"

TARGET_OKPD2 = [
    "24.42.22", "24.42.23", "24.42.24",
    "24.42.25", "24.42.26", "24.42.11",
]

KEYWORDS = [
    "алюминиев", "алюминий", "aluminium", "aluminum",
    "лента алюм", "лист алюм", "профиль алюм",
    "труба алюм", "пруток алюм", "прокат цветн",
]

SOAP_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:ws="http://zakupki.gov.ru/eis/types/ws/1">
  <soapenv:Header>
    <ws:individualPerson_token>{token}</ws:individualPerson_token>
  </soapenv:Header>
  <soapenv:Body>
    <ws:getDocsByDateChangeRequest>
      <ws:index>
        <ws:registrationNumber/>
        <ws:packageType>{package_type}</ws:packageType>
        <ws:docType/>
        <ws:organCode/>
        <ws:regionCode/>
        <ws:dateFrom>{date_from}</ws:dateFrom>
        <ws:dateTo>{date_to}</ws:dateTo>
      </ws:index>
    </ws:getDocsByDateChangeRequest>
  </soapenv:Body>
</soapenv:Envelope>"""

SOAP_BY_NUMBER = """<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:ws="http://zakupki.gov.ru/eis/types/ws/1">
  <soapenv:Header>
    <ws:individualPerson_token>{token}</ws:individualPerson_token>
  </soapenv:Header>
  <soapenv:Body>
    <ws:getDocsByReestrNumberRequest>
      <ws:reestrNumber>{registry_number}</ws:reestrNumber>
    </ws:getDocsByReestrNumberRequest>
  </soapenv:Body>
</soapenv:Envelope>"""


def _get_token() -> str:
    token = getattr(settings, "eis_token", "")
    if not token:
        raise ValueError(
            "EIS_TOKEN не задан в .env. "
            "Добавьте строку: EIS_TOKEN=ВАШ_ТОКЕН"
        )
    return token


def _soap_request(body: str) -> bytes:
    headers = {"Content-Type": "text/xml; charset=utf-8", "SOAPAction": ""}
    with httpx.Client(timeout=60.0, verify=True) as client:
        r = client.post(EIS_SOAP_URL, content=body.encode("utf-8"), headers=headers)
        r.raise_for_status()
        return r.content


def _parse_soap_urls(raw: bytes) -> list[str]:
    """Извлекает URL архивов из SOAP ответа ЕИС."""
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        return []
    urls = []
    for elem in root.iter():
        tag = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
        if tag in ("url", "href", "archiveUrl", "documentUrl"):
            if elem.text and elem.text.strip().startswith("http"):
                urls.append(elem.text.strip())
    return urls


def _download_zip(url: str) -> list[tuple[str, bytes]]:
    """Скачивает ZIP и возвращает список (имя_файла, содержимое)."""
    try:
        token = _get_token()
        with httpx.Client(timeout=120.0) as client:
            r = client.get(url, headers={"usertoken": token}, follow_redirects=True)
            r.raise_for_status()
        with zipfile.ZipFile(io.BytesIO(r.content)) as zf:
            return [(n, zf.read(n)) for n in zf.namelist() if not n.endswith("/")]
    except Exception as e:
        logger.error("zip_download_failed", url=url[:80], error=str(e))
        return []


def _parse_xml(xml_bytes: bytes) -> dict:
    """
    Парсит XML извещения ЕИС.
    Поддерживает форматы 44-ФЗ и 223-ФЗ.
    Возвращает словарь с основными полями тендера.
    """
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError:
        return {}

    def find_text(*tags) -> Optional[str]:
        """Ищет текст элемента по возможным именам тегов."""
        for tag in tags:
            for elem in root.iter():
                local = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
                if local == tag and elem.text:
                    return elem.text.strip()
        return None

    def find_all_text(tag) -> list[str]:
        result = []
        for elem in root.iter():
            local = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
            if local == tag and elem.text:
                result.append(elem.text.strip())
        return result

    # Номер закупки
    registry_number = find_text(
        "registrationNumber", "notificationNumber", "purchaseNumber"
    )

    # Название
    title = find_text(
        "purchaseObjectInfo", "subject", "purchaseName",
        "objectOfPurchase", "name"
    )

    # Заказчик
    customer_name = find_text("fullName", "organizationName", "customerFullName")
    customer_inn = find_text("INN", "inn")

    # НМЦК
    nmck_str = find_text("maxPrice", "initialContractPrice", "nmck", "price")
    nmck = None
    if nmck_str:
        try:
            nmck = float(nmck_str.replace(",", ".").replace(" ", ""))
        except ValueError:
            pass

    # Срок подачи заявок
    deadline = find_text(
        "applicationEndDate", "submissionCloseDateTime",
        "requestEndDate", "collectingEndDate"
    )

    # Регион
    region = find_text("regionName", "deliveryPlace", "region")

    # ОКПД2
    okpd2_codes = find_all_text("OKPD2code") or find_all_text("okdpCode") or []
    okpd2 = okpd2_codes[0] if okpd2_codes else ""

    # Описание для фильтрации
    description = find_text("purchaseObjectInfo", "lotSubject", "description") or ""

    return {
        "registry_number": registry_number or "",
        "title": title or "",
        "customer_name": customer_name,
        "customer_inn": customer_inn,
        "nmck": nmck,
        "submission_deadline": deadline,
        "region": region,
        "okpd2": okpd2,
        "description": description,
    }


def _matches_our_products(title: str, description: str = "") -> bool:
    """Первичная фильтрация по ключевым словам."""
    text = f"{title} {description}".lower()
    return any(kw in text for kw in KEYWORDS)


def _okpd2_matches(okpd2: str) -> bool:
    if not okpd2:
        return False
    return any(okpd2.startswith(code) for code in TARGET_OKPD2)


def _process_archive(url: str, law: str) -> Optional[dict]:
    """Скачивает архив, парсит XML, фильтрует."""
    files = _download_zip(url)
    if not files:
        return None

    # Ищем главный XML файл извещения
    xml_content = None
    doc_urls = []

    for filename, content in files:
        ext = Path(filename).suffix.lower()
        if ext == ".xml":
            xml_content = content
        elif ext in (".pdf", ".docx", ".xlsx"):
            doc_urls.append(f"__archive__{url}#{filename}")

    if not xml_content:
        return None

    parsed = _parse_xml(xml_content)
    if not parsed.get("registry_number"):
        return None

    # Фильтрация
    title = parsed.get("title", "")
    description = parsed.get("description", "")
    okpd2 = parsed.get("okpd2", "")

    if not _okpd2_matches(okpd2) and not _matches_our_products(title, description):
        return None

    reg_num = parsed.get("registry_number", "")
    return {
        "source": "zakupki_gov_ru",
        "external_id": reg_num,
        "title": title,
        "customer_name": parsed.get("customer_name"),
        "customer_inn": parsed.get("customer_inn"),
        "amount": parsed.get("nmck"),
        "region": parsed.get("region"),
        "source_url": (
            f"https://zakupki.gov.ru/epz/order/notice/ea20/view/"
            f"common-info.html?regNumber={reg_num}"
        ),
        "submission_deadline": parsed.get("submission_deadline"),
        "law_type": law,
        "document_urls": doc_urls,
    }


def fetch_new_tenders(days_back: int = 1) -> list[dict]:
    """
    Главная функция — получает тендеры из ЕИС за последние N дней.
    Вызывается tasks_parsing.monitor_source каждую ночь в 03:00.
    """
    now = datetime.now(timezone.utc)
    date_from = now - timedelta(days=days_back)
    date_to = now

    logger.info("eis_fetch_started",
                date_from=date_from.date().isoformat(),
                date_to=date_to.date().isoformat())

    results = []
    errors = 0

    for pkg_type, law in [("epNotification44", "44-FZ"), ("epNotification223", "223-FZ")]:
        try:
            body = SOAP_TEMPLATE.format(
                token=_get_token(),
                package_type=pkg_type,
                date_from=date_from.strftime("%Y-%m-%dT00:00:00+03:00"),
                date_to=date_to.strftime("%Y-%m-%dT23:59:59+03:00"),
            )
            response = _soap_request(body)
            urls = _parse_soap_urls(response)

            logger.info("eis_archives_received", pkg=pkg_type, count=len(urls))

            for url in urls:
                try:
                    tender = _process_archive(url, law)
                    if tender:
                        results.append(tender)
                        logger.info("tender_accepted",
                                    external_id=tender["external_id"],
                                    title=tender["title"][:60])
                except Exception as e:
                    logger.error("archive_error", url=url[:80], error=str(e))
                    errors += 1

        except ValueError as e:
            logger.error("eis_config_error", error=str(e))
            return []
        except httpx.HTTPError as e:
            logger.error("eis_http_error", pkg=pkg_type, error=str(e))
            errors += 1

    logger.info("eis_fetch_done", found=len(results), errors=errors)
    return results


def fetch_tender_by_number(registry_number: str) -> Optional[dict]:
    """
    Получает конкретный тендер по реестровому номеру.
    Используется при анализе по ссылке.
    """
    try:
        body = SOAP_BY_NUMBER.format(
            token=_get_token(),
            registry_number=registry_number,
        )
        response = _soap_request(body)
        urls = _parse_soap_urls(response)
        if urls:
            return _process_archive(urls[0], "44-FZ")
    except Exception as e:
        logger.error("fetch_by_number_failed", number=registry_number, error=str(e))
    return None
