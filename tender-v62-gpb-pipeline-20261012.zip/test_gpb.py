"""Offline contract tests: no network, databases, queues or LLM."""
import copy
import json
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch
from urllib.parse import parse_qs,urlsplit
from app.sources.gpb.card import decode_store, inspect_store
from app.sources.gpb.adapter import build_card, references
from app.sources.gpb.transport import valid_url, fetch
from app.marketplace_discovery.primary.gpb_search import search

NOW=datetime(2026,10,12,tzinfo=timezone.utc)
URL='https://etpgpb.ru/procedures/etp/1297476-materialy-dlya-ehz/'
FIX=json.loads((Path(__file__).parent/'fixture.json').read_text())

class Contracts(unittest.TestCase):
    def test_real_card(self):
        card=build_card(FIX,'2073064',URL,NOW)
        self.assertEqual(len(card.documents),6)
        self.assertEqual(len(card.raw_payload['positions']),21)
        self.assertTrue(card.raw_payload['gpb']['participation_unknown'])
        self.assertFalse(card.raw_payload['gpb']['all_positions_required'])
        self.assertTrue(all(d.name.endswith(('.xlsx','.docx')) for d in card.documents))
    def test_expired(self):
        self.assertIsNone(build_card(FIX,'2073064',URL,datetime(2026,11,1,tzinfo=timezone.utc)))
    def test_wrong_identity(self):
        with self.assertRaises(ValueError): build_card(FIX,'1',URL,NOW)
    def test_multi_lot(self):
        data=copy.deepcopy(FIX);data['lots']*=2
        with self.assertRaises(ValueError):build_card(data,'2073064',URL,NOW)
    def test_missing_doc_attrs(self):
        data=copy.deepcopy(FIX);data['lots'][0]['relationships']['docs']['data'][0].pop('attributes')
        with self.assertRaises(ValueError):build_card(data,'2073064',URL,NOW)
    def test_nuxt_roundtrip(self):
        pool=[]
        def pack(v):
            i=len(pool);pool.append(None)
            if isinstance(v,dict):pool[i]={k:pack(x) for k,x in v.items()}
            elif isinstance(v,list):pool[i]=[pack(x) for x in v]
            else:pool[i]=v
            return i
        value=pack(FIX);wrap=len(pool);pool.append(['Reactive',value]);pool.append({'PROCEDURES_ID_STORE':wrap})
        self.assertEqual(decode_store('<script id="__NUXT_DATA__">'+json.dumps(pool)+'</script>'),FIX)
    def test_url_scope(self):
        self.assertFalse(valid_url('https://evil.example/file/get/a',True))
        self.assertFalse(valid_url('https://etp.gpb.ru:444/file/get/a',True))
        self.assertFalse(valid_url('http://etp.gpb.ru/file/get/a',True))
        self.assertFalse(valid_url('https://etp.gpb.ru@evil.example/file/get/a',True))
    def test_empty_response(self):
        class R: returncode=0;stdout=b'';stderr=b'GPB_HTTP:200'
        with patch('app.sources.gpb.transport.root_pem',return_value=b'cert'),patch('subprocess.run',return_value=R()):
            with self.assertRaisesRegex(ValueError,'download_empty'):fetch('https://etp.gpb.ru/file/get/a',document=True)
    def test_search_ambiguous_title(self):
        def read(url):
            return json.dumps({'data':[{'id':'2073064','attributes':{'title':'Материалы для ЭХЗ', 'stage':'accepting','end_registration':'2026-10-15T16:00:00+03:00','rebranding_truncated_path':urlsplit(URL).path}}], 'meta':{'total_pages':1,'total_count':1}})
        report=search(read=read,now=NOW)
        self.assertEqual(len(report['items']),1)
        self.assertEqual(report['status'],'ok')
    def test_repeat_page(self):
        def read(url):
            return json.dumps({'data':[{'id':'1','attributes':{}}], 'meta':{'total_pages':3,'total_count':50}})
        report=search(read=read,now=NOW)
        self.assertEqual(report['errors'][0]['reason'],'gpb_pagination_repeated')

if __name__=='__main__':unittest.main()
