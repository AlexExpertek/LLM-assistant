import json
from app.marketplace_discovery.primary.collector import folder
from app.workers.celery_app import celery_app
for key,item in celery_app.conf.beat_schedule.items():
    if 'gpb' in str(item.get('args')):
        print('SCHEDULE:',key,item.get('schedule'),'TASK:',item.get('task'),'ARGS:',item.get('args'))
p=folder()/'gpb.json'
print(p.read_text() if p.exists() else 'REPORT: first scheduled run pending')
print('READ_ONLY: no HTTP, DB changes, tasks or LLM')
