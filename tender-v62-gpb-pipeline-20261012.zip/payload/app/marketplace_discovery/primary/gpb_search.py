"""Bounded API search; ambiguous titles are preserved for document analysis."""
import fcntl
import json
from datetime import datetime, timezone
from urllib.parse import urlencode, urljoin
from app.sources.gpb.transport import fetch
from app.sources.gpb.card import deadline, card_path

QUERIES = ('алюминий', 'алюминиевая лента', 'алюминиевый лист', 'алюминиевый профиль',
           'алюминиевая труба', 'алюминиевый пруток', 'алюминиевая шина', 'алюминиевая фольга')


def search(*, previous=None, read=None, now=None):
    previous = previous or {}; read = read or fetch
    now = now or datetime.now(timezone.utc)
    cursor = dict(previous.get('next_pages') or {})
    rotation = int(previous.get('query_rotation') or 0)
    queries = (QUERIES[0], QUERIES[1 + rotation % (len(QUERIES)-1)])
    report = dict(source='gpb', name='ЭТП ГПБ', checked_at=now.isoformat(),
        status='partial', coverage='first_page_plus_two_cursor_pages_per_query',
        items=[], searches=[], skipped={}, errors=[], requests=0,
        next_pages=cursor, query_rotation=rotation+1,
        pipeline_status='read_only_no_handoff')
    found = {}
    for query in queries:
        pages = [1]; tail = max(2, int(cursor.get(query, 2)))
        seen = set(); total_pages = None
        record = dict(query=query, pages=[], complete=False)
        report['searches'].append(record)
        try:
            for page in [1, tail, tail+1]:
                if total_pages is not None and page > total_pages:
                    break
                url = 'https://etpgpb.ru/api/v2/procedures/?' + urlencode({
                    'page':page, 'per':20, 'search':query, 'sort':'by_relevance',
                    'procedure[stage][0]':'accepting'})
                report['requests'] += 1
                payload = json.loads(read(url))
                rows = payload.get('data'); meta = payload.get('meta') or {}
                if not isinstance(rows, list) or not isinstance(meta.get('total_pages'), int):
                    raise ValueError('gpb_search_schema_invalid')
                total_pages = meta['total_pages']
                ids = tuple(str(r.get('id')) for r in rows)
                if rows and (ids in seen):
                    raise ValueError('gpb_pagination_repeated')
                seen.add(ids); record['pages'].append(page)
                record['total'] = meta.get('total_count')
                for row in rows:
                    a = row.get('attributes') or {}; uid = str(row.get('id') or '')
                    end = deadline(a.get('end_registration'))
                    reason = None
                    path = a.get('rebranding_truncated_path') or ''
                    if a.get('stage') != 'accepting': reason = 'not_open'
                    elif end is None: reason = 'deadline_unknown_requires_review'
                    elif end <= now: reason = 'expired'
                    elif path.startswith('/procedures/sale/'): reason = 'sale_not_purchase'
                    else:
                        try: card_path(urljoin('https://etpgpb.ru', path))
                        except ValueError: reason = 'section_requires_adapter'
                    if reason:
                        report['skipped'][reason] = report['skipped'].get(reason,0)+1
                        continue
                    if not uid.isdigit(): raise ValueError('gpb_search_id_invalid')
                    found[uid] = dict(external_id=uid, number=a.get('registry_number'),
                        title=a.get('title'), source_url=urljoin('https://etpgpb.ru',path),
                        submission_deadline=end.isoformat(), source='gpb')
                if page >= total_pages or not rows:
                    cursor[query] = 2
                    record['cycle_finished'] = True
                    record['complete'] = tail == 2 or total_pages <= 1
                    break
                cursor[query] = max(2, page+1)
            if not record.get('cycle_finished'):
                record['reason'] = 'page_limit'
        except Exception as exc:
            report['errors'].append({'query':query,'reason':str(exc) if isinstance(exc,ValueError) else type(exc).__name__})
    report['items'] = list(found.values())
    if not report['errors'] and all(r['complete'] for r in report['searches']):
        report['status'] = 'ok' if found else 'no_matches_in_checked_filters'
    return report


def collect_gpb(*, persist=True, fetch=None):
    from .collector import folder, save_report
    path = folder() / 'gpb.json'
    try: previous = json.loads(path.read_text())
    except FileNotFoundError: previous = {}
    if not persist:
        return search(previous=previous, read=fetch)
    folder().mkdir(parents=True, exist_ok=True)
    with (folder()/'gpb.lock').open('a') as lock:
        try: fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            return {'source':'gpb', 'status':'already_running', 'items':[]}
        # Reload cursor inside lock.
        try: previous = json.loads(path.read_text())
        except FileNotFoundError: previous = {}
        report = search(previous=previous, read=fetch)
        from app.sources.gpb.dispatch import drain
        backlog = drain((previous.get('items') or []) + report['items'])
        report.update(pipeline=backlog['outcomes'], backlog_pending=backlog['pending'],
                      pipeline_status='automatic_bounded_handoff')
        save_report('gpb', report)
        return report
