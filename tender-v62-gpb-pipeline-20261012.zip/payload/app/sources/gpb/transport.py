"""Verified TLS, curl HTTP/1.1; no redirects or cookie/session reuse."""
import hashlib
import re
import ssl
import subprocess
from functools import lru_cache
from urllib.parse import urlsplit
import httpx

CA_URL = 'https://gu-st.ru/content/Other/doc/russian_trusted_root_ca.cer'
CA_SHA256 = 'D26D2D0231B7C39F92CC738512BA54103519E4405D68B5BD703E9788CA8ECF31'

@lru_cache(maxsize=1)
def root_pem():
    with httpx.Client(timeout=30, follow_redirects=False) as client:
        with client.stream('GET', CA_URL) as response:
            response.raise_for_status()
            content = bytearray()
            for chunk in response.iter_bytes():
                content.extend(chunk)
                if len(content) > 131072:
                    raise ValueError('gpb_ca_size_limit')
    content = bytes(content)
    if b'-----BEGIN CERTIFICATE-----' in content:
        blocks = re.findall(rb'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----', content, re.S)
        if len(blocks) != 1:
            raise ValueError('gpb_ca_count')
        pem = blocks[0].decode('ascii')
        der = ssl.PEM_cert_to_DER_cert(pem)
    else:
        der = content
        pem = ssl.DER_cert_to_PEM_cert(der)
    if hashlib.sha256(der).hexdigest().upper() != CA_SHA256:
        raise ValueError('gpb_ca_fingerprint_mismatch')
    return pem.encode('ascii')

def valid_url(url, document=False):
    try:
        p = urlsplit(url)
        host = 'etp.gpb.ru' if document else 'etpgpb.ru'
        return (p.scheme == 'https' and p.hostname == host and not p.username
                and not p.password and p.port in (None, 443) and not p.fragment
                and (p.path.startswith('/file/get/') if document else
                     (p.path.startswith('/procedures/') or p.path == '/api/v2/procedures/')))
    except ValueError:
        return False

def fetch(url, *, document=False, max_bytes=None):
    if not valid_url(url, document):
        raise ValueError('gpb_unexpected_host_or_path')
    limit = max_bytes or (20 * 1024 * 1024 if document else 4 * 1024 * 1024)
    args = ['curl', '--disable', '--silent', '--show-error', '--http1.1',
            '--connect-timeout', '15', '--max-time', '45', '--max-filesize', str(limit),
            '--proto', '=https', '--output', '-', '--write-out', '%{stderr}\nGPB_HTTP:%{http_code}\n']
    pem = None
    if document:
        pem = root_pem()
        args.extend(['--cacert', '/dev/stdin'])
    args.append(url)
    try:
        result = subprocess.run(args, input=pem, capture_output=True, timeout=50)
    except FileNotFoundError:
        raise ValueError('gpb_curl_missing') from None
    except subprocess.TimeoutExpired:
        raise ValueError('gpb_download_timeout') from None
    if result.returncode:
        raise ValueError('gpb_curl_error_' + str(result.returncode))
    match = re.search(rb'GPB_HTTP:(\d{3})', result.stderr)
    status = int(match[1]) if match else 0
    if status != 200:
        raise ValueError('gpb_http_' + str(status))
    if not result.stdout:
        raise ValueError('gpb_document_download_empty' if document else 'gpb_empty_response')
    if len(result.stdout) > limit:
        raise ValueError('gpb_response_size_limit')
    return result.stdout
