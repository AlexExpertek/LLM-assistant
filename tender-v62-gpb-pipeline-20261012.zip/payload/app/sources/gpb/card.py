"""Decode Nuxt reference pool without executing JavaScript."""
import json
import re
from datetime import datetime, timezone
from urllib.parse import urlsplit
from bs4 import BeautifulSoup


def deadline(value):
    try:
        d = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        return d.astimezone(timezone.utc) if d.tzinfo else None
    except (ValueError, TypeError):
        return None


def card_path(url):
    p = urlsplit(url)
    if (p.scheme != 'https' or p.hostname != 'etpgpb.ru' or p.username or p.password
            or p.port not in (None, 443) or p.query or p.fragment):
        raise ValueError('gpb_card_url_invalid')
    if not re.fullmatch(r'/procedures/(?:etp|price_request)/\d+-[^/]+/', p.path):
        raise ValueError('gpb_card_section_requires_adapter')
    return p.path


def decode_store(html):
    soup = BeautifulSoup(html, 'html.parser')
    script = soup.find('script', id='__NUXT_DATA__')
    if script is None:
        raise ValueError('gpb_nuxt_data_missing')
    pool = json.loads(script.string or script.get_text())
    if not isinstance(pool, list) or len(pool) > 100000:
        raise ValueError('gpb_nuxt_format')
    count = [0]
    def resolve(ref, trail=()):
        count[0] += 1
        if count[0] > 200000 or len(trail) > 100:
            raise ValueError('gpb_nuxt_decode_limit')
        if not isinstance(ref, int) or isinstance(ref, bool):
            raise ValueError('gpb_nuxt_reference_type')
        if ref in (-1, -2):
            return None
        if ref < 0 or ref >= len(pool):
            raise ValueError('gpb_nuxt_unknown_reference')
        if ref in trail:
            return {'reference': ref}
        value = pool[ref]
        trail = trail + (ref,)
        if isinstance(value, dict):
            return {k: resolve(v, trail) for k, v in value.items()}
        if isinstance(value, list):
            if value and isinstance(value[0], str):
                if value[0] in ('Ref', 'ShallowRef', 'Reactive', 'ShallowReactive'):
                    return resolve(value[1], trail)
                if value[0] == 'EmptyRef':
                    return None
                raise ValueError('gpb_nuxt_unknown_wrapper')
            return [resolve(v, trail) for v in value]
        return value
    matches = [v['PROCEDURES_ID_STORE'] for v in pool
               if isinstance(v, dict) and 'PROCEDURES_ID_STORE' in v]
    if len(matches) != 1:
        raise ValueError('gpb_procedure_store_ambiguous')
    result = resolve(matches[0])
    if not isinstance(result, dict):
        raise ValueError('gpb_procedure_store_invalid')
    return result


def relation(obj, name):
    value = (obj.get('relationships') or {}).get(name, {}).get('data')
    return value


def inspect_store(store, external_id, url, now=None):
    path = card_path(url)
    proc = store.get('procedure') or {}
    attrs = proc.get('attributes') or {}
    if str(proc.get('id')) != str(external_id):
        raise ValueError('gpb_procedure_identity_mismatch')
    if attrs.get('rebranding_truncated_path') != path:
        raise ValueError('gpb_procedure_path_mismatch')
    if attrs.get('archive') or attrs.get('stage') != 'accepting':
        return None
    if attrs.get('method_sale') or attrs.get('human_method_sale'):
        return None
    lots = store.get('lots')
    if not isinstance(lots, list) or len(lots) != 1:
        raise ValueError('gpb_multi_lot_or_missing_lot_requires_review')
    lot = lots[0]
    la = lot.get('attributes') or {}
    end = deadline(la.get('date_end_registration'))
    if end is None:
        raise ValueError('gpb_deadline_unknown')
    if end <= (now or datetime.now(timezone.utc)):
        return None
    units = relation(lot, 'units')
    if not isinstance(units, list):
        raise ValueError('gpb_positions_missing')
    positions = []
    seen = set()
    for unit in units:
        uid = str(unit.get('id') or '')
        ua = unit.get('attributes')
        if not uid or uid in seen or not isinstance(ua, dict):
            raise ValueError('gpb_positions_incomplete')
        seen.add(uid)
        positions.append({'source_unit_id': uid, 'lot_id': str(lot['id']), **ua})
    # Only actual position_control value is evidence, never its translation dictionary.
    control = la.get('position_control')
    return dict(procedure=proc, lot=lot, positions=positions, deadline=end,
                all_positions_required=control == 'all_position',
                participation_unknown=control not in ('all_position', 'min_one_position'))
