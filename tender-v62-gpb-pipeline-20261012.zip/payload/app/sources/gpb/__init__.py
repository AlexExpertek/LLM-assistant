"""GPB public search and bounded document pipeline."""
