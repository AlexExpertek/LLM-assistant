import json
from app.marketplace_discovery.primary.gpb_search import collect_gpb
report=collect_gpb(persist=False)
print(json.dumps(report,ensure_ascii=False,default=str,indent=2))
print('READ_ONLY: HTTP search only; no files, DB writes, queues, OCR, LLM or notifications')
