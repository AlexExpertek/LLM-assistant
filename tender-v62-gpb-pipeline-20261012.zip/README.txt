GPB integration, 2026-10-12

Install from the existing tender-ai-platform-v6.2 project root:
  bash /tmp/tender-v62-gpb-pipeline-20261012/install.sh
The installer validates all baseline hashes before any source write, creates a
backup, builds app/celery_worker/celery_discovery, runs offline tests, checks curl,
and recreates these services. Beat schedule is not changed. Scheduled GPB runs
will use the new pipeline once the discovery worker is recreated.

Checks:
  docker compose exec -T celery_discovery python - < /tmp/tender-v62-gpb-pipeline-20261012/check_live.py
  docker compose exec -T celery_discovery python - < /tmp/tender-v62-gpb-pipeline-20261012/check_documents.py
  docker compose exec -T celery_discovery python - < /tmp/tender-v62-gpb-pipeline-20261012/check_status.py
check_live performs public search only. check_documents downloads two example
files and extracts text to temporary files, then deletes them. Neither enqueues
analysis or writes to the database.
run_once.py explicitly performs a real collection and bounded handoff; it can
write DB indirectly through Celery and run OCR/LLM. Notifications are suppressed.

Supported automatic path: search API -> etpgpb.ru public /etp/ or /price_request/
card -> one lot -> fully hydrated positions and documentation -> verified curl
download -> existing OCR/extraction/scoring/dashboard pipeline. Other sections,
missing deadlines and multi-lot procedures are reported, not claimed covered.
Known sale paths and closed/expired cards are skipped. No title-only product
rejection. At most two new cards handed off per run; pending candidates persist.
Completed analyses and manual dismissals use existing guards.
Unknown partial-bid rules force manual review of otherwise eligible results.
The existing per-position weight and product criteria are not modified.

TLS root obtained from official HTTPS URL, fingerprint checked, passed only to
curl calls to etp.gpb.ru. No global trust changes, no verify=False, no login or
captcha bypass. HTTP redirects stop with a diagnostic. Empty 200 responses fail
explicitly. Documents with the same name remain distinct until actual byte hash
matches; uncertain formats/missing documentation stop analysis, not mark a
procurement unsuitable. Shared extraction errors already seen on other tenders
are not fixed by this package.

Validation: offline tests use the user-provided public card snapshot (21 positions,
6 document references). XLSX transport has been verified on the user's server;
DOCX live extraction and real GPB end-to-end analysis remain to be confirmed.

SOURCE_VERSION_CONFLICT means no changes made; share the filename, do not force
an overwrite. A build/test failure leaves old containers running but changed
source files on disk; use the printed backup if rollback is required.
