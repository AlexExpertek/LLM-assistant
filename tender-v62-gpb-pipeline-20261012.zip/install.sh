#!/usr/bin/env bash
set -Eeuo pipefail
pkg_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
test -f app/sources/document_preparer.py || { echo 'Run from project root'; exit 1; }
python3 "$pkg_dir/apply.py" --project "$PWD"
docker compose build app celery_worker celery_discovery
docker compose run --rm --no-deps -T -e PYTHONPATH=/app -v "$pkg_dir:/gpb-check:ro" celery_discovery python /gpb-check/test_gpb.py
docker compose run --rm --no-deps -T celery_discovery curl --version
docker compose up -d --no-deps --timeout 60 app celery_worker celery_discovery
printf '%s\n' 'GPB_PIPELINE_UPDATE_INSTALLED' 'Existing schedule retained; up to two new cards per run. No immediate collection or notifications.'
