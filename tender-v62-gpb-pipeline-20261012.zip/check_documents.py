"""Two verified example URLs; local temporary extraction only, no LLM/DB/queues."""
import tempfile
from pathlib import Path
from app.sources.gpb.transport import fetch
from app.sources.metal_it.documents import validate_bytes
from app.ocr.pipeline import extract_document
files=[
('upload_positions_form.xlsx','https://etp.gpb.ru/file/get/t/LotDocuments/id/7058810/name/6ac8d5bc722ae8.74935863'),
('Прил1___техническое_задание.docx','https://etp.gpb.ru/file/get/t/LotDocuments/id/7058811/name/6ac8d5bc800cf7.49526262')]
with tempfile.TemporaryDirectory(prefix='gpb-document-check-') as directory:
    for name,url in files:
        data=fetch(url,document=True)
        validate_bytes(data,Path(name).suffix)
        path=Path(directory)/name;path.write_bytes(data)
        result=extract_document(str(path))
        print('FILE:',name,'BYTES:',len(data),'TEXT_CHARACTERS:',len(result.full_text or ''))
        if not (result.full_text or '').strip():raise ValueError('gpb_empty_extraction')
print('DOCUMENTS_OK: temporary files deleted; no DB, queues, LLM or notifications')
