"""Explicit live run: writes report/backlog and can queue up to two analyses."""
import json
from app.marketplace_discovery.primary.gpb_search import collect_gpb
print(json.dumps(collect_gpb(persist=True),ensure_ascii=False,default=str,indent=2))
