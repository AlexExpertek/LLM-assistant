import os
# Offline verification never uses production connection settings.
for k,v in dict(DATABASE_URL='postgresql+asyncpg://test:test@127.0.0.1/test',DATABASE_URL_SYNC='postgresql://test:test@127.0.0.1/test',REDIS_URL='redis://127.0.0.1:6379/0',CELERY_BROKER_URL='memory://',CELERY_RESULT_BACKEND='cache+memory://',QDRANT_URL='http://127.0.0.1:6333').items():os.environ[k]=v
import unittest
from datetime import datetime, timezone, timedelta
from types import SimpleNamespace
from unittest.mock import patch, Mock
from app.marketplace_discovery.product_screening import *
from app.marketplace_discovery import runner
from app.marketplace_discovery.b2b_public import PublicCard
from app.marketplace_discovery.schemas import MarketplaceTender

class Checks(unittest.TestCase):
 def test_explicit_other_titles(self):
  for title in ['Стальной прокат ГОСТ 2590-2006', 'Запасные части для ЛГОК и МГОК по чертежам заказчика', 'Оснастка Пумори', 'Сульфат алюминия технический', 'Кабельная продукция для ООО Клен']:
   with self.subTest(title=title): self.assertTrue(title_excluded(title))
 def test_mixed_preserved(self):
  for title in ['Поставка стального проката и прутка Д16', 'Лист стальной; лист алюминиевый', 'Поставка алюминиевого листа неизвестного сплава']:
   with self.subTest(title=title): self.assertFalse(title_excluded(title));self.assertTrue(aluminium_evidence(title))
 def test_alloy_and_forms(self):
  for title in ['Пруток Д16Т', 'Поставка алюминия', 'Лист АМг2', 'Поставка алюминиевого профиля АД31']:
   self.assertTrue(aluminium_evidence(title))
 def test_no_evidence(self):
  for title in ['Авиамотрная СКТВ (служебка)', 'Поставка металла (лист, круг, уголок)', '24.42.22', 'Оснастка для алюминия', 'Сульфат алюминия', 'Поставка дверей из алюминиевого профиля']:
   self.assertFalse(candidate_relevant({'title':title}))
 def test_public_positions_rescue_generic(self):
  self.assertTrue(candidate_relevant({'title':'Металлопродукция','raw_payload':{'positions':[{'name':'Лист алюминиевый','quantity':600,'unit':'кг'}]}}))
 def run_case(self,title,public=None,error=None,raw_text=''):
  item=MarketplaceTender(platform='b2b_center',external_id='123',title=title,deadline=datetime.now(timezone.utc)+timedelta(days=5),source_url='https://www.b2b-center.ru/market/test/tender-123/',raw_text=raw_text)
  adapter=SimpleNamespace(platform_code='b2b_center',verify=True,timeout=10,search=Mock(return_value=[item]))
  with patch.object(runner,'get_marketplaces',return_value=[adapter]), patch.object(runner,'is_dismissed',return_value=False), patch.object(runner,'remove_candidate'), patch.object(runner,'fetch_public',return_value=public,side_effect=error) as fetch, patch.object(runner,'save_candidate') as save, patch.object(runner,'_already_processed',return_value=False), patch('app.workers.tasks_parsing.process_new_tender') as task:
   task.run.return_value={'status':'saved'}
   stats=runner.run_marketplace_discovery(max_per_platform=1)['b2b_center']
   return stats,fetch.call_count,save.call_count,task.delay.call_count
 def test_steel_no_fetch(self):
  s,f,c,q=self.run_case('Стальной прокат ГОСТ 2590-2006')
  self.assertEqual((f,c,q),(0,0,0));self.assertEqual(s['rejected'],1)
 def test_unknown_incomplete_not_reviewed(self):
  s,f,c,q=self.run_case('Поставка металла',PublicCard())
  self.assertEqual((f,c,q),(1,0,0));self.assertEqual(s['unconfirmed_product'],1)
 def test_unknown_error_not_reviewed(self):
  s,f,c,q=self.run_case('Поставка металла',error=RuntimeError('network'))
  self.assertEqual((c,q),(0,0));self.assertEqual(s['status'],'partial')
 def test_al_incomplete_reviewed(self):
  s,f,c,q=self.run_case('Поставка листа алюминиевого',PublicCard())
  self.assertEqual((c,q),(1,0))
 def test_known_small_positions_rejected(self):
  card=PublicCard(complete=True,positions=[{'name':'Пруток Д16','quantity':300,'unit':'кг'},{'name':'Пруток Д16','quantity':300,'unit':'кг'}])
  s,f,c,q=self.run_case('Металлопродукция',card)
  self.assertEqual((c,q),(0,0));self.assertEqual(s['rejected'],1)
 def test_500kg_queued(self):
  s,f,c,q=self.run_case('Металлопродукция',PublicCard(complete=True,positions=[{'name':'Лист АМг2','quantity':500,'unit':'кг'}]))
  self.assertEqual(q,1)
 def test_description_preserves_mixed_before_fetch(self):
  s,f,c,q=self.run_case('Стальной прокат',PublicCard(complete=True,positions=[{'name':'Пруток Д16','quantity':500,'unit':'кг'}]),raw_text='Также пруток Д16')
  self.assertEqual((f,q),(1,1))
 def test_dashboard_filters_saved_candidates(self):
  from app.reports import review_dashboard as dashboard
  deadline=(datetime.now(timezone.utc)+timedelta(days=5)).isoformat()
  candidates=[{'source':'b2b_center','external_id':str(i),'title':title,'submission_deadline':deadline} for i,title in enumerate(['Стальной прокат','Поставка металла','Пруток Д16'])]
  with patch.object(dashboard,'SyncSessionLocal') as db, patch.object(dashboard,'list_review_candidates',return_value=candidates), patch('app.reports.review_dismissals.is_dismissed',return_value=False):
   db.return_value.__enter__.return_value.execute.return_value.scalars.return_value.all.return_value=[]
   self.assertEqual([x['external_id'] for x in dashboard.get_review_dashboard()['tenders']],['2'])
if __name__=='__main__':unittest.main()

