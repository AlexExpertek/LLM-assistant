"""Read-only screening of stored B2B candidates; no requests/tasks or writes."""
from collections import Counter
from app.marketplace_discovery.review_store import list_review_candidates
from app.marketplace_discovery.product_screening import candidate_relevant
counts=Counter()
for row in list_review_candidates(500):
    if row.get('source') != 'b2b_center': continue
    state='PRODUCT_EVIDENCE' if candidate_relevant(row) else 'HIDDEN_NO_PRODUCT_EVIDENCE'
    counts[state]+=1
    print(state, row.get('external_id'), row.get('title'))
print(dict(counts))
print('READ_ONLY: relevance only; dashboard additionally checks deadlines and dismissals')
