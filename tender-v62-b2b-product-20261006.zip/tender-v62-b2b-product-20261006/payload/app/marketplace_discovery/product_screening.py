"""Conservative B2B product evidence; search hits and missing access are not evidence."""
import re
from app.scoring.selection_policy import ALUMINIUM, material_status
from app.marketplace_discovery.subject_classifier import classify_tender_subject

VERSION = 'b2b-product-20261006'
OTHER = re.compile(r'\b(?:сталь|стальн\w*|кабел\w*|провод\w*|запасн\w*\s+част\w*|оснастк\w*|ветеринар\w*|сульфат\w*|оксид\w*|гидроксид\w*|хлорид\w*)\b', re.I)
CHEMICAL = re.compile(r'\b(?:сульфат\w*|оксид\w*|гидроксид\w*|хлорид\w*|ветеринар\w*)\b', re.I)


def aluminium_evidence(text):
    # Evaluate separate goods independently: steel elsewhere must not veto Al.
    # Do not use classifier codes or arbitrary search matches as product evidence.
    for part in re.split(r'[;\n,]|\s+и\s+', str(text or '')):
        if CHEMICAL.search(part):
            continue
        if material_status({'name': part}) is True:
            return True
        # Bare aluminium procurement can legitimately omit the form/alloy.
        if (ALUMINIUM.search(part) and not OTHER.search(part)
                and classify_tender_subject(part).allowed
                and re.search(r'\b(?:поставка|закупка|закупаем|приобретение)\s+алюмини[яй]\b', part, re.I)):
            return True
    return False


def title_excluded(title, description=''):
    if not classify_tender_subject(title).allowed:
        return True
    # A specific positive product in a search description preserves mixed tenders.
    if aluminium_evidence(title) or aluminium_evidence(description):
        return False
    return bool(OTHER.search(title or ''))


def candidate_relevant(candidate):
    raw = candidate.get('raw_payload') or {}
    positions = raw.get('positions') or []
    if any(isinstance(p, dict) and material_status(p) is True for p in positions):
        return True
    # An explicitly non-target title cannot be rescued by a bare aluminium mention.
    title = candidate.get('title') or ''
    return (not title_excluded(title)
            and aluminium_evidence(title))
