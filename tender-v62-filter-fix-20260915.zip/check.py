from app.marketplace_discovery.business_filter import evaluate_business_rules as evaluate
from app.marketplace_discovery.position_parser import extract_aluminium_positions as parse
from app.marketplace_discovery.subject_classifier import classify_tender_subject as classify

def check():
    for title in (
        'Тендер по остеклению лоджий из алюминиевого профиля ЖК Люмен',
        'Тендер на остекление лоджий из алюминиевого профиля ЖК Ленский в г.Всеволожск',
        'Устройство фасадов ЖК',
    ):
        assert evaluate(title, title).decision == 'works_service', title
    for title in (
        'Поставка алюминиевого профиля для остекления лоджий',
        'Поставка алюминиевого листа для устройства фасадов',
    ):
        assert classify(title).allowed, title
    for text, alloy in (
        ('Лист алюминиевый 1.5х1200х3000 АМг 2М ГОСТ 21631-76', 'АМГ2'),
        ('Пруток алюминиевый круглый Д16Т КР20 ГОСТ 21488-97', 'Д16'),
    ):
        positions = parse(text)
        assert any(p.alloy == alloy for p in positions), text
        assert all(not p.quantity_confirmed for p in positions), text
        assert evaluate(text, text).decision == 'candidate', text
    assert not any(p.alloy for p in parse('Лист алюминиевый Д160 АМГ20'))
    assert evaluate('Лист алюминиевый', 'Лист алюминиевый АМг2 600 кг').relevant
    assert not evaluate('Лист алюминиевый', 'Лист алюминиевый АМг2 100 кг').relevant
    print('HOTFIX_CHECK_OK: 10 cases, no HTTP/DB/LLM calls')

check()
