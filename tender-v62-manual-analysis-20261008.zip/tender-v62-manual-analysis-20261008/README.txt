Manual selection and explicit LLM analysis — 2026-10-08
Requires installed tender-v62-no-repeat-20261008.

Review table: «Подходит к закупке — анализировать».
Selected purchases appear in a separate table on the main dashboard:
«Выбраны вручную к закупке». This is an operator choice, not AI approval.
Existing automatically qualified table/500kg qualification are unchanged.
Selections leave the visible review table and persist through analysis errors.
A successful result displays the actual score and AI decision, including rejection.
Failure displays «Ошибка анализа» and keeps the previously saved score.
The retry button is explicit; automatic no-repeat protection remains enabled.
No Bitrix/Telegram notifications are sent by the manual analysis workflow.

POST /tenders/manual-analysis: source, external_id, X-Review-Action: manual.
GET /tenders/manual-analysis: future, non-dismissed manual selections.
Uses the existing application's access controls and same-origin mutation check.
Does not provide new authentication or a new login system.

Uses saved complete document text or source positions. If neither is available,
tries the installed source adapter and document preparation pipeline. Missing,
restricted or incompletely recognized documents produce a visible analysis error.
No synthetic measurements or approval on failure.
Public marketplace candidates can be ingested without scheduling the old pipeline.
Freshness and dismissal checks remain; expired/unknown-deadline entries cannot be selected.

Queue states stored in shared storage/manual_analysis.sqlite3 (no PostgreSQL migration).
Atomic reservation prevents double clicks; task tokens reject obsolete deliveries.
Task soft/hard limits: 840/900 sec. Missing completion becomes a visible error after
1 hour; only an explicit click retries it. The shared storage mount must remain persistent.
A hard worker crash can therefore remain displayed as running until that interval.

Install: bash install.sh. Hash mismatch stops before any writes. Printed backup
contains replaced source files. Build and 15 offline tests precede recreation.
Refresh the browser page after installation. No analysis is automatically enqueued.
Schedule is unchanged. This archive does not add new marketplace adapters.
Rollback: restore backed-up sources and rebuild/recreate the same services.
Operator selections are preserved in shared storage, not erased on rollback.
