import os
for k,v in dict(DATABASE_URL='postgresql+asyncpg://test:test@127.0.0.1/test',DATABASE_URL_SYNC='postgresql://test:test@127.0.0.1/test',REDIS_URL='redis://127.0.0.1:6379/0',CELERY_BROKER_URL='memory://',CELERY_RESULT_BACKEND='cache+memory://',QDRANT_URL='http://127.0.0.1:6333').items():os.environ[k]=v
import inspect, unittest
from types import SimpleNamespace as NS
from unittest.mock import MagicMock, patch
from app.workers import tasks_scoring as scoring, tasks_ocr as ocr, tasks_parsing as parsing
from app.workers.completed_analysis import has_completed_analysis
from app.marketplace_discovery import runner
class Checks(unittest.TestCase):
 def test_done_needs_no_query(self):
  s=MagicMock();self.assertTrue(has_completed_analysis(s,NS(analysis_done=True)));s.execute.assert_not_called()
 def test_previous_committed_success(self):
  s=MagicMock();s.execute.return_value.scalar_one_or_none.return_value='decision'
  self.assertTrue(has_completed_analysis(s,NS(id='t',analysis_done=False)))
 def test_first_analysis_allowed(self):
  s=MagicMock();s.execute.return_value.scalar_one_or_none.return_value=None
  self.assertFalse(has_completed_analysis(s,NS(id='t',analysis_done=False)))
  self.assertFalse(has_completed_analysis(s,None))
 def test_queued_analysis_no_llm(self):
  s=MagicMock();s.get.return_value=NS(analysis_done=True)
  with patch.object(scoring,'SyncSessionLocal') as sm,patch.object(scoring,'extract_tender_positions') as llm:
   sm.return_value.__enter__.return_value=s
   result=inspect.unwrap(scoring.analyze_tender.run)(NS(), 't')
   self.assertEqual(result['reason'],'analysis_already_completed');llm.assert_not_called();s.execute.assert_not_called()
 def test_queued_ocr_preserves_documents(self):
  s=MagicMock();s.get.return_value=NS(analysis_done=True)
  with patch.object(ocr,'SyncSessionLocal') as sm,patch.object(ocr,'_materialize') as download:
   sm.return_value.__enter__.return_value=s
   self.assertEqual(ocr._process_documents('t',[])['status'],'cached')
   ocr._mark_incomplete('t');download.assert_not_called();s.execute.assert_not_called()
 def test_b2b_changed_hash_cached(self):
  s=MagicMock();s.execute.return_value.scalar_one_or_none.return_value=NS(analysis_done=True,source_hash='old')
  with patch('app.db.session.SyncSessionLocal') as sm:
   sm.return_value.__enter__.return_value=s
   self.assertTrue(runner._already_processed(NS(source='b2b_center',external_id='1')))
 def test_ingestion_preserves_score(self):
  from datetime import datetime
  from app.sources.schemas import SourceTender
  t=NS(id='t',analysis_done=True,is_active=True,score=67,status='can_apply',source_hash='old',submission_deadline=datetime(2099,1,1))
  s=MagicMock()
  source=SourceTender(source='zakupki_gov_ru',external_id='32616417112',title='Трубы алюминиевые',submission_deadline=datetime(2099,2,1),raw_payload={'stage':'detail'})
  with patch.object(parsing,'SyncSessionLocal') as sm,patch.object(parsing,'find_existing_tender',return_value=t),patch.object(parsing,'eligibility',return_value=None):
   sm.return_value.__enter__.return_value=s
   result=inspect.unwrap(parsing.process_new_tender.run)(source.model_dump(mode='json'))
  self.assertEqual(result['status'],'cached');self.assertEqual(t.score,67);self.assertTrue(t.analysis_done);self.assertEqual(t.source_hash,'old');self.assertEqual(t.submission_deadline,datetime(2099,2,1))
if __name__=='__main__':unittest.main()
