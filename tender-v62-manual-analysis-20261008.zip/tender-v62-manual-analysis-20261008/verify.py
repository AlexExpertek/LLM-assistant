import os
for k,v in dict(DATABASE_URL='postgresql+asyncpg://test:test@127.0.0.1/test',DATABASE_URL_SYNC='postgresql://test:test@127.0.0.1/test',REDIS_URL='redis://127.0.0.1:6379/0',CELERY_BROKER_URL='memory://',CELERY_RESULT_BACKEND='cache+memory://',QDRANT_URL='http://127.0.0.1:6333').items():os.environ[k]=v
import inspect,unittest,tempfile
from types import SimpleNamespace as NS
from unittest.mock import patch,MagicMock
from datetime import datetime,timezone,timedelta
from app.reports import manual_analysis as store
from app.workers import tasks_manual_analysis as worker
from app.api import manual_analysis as api
from app.models.database import OCRStatus
from fastapi import HTTPException
class Checks(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.p=patch.object(store,'settings',NS(storage_path=self.temp.name));self.p.start()
  self.card=dict(source='zakupki_gov_ru',external_id='123',title='Труба',submission_deadline='2099-01-01T00:00:00+00:00',score=67)
 def tearDown(self):self.p.stop();self.temp.cleanup()
 def test_double_click(self):
  a,new=store.reserve(self.card);b,again=store.reserve(self.card)
  self.assertTrue(new);self.assertFalse(again);self.assertEqual(a['task_id'],b['task_id'])
 def test_duplicate_delivery(self):
  a,_=store.reserve(self.card);args=('zakupki_gov_ru','123',a['task_id'])
  self.assertTrue(store.claim(*args));self.assertFalse(store.claim(*args))
 def test_retry_old_worker_cannot_overwrite(self):
  a,_=store.reserve(self.card);store.finish(a['source'],a['external_id'],a['task_id'],state='error')
  b,new=store.reserve(self.card);self.assertTrue(new);self.assertNotEqual(a['task_id'],b['task_id'])
  self.assertFalse(store.finish(a['source'],a['external_id'],a['task_id'],state='done'))
 def test_expired_hidden(self):
  store.reserve({**self.card,'submission_deadline':'2014-01-01T00:00:00+00:00'})
  with patch('app.reports.review_dismissals.is_dismissed',return_value=False):self.assertEqual(store.selected_rows(),[])
 def test_stale_recoverable(self):
  a,_=store.reserve(self.card);store.finish(a['source'],a['external_id'],a['task_id'],selected_at=(datetime.now(timezone.utc)-timedelta(hours=2)).isoformat())
  with patch('app.reports.review_dismissals.is_dismissed',return_value=False):self.assertEqual(store.selected_rows()[0]['state'],'error')
 def test_origin_guard(self):
  for headers in ({},{'x-review-action':'manual','origin':'https://evil.test','host':'app.test'}):
   with self.assertRaises(HTTPException) as caught:api.start(api.Selection(source='zakupki_gov_ru',external_id='123'),NS(headers=headers))
   self.assertEqual(caught.exception.status_code,403)
 def run_worker(self,result=None,error=None):
  a,_=store.reserve(self.card);s=MagicMock()
  s.execute.return_value.scalar_one_or_none.return_value=NS(id='t')
  s.execute.return_value.scalars.return_value.all.return_value=[NS(ocr_status=OCRStatus.NOT_REQUIRED,extracted_text='Труба АД1 8000 кг')]
  with patch.object(worker,'SyncSessionLocal') as sm,patch('app.reports.review_dismissals.is_dismissed',return_value=False),patch('app.workers.tasks_scoring.analyze_tender') as task:
   sm.return_value.__enter__.return_value=s;task.run.return_value=result;task.run.side_effect=error
   inspect.unwrap(worker.analyze_selected.run)(a)
   self.assertTrue(task.run.call_args.kwargs['force_reanalysis']);self.assertTrue(task.run.call_args.kwargs['suppress_notifications'])
  return store.rows()[0]
 def test_llm_failure_keeps_selection_and_score(self):
  r=self.run_worker(error=ValueError('EXTRACTION_POSITION_CONFLICT'))
  self.assertEqual(r['state'],'error');self.assertEqual(r['score'],67);self.assertIn('CONFLICT',r['error'])
 def test_success(self):
  r=self.run_worker(result={'status':'analyzed','score':58,'decision':'manual_review'})
  self.assertEqual(r['state'],'done');self.assertEqual(r['score'],58);self.assertEqual(r['ai_decision'],'manual_review')
if __name__=='__main__':unittest.main()
