#!/usr/bin/env bash
set -Eeuo pipefail
pkg_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
project_dir="${TENDER_PROJECT_DIR:-/home/stdadmin/LLM-assistant/tender-ai-platform-v6.2}"
cd "$project_dir"
test -f app/workers/completed_analysis.py
python3 "$pkg_dir/apply.py" --project "$project_dir"
docker compose build app celery_worker celery_discovery
for script in verify.py verify_no_repeat.py; do
 docker compose run --rm --no-deps -T celery_worker python - < "$pkg_dir/$script"
done
docker compose up -d --no-deps --timeout 60 app celery_worker celery_discovery
printf '\nMANUAL_ANALYSIS_UPDATE_INSTALLED\nExisting schedule retained. Manual analysis starts only after a button click.\n'
