from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel,Field
from urllib.parse import urlsplit
from sqlalchemy import select
from app.db.session import SyncSessionLocal
from app.models.database import Tender
from app.workers.completed_analysis import has_completed_analysis
from app.reports.manual_analysis import reserve,finish,selected_rows
router=APIRouter()
class Selection(BaseModel):
 source:str=Field(pattern=r'^[a-z0-9_]+$',max_length=100)
 external_id:str=Field(pattern=r'^[A-Za-z0-9_-]+$',max_length=200)

@router.get('/tenders/manual-analysis')
def listing():return {'tenders':selected_rows()}

@router.post('/tenders/manual-analysis')
def start(body:Selection,request:Request):
 origin=request.headers.get('origin')
 if request.headers.get('x-review-action')!='manual' or (origin and urlsplit(origin).netloc!=request.headers.get('host')):
  raise HTTPException(403,'Manual same-origin action required')
 from app.reports.review_dismissals import is_dismissed
 if is_dismissed(body.source,body.external_id):raise HTTPException(409,'Закупка ранее отклонена')
 from app.sources.eis_freshness import eligibility
 with SyncSessionLocal() as s:
  t=s.execute(select(Tender).where(Tender.source==body.source,Tender.external_id==body.external_id)).scalar_one_or_none()
  if t:
   reason=eligibility(t.source,t.submission_deadline,t.raw_payload,t.is_active)
   card={'source':t.source,'external_id':t.external_id,'title':t.title,'source_url':t.source_url,'submission_deadline':t.submission_deadline,'tender_id':str(t.id),'score':t.score if has_completed_analysis(s,t) else None}
  else:
   from app.marketplace_discovery.review_store import list_review_candidates
   candidate=next((r for r in list_review_candidates(500) if r.get('source')==body.source and str(r.get('external_id'))==body.external_id),None)
   if candidate is None:raise HTTPException(404,'Закупка не найдена')
   reason=eligibility(body.source,candidate.get('submission_deadline'),candidate.get('raw_payload') or {})
   card={k:candidate.get(k) for k in ('source','external_id','title','source_url','submission_deadline')}
 if reason:raise HTTPException(409,'Не подтверждён действующий приём заявок: '+reason)
 record,new=reserve(card)
 if new:
  try:
   from app.workers.tasks_manual_analysis import analyze_selected
   analyze_selected.apply_async(args=[record],task_id=record['task_id'],queue='celery')
  except Exception:
   finish(body.source,body.external_id,record['task_id'],state='error',error='Не удалось поставить анализ в очередь')
   raise HTTPException(503,'Не удалось поставить анализ в очередь. Можно повторить.')
 return {'state':record['state'],'task_id':record['task_id']}
