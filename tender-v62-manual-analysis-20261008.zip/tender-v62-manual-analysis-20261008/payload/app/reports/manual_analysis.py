"""Durable explicit operator selections, separate from machine qualification."""
import json, sqlite3, uuid
from pathlib import Path
from datetime import datetime, timezone
from app.core.config import settings

def connect():
 p=Path(settings.storage_path)/'manual_analysis.sqlite3';p.parent.mkdir(parents=True,exist_ok=True)
 c=sqlite3.connect(p,timeout=15)
 c.execute('CREATE TABLE IF NOT EXISTS selections (source TEXT, number TEXT, payload TEXT, PRIMARY KEY(source,number))')
 return c

def rows():
 with connect() as c:return [json.loads(r[0]) for r in c.execute('SELECT payload FROM selections')]

def reserve(card):
 with connect() as c:
  c.execute('BEGIN IMMEDIATE')
  old=c.execute('SELECT payload FROM selections WHERE source=? AND number=?',(card['source'],card['external_id'])).fetchone()
  if old:
   r=json.loads(old[0])
   if r['state'] in ('queued','running') and not stale(r):return r,False
  r={**card,'task_id':str(uuid.uuid4()),'state':'queued','selected_at':datetime.now(timezone.utc).isoformat(),'error':None}
  c.execute('INSERT OR REPLACE INTO selections VALUES (?,?,?)',(r['source'],r['external_id'],json.dumps(r,ensure_ascii=False,default=str)))
  return r,True

def finish(source,number,task_id,**changes):
 with connect() as c:
  c.execute('BEGIN IMMEDIATE')
  old=c.execute('SELECT payload FROM selections WHERE source=? AND number=?',(source,number)).fetchone()
  if not old:return False
  r=json.loads(old[0])
  if r['task_id']!=task_id:return False
  r.update(changes)
  c.execute('UPDATE selections SET payload=? WHERE source=? AND number=?',(json.dumps(r,ensure_ascii=False,default=str),source,number))
  return True

def selected_rows():
 from app.reports.review_dashboard import assemble
 from app.reports.review_dismissals import is_dismissed
 for r in rows():
  if stale(r):finish(r['source'],r['external_id'],r['task_id'],state='error',error='Задача не завершилась за 1 час. Можно повторить анализ.')
 return [r for r in assemble(rows(),[]) if not is_dismissed(r['source'],r['external_id'])]

def claim(source,number,task_id):
 with connect() as c:
  c.execute('BEGIN IMMEDIATE')
  old=c.execute('SELECT payload FROM selections WHERE source=? AND number=?',(source,number)).fetchone()
  if not old:return False
  r=json.loads(old[0])
  if r['task_id']!=task_id or r['state']!='queued':return False
  r['state']='running'
  c.execute('UPDATE selections SET payload=? WHERE source=? AND number=?',(json.dumps(r,ensure_ascii=False),source,number))
  return True


def stale(r):
 if r.get('state') not in ('queued','running'):return False
 return (datetime.now(timezone.utc)-datetime.fromisoformat(r['selected_at'])).total_seconds()>3600
