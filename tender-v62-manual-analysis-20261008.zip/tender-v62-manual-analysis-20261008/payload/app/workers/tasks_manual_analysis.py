"""Explicit manual analysis; errors do not erase operator selection."""
from sqlalchemy import select
from app.db.session import SyncSessionLocal
from app.models.database import Tender,Document,OCRStatus
from app.workers.celery_app import celery_app
from app.reports.manual_analysis import finish,claim
from app.workers.execution_guard import exclusive_task

@celery_app.task(name='app.workers.tasks_manual_analysis.analyze_selected', soft_time_limit=840, time_limit=900)
@exclusive_task('manual_selection','record')
def analyze_selected(record):
 source,number,task_id=record['source'],record['external_id'],record['task_id']
 if not claim(source,number,task_id):return {'status':'obsolete'}
 try:
  from app.reports.review_dismissals import is_dismissed
  if is_dismissed(source,number):raise ValueError('Закупка отклонена вручную')
  with SyncSessionLocal() as s:
   t=s.execute(select(Tender).where(Tender.source==source,Tender.external_id==number)).scalar_one_or_none()
   if t is None:
    from app.marketplace_discovery.review_store import list_review_candidates
    from app.workers.tasks_parsing import process_new_tender
    card=next((r for r in list_review_candidates(500) if r.get('source')==source and str(r.get('external_id'))==number),None)
    if card is None:raise ValueError('Исходная карточка недоступна')
    result=process_new_tender.run(card,launch_pipeline=False)
    if not result.get('tender_id'):raise ValueError('Карточка не сохранена: '+str(result.get('reason',result.get('status'))))
    s.expire_all()
    t=s.get(Tender,result['tender_id'])
   tid=str(t.id)
   docs=s.execute(select(Document).where(Document.tender_id==tid)).scalars().all()
   texts=[d.extracted_text for d in docs if d.ocr_status in (OCRStatus.DONE,OCRStatus.NOT_REQUIRED) and (d.extracted_text or '').strip()]
   if docs and len(texts)!=len(docs):raise ValueError('Не все документы распознаны; требуется восстановить документы')
   if not texts:
    positions=(t.raw_payload or {}).get('positions') or []
    if positions:
     import json
     texts=[json.dumps(positions,ensure_ascii=False)]
    else:
     # Fetch only through the already installed source adapter.
     from app.sources.registry import get_adapter
     from app.sources.document_preparer import prepare_tender_documents
     from app.workers.tasks_ocr import _materialize
     from app.ocr.pipeline import extract_document
     from pathlib import Path
     from tempfile import TemporaryDirectory
     adapter=get_adapter(source)
     if adapter is None:raise ValueError('Для площадки ещё нет обработчика документов')
     card=adapter.fetch_by_id(number,source_url=t.source_url) if source=='zakupki_gov_ru' else adapter.fetch_by_id(number)
     if card is None:raise ValueError('Карточка не получена')
     prepared=prepare_tender_documents(card)
     if not prepared:raise ValueError('Нет доступных документов спецификации')
     with TemporaryDirectory(prefix='manual-analysis-') as directory:
      for doc in prepared:
       path=_materialize(doc,Path(directory))
       extracted=extract_document(str(path))
       if extracted.status not in (OCRStatus.DONE,OCRStatus.NOT_REQUIRED) or not extracted.full_text.strip():
        raise ValueError('Документ не распознан: '+doc.name)
       texts.append(extracted.full_text)
  from app.workers.tasks_scoring import analyze_tender
  result=analyze_tender.run(tid,'\n\n'.join(texts),None,force_reanalysis=True,suppress_notifications=True)
  if result.get('status')!='analyzed':raise ValueError('Анализ не завершён: '+str(result.get('reason',result.get('status'))))
  finish(source,number,task_id,state='done',error=None,score=result.get('score'),ai_decision=result.get('decision'),tender_id=tid)
  return result
 except Exception as exc:
  # Persist the error before acknowledging this manual task. Retrying is explicit.
  code=str(exc)
  if not isinstance(exc,ValueError):code=type(exc).__name__
  finish(source,number,task_id,state='error',error=code[:500])
  return {'status':'analysis_error','error':code[:500]}
