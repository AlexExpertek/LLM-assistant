"""Rescore one completed tender from persisted items, without LLM or notifications."""
import sys,json,argparse
from datetime import datetime
sys.path.insert(0,'/app')
from sqlalchemy import select
from app.db.session import SyncSessionLocal
from app.models.database import Tender,Document,TenderItem,Lot,Decision,ProcessingStatus
from app.scoring.rules import score_tender
from app.scoring.alloy_normalizer import is_known_alloy
from app.scoring.multiposition import analyze_positions,position_status
p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');args=p.parse_args()
tid='03c10841-1fc5-420b-8467-4924f5d9deba'
with SyncSessionLocal() as s:
 t=s.execute(select(Tender).where(Tender.id==tid).with_for_update()).scalar_one()
 if t.processing_status!=ProcessingStatus.ANALYZED:raise SystemExit('Tender is not analyzed; no changes')
 decisions=s.execute(select(Decision).where(Decision.tender_id==tid)).scalars().all()
 if any(d.is_manual_override for d in decisions):raise SystemExit('Manual decision exists; no changes')
 items=s.execute(select(TenderItem).join(Lot,TenderItem.lot_id==Lot.id).where(Lot.tender_id==tid).order_by(TenderItem.id)).scalars().all()
 docs=s.execute(select(Document).where(Document.tender_id==tid)).scalars().all()
 if not items or not docs:raise SystemExit('Missing items/documents; no changes')
 text='\n'.join(filter(None,[t.title,t.description,t.delivery_place]+[d.extracted_text for d in docs]))
 positions=[{k:getattr(i,k) for k in ['product_type','alloy','mass_kg','thickness_mm','width_mm','diameter_mm']} for i in items]
 mp=analyze_positions(positions,partial_delivery_allowed=None)
 score=score_tender(text,any(is_known_alloy(i.alloy) for i in items),any(i.thickness_mm or i.width_mm for i in items),any(i.mass_kg for i in items),any(i.standard for i in items),any(i.has_drawings for i in items),any(i.coating_required or i.machining_required for i in items))
 status=position_status(score,mp)
 reasons=[signal.reason for signal in score.signals]+[mp.summary]+[i.reason for i in mp.positions]
 print(json.dumps({'old_status':t.status.value,'old_score':t.score,'new_status':status.value,'new_score':score.total_score,'reasons':reasons,'risks':score.critical_unknowns},ensure_ascii=False,indent=2))
 if args.apply:
  # Preserve the earlier Decision row as history. Repeat application is a no-op.
  version='scoring-v6.2-20260915-persisted'
  if any(d.model_version==version for d in decisions):raise SystemExit('Already rescored; no changes')
  for row,analysis in zip(items,mp.positions):row.can_supply=analysis.can_supply;row.supply_reason=analysis.reason
  s.add(Decision(tender_id=tid,score=score.total_score,status=status,reasons=reasons,risks=score.critical_unknowns,model_version=version))
  t.status=status;t.score=score.total_score;t.updated_at=datetime.utcnow()
  s.commit();print('RESCORE_SAVED: no LLM requests or notifications')
 else:print('PREVIEW_ONLY: add --apply to save')
