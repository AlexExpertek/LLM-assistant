#!/usr/bin/env bash
set -Eeuo pipefail
PACKAGE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd /home/stdadmin/LLM-assistant/tender-ai-platform-v6.2
python3 "$PACKAGE_DIR/apply.py" "$PWD"
docker compose config --quiet
docker compose build app celery_worker
docker compose run --rm --no-deps -T celery_worker python - < "$PACKAGE_DIR/verify_scoring.py"
docker compose run --rm --no-deps -T celery_worker python -c 'from app.workers.tasks_scoring import analyze_tender; print("SCORING_IMPORT_OK")'
docker compose up -d --no-deps --timeout 60 app celery_worker
docker compose exec -T celery_worker python - <<'PY'
import socket,time
from app.workers.celery_app import celery_app
node='celery@'+socket.gethostname()
for attempt in range(10):
    if any(reply.get(node,{}).get('ok')=='pong' for reply in celery_app.control.ping(destination=[node],timeout=5)):
        print('SCORING_WORKER_READY:',node)
        break
    time.sleep(2)
else:raise SystemExit('Worker did not reply; inspect logs')
PY
echo SCORING_UPDATE_INSTALLED
