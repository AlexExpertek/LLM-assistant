import os,sys,unittest
sys.path.insert(0,os.environ.get('OCR_PROJECT','/app'))
os.environ.update(DATABASE_URL='postgresql+asyncpg://test:test@localhost/test',DATABASE_URL_SYNC='postgresql+psycopg2://test:test@localhost/test',CELERY_BROKER_URL='memory://',CELERY_RESULT_BACKEND='cache+memory://')
os.environ.update(REDIS_URL='redis://localhost:1/0',QDRANT_URL='http://localhost:1')
from app.scoring.rules import hard_stop_hits,score_tender
from app.scoring.multiposition import analyze_positions,position_status
from app.models.database import TenderStatus

def score(text):
 return score_tender(text,False,False,False,False,False,False)
class Checks(unittest.TestCase):
 def test_false_substrings(self):
  self.assertEqual(hard_stop_hits('Все налоги, пошлины и прочие сборы. Порядок определен подразделом 3.10. Одним файлом.'),[])
 def test_scrap_forms(self):
  for text in ['Сбор алюминиевого лома','Услуги по сбору и утилизации лома','Прием металлолома']:
   self.assertTrue(hard_stop_hits(text),text)
 def test_distant_terms(self):
  self.assertEqual(hard_stop_hits('Сбор налогов. Поставка лома'),[])
 def test_tube_unknown(self):
  mp=analyze_positions([{'product_type':'трубы','alloy':'АМг61'}])
  self.assertIsNone(mp.positions[0].can_supply)
  self.assertEqual(mp.unknown_count,1)
  self.assertNotIn('вне нашего ассортимента',mp.positions[0].reason)
  self.assertEqual(position_status(score('Закупка труб'),mp),TenderStatus.MANUAL_REVIEW)
 def test_known_tube_missing_data(self):
  mp=analyze_positions([{'product_type':'трубы','alloy':'1561'}])
  self.assertIsNone(mp.positions[0].can_supply)
 def test_complete_position(self):
  mp=analyze_positions([{'product_type':'трубы','alloy':'1561','mass_kg':600,'diameter_mm':40,'thickness_mm':3}])
  self.assertTrue(mp.positions[0].can_supply)
 def test_small_mass(self):
  for mass in [0,100]:
   self.assertFalse(analyze_positions([{'product_type':'трубы','alloy':'1561','mass_kg':mass}]).positions[0].can_supply)
 def test_not_substring_product(self):
  self.assertFalse(analyze_positions([{'product_type':'листовки','alloy':'1561','mass_kg':600}]).positions[0].can_supply)
 def test_partial_not_assumed(self):
  mp=analyze_positions([{'product_type':'лист','alloy':'1561','mass_kg':600,'thickness_mm':3},{'product_type':'кастрюля'}])
  self.assertFalse(mp.partial_delivery_possible)
 def test_scrap_still_rejected(self):
  self.assertEqual(position_status(score('Сбор алюминиевого лома'),None),TenderStatus.NOT_SUITABLE)
 def test_no_positions_review(self):
  self.assertEqual(position_status(score('Закупка'),None),TenderStatus.MANUAL_REVIEW)
if __name__=='__main__':unittest.main()
