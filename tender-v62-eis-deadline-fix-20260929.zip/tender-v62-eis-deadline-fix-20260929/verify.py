import unittest, os
from app.sources.zakupki_gov_public.detail_client import _extract_deadline_utc
from app.sources.zakupki_gov_public.public_client import _extract_status, EisPublicSearchClient
import httpx
from unittest.mock import patch
LABEL='Дата и время окончания срока подачи заявок (по местному времени заказчика) '
class Checks(unittest.TestCase):
 def test_sakhalin(self):self.assertEqual(_extract_deadline_utc(LABEL+'12.10.2026 18:00 (МСК+8)'), '2026-10-12 07:00:00')
 def test_moscow(self):self.assertEqual(_extract_deadline_utc(LABEL+'12.10.2026 18:00 (МСК)'), '2026-10-12 15:00:00')
 def test_minus(self):self.assertEqual(_extract_deadline_utc(LABEL+'12.10.2026 18:00 (МСК-1)'), '2026-10-12 16:00:00')
 def test_rollover(self):self.assertEqual(_extract_deadline_utc(LABEL+'12.10.2026 01:00 (МСК+8)'), '2026-10-11 14:00:00')
 def test_unknown_zone(self):self.assertIsNone(_extract_deadline_utc(LABEL+'12.10.2026 18:00'))
 def test_date_only(self):self.assertIsNone(_extract_deadline_utc('Окончание подачи заявок 12.10.2026'))
 def test_invalid(self):self.assertIsNone(_extract_deadline_utc(LABEL+'31.02.2026 18:00 (МСК+8)'))
 def test_footer_status(self):self.assertEqual(_extract_status('Работа комиссии Объект закупки Трубы Подача заявок'), 'Работа комиссии')
 def test_closed(self):self.assertEqual(_extract_status('Определение поставщика завершено Объект закупки Трубы'), 'Определение поставщика завершено')
 def test_unknown(self):self.assertIsNone(_extract_status('Объект закупки Трубы Подача заявок'))
 def test_block_boundary(self):
  html='<div class="search-registry-entry-block"><div>card</div></div><aside>Подача заявок</aside>'
  response=httpx.Response(200,text=html,request=httpx.Request('GET','https://example.test'))
  with patch.dict(os.environ, {}, clear=True), patch.object(httpx.Client,'get',return_value=response), patch('app.sources.zakupki_gov_public.public_client.parse_search_card',return_value=None) as parser:
   EisPublicSearchClient().search('трубы')
   self.assertEqual(parser.call_count,1)
   self.assertNotIn('Подача заявок',parser.call_args.args[0])
unittest.main()
