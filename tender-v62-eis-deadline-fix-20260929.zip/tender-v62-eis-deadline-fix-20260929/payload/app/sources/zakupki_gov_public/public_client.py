"""Public discovery client for zakupki.gov.ru."""

from __future__ import annotations

import html
import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any
from urllib.parse import urljoin

import httpx


BASE_URL = "https://zakupki.gov.ru"

SEARCH_URL = (
    BASE_URL
    + "/epz/order/extendedsearch/results.html"
)

DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) "
        "AppleWebKit/537.36 "
        "Chrome/126.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml",
    "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
}


@dataclass
class EisSearchItem:
    external_id: str
    title: str | None
    law_type: str | None
    procurement_method: str | None
    status: str | None
    customer_name: str | None
    amount: Decimal | None
    published_date: str | None
    updated_date: str | None
    submission_deadline: str | None
    source_url: str | None
    search_text: str
    raw_html: str


def _plain_text(value: str) -> str:
    # EIS wraps matched fragments with inline HTML.
    # Example:
    # алюмин<span>...</span>иевых
    # A normal tag-to-space conversion would produce
    # "алюмин иевых" and break relevance filtering.
    #
    # Remove inline highlight tags first without inserting
    # whitespace, then convert remaining structural tags.

    value = re.sub(
        r"</?(?:span|mark)\b[^>]*>",
        "",
        value,
        flags=re.I,
    )

    value = re.sub(
        r"<script.*?</script>|<style.*?</style>",
        " ",
        value,
        flags=re.S | re.I,
    )

    value = re.sub(
        r"<[^>]+>",
        " ",
        value,
    )

    value = html.unescape(value)

    return re.sub(
        r"\s+",
        " ",
        value,
    ).strip()


def _extract_between(
    text: str,
    start: str,
    ends: tuple[str, ...],
) -> str | None:
    pos = text.find(start)

    if pos == -1:
        return None

    value_start = pos + len(start)

    candidates = []

    for marker in ends:
        marker_pos = text.find(
            marker,
            value_start,
        )

        if marker_pos != -1:
            candidates.append(marker_pos)

    if not candidates:
        return None

    value = text[
        value_start:min(candidates)
    ].strip()

    return value or None


def _parse_amount(
    value: str | None,
) -> Decimal | None:
    if not value:
        return None

    normalized = (
        value
        .replace("\xa0", "")
        .replace(" ", "")
        .replace("₽", "")
        .replace(",", ".")
    )

    normalized = re.sub(
        r"[^\d.\-]",
        "",
        normalized,
    )

    if not normalized:
        return None

    try:
        return Decimal(normalized)

    except InvalidOperation:
        return None


def _extract_date(
    text: str,
    label: str,
) -> str | None:
    match = re.search(
        rf"{re.escape(label)}\s+"
        r"(\d{2}\.\d{2}\.\d{4})",
        text,
        flags=re.I,
    )

    if not match:
        return None

    return match.group(1)


def _extract_external_id(
    block: str,
    text: str,
) -> str | None:
    patterns = (
        r"[?&]regNumber=(\d{10,25})",
        r"[?&]purchaseNoticeNumber=(\d{10,25})",
        r"№\s*(\d{10,25})",
    )

    for pattern in patterns:
        match = re.search(
            pattern,
            block + " " + text,
            flags=re.I,
        )

        if match:
            return match.group(1)

    return None


def _extract_source_url(
    block: str,
    external_id: str,
) -> str | None:
    links = re.findall(
        r'href=["\']([^"\']+)["\']',
        block,
        flags=re.I,
    )

    # Prefer the real common-info card.
    for link in links:
        if (
            external_id in link
            and "common-info" in link
        ):
            return urljoin(
                BASE_URL,
                link.replace("&", "&"),
            )

    # Fallback to any useful notice link.
    for link in links:
        if (
            external_id in link
            and (
                "notice" in link
                or "purchase" in link
            )
        ):
            return urljoin(
                BASE_URL,
                link.replace("&", "&"),
            )

    return None


def _extract_law_type(
    text: str,
) -> str | None:
    if "223-ФЗ" in text:
        return "223-FZ"

    if "44-ФЗ" in text:
        return "44-FZ"

    return None


def _extract_status(
    text: str,
) -> str | None:
    statuses = (
        "Подача заявок",
        "Работа комиссии",
        "Закупка завершена",
        "Закупка отменена",
        "Определение поставщика завершено",
    )

    header = text.split("Объект закупки", 1)[0]
    matches = [(header.find(status), status) for status in statuses if status in header]
    if matches:
        return min(matches)[1]

    return None


def _extract_method(
    text: str,
    external_id: str,
) -> str | None:
    marker = f"№ {external_id}"

    pos = text.find(marker)

    if pos == -1:
        return None

    prefix = text[:pos].strip()

    prefix = re.sub(
        r"^(44-ФЗ|223-ФЗ)\s+",
        "",
        prefix,
    )

    if "223-ФЗ" in prefix:
        prefix = prefix.split(
            "223-ФЗ",
            1,
        )[-1].strip()

    if "44-ФЗ" in prefix:
        prefix = prefix.split(
            "44-ФЗ",
            1,
        )[-1].strip()

    return prefix[-500:] or None


def parse_search_card(
    block: str,
) -> EisSearchItem | None:
    text = _plain_text(block)

    external_id = _extract_external_id(
        block,
        text,
    )

    if not external_id:
        return None

    title = _extract_between(
        text,
        "Объект закупки",
        (
            "Заказчик",
            "Организация, осуществляющая размещение",
            "Начальная цена",
        ),
    )

    customer = _extract_between(
        text,
        "Заказчик",
        (
            "Начальная цена",
            "Размещено",
        ),
    )

    if customer is None:
        customer = _extract_between(
            text,
            "Организация, осуществляющая размещение",
            (
                "Начальная цена",
                "Размещено",
            ),
        )

    amount_text = _extract_between(
        text,
        "Начальная цена",
        (
            "Размещено",
            "Обновлено",
        ),
    )

    return EisSearchItem(
        external_id=external_id,
        title=title,
        law_type=_extract_law_type(text),
        procurement_method=_extract_method(
            text,
            external_id,
        ),
        status=_extract_status(text),
        customer_name=customer,
        amount=_parse_amount(amount_text),
        published_date=_extract_date(
            text,
            "Размещено",
        ),
        updated_date=_extract_date(
            text,
            "Обновлено",
        ),
        submission_deadline=_extract_date(
            text,
            "Окончание подачи заявок",
        ),
        source_url=_extract_source_url(
            block,
            external_id,
        ),
        search_text=text,
        raw_html=block,
    )


class EisPublicSearchClient:
    """
    Cheap discovery through the public EIS search.

    This client does NOT download procurement documents.
    """

    def __init__(
        self,
        *,
        verify: bool | str = False,
        timeout: float = 30.0,
    ):
        self.verify = verify
        self.timeout = timeout

    def search(
        self,
        query: str,
        *,
        page: int = 1,
        records_per_page: int = 10,
    ) -> list[EisSearchItem]:

        params: dict[str, Any] = {
            "searchString": query,
            "morphology": "on",
            "pageNumber": page,
            "recordsPerPage": (
                f"_{records_per_page}"
            ),
            "sortDirection": "false",
            "sortBy": "UPDATE_DATE",
        }

        with httpx.Client(
            timeout=self.timeout,
            follow_redirects=True,
            verify=self.verify,
            headers=DEFAULT_HEADERS,
        ) as client:
            response = client.get(
                SEARCH_URL,
                params=params,
            )

        response.raise_for_status()

        from bs4 import BeautifulSoup
        soup = BeautifulSoup(response.text, "html.parser")
        blocks = [str(node) for node in soup.select(".search-registry-entry-block")]

        result = []

        for block in blocks:
            item = parse_search_card(block)

            if item is not None:
                result.append(item)

        return result
