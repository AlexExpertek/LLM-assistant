"""Public detail client for zakupki.gov.ru."""

from __future__ import annotations

import re
from html.parser import HTMLParser
from dataclasses import dataclass, field
from decimal import Decimal
from urllib.parse import urljoin

import httpx

from app.sources.zakupki_gov_public.public_client import (
    BASE_URL,
    DEFAULT_HEADERS,
    _parse_amount,
    _plain_text,
)


@dataclass
class EisDocumentRef:
    name: str
    url: str
    uid: str | None = None


@dataclass
class EisLot:
    number: str | None = None
    title: str | None = None
    amount: Decimal | None = None
    okpd2: list[str] = field(
        default_factory=list
    )


@dataclass
class EisPurchaseDetail:
    external_id: str
    source_url: str
    notice_guid: str | None = None
    title: str | None = None
    customer_name: str | None = None
    amount: Decimal | None = None
    law_type: str | None = None
    publish_date: str | None = None
    submission_deadline: str | None = None
    lots: list[EisLot] = field(
        default_factory=list
    )
    documents: list[EisDocumentRef] = field(
        default_factory=list
    )


def _extract_card_date(text: str, labels: tuple[str, ...]) -> str | None:
    """Only read a calendar date directly following a named field."""
    from datetime import datetime
    compact = re.sub(r"\s+", " ", text).strip()
    for label in labels:
        pattern = re.escape(label) + r"\s*:?\s*(\d{2}\.\d{2}\.\d{4}(?:[ T]+\d{2}:\d{2}(?::\d{2})?)?)(?![\d:])"
        match = re.search(pattern, compact, re.IGNORECASE)
        if not match:
            continue
        value = match.group(1).replace("T", " ")
        for fmt in ("%d.%m.%Y %H:%M:%S", "%d.%m.%Y %H:%M", "%d.%m.%Y"):
            try:
                datetime.strptime(value, fmt)
                return value
            except ValueError:
                pass
    return None


def _extract_deadline_utc(text: str) -> str | None:
    """Return naive UTC, matching database convention; require explicit time/zone."""
    from datetime import datetime, timedelta, timezone
    compact = re.sub(r"\s+", " ", text).strip()
    pattern = (
        r"Дата и время окончания срока подачи заявок\s*"
        r"(?:\(по местному времени заказчика\)\s*)?:?\s*"
        r"(\d{2}\.\d{2}\.\d{4})\s+(\d{2}:\d{2}(?::\d{2})?)\s*"
        r"\(МСК\s*(?:([+−-])\s*(\d{1,2}))?\)"
    )
    match = re.search(pattern, compact, re.I)
    if not match:
        return None
    day, clock, sign, delta = match.groups()
    offset = 3 + (int(delta or 0) * (-1 if sign in ('-', '−') else 1))
    if not -12 <= offset <= 14:
        return None
    try:
        fmt = '%d.%m.%Y %H:%M:%S' if clock.count(':') == 2 else '%d.%m.%Y %H:%M'
        local = datetime.strptime(day + ' ' + clock, fmt)
        utc = local.replace(tzinfo=timezone(timedelta(hours=offset))).astimezone(timezone.utc)
        return utc.replace(tzinfo=None).strftime('%Y-%m-%d %H:%M:%S')
    except ValueError:
        return None


def _extract_card_dates(text: str) -> tuple[str | None, str | None]:
    published = _extract_card_date(text, (
        "Дата размещения извещения", "Дата публикации извещения", "Размещено",
    ))
    deadline = _extract_deadline_utc(text)
    return published, deadline


def _clean_href(value: str) -> str:
    # Do NOT use html.unescape() here:
    # "&noticeGuid" may be interpreted as "&not;".
    return (
        value
        .replace("&", "&")
        .strip()
    )


def _extract_notice_guid(
    value: str,
) -> str | None:

    match = re.search(
        r"(?:noticeGuid|purchaseNoticeGuid)="
        r"([0-9a-fA-F-]{36})",
        value,
    )

    return (
        match.group(1)
        if match
        else None
    )


def _extract_label_value(
    text: str,
    label: str,
    end_labels: tuple[str, ...],
) -> str | None:

    pos = text.find(label)

    if pos == -1:
        return None

    start = pos + len(label)

    ends = []

    for marker in end_labels:
        marker_pos = text.find(
            marker,
            start,
        )

        if marker_pos != -1:
            ends.append(marker_pos)

    if not ends:
        return None

    value = text[
        start:min(ends)
    ].strip()

    return value or None


def _parse_lot_page(
    html_text: str,
) -> list[EisLot]:

    text = _plain_text(html_text)

    marker = "Сведения о лотах"

    pos = text.find(marker)

    if pos == -1:
        return []

    section = text[pos:]

    # Для первой версии фиксируем основную информацию
    # хотя бы по одному лоту.
    title_match = re.search(
        r"\b1\s+(.+?)\s+"
        r"(?:Да|Нет)\s+"
        r"Начальная \(максимальная\) цена договора:",
        section,
        flags=re.I,
    )

    amount_match = re.search(
        r"Начальная \(максимальная\) цена договора:"
        r"\s*([\d\s]+,\d{2})\s*₽",
        section,
        flags=re.I,
    )

    okpd2_codes = re.findall(
        r"\b\d{2}\.\d{2}\.\d{2}\.\d{3}\b",
        section,
    )

    if (
        not title_match
        and not amount_match
        and not okpd2_codes
    ):
        return []

    return [
        EisLot(
            number="1",
            title=(
                title_match.group(1).strip()
                if title_match
                else None
            ),
            amount=_parse_amount(
                amount_match.group(1)
                if amount_match
                else None
            ),
            okpd2=list(
                dict.fromkeys(okpd2_codes)
            ),
        )
    ]


def _parse_documents_page(
    html_text: str,
) -> list[EisDocumentRef]:
    """Parse EIS 223-FZ filestore attachments."""

    class AttachmentParser(HTMLParser):
        def __init__(self):
            super().__init__(
                convert_charrefs=True
            )
            self.documents = []
            self.current = None
            self.text_parts = []

        def handle_starttag(
            self,
            tag,
            attrs,
        ):
            if tag.lower() != "a":
                return

            attributes = dict(attrs)

            href = (
                attributes.get("href")
                or ""
            )

            if (
                "/filestore/public/" not in href
                or "/download/" not in href
            ):
                return

            tooltip = (
                attributes.get(
                    "data-tooltip"
                )
                or ""
            )

            self.current = {
                "href": href,
                "tooltip": tooltip,
            }

            self.text_parts = []

        def handle_data(
            self,
            data,
        ):
            if self.current is not None:
                self.text_parts.append(data)

        def handle_endtag(
            self,
            tag,
        ):
            if (
                tag.lower() != "a"
                or self.current is None
            ):
                return

            self.current[
                "visible_text"
            ] = " ".join(
                x.strip()
                for x in self.text_parts
                if x.strip()
            )

            self.documents.append(
                self.current
            )

            self.current = None
            self.text_parts = []

    parser = AttachmentParser()
    parser.feed(html_text)

    documents: list[EisDocumentRef] = []
    seen_urls: set[str] = set()

    for raw in parser.documents:

        raw_url = _clean_href(
            raw.get("href") or ""
        )

        url = urljoin(
            BASE_URL,
            raw_url,
        )

        if url in seen_urls:
            continue

        uid_match = re.search(
            r"[?&]uid=([A-Fa-f0-9]+)",
            url,
        )

        uid = (
            uid_match.group(1)
            if uid_match
            else None
        )

        tooltip = (
            raw.get("tooltip")
            or ""
        )

        visible_text = (
            raw.get("visible_text")
            or ""
        ).strip()

        # data-tooltip contains the full filename:
        # <span class="custom-tooltiptext">
        #     Тех. зад алюм. констр.docx
        # </span>
        tooltip_name = (
            _plain_text(tooltip)
            if tooltip
            else ""
        ).strip()

        name = (
            tooltip_name
            or visible_text
            or f"document_{len(documents) + 1}"
        )

        documents.append(
            EisDocumentRef(
                name=name,
                url=url,
                uid=uid,
            )
        )

        seen_urls.add(url)

    return documents


class EisPublicDetailClient:

    def __init__(
        self,
        *,
        verify: bool | str = False,
        timeout: float = 30.0,
    ):
        self.verify = verify
        self.timeout = timeout

    def fetch_223(
        self,
        external_id: str,
        source_url: str,
    ) -> EisPurchaseDetail:

        with httpx.Client(
            verify=self.verify,
            timeout=self.timeout,
            follow_redirects=True,
            headers=DEFAULT_HEADERS,
        ) as client:

            common = client.get(
                source_url
            )
            common.raise_for_status()

            notice_guid = (
                _extract_notice_guid(
                    common.text
                )
            )

            if not notice_guid:
                raise RuntimeError(
                    "EIS noticeGuid not found"
                )

            lot_url = (
                BASE_URL
                + "/epz/order/notice/"
                "notice223/lot-list.html"
                f"?purchaseNoticeNumber={external_id}"
                f"&noticeGuid={notice_guid}"
            )

            documents_url = (
                BASE_URL
                + "/epz/order/notice/"
                "notice223/documents.html"
                f"?purchaseNoticeNumber={external_id}"
                f"&noticeGuid={notice_guid}"
            )

            lot_response = client.get(
                lot_url
            )
            lot_response.raise_for_status()

            documents_response = client.get(
                documents_url
            )
            documents_response.raise_for_status()

        common_text = _plain_text(
            common.text
        )

        published, deadline = _extract_card_dates(common_text)

        title = _extract_label_value(
            common_text,
            "Объект закупки",
            (
                "Заказчик",
                "Организация, осуществляющая размещение",
                "Начальная цена",
            ),
        )

        customer = _extract_label_value(
            common_text,
            "Заказчик",
            (
                "Начальная цена",
                "Размещено",
            ),
        )

        amount_text = _extract_label_value(
            common_text,
            "Начальная цена",
            (
                "Размещено",
                "Обновлено",
            ),
        )

        return EisPurchaseDetail(
            external_id=external_id,
            source_url=str(
                common.url
            ),
            notice_guid=notice_guid,
            title=title,
            customer_name=customer,
            amount=_parse_amount(
                amount_text
            ),
            law_type="223-FZ",
            publish_date=published,
            submission_deadline=deadline,
            lots=_parse_lot_page(
                lot_response.text
            ),
            documents=_parse_documents_page(
                documents_response.text
            ),
        )
