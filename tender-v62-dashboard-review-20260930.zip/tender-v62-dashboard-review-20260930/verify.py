import ast
from pathlib import Path
from datetime import datetime, timezone
path=Path('app/reports/review_dashboard.py')
tree=ast.parse(path.read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='assemble')
ns={'datetime':datetime,'timezone':timezone}
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(path),'exec'),ns)
a=ns['assemble'];now=datetime(2026,9,30,tzinfo=timezone.utc)
def row(id,deadline=None,**kw):return dict(source='b2b_center',external_id=id,submission_deadline=deadline,**kw)
assert a([row('1',reason='DB')],[row('1',reason='candidate')],now)[0]['reason']=='DB'
assert a([row('1','2026-09-29T20:00:00Z')],[],now)==[]
assert a([row('1')],[],now)[0]['deadline_unknown']
assert not a([row('1','2026-10-01 00:00:00')],[],now)[0]['deadline_unknown']
assert a([row('1','bad')],[],now)[0]['deadline_unknown']
assert len(a([row('1')],[dict(row('1'),source='zakupki_gov_ru')],now))==2
assert a([row('1'),row('2','2026-10-01T00:00:00Z')],[],now)[0]['external_id']=='2'
from app.reports.review_dashboard import get_review_dashboard
from app.main import app
assert any(r.path=='/tenders/review' and 'GET' in r.methods for r in app.routes)
print('DASHBOARD_REVIEW_CHECKS_OK: imports, route, expiry, deduplication, unknown dates')
